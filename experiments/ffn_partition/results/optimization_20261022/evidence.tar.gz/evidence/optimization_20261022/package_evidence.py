from pathlib import Path
import os,json,time,hashlib,subprocess,shutil,tarfile
root=Path('/notebooks/HeteroMega-opt-20261022'); e=root/'evidence/optimization_20261022'
artifacts={}
for report in e.glob('*.json'):
 d=json.loads(report.read_text());
 if not isinstance(d,dict): continue
 metas=[x['npu'] for x in d.get('partitions',[]) if x.get('npu')]
 if 'npu_metadata' in d: metas.append(d['npu_metadata'])
 for meta in metas:
  for stage,a in meta['artifacts'].items():
   xcl=Path(a['xclbin']); inst=Path(a['insts']); hs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (xcl,inst)}; assert hs[str(xcl)]==a['manifest']['xclbin_sha256'] and hs[str(inst)]==a['manifest']['insts_sha256']; artifacts.update(hs)
   dest=e/'build_contracts'/xcl.parent.name; dest.mkdir(parents=True,exist_ok=True)
   for p in xcl.parent.glob('*.json'): shutil.copy2(p,dest/p.name)
(e/'binary_hashes.json').write_text(json.dumps(artifacts,indent=2))
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(e.rglob('*')) if p.is_file() and p.name not in ('archive_manifest.json','finalizer.log')}
(e/'archive_manifest.json').write_text(json.dumps({'files':files,'method':'SHA256 before archive; finalizer log excluded'},indent=2))
out=Path('/notebooks/heteromega-optimization-evidence-20261022.tar.gz')
with tarfile.open(out,'w:gz') as t:
 for p in sorted(e.rglob('*')):
  if p.is_file() and p.name!='finalizer.log': t.add(p,arcname=str(p.relative_to(root)))
print('ARCHIVE_READY',str(out),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
