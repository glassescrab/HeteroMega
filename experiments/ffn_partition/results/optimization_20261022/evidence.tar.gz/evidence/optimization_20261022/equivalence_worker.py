import sys,json,hashlib
from pathlib import Path
import numpy as np
from experiments.ffn_partition.contract import random_weights,split_weights,bf16
from experiments.ffn_partition.npu_backend import NPUBranch
label=sys.argv[1]; e=Path('/notebooks/HeteroMega-opt-20261022/evidence/optimization_20261022')
weights=split_weights(random_weights(4096,14336,12832),2048)['npu']
n=NPUBranch(weights.gate,weights.up,weights.down,512,Path('/notebooks/HeteroMega-bfp16-20261022/experiments/ffn_partition/artifacts'),8,npu_design='array8',fuse_gate_up=True,fuse_swiglu=True,npu_arithmetic='bfp16',copy_output_bits=label=='control')
rng=np.random.default_rng(12833); xs=[(bf16(rng.normal(size=(512,4096)).astype(np.float32)).view(np.uint32)>>16).astype(np.uint16) for _ in range(2)]; xs.append(np.zeros_like(xs[0])); outputs=[]
for i in (0,1,2,0):
 y=n.run(xs[i]); outputs.append({'input_index':i,'input_sha256':hashlib.sha256(xs[i].tobytes()).hexdigest(),'output_sha256':hashlib.sha256(y.tobytes()).hexdigest(),'nonzero_elements':int(np.count_nonzero((y.astype(np.uint32)<<16).view(np.float32))),'finite':bool(np.isfinite((y.astype(np.uint32)<<16).view(np.float32)).all())})
assert all(o['finite'] for o in outputs) and outputs[2]['nonzero_elements']==0 and outputs[0]['output_sha256']==outputs[3]['output_sha256'] and outputs[0]['output_sha256']!=outputs[1]['output_sha256']
counts={k:r.completed_dispatches for k,r in n.runners.items()}; assert all(c==4 for c in counts.values())
report={'variant':label,'shape':[512,4096,14336,2048],'seed':12832,'outputs':outputs,'completed_npu_dispatches_by_stage':counts,'source_sha256':hashlib.sha256(Path('npu/ffn/w4a16_prefill_bfp16.cc').read_bytes()).hexdigest(),'host_output_readback':n.metadata['host_output_readback']}
(e/('equivalence_'+label+'.json')).write_text(json.dumps(report,indent=2)); print(label,'COMPLETE',counts)
