from pathlib import Path
import subprocess,os,json,time
root=Path('/notebooks/HeteroMega-opt-20261022')
control=Path('/notebooks/HeteroMega-opt-control-20261022')
e=root/'evidence/optimization_20261022'
env=os.environ.copy(); env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PATH='/notebooks/heteromega-ffn-venv/bin:'+env['PATH'])
python='/notebooks/heteromega-ffn-venv/bin/python'
common=['--npu-arithmetic','bfp16','--fuse-swiglu','--columns','8','--warmup','3','--artifact-root','/notebooks/HeteroMega-bfp16-20261022/experiments/ffn_partition/artifacts','--iron-python','/home/mliraie/mlir-aie/ironenv/bin/python']
jobs=[('optimized_owned_confirm',root,'run',['--m','512','--npu-channels','2560','--iterations','50','--owned-npu-readback']),('optimized_borrowed_repeat',root,'run',['--m','512','--npu-channels','2560','--iterations','50']),('optimized_owned_timeline_2048',root,'profile_timeline',['--m','512','--npu-channels','2048','--iterations','15','--owned-npu-readback'])]
records=[]
for name,cwd,module,args in jobs:
 cmd=[python,'-m','experiments.ffn_partition.'+module,*common,*args,'--output',str(e/(name+'.json'))]
 rec={'name':name,'cwd':str(cwd),'command':cmd,'started':time.time()}; print('START',name,flush=True)
 with (e/(name+'.log')).open('w') as log: rec['returncode']=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 rec['finished']=time.time(); records.append(rec); (e/'readback_jobs.json').write_text(json.dumps(records,indent=2)); print('DONE',name,rec['returncode'],flush=True)
 if rec['returncode']: break
print('ALL_DONE',flush=True)
