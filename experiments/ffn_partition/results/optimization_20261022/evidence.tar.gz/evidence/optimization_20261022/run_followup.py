from pathlib import Path
import subprocess,os,json,time
root=Path('/notebooks/HeteroMega-opt-20261022'); control=Path('/notebooks/HeteroMega-opt-control-20261022'); e=root/'evidence/optimization_20261022'
while 'ALL_DONE' not in (e/'driver.log').read_text(): time.sleep(5)
assert all(x['returncode']==0 for x in json.loads((e/'jobs.json').read_text()))
env=os.environ.copy(); env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PATH='/notebooks/heteromega-ffn-venv/bin:'+env['PATH'])
python='/notebooks/heteromega-ffn-venv/bin/python'
common=['--m','512','--npu-arithmetic','bfp16','--fuse-swiglu','--columns','8','--warmup','3','--artifact-root','/notebooks/HeteroMega-bfp16-20261022/experiments/ffn_partition/artifacts','--iron-python','/home/mliraie/mlir-aie/ironenv/bin/python']
records=[]
def run(name,cwd,module,args):
 cmd=[python,'-m','experiments.ffn_partition.'+module,*common,*args,'--output',str(e/(name+'.json'))]; r={'name':name,'cwd':str(cwd),'command':cmd,'started':time.time()}; print('START',name,flush=True)
 with (e/(name+'.log')).open('w') as log: r['returncode']=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 r['finished']=time.time(); records.append(r); (e/'followup_jobs.json').write_text(json.dumps(records,indent=2)); print('DONE',name,r['returncode'],flush=True); assert r['returncode']==0
run('optimized_refine',root,'run',['--npu-channels','2304,2816','--iterations','30'])
entries=[x for name in ('optimized_sweep','optimized_refine') for x in json.loads((e/(name+'.json')).read_text())['partitions']]
best=min(entries,key=lambda x:x['stats']['concurrent']['median_us'])['npu_channels']; (e/'selected_partition.json').write_text(json.dumps({'npu_channels':best,'selection':'minimum ordinary concurrent median across sweep+refine; confirmation held out'})); print('SELECTED',best,flush=True)
run('optimized_confirm',root,'run',['--npu-channels',str(best),'--iterations','50'])
run('control_confirm',control,'run',['--npu-channels','1792','--iterations','50','--owned-npu-readback'])
run('optimized_timeline_best',root,'profile_timeline',['--npu-channels',str(best),'--iterations','15'])
print('ALL_DONE',flush=True)
