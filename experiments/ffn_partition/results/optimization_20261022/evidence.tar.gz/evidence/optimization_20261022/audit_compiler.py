from pathlib import Path
import hashlib,json,subprocess,re,shutil,tarfile
root=Path('/notebooks/HeteroMega-opt-20261022'); e=root/'evidence/optimization_20261022'
objdump='/home/mliraie/mlir-aie/ironenv/lib/python3.12/site-packages/llvm-aie/bin/llvm-objdump'
audit=[]; dest=e/'compiler_audit'; dest.mkdir(exist_ok=True)
for variant in ('control','optimized'):
 report=json.loads((e/(variant+'_sweep.json')).read_text()); entry=next(x for x in report['partitions'] if x['npu_channels']==2048)
 for role,stage,core in [('gate','swiglu','0_2'),('up','swiglu','1_2'),('down','down','0_2')]:
  a=entry['npu']['artifacts'][stage]; xcl=Path(a['xclbin']); assert hashlib.sha256(xcl.read_bytes()).hexdigest()==a['manifest']['xclbin_sha256']
  elf=next(xcl.parent.rglob('*core_'+core+'.elf')); dis=subprocess.check_output([objdump,'-d','--demangle',str(elf)],text=True); (dest/(variant+'_'+role+'.disasm')).write_text(dis); shutil.copy2(elf,dest/(variant+'_'+role+'.elf'))
  symbols=re.findall(r'^([0-9a-f]+) <__floatunsisf>:',dis,re.M); addresses={int(x,16) for x in symbols}; calls=[]
  for line in dis.splitlines():
   if 'jl' in line:
    fields=line.split('jl',1)[1].strip().split()
    if fields and fields[0].startswith('#0x') and int(fields[0].rstrip(';')[1:],16) in addresses: calls.append(line.strip())
  audit.append({'variant':variant,'role':role,'core':core,'elf':str(elf),'elf_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'xclbin_sha256':a['manifest']['xclbin_sha256'],'kernel_source_sha256':a['manifest']['source_sha256'],'floatunsisf_symbols':symbols,'floatunsisf_call_sites':len(calls),'call_examples':calls[:2]})
(dest/'audit.json').write_text(json.dumps({'method':'llvm-objdump; static call sites, no cycle attribution','records':audit},indent=2)); print(json.dumps(audit,indent=2))
