from pathlib import Path
import os,json,time,hashlib,subprocess,shutil,tarfile
root=Path('/notebooks/HeteroMega-opt-20261022'); control=Path('/notebooks/HeteroMega-opt-control-20261022'); e=root/'evidence/optimization_20261022'
while 'ALL_DONE' not in (e/'followup.log').read_text(): time.sleep(5)
assert all(x['returncode']==0 for x in json.loads((e/'followup_jobs.json').read_text()))
env=os.environ.copy(); env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PATH='/notebooks/heteromega-ffn-venv/bin:'+env['PATH'])
python='/notebooks/heteromega-ffn-venv/bin/python'
for label,cwd in [('control',control),('optimized',root)]:
 with (e/('equivalence_'+label+'.log')).open('w') as log:
  subprocess.run([python,'-c','from pathlib import Path; exec(Path('+repr(str(e/'equivalence_worker.py'))+').read_text())',label],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
a,b=[json.loads((e/('equivalence_'+x+'.json')).read_text()) for x in ('control','optimized')]; assert a['outputs']==b['outputs']; (e/'equivalence.json').write_text(json.dumps({'status':'passed','method':'SHA256 of complete BF16 output bytes, same weights and two random/zero/repeated inputs','shape':a['shape'],'bit_identical':True,'completed_npu_dispatches':16,'variants':[a,b]},indent=2))
with (e/'compiler_audit.log').open('w') as log: subprocess.run(['python',str(e/'audit_compiler.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
a=json.loads((e/'compiler_audit/audit.json').read_text()); assert all(r['floatunsisf_call_sites']==(32 if r['variant']=='control' else 0) for r in a['records'])
p=subprocess.run(['/opt/xilinx/xrt/bin/xrt-smi','examine','-d','0000:66:00.1','-r','platform'],capture_output=True,text=True); (e/'power_after.txt').write_text(p.stdout+p.stderr)
sources=e/'sources'; sources.mkdir(exist_ok=True)
with tarfile.open(sources/'optimized-runtime.tar.gz','w:gz') as t:
 for pattern in ('npu/ffn/*.py','npu/ffn/*.cc','npu/ffn/Makefile*','experiments/ffn_partition/*.py','experiments/ffn_partition/*.cpp'):
  for p in sorted(root.glob(pattern)): t.add(p,arcname=str(p.relative_to(root)))
 for name in ('src/hipkernels/w4a16_gemm_packed.cu','include/hipkernels/w4a16_gemm_packed.hpp'): t.add(root/name,arcname=name)
shutil.copy2(control/'npu/ffn/w4a16_prefill_bfp16.cc',sources/'control-w4a16_prefill_bfp16.cc')
artifacts={}
for report in e.glob('*.json'):
 d=json.loads(report.read_text());
 if not isinstance(d,dict): continue
 metas=[x['npu'] for x in d.get('partitions',[]) if x.get('npu')]
 if 'npu_metadata' in d: metas.append(d['npu_metadata'])
 for meta in metas:
  for stage,a in meta['artifacts'].items():
   xcl=Path(a['xclbin']); inst=Path(a['insts']); hs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (xcl,inst)}; assert hs[str(xcl)]==a['manifest']['xclbin_sha256'] and hs[str(inst)]==a['manifest']['insts_sha256']; artifacts.update(hs)
   dest=e/'build_contracts'/xcl.parent.name; dest.mkdir(parents=True,exist_ok=True)
   for p in xcl.parent.glob('*.json'): shutil.copy2(p,dest/p.name)
(e/'binary_hashes.json').write_text(json.dumps(artifacts,indent=2))
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(e.rglob('*')) if p.is_file() and p.name not in ('archive_manifest.json','finalizer.log')}
(e/'archive_manifest.json').write_text(json.dumps({'files':files,'method':'SHA256 before archive; finalizer log excluded'},indent=2))
out=Path('/notebooks/heteromega-optimization-evidence-20261022.tar.gz')
with tarfile.open(out,'w:gz') as t:
 for p in sorted(e.rglob('*')):
  if p.is_file() and p.name!='finalizer.log': t.add(p,arcname=str(p.relative_to(root)))
print('ARCHIVE_READY',str(out),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
