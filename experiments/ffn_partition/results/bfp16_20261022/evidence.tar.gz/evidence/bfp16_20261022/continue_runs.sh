#!/usr/bin/env bash
set -eu
cd /notebooks/HeteroMega-bfp16-20261022
export IRON_PYTHON=/home/mliraie/mlir-aie/ironenv/bin/python
export PATH=/notebooks/heteromega-ffn-venv/bin:$PATH
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python -m experiments.ffn_partition.run --m 512 --hidden 4096 --intermediate 14336 --npu-channels 2560,3072,4096 --npu-arithmetic bfp16 --fuse-swiglu --warmup 3 --iterations 30 --output evidence/bfp16_20261022/bfp16_wider.json > evidence/bfp16_20261022/bfp16_wider.log 2>&1
python -m experiments.ffn_partition.run --m 512 --hidden 4096 --intermediate 14336 --npu-channels 1152,2048 --npu-arithmetic bf16 --fuse-swiglu --warmup 3 --iterations 30 --output evidence/bfp16_20261022/bf16_control.json > evidence/bfp16_20261022/bf16_control.log 2>&1
python -m experiments.ffn_partition.profile_timeline --m 512 --hidden 4096 --intermediate 14336 --npu-channels 2048 --npu-arithmetic bfp16 --fuse-swiglu --warmup 3 --iterations 10 --output evidence/bfp16_20261022/bfp16_profile_p2048.json > evidence/bfp16_20261022/bfp16_profile_p2048.log 2>&1
python -m experiments.ffn_partition.profile_timeline --m 512 --hidden 4096 --intermediate 14336 --npu-channels 2048 --npu-arithmetic bf16 --fuse-swiglu --warmup 3 --iterations 10 --output evidence/bfp16_20261022/bf16_profile_p2048.json > evidence/bfp16_20261022/bf16_profile_p2048.log 2>&1
/opt/xilinx/xrt/bin/xrt-smi examine -d 0000:66:00.1 -r platform > evidence/bfp16_20261022/power_after.txt 2>&1
echo ALL_RUNS_COMPLETED
