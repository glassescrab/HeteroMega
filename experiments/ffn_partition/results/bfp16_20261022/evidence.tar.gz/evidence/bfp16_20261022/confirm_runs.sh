#!/usr/bin/env bash
set -eu
cd /notebooks/HeteroMega-bfp16-20261022
export IRON_PYTHON=/home/mliraie/mlir-aie/ironenv/bin/python
export PATH=/notebooks/heteromega-ffn-venv/bin:$PATH
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python -m experiments.ffn_partition.run --m 512 --hidden 4096 --intermediate 14336 --npu-channels 1536,1792 --npu-arithmetic bfp16 --fuse-swiglu --warmup 3 --iterations 50 --output evidence/bfp16_20261022/bfp16_confirm.json > evidence/bfp16_20261022/bfp16_confirm.log 2>&1
python -m experiments.ffn_partition.run --m 512 --hidden 4096 --intermediate 14336 --npu-channels 1152 --npu-arithmetic bf16 --fuse-swiglu --warmup 3 --iterations 50 --output evidence/bfp16_20261022/bf16_confirm.json > evidence/bfp16_20261022/bf16_confirm.log 2>&1
python -m experiments.ffn_partition.profile_timeline --m 512 --hidden 4096 --intermediate 14336 --npu-channels 1792 --npu-arithmetic bfp16 --fuse-swiglu --warmup 3 --iterations 15 --output evidence/bfp16_20261022/bfp16_profile_p1792.json > evidence/bfp16_20261022/bfp16_profile_p1792.log 2>&1
/opt/xilinx/xrt/bin/xrt-smi examine -d 0000:66:00.1 -r platform > evidence/bfp16_20261022/power_final.txt 2>&1
echo CONFIRM_RUNS_COMPLETED
