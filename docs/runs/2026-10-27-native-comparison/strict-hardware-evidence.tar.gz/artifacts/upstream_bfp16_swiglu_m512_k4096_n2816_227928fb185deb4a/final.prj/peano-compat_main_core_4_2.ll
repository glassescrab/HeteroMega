; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aie2p"

@direct_up_7_3 = external global [1024 x bfloat]
@direct_dequant_7_3 = external global [4096 x bfloat]
@direct_acc1_7_3 = external global [1024 x float]
@direct_acc0_7_3 = external global [1024 x float]
@direct_up_7_2 = external global [1024 x bfloat]
@direct_dequant_7_2 = external global [4096 x bfloat]
@direct_acc1_7_2 = external global [1024 x float]
@direct_acc0_7_2 = external global [1024 x float]
@direct_up_7_1 = external global [1024 x bfloat]
@direct_dequant_7_1 = external global [4096 x bfloat]
@direct_acc1_7_1 = external global [1024 x float]
@direct_acc0_7_1 = external global [1024 x float]
@direct_up_7_0 = external global [1024 x bfloat]
@direct_dequant_7_0 = external global [4096 x bfloat]
@direct_acc1_7_0 = external global [1024 x float]
@direct_acc0_7_0 = external global [1024 x float]
@direct_dequant_6_3 = external global [4096 x bfloat]
@direct_acc1_6_3 = external global [1024 x float]
@direct_acc0_6_3 = external global [1024 x float]
@direct_dequant_6_2 = external global [4096 x bfloat]
@direct_acc1_6_2 = external global [1024 x float]
@direct_acc0_6_2 = external global [1024 x float]
@direct_dequant_6_1 = external global [4096 x bfloat]
@direct_acc1_6_1 = external global [1024 x float]
@direct_acc0_6_1 = external global [1024 x float]
@direct_dequant_6_0 = external global [4096 x bfloat]
@direct_acc1_6_0 = external global [1024 x float]
@direct_acc0_6_0 = external global [1024 x float]
@direct_up_5_3 = external global [1024 x bfloat]
@direct_dequant_5_3 = external global [4096 x bfloat]
@direct_acc1_5_3 = external global [1024 x float]
@direct_acc0_5_3 = external global [1024 x float]
@direct_up_5_2 = external global [1024 x bfloat]
@direct_dequant_5_2 = external global [4096 x bfloat]
@direct_acc1_5_2 = external global [1024 x float]
@direct_acc0_5_2 = external global [1024 x float]
@direct_up_5_1 = external global [1024 x bfloat]
@direct_dequant_5_1 = external global [4096 x bfloat]
@direct_acc1_5_1 = external global [1024 x float]
@direct_acc0_5_1 = external global [1024 x float]
@direct_up_5_0 = external global [1024 x bfloat]
@direct_dequant_5_0 = external global [4096 x bfloat]
@direct_acc1_5_0 = external global [1024 x float]
@direct_acc0_5_0 = external global [1024 x float]
@direct_dequant_4_3 = external global [4096 x bfloat]
@direct_acc1_4_3 = external global [1024 x float]
@direct_acc0_4_3 = external global [1024 x float]
@direct_dequant_4_2 = external global [4096 x bfloat]
@direct_acc1_4_2 = external global [1024 x float]
@direct_acc0_4_2 = external global [1024 x float]
@direct_dequant_4_1 = external global [4096 x bfloat]
@direct_acc1_4_1 = external global [1024 x float]
@direct_acc0_4_1 = external global [1024 x float]
@direct_dequant_4_0 = external global [4096 x bfloat]
@direct_acc1_4_0 = external global [1024 x float]
@direct_acc0_4_0 = external global [1024 x float]
@direct_up_3_3 = external global [1024 x bfloat]
@direct_dequant_3_3 = external global [4096 x bfloat]
@direct_acc1_3_3 = external global [1024 x float]
@direct_acc0_3_3 = external global [1024 x float]
@direct_up_3_2 = external global [1024 x bfloat]
@direct_dequant_3_2 = external global [4096 x bfloat]
@direct_acc1_3_2 = external global [1024 x float]
@direct_acc0_3_2 = external global [1024 x float]
@direct_up_3_1 = external global [1024 x bfloat]
@direct_dequant_3_1 = external global [4096 x bfloat]
@direct_acc1_3_1 = external global [1024 x float]
@direct_acc0_3_1 = external global [1024 x float]
@direct_up_3_0 = external global [1024 x bfloat]
@direct_dequant_3_0 = external global [4096 x bfloat]
@direct_acc1_3_0 = external global [1024 x float]
@direct_acc0_3_0 = external global [1024 x float]
@direct_dequant_2_3 = external global [4096 x bfloat]
@direct_acc1_2_3 = external global [1024 x float]
@direct_acc0_2_3 = external global [1024 x float]
@direct_dequant_2_2 = external global [4096 x bfloat]
@direct_acc1_2_2 = external global [1024 x float]
@direct_acc0_2_2 = external global [1024 x float]
@direct_dequant_2_1 = external global [4096 x bfloat]
@direct_acc1_2_1 = external global [1024 x float]
@direct_acc0_2_1 = external global [1024 x float]
@direct_dequant_2_0 = external global [4096 x bfloat]
@direct_acc1_2_0 = external global [1024 x float]
@direct_acc0_2_0 = external global [1024 x float]
@direct_up_1_3 = external global [1024 x bfloat]
@direct_dequant_1_3 = external global [4096 x bfloat]
@direct_acc1_1_3 = external global [1024 x float]
@direct_acc0_1_3 = external global [1024 x float]
@direct_up_1_2 = external global [1024 x bfloat]
@direct_dequant_1_2 = external global [4096 x bfloat]
@direct_acc1_1_2 = external global [1024 x float]
@direct_acc0_1_2 = external global [1024 x float]
@direct_up_1_1 = external global [1024 x bfloat]
@direct_dequant_1_1 = external global [4096 x bfloat]
@direct_acc1_1_1 = external global [1024 x float]
@direct_acc0_1_1 = external global [1024 x float]
@direct_up_1_0 = external global [1024 x bfloat]
@direct_dequant_1_0 = external global [4096 x bfloat]
@direct_acc1_1_0 = external global [1024 x float]
@direct_acc0_1_0 = external global [1024 x float]
@direct_dequant_0_3 = external global [4096 x bfloat]
@direct_acc1_0_3 = external global [1024 x float]
@direct_acc0_0_3 = external global [1024 x float]
@direct_dequant_0_2 = external global [4096 x bfloat]
@direct_acc1_0_2 = external global [1024 x float]
@direct_acc0_0_2 = external global [1024 x float]
@direct_dequant_0_1 = external global [4096 x bfloat]
@direct_acc1_0_1 = external global [1024 x float]
@direct_acc0_0_1 = external global [1024 x float]
@direct_dequant_0_0 = external global [4096 x bfloat]
@direct_acc1_0_0 = external global [1024 x float]
@direct_acc0_0_0 = external global [1024 x float]
@direct_a_broadcast_0_7_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_7_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_6_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_6_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_5_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_5_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_4_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_4_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_3_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_3_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_2_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_1_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_0_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_host_0_cons_buff_1 = external global [4096 x bfloat]
@direct_a_host_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_7_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_1_7_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_6_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_1_6_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_5_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_1_5_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_4_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_1_4_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_3_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_1_3_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_2_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_1_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_1_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_1_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_0_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_1_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_host_1_cons_buff_1 = external global [4096 x bfloat]
@direct_a_host_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_7_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_2_7_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_6_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_2_6_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_5_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_2_5_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_4_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_2_4_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_3_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_2_3_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_2_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_2_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_1_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_2_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_0_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_2_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_host_2_cons_buff_1 = external global [4096 x bfloat]
@direct_a_host_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_7_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_3_7_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_6_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_3_6_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_5_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_3_5_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_4_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_3_4_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_3_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_3_3_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_2_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_3_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_1_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_3_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_0_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_3_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_host_3_cons_buff_1 = external global [4096 x bfloat]
@direct_a_host_3_cons_buff_0 = external global [4096 x bfloat]
@direct_gate_0_0_buff_1 = external global [1024 x bfloat]
@direct_gate_0_0_buff_0 = external global [1024 x bfloat]
@direct_gate_0_1_buff_1 = external global [1024 x bfloat]
@direct_gate_0_1_buff_0 = external global [1024 x bfloat]
@direct_gate_0_2_buff_1 = external global [1024 x bfloat]
@direct_gate_0_2_buff_0 = external global [1024 x bfloat]
@direct_gate_0_3_buff_1 = external global [1024 x bfloat]
@direct_gate_0_3_buff_0 = external global [1024 x bfloat]
@direct_gate_2_0_buff_1 = external global [1024 x bfloat]
@direct_gate_2_0_buff_0 = external global [1024 x bfloat]
@direct_gate_2_1_buff_1 = external global [1024 x bfloat]
@direct_gate_2_1_buff_0 = external global [1024 x bfloat]
@direct_gate_2_2_buff_1 = external global [1024 x bfloat]
@direct_gate_2_2_buff_0 = external global [1024 x bfloat]
@direct_gate_2_3_buff_1 = external global [1024 x bfloat]
@direct_gate_2_3_buff_0 = external global [1024 x bfloat]
@direct_gate_4_0_buff_1 = external global [1024 x bfloat]
@direct_gate_4_0_buff_0 = external global [1024 x bfloat]
@direct_gate_4_1_buff_1 = external global [1024 x bfloat]
@direct_gate_4_1_buff_0 = external global [1024 x bfloat]
@direct_gate_4_2_buff_1 = external global [1024 x bfloat]
@direct_gate_4_2_buff_0 = external global [1024 x bfloat]
@direct_gate_4_3_buff_1 = external global [1024 x bfloat]
@direct_gate_4_3_buff_0 = external global [1024 x bfloat]
@direct_gate_6_0_buff_1 = external global [1024 x bfloat]
@direct_gate_6_0_buff_0 = external global [1024 x bfloat]
@direct_gate_6_1_buff_1 = external global [1024 x bfloat]
@direct_gate_6_1_buff_0 = external global [1024 x bfloat]
@direct_gate_6_2_buff_1 = external global [1024 x bfloat]
@direct_gate_6_2_buff_0 = external global [1024 x bfloat]
@direct_gate_6_3_buff_1 = external global [1024 x bfloat]
@direct_gate_6_3_buff_0 = external global [1024 x bfloat]
@direct_y_host_1_buff_1 = external global [4096 x bfloat]
@direct_y_host_1_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_0_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_3_buff_1 = external global [4096 x bfloat]
@direct_y_host_3_buff_0 = external global [4096 x bfloat]
@direct_y_host_5_buff_1 = external global [4096 x bfloat]
@direct_y_host_5_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_1_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_7_buff_1 = external global [4096 x bfloat]
@direct_y_host_7_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_2_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_0_cons_buff_1 = external global [4352 x i8]
@direct_w_host_0_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_1_cons_buff_1 = external global [4352 x i8]
@direct_w_host_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_2_cons_buff_1 = external global [4352 x i8]
@direct_w_host_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_3_cons_buff_1 = external global [4352 x i8]
@direct_w_host_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_4_cons_buff_1 = external global [4352 x i8]
@direct_w_host_4_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_5_cons_buff_1 = external global [4352 x i8]
@direct_w_host_5_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_1_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_1_0_buff_0 = external global [1024 x bfloat]
@direct_w_host_6_cons_buff_1 = external global [4352 x i8]
@direct_w_host_6_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_1_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_1_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_1_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_1_2_buff_0 = external global [1024 x bfloat]
@direct_w_host_7_cons_buff_1 = external global [4352 x i8]
@direct_w_host_7_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_1_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_1_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_3_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_3_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_3_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_3_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_3_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_3_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_3_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_3_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_5_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_5_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_5_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_5_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_7_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_7_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_7_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_7_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_7_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_7_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_7_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_7_3_buff_0 = external global [1024 x bfloat]

declare void @debug_i32(i32)

; Unknown intrinsic
declare void @llvm.aie2p.event(i32)

; Unknown intrinsic
declare void @llvm.aie2p.put.ms(i32, i32)

; Unknown intrinsic
declare { i32, i32 } @llvm.aie2p.get.ss()

; Unknown intrinsic
declare void @llvm.aie2p.mcd.write.vec(<16 x i32>, i32)

; Unknown intrinsic
declare <16 x i32> @llvm.aie2p.scd.read.vec(i32)

; Unknown intrinsic
declare void @llvm.aie2p.acquire(i32, i32)

; Unknown intrinsic
declare void @llvm.aie2p.release(i32, i32)

; Unknown intrinsic
declare void @llvm.aie2p.set.ctrl.reg(i32, i32)

declare void @w4a16_prefill_reuse_init(ptr)

declare void @w4a16_prefill_reuse_accumulate_low(ptr, ptr, ptr, ptr)

declare void @w4a16_prefill_reuse_accumulate_high(ptr, ptr, ptr, ptr)

declare void @w4a16_prefill_reuse_finish(ptr, ptr)

declare void @silu_mul_bf16(ptr, ptr, ptr)

define void @core_4_2() {
  br label %1

1:                                                ; preds = %277, %0
  %2 = phi i64 [ %278, %277 ], [ 0, %0 ]
  %3 = phi i32 [ %8, %277 ], [ 0, %0 ]
  %4 = phi i32 [ %9, %277 ], [ 0, %0 ]
  %5 = icmp slt i64 %2, 9223372036854775807
  br i1 %5, label %6, label %279

6:                                                ; preds = %275, %1
  %7 = phi i64 [ %276, %275 ], [ 0, %1 ]
  %8 = phi i32 [ %254, %275 ], [ %3, %1 ]
  %9 = phi i32 [ %255, %275 ], [ %4, %1 ]
  %10 = icmp slt i64 %7, 4
  br i1 %10, label %11, label %277

11:                                               ; preds = %6
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %12

12:                                               ; preds = %27, %11
  %13 = phi i64 [ %34, %27 ], [ 0, %11 ]
  %14 = phi i32 [ %30, %27 ], [ %8, %11 ]
  %15 = phi i32 [ %33, %27 ], [ %9, %11 ]
  %16 = icmp slt i64 %13, 32
  br i1 %16, label %17, label %35

17:                                               ; preds = %12
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %18 = sext i32 %14 to i64
  switch i64 %18, label %19 [
    i64 0, label %280
    i64 1, label %282
  ]

19:                                               ; preds = %280, %282, %17
  %20 = phi ptr [ %283, %282 ], [ %281, %280 ], [ @direct_a_broadcast_0_4_cons_buff_0, %17 ]
  %21 = getelementptr [4096 x bfloat], ptr %20, i32 0, i32 0
  br label %22

22:                                               ; preds = %19
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %23 = sext i32 %15 to i64
  switch i64 %23, label %24 [
    i64 0, label %284
    i64 1, label %286
  ]

24:                                               ; preds = %284, %286, %22
  %25 = phi ptr [ %287, %286 ], [ %285, %284 ], [ @direct_w_broadcast_4_0_cons_buff_0, %22 ]
  %26 = getelementptr [4352 x i8], ptr %25, i32 0, i32 0
  br label %27

27:                                               ; preds = %24
  call void @w4a16_prefill_reuse_accumulate_low(ptr %21, ptr %26, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %21, ptr %26, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %28 = add i32 %14, 1
  %29 = icmp sge i32 %28, 2
  %30 = select i1 %29, i32 0, i32 %28
  call void @llvm.aie2p.release(i32 48, i32 1)
  %31 = add i32 %15, 1
  %32 = icmp sge i32 %31, 2
  %33 = select i1 %32, i32 0, i32 %31
  %34 = add i64 %13, 1
  br label %12

35:                                               ; preds = %12
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %36

36:                                               ; preds = %51, %35
  %37 = phi i64 [ %58, %51 ], [ 0, %35 ]
  %38 = phi i32 [ %54, %51 ], [ %14, %35 ]
  %39 = phi i32 [ %57, %51 ], [ %15, %35 ]
  %40 = icmp slt i64 %37, 32
  br i1 %40, label %41, label %59

41:                                               ; preds = %36
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %42 = sext i32 %38 to i64
  switch i64 %42, label %43 [
    i64 0, label %288
    i64 1, label %290
  ]

43:                                               ; preds = %288, %290, %41
  %44 = phi ptr [ %291, %290 ], [ %289, %288 ], [ @direct_a_broadcast_0_4_cons_buff_0, %41 ]
  %45 = getelementptr [4096 x bfloat], ptr %44, i32 0, i32 0
  br label %46

46:                                               ; preds = %43
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %47 = sext i32 %39 to i64
  switch i64 %47, label %48 [
    i64 0, label %292
    i64 1, label %294
  ]

48:                                               ; preds = %292, %294, %46
  %49 = phi ptr [ %295, %294 ], [ %293, %292 ], [ @direct_w_broadcast_4_0_cons_buff_0, %46 ]
  %50 = getelementptr [4352 x i8], ptr %49, i32 0, i32 0
  br label %51

51:                                               ; preds = %48
  call void @w4a16_prefill_reuse_accumulate_low(ptr %45, ptr %50, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %45, ptr %50, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %52 = add i32 %38, 1
  %53 = icmp sge i32 %52, 2
  %54 = select i1 %53, i32 0, i32 %52
  call void @llvm.aie2p.release(i32 48, i32 1)
  %55 = add i32 %39, 1
  %56 = icmp sge i32 %55, 2
  %57 = select i1 %56, i32 0, i32 %55
  %58 = add i64 %37, 1
  br label %36

59:                                               ; preds = %36
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %60

60:                                               ; preds = %75, %59
  %61 = phi i64 [ %82, %75 ], [ 0, %59 ]
  %62 = phi i32 [ %78, %75 ], [ %38, %59 ]
  %63 = phi i32 [ %81, %75 ], [ %39, %59 ]
  %64 = icmp slt i64 %61, 32
  br i1 %64, label %65, label %83

65:                                               ; preds = %60
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %66 = sext i32 %62 to i64
  switch i64 %66, label %67 [
    i64 0, label %296
    i64 1, label %298
  ]

67:                                               ; preds = %296, %298, %65
  %68 = phi ptr [ %299, %298 ], [ %297, %296 ], [ @direct_a_broadcast_0_4_cons_buff_0, %65 ]
  %69 = getelementptr [4096 x bfloat], ptr %68, i32 0, i32 0
  br label %70

70:                                               ; preds = %67
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %71 = sext i32 %63 to i64
  switch i64 %71, label %72 [
    i64 0, label %300
    i64 1, label %302
  ]

72:                                               ; preds = %300, %302, %70
  %73 = phi ptr [ %303, %302 ], [ %301, %300 ], [ @direct_w_broadcast_4_0_cons_buff_0, %70 ]
  %74 = getelementptr [4352 x i8], ptr %73, i32 0, i32 0
  br label %75

75:                                               ; preds = %72
  call void @w4a16_prefill_reuse_accumulate_low(ptr %69, ptr %74, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %69, ptr %74, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %76 = add i32 %62, 1
  %77 = icmp sge i32 %76, 2
  %78 = select i1 %77, i32 0, i32 %76
  call void @llvm.aie2p.release(i32 48, i32 1)
  %79 = add i32 %63, 1
  %80 = icmp sge i32 %79, 2
  %81 = select i1 %80, i32 0, i32 %79
  %82 = add i64 %61, 1
  br label %60

83:                                               ; preds = %60
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %84

84:                                               ; preds = %99, %83
  %85 = phi i64 [ %106, %99 ], [ 0, %83 ]
  %86 = phi i32 [ %102, %99 ], [ %62, %83 ]
  %87 = phi i32 [ %105, %99 ], [ %63, %83 ]
  %88 = icmp slt i64 %85, 32
  br i1 %88, label %89, label %107

89:                                               ; preds = %84
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %90 = sext i32 %86 to i64
  switch i64 %90, label %91 [
    i64 0, label %304
    i64 1, label %306
  ]

91:                                               ; preds = %304, %306, %89
  %92 = phi ptr [ %307, %306 ], [ %305, %304 ], [ @direct_a_broadcast_0_4_cons_buff_0, %89 ]
  %93 = getelementptr [4096 x bfloat], ptr %92, i32 0, i32 0
  br label %94

94:                                               ; preds = %91
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %95 = sext i32 %87 to i64
  switch i64 %95, label %96 [
    i64 0, label %308
    i64 1, label %310
  ]

96:                                               ; preds = %308, %310, %94
  %97 = phi ptr [ %311, %310 ], [ %309, %308 ], [ @direct_w_broadcast_4_0_cons_buff_0, %94 ]
  %98 = getelementptr [4352 x i8], ptr %97, i32 0, i32 0
  br label %99

99:                                               ; preds = %96
  call void @w4a16_prefill_reuse_accumulate_low(ptr %93, ptr %98, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %93, ptr %98, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %100 = add i32 %86, 1
  %101 = icmp sge i32 %100, 2
  %102 = select i1 %101, i32 0, i32 %100
  call void @llvm.aie2p.release(i32 48, i32 1)
  %103 = add i32 %87, 1
  %104 = icmp sge i32 %103, 2
  %105 = select i1 %104, i32 0, i32 %103
  %106 = add i64 %85, 1
  br label %84

107:                                              ; preds = %84
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %108

108:                                              ; preds = %123, %107
  %109 = phi i64 [ %130, %123 ], [ 0, %107 ]
  %110 = phi i32 [ %126, %123 ], [ %86, %107 ]
  %111 = phi i32 [ %129, %123 ], [ %87, %107 ]
  %112 = icmp slt i64 %109, 32
  br i1 %112, label %113, label %131

113:                                              ; preds = %108
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %114 = sext i32 %110 to i64
  switch i64 %114, label %115 [
    i64 0, label %312
    i64 1, label %314
  ]

115:                                              ; preds = %312, %314, %113
  %116 = phi ptr [ %315, %314 ], [ %313, %312 ], [ @direct_a_broadcast_0_4_cons_buff_0, %113 ]
  %117 = getelementptr [4096 x bfloat], ptr %116, i32 0, i32 0
  br label %118

118:                                              ; preds = %115
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %119 = sext i32 %111 to i64
  switch i64 %119, label %120 [
    i64 0, label %316
    i64 1, label %318
  ]

120:                                              ; preds = %316, %318, %118
  %121 = phi ptr [ %319, %318 ], [ %317, %316 ], [ @direct_w_broadcast_4_0_cons_buff_0, %118 ]
  %122 = getelementptr [4352 x i8], ptr %121, i32 0, i32 0
  br label %123

123:                                              ; preds = %120
  call void @w4a16_prefill_reuse_accumulate_low(ptr %117, ptr %122, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %117, ptr %122, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %124 = add i32 %110, 1
  %125 = icmp sge i32 %124, 2
  %126 = select i1 %125, i32 0, i32 %124
  call void @llvm.aie2p.release(i32 48, i32 1)
  %127 = add i32 %111, 1
  %128 = icmp sge i32 %127, 2
  %129 = select i1 %128, i32 0, i32 %127
  %130 = add i64 %109, 1
  br label %108

131:                                              ; preds = %108
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %132

132:                                              ; preds = %147, %131
  %133 = phi i64 [ %154, %147 ], [ 0, %131 ]
  %134 = phi i32 [ %150, %147 ], [ %110, %131 ]
  %135 = phi i32 [ %153, %147 ], [ %111, %131 ]
  %136 = icmp slt i64 %133, 32
  br i1 %136, label %137, label %155

137:                                              ; preds = %132
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %138 = sext i32 %134 to i64
  switch i64 %138, label %139 [
    i64 0, label %320
    i64 1, label %322
  ]

139:                                              ; preds = %320, %322, %137
  %140 = phi ptr [ %323, %322 ], [ %321, %320 ], [ @direct_a_broadcast_0_4_cons_buff_0, %137 ]
  %141 = getelementptr [4096 x bfloat], ptr %140, i32 0, i32 0
  br label %142

142:                                              ; preds = %139
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %143 = sext i32 %135 to i64
  switch i64 %143, label %144 [
    i64 0, label %324
    i64 1, label %326
  ]

144:                                              ; preds = %324, %326, %142
  %145 = phi ptr [ %327, %326 ], [ %325, %324 ], [ @direct_w_broadcast_4_0_cons_buff_0, %142 ]
  %146 = getelementptr [4352 x i8], ptr %145, i32 0, i32 0
  br label %147

147:                                              ; preds = %144
  call void @w4a16_prefill_reuse_accumulate_low(ptr %141, ptr %146, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %141, ptr %146, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %148 = add i32 %134, 1
  %149 = icmp sge i32 %148, 2
  %150 = select i1 %149, i32 0, i32 %148
  call void @llvm.aie2p.release(i32 48, i32 1)
  %151 = add i32 %135, 1
  %152 = icmp sge i32 %151, 2
  %153 = select i1 %152, i32 0, i32 %151
  %154 = add i64 %133, 1
  br label %132

155:                                              ; preds = %132
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %156

156:                                              ; preds = %171, %155
  %157 = phi i64 [ %178, %171 ], [ 0, %155 ]
  %158 = phi i32 [ %174, %171 ], [ %134, %155 ]
  %159 = phi i32 [ %177, %171 ], [ %135, %155 ]
  %160 = icmp slt i64 %157, 32
  br i1 %160, label %161, label %179

161:                                              ; preds = %156
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %162 = sext i32 %158 to i64
  switch i64 %162, label %163 [
    i64 0, label %328
    i64 1, label %330
  ]

163:                                              ; preds = %328, %330, %161
  %164 = phi ptr [ %331, %330 ], [ %329, %328 ], [ @direct_a_broadcast_0_4_cons_buff_0, %161 ]
  %165 = getelementptr [4096 x bfloat], ptr %164, i32 0, i32 0
  br label %166

166:                                              ; preds = %163
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %167 = sext i32 %159 to i64
  switch i64 %167, label %168 [
    i64 0, label %332
    i64 1, label %334
  ]

168:                                              ; preds = %332, %334, %166
  %169 = phi ptr [ %335, %334 ], [ %333, %332 ], [ @direct_w_broadcast_4_0_cons_buff_0, %166 ]
  %170 = getelementptr [4352 x i8], ptr %169, i32 0, i32 0
  br label %171

171:                                              ; preds = %168
  call void @w4a16_prefill_reuse_accumulate_low(ptr %165, ptr %170, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %165, ptr %170, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %172 = add i32 %158, 1
  %173 = icmp sge i32 %172, 2
  %174 = select i1 %173, i32 0, i32 %172
  call void @llvm.aie2p.release(i32 48, i32 1)
  %175 = add i32 %159, 1
  %176 = icmp sge i32 %175, 2
  %177 = select i1 %176, i32 0, i32 %175
  %178 = add i64 %157, 1
  br label %156

179:                                              ; preds = %156
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %180

180:                                              ; preds = %195, %179
  %181 = phi i64 [ %202, %195 ], [ 0, %179 ]
  %182 = phi i32 [ %198, %195 ], [ %158, %179 ]
  %183 = phi i32 [ %201, %195 ], [ %159, %179 ]
  %184 = icmp slt i64 %181, 32
  br i1 %184, label %185, label %203

185:                                              ; preds = %180
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %186 = sext i32 %182 to i64
  switch i64 %186, label %187 [
    i64 0, label %336
    i64 1, label %338
  ]

187:                                              ; preds = %336, %338, %185
  %188 = phi ptr [ %339, %338 ], [ %337, %336 ], [ @direct_a_broadcast_0_4_cons_buff_0, %185 ]
  %189 = getelementptr [4096 x bfloat], ptr %188, i32 0, i32 0
  br label %190

190:                                              ; preds = %187
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %191 = sext i32 %183 to i64
  switch i64 %191, label %192 [
    i64 0, label %340
    i64 1, label %342
  ]

192:                                              ; preds = %340, %342, %190
  %193 = phi ptr [ %343, %342 ], [ %341, %340 ], [ @direct_w_broadcast_4_0_cons_buff_0, %190 ]
  %194 = getelementptr [4352 x i8], ptr %193, i32 0, i32 0
  br label %195

195:                                              ; preds = %192
  call void @w4a16_prefill_reuse_accumulate_low(ptr %189, ptr %194, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %189, ptr %194, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %196 = add i32 %182, 1
  %197 = icmp sge i32 %196, 2
  %198 = select i1 %197, i32 0, i32 %196
  call void @llvm.aie2p.release(i32 48, i32 1)
  %199 = add i32 %183, 1
  %200 = icmp sge i32 %199, 2
  %201 = select i1 %200, i32 0, i32 %199
  %202 = add i64 %181, 1
  br label %180

203:                                              ; preds = %180
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %204

204:                                              ; preds = %219, %203
  %205 = phi i64 [ %226, %219 ], [ 0, %203 ]
  %206 = phi i32 [ %222, %219 ], [ %182, %203 ]
  %207 = phi i32 [ %225, %219 ], [ %183, %203 ]
  %208 = icmp slt i64 %205, 32
  br i1 %208, label %209, label %227

209:                                              ; preds = %204
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %210 = sext i32 %206 to i64
  switch i64 %210, label %211 [
    i64 0, label %344
    i64 1, label %346
  ]

211:                                              ; preds = %344, %346, %209
  %212 = phi ptr [ %347, %346 ], [ %345, %344 ], [ @direct_a_broadcast_0_4_cons_buff_0, %209 ]
  %213 = getelementptr [4096 x bfloat], ptr %212, i32 0, i32 0
  br label %214

214:                                              ; preds = %211
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %215 = sext i32 %207 to i64
  switch i64 %215, label %216 [
    i64 0, label %348
    i64 1, label %350
  ]

216:                                              ; preds = %348, %350, %214
  %217 = phi ptr [ %351, %350 ], [ %349, %348 ], [ @direct_w_broadcast_4_0_cons_buff_0, %214 ]
  %218 = getelementptr [4352 x i8], ptr %217, i32 0, i32 0
  br label %219

219:                                              ; preds = %216
  call void @w4a16_prefill_reuse_accumulate_low(ptr %213, ptr %218, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %213, ptr %218, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %220 = add i32 %206, 1
  %221 = icmp sge i32 %220, 2
  %222 = select i1 %221, i32 0, i32 %220
  call void @llvm.aie2p.release(i32 48, i32 1)
  %223 = add i32 %207, 1
  %224 = icmp sge i32 %223, 2
  %225 = select i1 %224, i32 0, i32 %223
  %226 = add i64 %205, 1
  br label %204

227:                                              ; preds = %204
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %228

228:                                              ; preds = %243, %227
  %229 = phi i64 [ %250, %243 ], [ 0, %227 ]
  %230 = phi i32 [ %246, %243 ], [ %206, %227 ]
  %231 = phi i32 [ %249, %243 ], [ %207, %227 ]
  %232 = icmp slt i64 %229, 32
  br i1 %232, label %233, label %251

233:                                              ; preds = %228
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %234 = sext i32 %230 to i64
  switch i64 %234, label %235 [
    i64 0, label %352
    i64 1, label %354
  ]

235:                                              ; preds = %352, %354, %233
  %236 = phi ptr [ %355, %354 ], [ %353, %352 ], [ @direct_a_broadcast_0_4_cons_buff_0, %233 ]
  %237 = getelementptr [4096 x bfloat], ptr %236, i32 0, i32 0
  br label %238

238:                                              ; preds = %235
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %239 = sext i32 %231 to i64
  switch i64 %239, label %240 [
    i64 0, label %356
    i64 1, label %358
  ]

240:                                              ; preds = %356, %358, %238
  %241 = phi ptr [ %359, %358 ], [ %357, %356 ], [ @direct_w_broadcast_4_0_cons_buff_0, %238 ]
  %242 = getelementptr [4352 x i8], ptr %241, i32 0, i32 0
  br label %243

243:                                              ; preds = %240
  call void @w4a16_prefill_reuse_accumulate_low(ptr %237, ptr %242, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %237, ptr %242, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %244 = add i32 %230, 1
  %245 = icmp sge i32 %244, 2
  %246 = select i1 %245, i32 0, i32 %244
  call void @llvm.aie2p.release(i32 48, i32 1)
  %247 = add i32 %231, 1
  %248 = icmp sge i32 %247, 2
  %249 = select i1 %248, i32 0, i32 %247
  %250 = add i64 %229, 1
  br label %228

251:                                              ; preds = %228
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_4_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_4_0)
  br label %252

252:                                              ; preds = %267, %251
  %253 = phi i64 [ %274, %267 ], [ 0, %251 ]
  %254 = phi i32 [ %270, %267 ], [ %230, %251 ]
  %255 = phi i32 [ %273, %267 ], [ %231, %251 ]
  %256 = icmp slt i64 %253, 32
  br i1 %256, label %257, label %275

257:                                              ; preds = %252
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %258 = sext i32 %254 to i64
  switch i64 %258, label %259 [
    i64 0, label %360
    i64 1, label %362
  ]

259:                                              ; preds = %360, %362, %257
  %260 = phi ptr [ %363, %362 ], [ %361, %360 ], [ @direct_a_broadcast_0_4_cons_buff_0, %257 ]
  %261 = getelementptr [4096 x bfloat], ptr %260, i32 0, i32 0
  br label %262

262:                                              ; preds = %259
  call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %263 = sext i32 %255 to i64
  switch i64 %263, label %264 [
    i64 0, label %364
    i64 1, label %366
  ]

264:                                              ; preds = %364, %366, %262
  %265 = phi ptr [ %367, %366 ], [ %365, %364 ], [ @direct_w_broadcast_4_0_cons_buff_0, %262 ]
  %266 = getelementptr [4352 x i8], ptr %265, i32 0, i32 0
  br label %267

267:                                              ; preds = %264
  call void @w4a16_prefill_reuse_accumulate_low(ptr %261, ptr %266, ptr @direct_acc0_4_0, ptr @direct_dequant_4_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr %261, ptr %266, ptr @direct_acc1_4_0, ptr @direct_dequant_4_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  %268 = add i32 %254, 1
  %269 = icmp sge i32 %268, 2
  %270 = select i1 %269, i32 0, i32 %268
  call void @llvm.aie2p.release(i32 48, i32 1)
  %271 = add i32 %255, 1
  %272 = icmp sge i32 %271, 2
  %273 = select i1 %272, i32 0, i32 %271
  %274 = add i64 %253, 1
  br label %252

275:                                              ; preds = %252
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_4_0, ptr @direct_gate_4_0_buff_0)
  call void @llvm.aie2p.release(i32 51, i32 1)
  call void @llvm.aie2p.acquire(i32 50, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_4_0, ptr @direct_gate_4_0_buff_1)
  call void @llvm.aie2p.release(i32 51, i32 1)
  %276 = add i64 %7, 1
  br label %6

277:                                              ; preds = %6
  %278 = add i64 %2, 1
  br label %1

279:                                              ; preds = %1
  ret void

280:                                              ; preds = %17
  %281 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %17 ]
  br label %19

282:                                              ; preds = %17
  %283 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %17 ]
  br label %19

284:                                              ; preds = %22
  %285 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %22 ]
  br label %24

286:                                              ; preds = %22
  %287 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %22 ]
  br label %24

288:                                              ; preds = %41
  %289 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %41 ]
  br label %43

290:                                              ; preds = %41
  %291 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %41 ]
  br label %43

292:                                              ; preds = %46
  %293 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %46 ]
  br label %48

294:                                              ; preds = %46
  %295 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %46 ]
  br label %48

296:                                              ; preds = %65
  %297 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %65 ]
  br label %67

298:                                              ; preds = %65
  %299 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %65 ]
  br label %67

300:                                              ; preds = %70
  %301 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %70 ]
  br label %72

302:                                              ; preds = %70
  %303 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %70 ]
  br label %72

304:                                              ; preds = %89
  %305 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %89 ]
  br label %91

306:                                              ; preds = %89
  %307 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %89 ]
  br label %91

308:                                              ; preds = %94
  %309 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %94 ]
  br label %96

310:                                              ; preds = %94
  %311 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %94 ]
  br label %96

312:                                              ; preds = %113
  %313 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %113 ]
  br label %115

314:                                              ; preds = %113
  %315 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %113 ]
  br label %115

316:                                              ; preds = %118
  %317 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %118 ]
  br label %120

318:                                              ; preds = %118
  %319 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %118 ]
  br label %120

320:                                              ; preds = %137
  %321 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %137 ]
  br label %139

322:                                              ; preds = %137
  %323 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %137 ]
  br label %139

324:                                              ; preds = %142
  %325 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %142 ]
  br label %144

326:                                              ; preds = %142
  %327 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %142 ]
  br label %144

328:                                              ; preds = %161
  %329 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %161 ]
  br label %163

330:                                              ; preds = %161
  %331 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %161 ]
  br label %163

332:                                              ; preds = %166
  %333 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %166 ]
  br label %168

334:                                              ; preds = %166
  %335 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %166 ]
  br label %168

336:                                              ; preds = %185
  %337 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %185 ]
  br label %187

338:                                              ; preds = %185
  %339 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %185 ]
  br label %187

340:                                              ; preds = %190
  %341 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %190 ]
  br label %192

342:                                              ; preds = %190
  %343 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %190 ]
  br label %192

344:                                              ; preds = %209
  %345 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %209 ]
  br label %211

346:                                              ; preds = %209
  %347 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %209 ]
  br label %211

348:                                              ; preds = %214
  %349 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %214 ]
  br label %216

350:                                              ; preds = %214
  %351 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %214 ]
  br label %216

352:                                              ; preds = %233
  %353 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %233 ]
  br label %235

354:                                              ; preds = %233
  %355 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %233 ]
  br label %235

356:                                              ; preds = %238
  %357 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %238 ]
  br label %240

358:                                              ; preds = %238
  %359 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %238 ]
  br label %240

360:                                              ; preds = %257
  %361 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_0, %257 ]
  br label %259

362:                                              ; preds = %257
  %363 = phi ptr [ @direct_a_broadcast_0_4_cons_buff_1, %257 ]
  br label %259

364:                                              ; preds = %262
  %365 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_0, %262 ]
  br label %264

366:                                              ; preds = %262
  %367 = phi ptr [ @direct_w_broadcast_4_0_cons_buff_1, %262 ]
  br label %264
}

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
