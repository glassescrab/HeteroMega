; ModuleID = '/notebooks/HeteroMega-upstream-partition-20261027/artifacts/upstream_bfp16_projection_m512_k2816_n4096_23fbcb8c25ebbbfa/final.prj/peano-linked_main_core_3_5.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:20:32-i1:8:32-i8:8:32-i16:16:32-i32:32:32-f32:32:32-i64:32-f64:32-a:0:32-n32"
target triple = "aie2p"

@direct_dequant_3_3 = external global [4096 x bfloat]
@direct_acc1_3_3 = external global [2048 x float]
@direct_acc0_3_3 = external global [2048 x float]
@direct_a_broadcast_3_3_cons_buff_0 = external global [8192 x bfloat]
@direct_w_broadcast_3_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_3_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_3_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_3_3_buff_0 = external global [2048 x bfloat]

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.acquire(i32, i32) #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.release(i32, i32) #0

declare void @w4a16_prefill_reuse_init(ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_low(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_high(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_finish(ptr, ptr) local_unnamed_addr

define void @core_3_5() local_unnamed_addr {
  br label %.preheader

.preheader:                                       ; preds = %0, %112
  %1 = phi i32 [ 0, %0 ], [ %106, %112 ]
  %2 = phi i64 [ 0, %0 ], [ %113, %112 ]
  br label %3

3:                                                ; preds = %.preheader, %109
  %4 = phi i32 [ %1, %.preheader ], [ %106, %109 ]
  %5 = phi i64 [ 0, %.preheader ], [ %110, %109 ]
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %6

6:                                                ; preds = %6, %3
  %7 = phi i32 [ %4, %3 ], [ %15, %6 ]
  %8 = phi i64 [ 0, %3 ], [ %16, %6 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond = icmp eq i32 %7, 1
  %spec.select = select i1 %cond, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %9 = add i32 %7, 1
  %10 = icmp sgt i32 %9, 1
  %11 = select i1 %10, i32 0, i32 %9
  %12 = or disjoint i64 %8, 1
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond.1 = icmp eq i32 %11, 1
  %spec.select.1 = select i1 %cond.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %13 = add i32 %11, 1
  %14 = icmp sgt i32 %13, 1
  %15 = select i1 %14, i32 0, i32 %13
  %16 = add nuw nsw i64 %8, 2
  %17 = icmp samesign ult i64 %12, 21
  br i1 %17, label %6, label %18

18:                                               ; preds = %6
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %19

19:                                               ; preds = %19, %18
  %20 = phi i32 [ %15, %18 ], [ %28, %19 ]
  %21 = phi i64 [ 0, %18 ], [ %29, %19 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1 = icmp eq i32 %20, 1
  %spec.select16 = select i1 %cond1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %22 = add i32 %20, 1
  %23 = icmp sgt i32 %22, 1
  %24 = select i1 %23, i32 0, i32 %22
  %25 = or disjoint i64 %21, 1
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1.1 = icmp eq i32 %24, 1
  %spec.select16.1 = select i1 %cond1.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %26 = add i32 %24, 1
  %27 = icmp sgt i32 %26, 1
  %28 = select i1 %27, i32 0, i32 %26
  %29 = add nuw nsw i64 %21, 2
  %30 = icmp samesign ult i64 %25, 21
  br i1 %30, label %19, label %31

31:                                               ; preds = %19
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %32

32:                                               ; preds = %32, %31
  %33 = phi i32 [ %28, %31 ], [ %41, %32 ]
  %34 = phi i64 [ 0, %31 ], [ %42, %32 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2 = icmp eq i32 %33, 1
  %spec.select17 = select i1 %cond2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %35 = add i32 %33, 1
  %36 = icmp sgt i32 %35, 1
  %37 = select i1 %36, i32 0, i32 %35
  %38 = or disjoint i64 %34, 1
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2.1 = icmp eq i32 %37, 1
  %spec.select17.1 = select i1 %cond2.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %39 = add i32 %37, 1
  %40 = icmp sgt i32 %39, 1
  %41 = select i1 %40, i32 0, i32 %39
  %42 = add nuw nsw i64 %34, 2
  %43 = icmp samesign ult i64 %38, 21
  br i1 %43, label %32, label %44

44:                                               ; preds = %32
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %45

45:                                               ; preds = %45, %44
  %46 = phi i32 [ %41, %44 ], [ %54, %45 ]
  %47 = phi i64 [ 0, %44 ], [ %55, %45 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3 = icmp eq i32 %46, 1
  %spec.select18 = select i1 %cond3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %48 = add i32 %46, 1
  %49 = icmp sgt i32 %48, 1
  %50 = select i1 %49, i32 0, i32 %48
  %51 = or disjoint i64 %47, 1
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3.1 = icmp eq i32 %50, 1
  %spec.select18.1 = select i1 %cond3.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %52 = add i32 %50, 1
  %53 = icmp sgt i32 %52, 1
  %54 = select i1 %53, i32 0, i32 %52
  %55 = add nuw nsw i64 %47, 2
  %56 = icmp samesign ult i64 %51, 21
  br i1 %56, label %45, label %57

57:                                               ; preds = %45
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %58

58:                                               ; preds = %58, %57
  %59 = phi i32 [ %54, %57 ], [ %67, %58 ]
  %60 = phi i64 [ 0, %57 ], [ %68, %58 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4 = icmp eq i32 %59, 1
  %spec.select19 = select i1 %cond4, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %61 = add i32 %59, 1
  %62 = icmp sgt i32 %61, 1
  %63 = select i1 %62, i32 0, i32 %61
  %64 = or disjoint i64 %60, 1
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4.1 = icmp eq i32 %63, 1
  %spec.select19.1 = select i1 %cond4.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %65 = add i32 %63, 1
  %66 = icmp sgt i32 %65, 1
  %67 = select i1 %66, i32 0, i32 %65
  %68 = add nuw nsw i64 %60, 2
  %69 = icmp samesign ult i64 %64, 21
  br i1 %69, label %58, label %70

70:                                               ; preds = %58
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %71

71:                                               ; preds = %71, %70
  %72 = phi i32 [ %67, %70 ], [ %80, %71 ]
  %73 = phi i64 [ 0, %70 ], [ %81, %71 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5 = icmp eq i32 %72, 1
  %spec.select20 = select i1 %cond5, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %74 = add i32 %72, 1
  %75 = icmp sgt i32 %74, 1
  %76 = select i1 %75, i32 0, i32 %74
  %77 = or disjoint i64 %73, 1
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5.1 = icmp eq i32 %76, 1
  %spec.select20.1 = select i1 %cond5.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %78 = add i32 %76, 1
  %79 = icmp sgt i32 %78, 1
  %80 = select i1 %79, i32 0, i32 %78
  %81 = add nuw nsw i64 %73, 2
  %82 = icmp samesign ult i64 %77, 21
  br i1 %82, label %71, label %83

83:                                               ; preds = %71
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %84

84:                                               ; preds = %84, %83
  %85 = phi i32 [ %80, %83 ], [ %93, %84 ]
  %86 = phi i64 [ 0, %83 ], [ %94, %84 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6 = icmp eq i32 %85, 1
  %spec.select21 = select i1 %cond6, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %87 = add i32 %85, 1
  %88 = icmp sgt i32 %87, 1
  %89 = select i1 %88, i32 0, i32 %87
  %90 = or disjoint i64 %86, 1
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6.1 = icmp eq i32 %89, 1
  %spec.select21.1 = select i1 %cond6.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %91 = add i32 %89, 1
  %92 = icmp sgt i32 %91, 1
  %93 = select i1 %92, i32 0, i32 %91
  %94 = add nuw nsw i64 %86, 2
  %95 = icmp samesign ult i64 %90, 21
  br i1 %95, label %84, label %96

96:                                               ; preds = %84
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %97

97:                                               ; preds = %97, %96
  %98 = phi i32 [ %93, %96 ], [ %106, %97 ]
  %99 = phi i64 [ 0, %96 ], [ %107, %97 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7 = icmp eq i32 %98, 1
  %spec.select22 = select i1 %cond7, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %100 = add i32 %98, 1
  %101 = icmp sgt i32 %100, 1
  %102 = select i1 %101, i32 0, i32 %100
  %103 = or disjoint i64 %99, 1
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7.1 = icmp eq i32 %102, 1
  %spec.select22.1 = select i1 %cond7.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %104 = add i32 %102, 1
  %105 = icmp sgt i32 %104, 1
  %106 = select i1 %105, i32 0, i32 %104
  %107 = add nuw nsw i64 %99, 2
  %108 = icmp samesign ult i64 %103, 21
  br i1 %108, label %97, label %109

109:                                              ; preds = %97
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  %110 = add nuw nsw i64 %5, 1
  %111 = icmp eq i64 %5, 0
  br i1 %111, label %3, label %112

112:                                              ; preds = %109
  %113 = add nuw nsw i64 %2, 1
  %.not = icmp eq i64 %113, 9223372036854775807
  br i1 %.not, label %114, label %.preheader

114:                                              ; preds = %112
  ret void
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
