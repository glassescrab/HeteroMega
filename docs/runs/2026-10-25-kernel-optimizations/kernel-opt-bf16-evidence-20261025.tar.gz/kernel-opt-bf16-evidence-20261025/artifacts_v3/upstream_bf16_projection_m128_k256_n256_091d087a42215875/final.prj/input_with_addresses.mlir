#loc166 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":259:17)
#loc169 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":263:15)
#loc172 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":272:19)
#loc175 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":276:18)
#loc180 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":282:16)
#loc184 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":289:17)
#loc186 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":293:15)
#loc189 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":302:19)
#loc192 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":306:18)
#loc197 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":312:16)
#loc201 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":319:17)
#loc203 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":323:15)
#loc206 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":332:19)
#loc209 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":336:18)
#loc214 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":342:16)
#loc218 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":349:17)
#loc220 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":353:15)
#loc223 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":362:19)
#loc226 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":366:18)
#loc231 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":372:16)
#loc235 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":379:17)
#loc237 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":383:15)
#loc240 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":392:19)
#loc243 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":396:18)
#loc248 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":402:16)
#loc252 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":409:17)
#loc254 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":413:15)
#loc257 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":422:19)
#loc260 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":426:18)
#loc265 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":432:16)
#loc269 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":439:17)
#loc271 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":443:15)
#loc274 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":452:19)
#loc277 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":456:18)
#loc282 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":462:16)
#loc286 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":469:17)
#loc288 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":473:15)
#loc291 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":482:19)
#loc294 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":486:18)
#loc299 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":492:16)
#loc303 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":499:17)
#loc305 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":503:15)
#loc308 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":512:19)
#loc311 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":516:18)
#loc316 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":522:16)
#loc320 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":529:17)
#loc322 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":533:15)
#loc325 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":542:19)
#loc328 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":546:18)
#loc333 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":552:16)
#loc337 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":559:17)
#loc339 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":563:15)
#loc342 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":572:19)
#loc345 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":576:18)
#loc350 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":582:16)
#loc354 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":589:17)
#loc356 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":593:15)
#loc359 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":602:19)
#loc362 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":606:18)
#loc367 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":612:16)
#loc371 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":619:17)
#loc373 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":623:15)
#loc376 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":632:19)
#loc379 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":636:18)
#loc384 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":642:16)
#loc388 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":649:17)
#loc390 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":653:15)
#loc393 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":662:19)
#loc396 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":666:18)
#loc401 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":672:16)
#loc405 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":679:17)
#loc407 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":683:15)
#loc410 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":692:19)
#loc413 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":696:18)
#loc418 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":702:16)
#loc422 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":709:17)
#loc424 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":713:15)
#loc427 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":722:19)
#loc430 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":726:18)
#loc435 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":732:16)
#loc439 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":739:17)
#loc441 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":743:15)
#loc444 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":752:19)
#loc447 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":756:18)
#loc452 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":762:16)
#loc456 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":769:17)
#loc458 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":773:15)
#loc461 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":782:19)
#loc464 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":786:18)
#loc469 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":792:16)
#loc473 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":799:17)
#loc475 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":803:15)
#loc478 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":812:19)
#loc481 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":816:18)
#loc486 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":822:16)
#loc490 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":829:17)
#loc492 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":833:15)
#loc495 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":842:19)
#loc498 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":846:18)
#loc503 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":852:16)
#loc507 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":859:17)
#loc509 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":863:15)
#loc512 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":872:19)
#loc515 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":876:18)
#loc520 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":882:16)
#loc524 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":889:17)
#loc526 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":893:15)
#loc529 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":902:19)
#loc532 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":906:18)
#loc537 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":912:16)
#loc541 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":919:17)
#loc543 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":923:15)
#loc546 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":932:19)
#loc549 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":936:18)
#loc554 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":942:16)
#loc558 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":949:17)
#loc560 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":953:15)
#loc563 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":962:19)
#loc566 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":966:18)
#loc571 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":972:16)
#loc575 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":979:17)
#loc577 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":983:15)
#loc580 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":992:19)
#loc583 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":996:18)
#loc588 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1002:16)
#loc592 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1009:17)
#loc594 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1013:15)
#loc597 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1022:19)
#loc600 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1026:18)
#loc605 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1032:16)
#loc609 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1039:17)
#loc611 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1043:15)
#loc614 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1052:19)
#loc617 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1056:18)
#loc622 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1062:16)
#loc626 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1069:17)
#loc628 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1073:15)
#loc631 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1082:19)
#loc634 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1086:18)
#loc639 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1092:16)
#loc643 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1099:17)
#loc645 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1103:15)
#loc648 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1112:19)
#loc651 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1116:18)
#loc656 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1122:16)
#loc660 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1129:17)
#loc662 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1133:15)
#loc665 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1142:19)
#loc668 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1146:18)
#loc673 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1152:16)
#loc677 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1159:17)
#loc679 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1163:15)
#loc682 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1172:19)
#loc685 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1176:18)
#loc690 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1182:16)
#loc694 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1189:17)
#loc696 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1193:15)
#loc699 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1202:19)
#loc702 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1206:18)
#loc707 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1212:16)
#loc712 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1219:26)
#loc713 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1219:53)
#loc714 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1219:80)
module {
  aie.device(npu2) {
    %shim_noc_tile_7_0 = aie.tile(7, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_6_0 = aie.tile(6, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_5_0 = aie.tile(5, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_4_0 = aie.tile(4, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %mem_tile_7_1 = aie.tile(7, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_6_1 = aie.tile(6, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_5_1 = aie.tile(5, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_4_1 = aie.tile(4, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %shim_noc_tile_3_0 = aie.tile(3, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_2_0 = aie.tile(2, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_1_0 = aie.tile(1, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_0_0 = aie.tile(0, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %mem_tile_3_1 = aie.tile(3, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_2_1 = aie.tile(2, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_1_1 = aie.tile(1, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_0_1 = aie.tile(0, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %tile_7_5 = aie.tile(7, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_7_4 = aie.tile(7, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_7_3 = aie.tile(7, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_7_2 = aie.tile(7, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_6_5 = aie.tile(6, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_6_4 = aie.tile(6, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_6_3 = aie.tile(6, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_6_2 = aie.tile(6, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_5_5 = aie.tile(5, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_5_4 = aie.tile(5, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_5_3 = aie.tile(5, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_5_2 = aie.tile(5, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_4_5 = aie.tile(4, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_4_4 = aie.tile(4, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_4_3 = aie.tile(4, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_4_2 = aie.tile(4, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_3_5 = aie.tile(3, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_3_4 = aie.tile(3, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_3_3 = aie.tile(3, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_3_2 = aie.tile(3, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_2_5 = aie.tile(2, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_2_4 = aie.tile(2, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_2_3 = aie.tile(2, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_2_2 = aie.tile(2, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_1_5 = aie.tile(1, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_1_4 = aie.tile(1, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_1_3 = aie.tile(1, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_1_2 = aie.tile(1, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_0_5 = aie.tile(0, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_0_4 = aie.tile(0, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_0_3 = aie.tile(0, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_0_2 = aie.tile(0, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %direct_y_worker_7_3_buff_0 = aie.buffer(%tile_7_5) {address = 35328 : i32, sym_name = "direct_y_worker_7_3_buff_0"} : memref<1024xbf16>  loc(#loc2)
    %direct_y_worker_7_3_buff_1 = aie.buffer(%tile_7_5) {address = 37376 : i32, sym_name = "direct_y_worker_7_3_buff_1"} : memref<1024xbf16>  loc(#loc2)
    %direct_y_worker_7_3_prod_lock_0 = aie.lock(%tile_7_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_7_3_prod_lock_0"} loc(#loc2)
    %direct_y_worker_7_3_cons_lock_0 = aie.lock(%tile_7_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_7_3_cons_lock_0"} loc(#loc2)
    %direct_y_worker_7_2_buff_0 = aie.buffer(%tile_7_4) {address = 35328 : i32, sym_name = "direct_y_worker_7_2_buff_0"} : memref<1024xbf16>  loc(#loc3)
    %direct_y_worker_7_2_buff_1 = aie.buffer(%tile_7_4) {address = 37376 : i32, sym_name = "direct_y_worker_7_2_buff_1"} : memref<1024xbf16>  loc(#loc3)
    %direct_y_worker_7_2_prod_lock_0 = aie.lock(%tile_7_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_7_2_prod_lock_0"} loc(#loc3)
    %direct_y_worker_7_2_cons_lock_0 = aie.lock(%tile_7_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_7_2_cons_lock_0"} loc(#loc3)
    %direct_y_worker_7_1_buff_0 = aie.buffer(%tile_7_3) {address = 35328 : i32, sym_name = "direct_y_worker_7_1_buff_0"} : memref<1024xbf16>  loc(#loc4)
    %direct_y_worker_7_1_buff_1 = aie.buffer(%tile_7_3) {address = 37376 : i32, sym_name = "direct_y_worker_7_1_buff_1"} : memref<1024xbf16>  loc(#loc4)
    %direct_y_worker_7_1_prod_lock_0 = aie.lock(%tile_7_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_7_1_prod_lock_0"} loc(#loc4)
    %direct_y_worker_7_1_cons_lock_0 = aie.lock(%tile_7_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_7_1_cons_lock_0"} loc(#loc4)
    %direct_y_worker_7_0_buff_0 = aie.buffer(%tile_7_2) {address = 35328 : i32, sym_name = "direct_y_worker_7_0_buff_0"} : memref<1024xbf16>  loc(#loc5)
    %direct_y_worker_7_0_buff_1 = aie.buffer(%tile_7_2) {address = 37376 : i32, sym_name = "direct_y_worker_7_0_buff_1"} : memref<1024xbf16>  loc(#loc5)
    %direct_y_worker_7_0_prod_lock_0 = aie.lock(%tile_7_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_7_0_prod_lock_0"} loc(#loc5)
    %direct_y_worker_7_0_cons_lock_0 = aie.lock(%tile_7_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_7_0_cons_lock_0"} loc(#loc5)
    %direct_y_host_7_cons_prod_lock_0 = aie.lock(%shim_noc_tile_7_0, 0) {init = 0 : i32, sym_name = "direct_y_host_7_cons_prod_lock_0"} loc(#loc6)
    %direct_y_host_7_cons_cons_lock_0 = aie.lock(%shim_noc_tile_7_0, 1) {init = 0 : i32, sym_name = "direct_y_host_7_cons_cons_lock_0"} loc(#loc6)
    %direct_y_worker_6_3_buff_0 = aie.buffer(%tile_6_5) {address = 35328 : i32, sym_name = "direct_y_worker_6_3_buff_0"} : memref<1024xbf16>  loc(#loc7)
    %direct_y_worker_6_3_buff_1 = aie.buffer(%tile_6_5) {address = 37376 : i32, sym_name = "direct_y_worker_6_3_buff_1"} : memref<1024xbf16>  loc(#loc7)
    %direct_y_worker_6_3_prod_lock_0 = aie.lock(%tile_6_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_6_3_prod_lock_0"} loc(#loc7)
    %direct_y_worker_6_3_cons_lock_0 = aie.lock(%tile_6_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_6_3_cons_lock_0"} loc(#loc7)
    %direct_y_worker_6_2_buff_0 = aie.buffer(%tile_6_4) {address = 35328 : i32, sym_name = "direct_y_worker_6_2_buff_0"} : memref<1024xbf16>  loc(#loc8)
    %direct_y_worker_6_2_buff_1 = aie.buffer(%tile_6_4) {address = 37376 : i32, sym_name = "direct_y_worker_6_2_buff_1"} : memref<1024xbf16>  loc(#loc8)
    %direct_y_worker_6_2_prod_lock_0 = aie.lock(%tile_6_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_6_2_prod_lock_0"} loc(#loc8)
    %direct_y_worker_6_2_cons_lock_0 = aie.lock(%tile_6_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_6_2_cons_lock_0"} loc(#loc8)
    %direct_y_worker_6_1_buff_0 = aie.buffer(%tile_6_3) {address = 35328 : i32, sym_name = "direct_y_worker_6_1_buff_0"} : memref<1024xbf16>  loc(#loc9)
    %direct_y_worker_6_1_buff_1 = aie.buffer(%tile_6_3) {address = 37376 : i32, sym_name = "direct_y_worker_6_1_buff_1"} : memref<1024xbf16>  loc(#loc9)
    %direct_y_worker_6_1_prod_lock_0 = aie.lock(%tile_6_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_6_1_prod_lock_0"} loc(#loc9)
    %direct_y_worker_6_1_cons_lock_0 = aie.lock(%tile_6_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_6_1_cons_lock_0"} loc(#loc9)
    %direct_y_worker_6_0_buff_0 = aie.buffer(%tile_6_2) {address = 35328 : i32, sym_name = "direct_y_worker_6_0_buff_0"} : memref<1024xbf16>  loc(#loc10)
    %direct_y_worker_6_0_buff_1 = aie.buffer(%tile_6_2) {address = 37376 : i32, sym_name = "direct_y_worker_6_0_buff_1"} : memref<1024xbf16>  loc(#loc10)
    %direct_y_worker_6_0_prod_lock_0 = aie.lock(%tile_6_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_6_0_prod_lock_0"} loc(#loc10)
    %direct_y_worker_6_0_cons_lock_0 = aie.lock(%tile_6_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_6_0_cons_lock_0"} loc(#loc10)
    %direct_y_host_6_cons_prod_lock_0 = aie.lock(%shim_noc_tile_6_0, 0) {init = 0 : i32, sym_name = "direct_y_host_6_cons_prod_lock_0"} loc(#loc11)
    %direct_y_host_6_cons_cons_lock_0 = aie.lock(%shim_noc_tile_6_0, 1) {init = 0 : i32, sym_name = "direct_y_host_6_cons_cons_lock_0"} loc(#loc11)
    %direct_y_worker_5_3_buff_0 = aie.buffer(%tile_5_5) {address = 35328 : i32, sym_name = "direct_y_worker_5_3_buff_0"} : memref<1024xbf16>  loc(#loc12)
    %direct_y_worker_5_3_buff_1 = aie.buffer(%tile_5_5) {address = 37376 : i32, sym_name = "direct_y_worker_5_3_buff_1"} : memref<1024xbf16>  loc(#loc12)
    %direct_y_worker_5_3_prod_lock_0 = aie.lock(%tile_5_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_5_3_prod_lock_0"} loc(#loc12)
    %direct_y_worker_5_3_cons_lock_0 = aie.lock(%tile_5_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_5_3_cons_lock_0"} loc(#loc12)
    %direct_y_worker_5_2_buff_0 = aie.buffer(%tile_5_4) {address = 35328 : i32, sym_name = "direct_y_worker_5_2_buff_0"} : memref<1024xbf16>  loc(#loc13)
    %direct_y_worker_5_2_buff_1 = aie.buffer(%tile_5_4) {address = 37376 : i32, sym_name = "direct_y_worker_5_2_buff_1"} : memref<1024xbf16>  loc(#loc13)
    %direct_y_worker_5_2_prod_lock_0 = aie.lock(%tile_5_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_5_2_prod_lock_0"} loc(#loc13)
    %direct_y_worker_5_2_cons_lock_0 = aie.lock(%tile_5_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_5_2_cons_lock_0"} loc(#loc13)
    %direct_y_worker_5_1_buff_0 = aie.buffer(%tile_5_3) {address = 35328 : i32, sym_name = "direct_y_worker_5_1_buff_0"} : memref<1024xbf16>  loc(#loc14)
    %direct_y_worker_5_1_buff_1 = aie.buffer(%tile_5_3) {address = 37376 : i32, sym_name = "direct_y_worker_5_1_buff_1"} : memref<1024xbf16>  loc(#loc14)
    %direct_y_worker_5_1_prod_lock_0 = aie.lock(%tile_5_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_5_1_prod_lock_0"} loc(#loc14)
    %direct_y_worker_5_1_cons_lock_0 = aie.lock(%tile_5_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_5_1_cons_lock_0"} loc(#loc14)
    %direct_y_worker_5_0_buff_0 = aie.buffer(%tile_5_2) {address = 35328 : i32, sym_name = "direct_y_worker_5_0_buff_0"} : memref<1024xbf16>  loc(#loc15)
    %direct_y_worker_5_0_buff_1 = aie.buffer(%tile_5_2) {address = 37376 : i32, sym_name = "direct_y_worker_5_0_buff_1"} : memref<1024xbf16>  loc(#loc15)
    %direct_y_worker_5_0_prod_lock_0 = aie.lock(%tile_5_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_5_0_prod_lock_0"} loc(#loc15)
    %direct_y_worker_5_0_cons_lock_0 = aie.lock(%tile_5_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_5_0_cons_lock_0"} loc(#loc15)
    %direct_y_host_5_cons_prod_lock_0 = aie.lock(%shim_noc_tile_5_0, 0) {init = 0 : i32, sym_name = "direct_y_host_5_cons_prod_lock_0"} loc(#loc16)
    %direct_y_host_5_cons_cons_lock_0 = aie.lock(%shim_noc_tile_5_0, 1) {init = 0 : i32, sym_name = "direct_y_host_5_cons_cons_lock_0"} loc(#loc16)
    %direct_y_worker_4_3_buff_0 = aie.buffer(%tile_4_5) {address = 35328 : i32, sym_name = "direct_y_worker_4_3_buff_0"} : memref<1024xbf16>  loc(#loc17)
    %direct_y_worker_4_3_buff_1 = aie.buffer(%tile_4_5) {address = 37376 : i32, sym_name = "direct_y_worker_4_3_buff_1"} : memref<1024xbf16>  loc(#loc17)
    %direct_y_worker_4_3_prod_lock_0 = aie.lock(%tile_4_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_4_3_prod_lock_0"} loc(#loc17)
    %direct_y_worker_4_3_cons_lock_0 = aie.lock(%tile_4_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_4_3_cons_lock_0"} loc(#loc17)
    %direct_y_worker_4_2_buff_0 = aie.buffer(%tile_4_4) {address = 35328 : i32, sym_name = "direct_y_worker_4_2_buff_0"} : memref<1024xbf16>  loc(#loc18)
    %direct_y_worker_4_2_buff_1 = aie.buffer(%tile_4_4) {address = 37376 : i32, sym_name = "direct_y_worker_4_2_buff_1"} : memref<1024xbf16>  loc(#loc18)
    %direct_y_worker_4_2_prod_lock_0 = aie.lock(%tile_4_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_4_2_prod_lock_0"} loc(#loc18)
    %direct_y_worker_4_2_cons_lock_0 = aie.lock(%tile_4_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_4_2_cons_lock_0"} loc(#loc18)
    %direct_y_worker_4_1_buff_0 = aie.buffer(%tile_4_3) {address = 35328 : i32, sym_name = "direct_y_worker_4_1_buff_0"} : memref<1024xbf16>  loc(#loc19)
    %direct_y_worker_4_1_buff_1 = aie.buffer(%tile_4_3) {address = 37376 : i32, sym_name = "direct_y_worker_4_1_buff_1"} : memref<1024xbf16>  loc(#loc19)
    %direct_y_worker_4_1_prod_lock_0 = aie.lock(%tile_4_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_4_1_prod_lock_0"} loc(#loc19)
    %direct_y_worker_4_1_cons_lock_0 = aie.lock(%tile_4_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_4_1_cons_lock_0"} loc(#loc19)
    %direct_y_worker_4_0_buff_0 = aie.buffer(%tile_4_2) {address = 35328 : i32, sym_name = "direct_y_worker_4_0_buff_0"} : memref<1024xbf16>  loc(#loc20)
    %direct_y_worker_4_0_buff_1 = aie.buffer(%tile_4_2) {address = 37376 : i32, sym_name = "direct_y_worker_4_0_buff_1"} : memref<1024xbf16>  loc(#loc20)
    %direct_y_worker_4_0_prod_lock_0 = aie.lock(%tile_4_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_4_0_prod_lock_0"} loc(#loc20)
    %direct_y_worker_4_0_cons_lock_0 = aie.lock(%tile_4_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_4_0_cons_lock_0"} loc(#loc20)
    %direct_y_host_4_cons_prod_lock_0 = aie.lock(%shim_noc_tile_4_0, 0) {init = 0 : i32, sym_name = "direct_y_host_4_cons_prod_lock_0"} loc(#loc21)
    %direct_y_host_4_cons_cons_lock_0 = aie.lock(%shim_noc_tile_4_0, 1) {init = 0 : i32, sym_name = "direct_y_host_4_cons_cons_lock_0"} loc(#loc21)
    %direct_y_worker_3_3_buff_0 = aie.buffer(%tile_3_5) {address = 35328 : i32, sym_name = "direct_y_worker_3_3_buff_0"} : memref<1024xbf16>  loc(#loc22)
    %direct_y_worker_3_3_buff_1 = aie.buffer(%tile_3_5) {address = 37376 : i32, sym_name = "direct_y_worker_3_3_buff_1"} : memref<1024xbf16>  loc(#loc22)
    %direct_y_worker_3_3_prod_lock_0 = aie.lock(%tile_3_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_3_3_prod_lock_0"} loc(#loc22)
    %direct_y_worker_3_3_cons_lock_0 = aie.lock(%tile_3_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_3_3_cons_lock_0"} loc(#loc22)
    %direct_y_worker_3_2_buff_0 = aie.buffer(%tile_3_4) {address = 35328 : i32, sym_name = "direct_y_worker_3_2_buff_0"} : memref<1024xbf16>  loc(#loc23)
    %direct_y_worker_3_2_buff_1 = aie.buffer(%tile_3_4) {address = 37376 : i32, sym_name = "direct_y_worker_3_2_buff_1"} : memref<1024xbf16>  loc(#loc23)
    %direct_y_worker_3_2_prod_lock_0 = aie.lock(%tile_3_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_3_2_prod_lock_0"} loc(#loc23)
    %direct_y_worker_3_2_cons_lock_0 = aie.lock(%tile_3_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_3_2_cons_lock_0"} loc(#loc23)
    %direct_y_worker_3_1_buff_0 = aie.buffer(%tile_3_3) {address = 35328 : i32, sym_name = "direct_y_worker_3_1_buff_0"} : memref<1024xbf16>  loc(#loc24)
    %direct_y_worker_3_1_buff_1 = aie.buffer(%tile_3_3) {address = 37376 : i32, sym_name = "direct_y_worker_3_1_buff_1"} : memref<1024xbf16>  loc(#loc24)
    %direct_y_worker_3_1_prod_lock_0 = aie.lock(%tile_3_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_3_1_prod_lock_0"} loc(#loc24)
    %direct_y_worker_3_1_cons_lock_0 = aie.lock(%tile_3_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_3_1_cons_lock_0"} loc(#loc24)
    %direct_y_worker_3_0_buff_0 = aie.buffer(%tile_3_2) {address = 35328 : i32, sym_name = "direct_y_worker_3_0_buff_0"} : memref<1024xbf16>  loc(#loc25)
    %direct_y_worker_3_0_buff_1 = aie.buffer(%tile_3_2) {address = 37376 : i32, sym_name = "direct_y_worker_3_0_buff_1"} : memref<1024xbf16>  loc(#loc25)
    %direct_y_worker_3_0_prod_lock_0 = aie.lock(%tile_3_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_3_0_prod_lock_0"} loc(#loc25)
    %direct_y_worker_3_0_cons_lock_0 = aie.lock(%tile_3_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_3_0_cons_lock_0"} loc(#loc25)
    %direct_y_host_3_cons_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 0) {init = 0 : i32, sym_name = "direct_y_host_3_cons_prod_lock_0"} loc(#loc26)
    %direct_y_host_3_cons_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 1) {init = 0 : i32, sym_name = "direct_y_host_3_cons_cons_lock_0"} loc(#loc26)
    %direct_y_worker_2_3_buff_0 = aie.buffer(%tile_2_5) {address = 35328 : i32, sym_name = "direct_y_worker_2_3_buff_0"} : memref<1024xbf16>  loc(#loc27)
    %direct_y_worker_2_3_buff_1 = aie.buffer(%tile_2_5) {address = 37376 : i32, sym_name = "direct_y_worker_2_3_buff_1"} : memref<1024xbf16>  loc(#loc27)
    %direct_y_worker_2_3_prod_lock_0 = aie.lock(%tile_2_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_2_3_prod_lock_0"} loc(#loc27)
    %direct_y_worker_2_3_cons_lock_0 = aie.lock(%tile_2_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_2_3_cons_lock_0"} loc(#loc27)
    %direct_y_worker_2_2_buff_0 = aie.buffer(%tile_2_4) {address = 35328 : i32, sym_name = "direct_y_worker_2_2_buff_0"} : memref<1024xbf16>  loc(#loc28)
    %direct_y_worker_2_2_buff_1 = aie.buffer(%tile_2_4) {address = 37376 : i32, sym_name = "direct_y_worker_2_2_buff_1"} : memref<1024xbf16>  loc(#loc28)
    %direct_y_worker_2_2_prod_lock_0 = aie.lock(%tile_2_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_2_2_prod_lock_0"} loc(#loc28)
    %direct_y_worker_2_2_cons_lock_0 = aie.lock(%tile_2_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_2_2_cons_lock_0"} loc(#loc28)
    %direct_y_worker_2_1_buff_0 = aie.buffer(%tile_2_3) {address = 35328 : i32, sym_name = "direct_y_worker_2_1_buff_0"} : memref<1024xbf16>  loc(#loc29)
    %direct_y_worker_2_1_buff_1 = aie.buffer(%tile_2_3) {address = 37376 : i32, sym_name = "direct_y_worker_2_1_buff_1"} : memref<1024xbf16>  loc(#loc29)
    %direct_y_worker_2_1_prod_lock_0 = aie.lock(%tile_2_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_2_1_prod_lock_0"} loc(#loc29)
    %direct_y_worker_2_1_cons_lock_0 = aie.lock(%tile_2_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_2_1_cons_lock_0"} loc(#loc29)
    %direct_y_worker_2_0_buff_0 = aie.buffer(%tile_2_2) {address = 35328 : i32, sym_name = "direct_y_worker_2_0_buff_0"} : memref<1024xbf16>  loc(#loc30)
    %direct_y_worker_2_0_buff_1 = aie.buffer(%tile_2_2) {address = 37376 : i32, sym_name = "direct_y_worker_2_0_buff_1"} : memref<1024xbf16>  loc(#loc30)
    %direct_y_worker_2_0_prod_lock_0 = aie.lock(%tile_2_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_2_0_prod_lock_0"} loc(#loc30)
    %direct_y_worker_2_0_cons_lock_0 = aie.lock(%tile_2_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_2_0_cons_lock_0"} loc(#loc30)
    %direct_y_host_2_cons_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 0) {init = 0 : i32, sym_name = "direct_y_host_2_cons_prod_lock_0"} loc(#loc31)
    %direct_y_host_2_cons_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 1) {init = 0 : i32, sym_name = "direct_y_host_2_cons_cons_lock_0"} loc(#loc31)
    %direct_y_worker_1_3_buff_0 = aie.buffer(%tile_1_5) {address = 35328 : i32, sym_name = "direct_y_worker_1_3_buff_0"} : memref<1024xbf16>  loc(#loc32)
    %direct_y_worker_1_3_buff_1 = aie.buffer(%tile_1_5) {address = 37376 : i32, sym_name = "direct_y_worker_1_3_buff_1"} : memref<1024xbf16>  loc(#loc32)
    %direct_y_worker_1_3_prod_lock_0 = aie.lock(%tile_1_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_1_3_prod_lock_0"} loc(#loc32)
    %direct_y_worker_1_3_cons_lock_0 = aie.lock(%tile_1_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_1_3_cons_lock_0"} loc(#loc32)
    %direct_y_worker_1_2_buff_0 = aie.buffer(%tile_1_4) {address = 35328 : i32, sym_name = "direct_y_worker_1_2_buff_0"} : memref<1024xbf16>  loc(#loc33)
    %direct_y_worker_1_2_buff_1 = aie.buffer(%tile_1_4) {address = 37376 : i32, sym_name = "direct_y_worker_1_2_buff_1"} : memref<1024xbf16>  loc(#loc33)
    %direct_y_worker_1_2_prod_lock_0 = aie.lock(%tile_1_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_1_2_prod_lock_0"} loc(#loc33)
    %direct_y_worker_1_2_cons_lock_0 = aie.lock(%tile_1_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_1_2_cons_lock_0"} loc(#loc33)
    %direct_w_host_7_cons_buff_0 = aie.buffer(%mem_tile_7_1) {address = 16384 : i32, sym_name = "direct_w_host_7_cons_buff_0"} : memref<4352xui8>  loc(#loc34)
    %direct_w_host_7_cons_buff_1 = aie.buffer(%mem_tile_7_1) {address = 20736 : i32, sym_name = "direct_w_host_7_cons_buff_1"} : memref<4352xui8>  loc(#loc34)
    %direct_w_host_7_cons_prod_lock_0 = aie.lock(%mem_tile_7_1, 0) {init = 2 : i32, sym_name = "direct_w_host_7_cons_prod_lock_0"} loc(#loc34)
    %direct_w_host_7_cons_cons_lock_0 = aie.lock(%mem_tile_7_1, 1) {init = 0 : i32, sym_name = "direct_w_host_7_cons_cons_lock_0"} loc(#loc34)
    %direct_y_worker_1_1_buff_0 = aie.buffer(%tile_1_3) {address = 35328 : i32, sym_name = "direct_y_worker_1_1_buff_0"} : memref<1024xbf16>  loc(#loc35)
    %direct_y_worker_1_1_buff_1 = aie.buffer(%tile_1_3) {address = 37376 : i32, sym_name = "direct_y_worker_1_1_buff_1"} : memref<1024xbf16>  loc(#loc35)
    %direct_y_worker_1_1_prod_lock_0 = aie.lock(%tile_1_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_1_1_prod_lock_0"} loc(#loc35)
    %direct_y_worker_1_1_cons_lock_0 = aie.lock(%tile_1_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_1_1_cons_lock_0"} loc(#loc35)
    %direct_y_worker_1_0_buff_0 = aie.buffer(%tile_1_2) {address = 35328 : i32, sym_name = "direct_y_worker_1_0_buff_0"} : memref<1024xbf16>  loc(#loc36)
    %direct_y_worker_1_0_buff_1 = aie.buffer(%tile_1_2) {address = 37376 : i32, sym_name = "direct_y_worker_1_0_buff_1"} : memref<1024xbf16>  loc(#loc36)
    %direct_y_worker_1_0_prod_lock_0 = aie.lock(%tile_1_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_1_0_prod_lock_0"} loc(#loc36)
    %direct_y_worker_1_0_cons_lock_0 = aie.lock(%tile_1_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_1_0_cons_lock_0"} loc(#loc36)
    %direct_y_host_1_cons_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 0) {init = 0 : i32, sym_name = "direct_y_host_1_cons_prod_lock_0"} loc(#loc37)
    %direct_y_host_1_cons_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 1) {init = 0 : i32, sym_name = "direct_y_host_1_cons_cons_lock_0"} loc(#loc37)
    %direct_w_host_6_cons_buff_0 = aie.buffer(%mem_tile_6_1) {address = 16384 : i32, sym_name = "direct_w_host_6_cons_buff_0"} : memref<4352xui8>  loc(#loc38)
    %direct_w_host_6_cons_buff_1 = aie.buffer(%mem_tile_6_1) {address = 20736 : i32, sym_name = "direct_w_host_6_cons_buff_1"} : memref<4352xui8>  loc(#loc38)
    %direct_w_host_6_cons_prod_lock_0 = aie.lock(%mem_tile_6_1, 0) {init = 2 : i32, sym_name = "direct_w_host_6_cons_prod_lock_0"} loc(#loc38)
    %direct_w_host_6_cons_cons_lock_0 = aie.lock(%mem_tile_6_1, 1) {init = 0 : i32, sym_name = "direct_w_host_6_cons_cons_lock_0"} loc(#loc38)
    %direct_y_worker_0_3_buff_0 = aie.buffer(%tile_0_5) {address = 35328 : i32, sym_name = "direct_y_worker_0_3_buff_0"} : memref<1024xbf16>  loc(#loc39)
    %direct_y_worker_0_3_buff_1 = aie.buffer(%tile_0_5) {address = 37376 : i32, sym_name = "direct_y_worker_0_3_buff_1"} : memref<1024xbf16>  loc(#loc39)
    %direct_y_worker_0_3_prod_lock_0 = aie.lock(%tile_0_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_0_3_prod_lock_0"} loc(#loc39)
    %direct_y_worker_0_3_cons_lock_0 = aie.lock(%tile_0_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_0_3_cons_lock_0"} loc(#loc39)
    %direct_w_host_5_cons_buff_0 = aie.buffer(%mem_tile_5_1) {address = 16384 : i32, sym_name = "direct_w_host_5_cons_buff_0"} : memref<4352xui8>  loc(#loc40)
    %direct_w_host_5_cons_buff_1 = aie.buffer(%mem_tile_5_1) {address = 20736 : i32, sym_name = "direct_w_host_5_cons_buff_1"} : memref<4352xui8>  loc(#loc40)
    %direct_w_host_5_cons_prod_lock_0 = aie.lock(%mem_tile_5_1, 0) {init = 2 : i32, sym_name = "direct_w_host_5_cons_prod_lock_0"} loc(#loc40)
    %direct_w_host_5_cons_cons_lock_0 = aie.lock(%mem_tile_5_1, 1) {init = 0 : i32, sym_name = "direct_w_host_5_cons_cons_lock_0"} loc(#loc40)
    %direct_y_worker_0_2_buff_0 = aie.buffer(%tile_0_4) {address = 35328 : i32, sym_name = "direct_y_worker_0_2_buff_0"} : memref<1024xbf16>  loc(#loc41)
    %direct_y_worker_0_2_buff_1 = aie.buffer(%tile_0_4) {address = 37376 : i32, sym_name = "direct_y_worker_0_2_buff_1"} : memref<1024xbf16>  loc(#loc41)
    %direct_y_worker_0_2_prod_lock_0 = aie.lock(%tile_0_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_0_2_prod_lock_0"} loc(#loc41)
    %direct_y_worker_0_2_cons_lock_0 = aie.lock(%tile_0_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_0_2_cons_lock_0"} loc(#loc41)
    %direct_y_worker_0_1_buff_0 = aie.buffer(%tile_0_3) {address = 35328 : i32, sym_name = "direct_y_worker_0_1_buff_0"} : memref<1024xbf16>  loc(#loc42)
    %direct_y_worker_0_1_buff_1 = aie.buffer(%tile_0_3) {address = 37376 : i32, sym_name = "direct_y_worker_0_1_buff_1"} : memref<1024xbf16>  loc(#loc42)
    %direct_y_worker_0_1_prod_lock_0 = aie.lock(%tile_0_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_0_1_prod_lock_0"} loc(#loc42)
    %direct_y_worker_0_1_cons_lock_0 = aie.lock(%tile_0_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_0_1_cons_lock_0"} loc(#loc42)
    %direct_w_host_4_cons_buff_0 = aie.buffer(%mem_tile_4_1) {address = 16384 : i32, sym_name = "direct_w_host_4_cons_buff_0"} : memref<4352xui8>  loc(#loc43)
    %direct_w_host_4_cons_buff_1 = aie.buffer(%mem_tile_4_1) {address = 20736 : i32, sym_name = "direct_w_host_4_cons_buff_1"} : memref<4352xui8>  loc(#loc43)
    %direct_w_host_4_cons_prod_lock_0 = aie.lock(%mem_tile_4_1, 0) {init = 2 : i32, sym_name = "direct_w_host_4_cons_prod_lock_0"} loc(#loc43)
    %direct_w_host_4_cons_cons_lock_0 = aie.lock(%mem_tile_4_1, 1) {init = 0 : i32, sym_name = "direct_w_host_4_cons_cons_lock_0"} loc(#loc43)
    %direct_y_worker_0_0_buff_0 = aie.buffer(%tile_0_2) {address = 35328 : i32, sym_name = "direct_y_worker_0_0_buff_0"} : memref<1024xbf16>  loc(#loc44)
    %direct_y_worker_0_0_buff_1 = aie.buffer(%tile_0_2) {address = 37376 : i32, sym_name = "direct_y_worker_0_0_buff_1"} : memref<1024xbf16>  loc(#loc44)
    %direct_y_worker_0_0_prod_lock_0 = aie.lock(%tile_0_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_0_0_prod_lock_0"} loc(#loc44)
    %direct_y_worker_0_0_cons_lock_0 = aie.lock(%tile_0_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_0_0_cons_lock_0"} loc(#loc44)
    %direct_y_host_0_cons_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 0) {init = 0 : i32, sym_name = "direct_y_host_0_cons_prod_lock_0"} loc(#loc45)
    %direct_y_host_0_cons_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 1) {init = 0 : i32, sym_name = "direct_y_host_0_cons_cons_lock_0"} loc(#loc45)
    %direct_w_host_3_cons_buff_0 = aie.buffer(%mem_tile_3_1) {address = 32768 : i32, sym_name = "direct_w_host_3_cons_buff_0"} : memref<4352xui8>  loc(#loc46)
    %direct_w_host_3_cons_buff_1 = aie.buffer(%mem_tile_3_1) {address = 37120 : i32, sym_name = "direct_w_host_3_cons_buff_1"} : memref<4352xui8>  loc(#loc46)
    %direct_w_host_3_cons_prod_lock_0 = aie.lock(%mem_tile_3_1, 0) {init = 2 : i32, sym_name = "direct_w_host_3_cons_prod_lock_0"} loc(#loc46)
    %direct_w_host_3_cons_cons_lock_0 = aie.lock(%mem_tile_3_1, 1) {init = 0 : i32, sym_name = "direct_w_host_3_cons_cons_lock_0"} loc(#loc46)
    %direct_w_host_7_prod_lock_0 = aie.lock(%shim_noc_tile_7_0, 2) {init = 0 : i32, sym_name = "direct_w_host_7_prod_lock_0"} loc(#loc34)
    %direct_w_host_7_cons_lock_0 = aie.lock(%shim_noc_tile_7_0, 3) {init = 0 : i32, sym_name = "direct_w_host_7_cons_lock_0"} loc(#loc34)
    %direct_w_broadcast_7_0_cons_buff_0 = aie.buffer(%tile_7_2) {address = 18432 : i32, sym_name = "direct_w_broadcast_7_0_cons_buff_0"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_7_0_cons_buff_1 = aie.buffer(%tile_7_2) {address = 22784 : i32, sym_name = "direct_w_broadcast_7_0_cons_buff_1"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_7_0_cons_prod_lock_0 = aie.lock(%tile_7_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_7_0_cons_prod_lock_0"} loc(#loc47)
    %direct_w_broadcast_7_0_cons_cons_lock_0 = aie.lock(%tile_7_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_7_0_cons_cons_lock_0"} loc(#loc47)
    %direct_w_broadcast_7_1_cons_buff_0 = aie.buffer(%tile_7_3) {address = 18432 : i32, sym_name = "direct_w_broadcast_7_1_cons_buff_0"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_7_1_cons_buff_1 = aie.buffer(%tile_7_3) {address = 22784 : i32, sym_name = "direct_w_broadcast_7_1_cons_buff_1"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_7_1_cons_prod_lock_0 = aie.lock(%tile_7_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_7_1_cons_prod_lock_0"} loc(#loc47)
    %direct_w_broadcast_7_1_cons_cons_lock_0 = aie.lock(%tile_7_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_7_1_cons_cons_lock_0"} loc(#loc47)
    %direct_w_broadcast_7_2_cons_buff_0 = aie.buffer(%tile_7_4) {address = 18432 : i32, sym_name = "direct_w_broadcast_7_2_cons_buff_0"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_7_2_cons_buff_1 = aie.buffer(%tile_7_4) {address = 22784 : i32, sym_name = "direct_w_broadcast_7_2_cons_buff_1"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_7_2_cons_prod_lock_0 = aie.lock(%tile_7_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_7_2_cons_prod_lock_0"} loc(#loc47)
    %direct_w_broadcast_7_2_cons_cons_lock_0 = aie.lock(%tile_7_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_7_2_cons_cons_lock_0"} loc(#loc47)
    %direct_w_broadcast_7_3_cons_buff_0 = aie.buffer(%tile_7_5) {address = 18432 : i32, sym_name = "direct_w_broadcast_7_3_cons_buff_0"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_7_3_cons_buff_1 = aie.buffer(%tile_7_5) {address = 22784 : i32, sym_name = "direct_w_broadcast_7_3_cons_buff_1"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_7_3_cons_prod_lock_0 = aie.lock(%tile_7_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_7_3_cons_prod_lock_0"} loc(#loc47)
    %direct_w_broadcast_7_3_cons_cons_lock_0 = aie.lock(%tile_7_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_7_3_cons_cons_lock_0"} loc(#loc47)
    %direct_w_host_2_cons_buff_0 = aie.buffer(%mem_tile_2_1) {address = 32768 : i32, sym_name = "direct_w_host_2_cons_buff_0"} : memref<4352xui8>  loc(#loc48)
    %direct_w_host_2_cons_buff_1 = aie.buffer(%mem_tile_2_1) {address = 37120 : i32, sym_name = "direct_w_host_2_cons_buff_1"} : memref<4352xui8>  loc(#loc48)
    %direct_w_host_2_cons_prod_lock_0 = aie.lock(%mem_tile_2_1, 0) {init = 2 : i32, sym_name = "direct_w_host_2_cons_prod_lock_0"} loc(#loc48)
    %direct_w_host_2_cons_cons_lock_0 = aie.lock(%mem_tile_2_1, 1) {init = 0 : i32, sym_name = "direct_w_host_2_cons_cons_lock_0"} loc(#loc48)
    %direct_w_host_6_prod_lock_0 = aie.lock(%shim_noc_tile_6_0, 2) {init = 0 : i32, sym_name = "direct_w_host_6_prod_lock_0"} loc(#loc38)
    %direct_w_host_6_cons_lock_0 = aie.lock(%shim_noc_tile_6_0, 3) {init = 0 : i32, sym_name = "direct_w_host_6_cons_lock_0"} loc(#loc38)
    %direct_w_broadcast_6_0_cons_buff_0 = aie.buffer(%tile_6_2) {address = 18432 : i32, sym_name = "direct_w_broadcast_6_0_cons_buff_0"} : memref<4352xui8>  loc(#loc49)
    %direct_w_broadcast_6_0_cons_buff_1 = aie.buffer(%tile_6_2) {address = 22784 : i32, sym_name = "direct_w_broadcast_6_0_cons_buff_1"} : memref<4352xui8>  loc(#loc49)
    %direct_w_broadcast_6_0_cons_prod_lock_0 = aie.lock(%tile_6_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_6_0_cons_prod_lock_0"} loc(#loc49)
    %direct_w_broadcast_6_0_cons_cons_lock_0 = aie.lock(%tile_6_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_6_0_cons_cons_lock_0"} loc(#loc49)
    %direct_w_broadcast_6_1_cons_buff_0 = aie.buffer(%tile_6_3) {address = 18432 : i32, sym_name = "direct_w_broadcast_6_1_cons_buff_0"} : memref<4352xui8>  loc(#loc49)
    %direct_w_broadcast_6_1_cons_buff_1 = aie.buffer(%tile_6_3) {address = 22784 : i32, sym_name = "direct_w_broadcast_6_1_cons_buff_1"} : memref<4352xui8>  loc(#loc49)
    %direct_w_broadcast_6_1_cons_prod_lock_0 = aie.lock(%tile_6_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_6_1_cons_prod_lock_0"} loc(#loc49)
    %direct_w_broadcast_6_1_cons_cons_lock_0 = aie.lock(%tile_6_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_6_1_cons_cons_lock_0"} loc(#loc49)
    %direct_w_broadcast_6_2_cons_buff_0 = aie.buffer(%tile_6_4) {address = 18432 : i32, sym_name = "direct_w_broadcast_6_2_cons_buff_0"} : memref<4352xui8>  loc(#loc49)
    %direct_w_broadcast_6_2_cons_buff_1 = aie.buffer(%tile_6_4) {address = 22784 : i32, sym_name = "direct_w_broadcast_6_2_cons_buff_1"} : memref<4352xui8>  loc(#loc49)
    %direct_w_broadcast_6_2_cons_prod_lock_0 = aie.lock(%tile_6_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_6_2_cons_prod_lock_0"} loc(#loc49)
    %direct_w_broadcast_6_2_cons_cons_lock_0 = aie.lock(%tile_6_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_6_2_cons_cons_lock_0"} loc(#loc49)
    %direct_w_broadcast_6_3_cons_buff_0 = aie.buffer(%tile_6_5) {address = 18432 : i32, sym_name = "direct_w_broadcast_6_3_cons_buff_0"} : memref<4352xui8>  loc(#loc49)
    %direct_w_broadcast_6_3_cons_buff_1 = aie.buffer(%tile_6_5) {address = 22784 : i32, sym_name = "direct_w_broadcast_6_3_cons_buff_1"} : memref<4352xui8>  loc(#loc49)
    %direct_w_broadcast_6_3_cons_prod_lock_0 = aie.lock(%tile_6_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_6_3_cons_prod_lock_0"} loc(#loc49)
    %direct_w_broadcast_6_3_cons_cons_lock_0 = aie.lock(%tile_6_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_6_3_cons_cons_lock_0"} loc(#loc49)
    %direct_w_host_1_cons_buff_0 = aie.buffer(%mem_tile_1_1) {address = 32768 : i32, sym_name = "direct_w_host_1_cons_buff_0"} : memref<4352xui8>  loc(#loc50)
    %direct_w_host_1_cons_buff_1 = aie.buffer(%mem_tile_1_1) {address = 37120 : i32, sym_name = "direct_w_host_1_cons_buff_1"} : memref<4352xui8>  loc(#loc50)
    %direct_w_host_1_cons_prod_lock_0 = aie.lock(%mem_tile_1_1, 0) {init = 2 : i32, sym_name = "direct_w_host_1_cons_prod_lock_0"} loc(#loc50)
    %direct_w_host_1_cons_cons_lock_0 = aie.lock(%mem_tile_1_1, 1) {init = 0 : i32, sym_name = "direct_w_host_1_cons_cons_lock_0"} loc(#loc50)
    %direct_w_host_5_prod_lock_0 = aie.lock(%shim_noc_tile_5_0, 2) {init = 0 : i32, sym_name = "direct_w_host_5_prod_lock_0"} loc(#loc40)
    %direct_w_host_5_cons_lock_0 = aie.lock(%shim_noc_tile_5_0, 3) {init = 0 : i32, sym_name = "direct_w_host_5_cons_lock_0"} loc(#loc40)
    %direct_w_broadcast_5_0_cons_buff_0 = aie.buffer(%tile_5_2) {address = 18432 : i32, sym_name = "direct_w_broadcast_5_0_cons_buff_0"} : memref<4352xui8>  loc(#loc51)
    %direct_w_broadcast_5_0_cons_buff_1 = aie.buffer(%tile_5_2) {address = 22784 : i32, sym_name = "direct_w_broadcast_5_0_cons_buff_1"} : memref<4352xui8>  loc(#loc51)
    %direct_w_broadcast_5_0_cons_prod_lock_0 = aie.lock(%tile_5_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_5_0_cons_prod_lock_0"} loc(#loc51)
    %direct_w_broadcast_5_0_cons_cons_lock_0 = aie.lock(%tile_5_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_5_0_cons_cons_lock_0"} loc(#loc51)
    %direct_w_broadcast_5_1_cons_buff_0 = aie.buffer(%tile_5_3) {address = 18432 : i32, sym_name = "direct_w_broadcast_5_1_cons_buff_0"} : memref<4352xui8>  loc(#loc51)
    %direct_w_broadcast_5_1_cons_buff_1 = aie.buffer(%tile_5_3) {address = 22784 : i32, sym_name = "direct_w_broadcast_5_1_cons_buff_1"} : memref<4352xui8>  loc(#loc51)
    %direct_w_broadcast_5_1_cons_prod_lock_0 = aie.lock(%tile_5_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_5_1_cons_prod_lock_0"} loc(#loc51)
    %direct_w_broadcast_5_1_cons_cons_lock_0 = aie.lock(%tile_5_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_5_1_cons_cons_lock_0"} loc(#loc51)
    %direct_w_broadcast_5_2_cons_buff_0 = aie.buffer(%tile_5_4) {address = 18432 : i32, sym_name = "direct_w_broadcast_5_2_cons_buff_0"} : memref<4352xui8>  loc(#loc51)
    %direct_w_broadcast_5_2_cons_buff_1 = aie.buffer(%tile_5_4) {address = 22784 : i32, sym_name = "direct_w_broadcast_5_2_cons_buff_1"} : memref<4352xui8>  loc(#loc51)
    %direct_w_broadcast_5_2_cons_prod_lock_0 = aie.lock(%tile_5_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_5_2_cons_prod_lock_0"} loc(#loc51)
    %direct_w_broadcast_5_2_cons_cons_lock_0 = aie.lock(%tile_5_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_5_2_cons_cons_lock_0"} loc(#loc51)
    %direct_w_broadcast_5_3_cons_buff_0 = aie.buffer(%tile_5_5) {address = 18432 : i32, sym_name = "direct_w_broadcast_5_3_cons_buff_0"} : memref<4352xui8>  loc(#loc51)
    %direct_w_broadcast_5_3_cons_buff_1 = aie.buffer(%tile_5_5) {address = 22784 : i32, sym_name = "direct_w_broadcast_5_3_cons_buff_1"} : memref<4352xui8>  loc(#loc51)
    %direct_w_broadcast_5_3_cons_prod_lock_0 = aie.lock(%tile_5_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_5_3_cons_prod_lock_0"} loc(#loc51)
    %direct_w_broadcast_5_3_cons_cons_lock_0 = aie.lock(%tile_5_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_5_3_cons_cons_lock_0"} loc(#loc51)
    %direct_w_host_0_cons_buff_0 = aie.buffer(%mem_tile_0_1) {address = 32768 : i32, sym_name = "direct_w_host_0_cons_buff_0"} : memref<4352xui8>  loc(#loc52)
    %direct_w_host_0_cons_buff_1 = aie.buffer(%mem_tile_0_1) {address = 37120 : i32, sym_name = "direct_w_host_0_cons_buff_1"} : memref<4352xui8>  loc(#loc52)
    %direct_w_host_0_cons_prod_lock_0 = aie.lock(%mem_tile_0_1, 0) {init = 2 : i32, sym_name = "direct_w_host_0_cons_prod_lock_0"} loc(#loc52)
    %direct_w_host_0_cons_cons_lock_0 = aie.lock(%mem_tile_0_1, 1) {init = 0 : i32, sym_name = "direct_w_host_0_cons_cons_lock_0"} loc(#loc52)
    %direct_w_host_4_prod_lock_0 = aie.lock(%shim_noc_tile_4_0, 2) {init = 0 : i32, sym_name = "direct_w_host_4_prod_lock_0"} loc(#loc43)
    %direct_w_host_4_cons_lock_0 = aie.lock(%shim_noc_tile_4_0, 3) {init = 0 : i32, sym_name = "direct_w_host_4_cons_lock_0"} loc(#loc43)
    %direct_w_broadcast_4_0_cons_buff_0 = aie.buffer(%tile_4_2) {address = 18432 : i32, sym_name = "direct_w_broadcast_4_0_cons_buff_0"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_0_cons_buff_1 = aie.buffer(%tile_4_2) {address = 22784 : i32, sym_name = "direct_w_broadcast_4_0_cons_buff_1"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_0_cons_prod_lock_0 = aie.lock(%tile_4_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_4_0_cons_prod_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_0_cons_cons_lock_0 = aie.lock(%tile_4_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_4_0_cons_cons_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_1_cons_buff_0 = aie.buffer(%tile_4_3) {address = 18432 : i32, sym_name = "direct_w_broadcast_4_1_cons_buff_0"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_1_cons_buff_1 = aie.buffer(%tile_4_3) {address = 22784 : i32, sym_name = "direct_w_broadcast_4_1_cons_buff_1"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_1_cons_prod_lock_0 = aie.lock(%tile_4_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_4_1_cons_prod_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_1_cons_cons_lock_0 = aie.lock(%tile_4_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_4_1_cons_cons_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_2_cons_buff_0 = aie.buffer(%tile_4_4) {address = 18432 : i32, sym_name = "direct_w_broadcast_4_2_cons_buff_0"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_2_cons_buff_1 = aie.buffer(%tile_4_4) {address = 22784 : i32, sym_name = "direct_w_broadcast_4_2_cons_buff_1"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_2_cons_prod_lock_0 = aie.lock(%tile_4_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_4_2_cons_prod_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_2_cons_cons_lock_0 = aie.lock(%tile_4_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_4_2_cons_cons_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_3_cons_buff_0 = aie.buffer(%tile_4_5) {address = 18432 : i32, sym_name = "direct_w_broadcast_4_3_cons_buff_0"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_3_cons_buff_1 = aie.buffer(%tile_4_5) {address = 22784 : i32, sym_name = "direct_w_broadcast_4_3_cons_buff_1"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_3_cons_prod_lock_0 = aie.lock(%tile_4_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_4_3_cons_prod_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_3_cons_cons_lock_0 = aie.lock(%tile_4_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_4_3_cons_cons_lock_0"} loc(#loc53)
    %direct_y_host_7_buff_0 = aie.buffer(%mem_tile_7_1) {address = 0 : i32, sym_name = "direct_y_host_7_buff_0"} : memref<4096xbf16>  loc(#loc6)
    %direct_y_host_7_buff_1 = aie.buffer(%mem_tile_7_1) {address = 8192 : i32, sym_name = "direct_y_host_7_buff_1"} : memref<4096xbf16>  loc(#loc6)
    %direct_y_host_7_prod_lock_0 = aie.lock(%mem_tile_7_1, 2) {init = 2 : i32, sym_name = "direct_y_host_7_prod_lock_0"} loc(#loc6)
    %direct_y_host_7_cons_lock_0 = aie.lock(%mem_tile_7_1, 3) {init = 0 : i32, sym_name = "direct_y_host_7_cons_lock_0"} loc(#loc6)
    %direct_y_host_7_prod_lock_1 = aie.lock(%mem_tile_7_1, 4) {init = 2 : i32, sym_name = "direct_y_host_7_prod_lock_1"} loc(#loc6)
    %direct_y_host_7_cons_lock_1 = aie.lock(%mem_tile_7_1, 5) {init = 0 : i32, sym_name = "direct_y_host_7_cons_lock_1"} loc(#loc6)
    %direct_y_host_7_prod_lock_2 = aie.lock(%mem_tile_7_1, 6) {init = 2 : i32, sym_name = "direct_y_host_7_prod_lock_2"} loc(#loc6)
    %direct_y_host_7_cons_lock_2 = aie.lock(%mem_tile_7_1, 7) {init = 0 : i32, sym_name = "direct_y_host_7_cons_lock_2"} loc(#loc6)
    %direct_y_host_7_prod_lock_3 = aie.lock(%mem_tile_7_1, 8) {init = 2 : i32, sym_name = "direct_y_host_7_prod_lock_3"} loc(#loc6)
    %direct_y_host_7_cons_lock_3 = aie.lock(%mem_tile_7_1, 9) {init = 0 : i32, sym_name = "direct_y_host_7_cons_lock_3"} loc(#loc6)
    %direct_w_host_3_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 2) {init = 0 : i32, sym_name = "direct_w_host_3_prod_lock_0"} loc(#loc46)
    %direct_w_host_3_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 3) {init = 0 : i32, sym_name = "direct_w_host_3_cons_lock_0"} loc(#loc46)
    %direct_w_broadcast_3_0_cons_buff_0 = aie.buffer(%tile_3_2) {address = 18432 : i32, sym_name = "direct_w_broadcast_3_0_cons_buff_0"} : memref<4352xui8>  loc(#loc54)
    %direct_w_broadcast_3_0_cons_buff_1 = aie.buffer(%tile_3_2) {address = 22784 : i32, sym_name = "direct_w_broadcast_3_0_cons_buff_1"} : memref<4352xui8>  loc(#loc54)
    %direct_w_broadcast_3_0_cons_prod_lock_0 = aie.lock(%tile_3_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_3_0_cons_prod_lock_0"} loc(#loc54)
    %direct_w_broadcast_3_0_cons_cons_lock_0 = aie.lock(%tile_3_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_3_0_cons_cons_lock_0"} loc(#loc54)
    %direct_w_broadcast_3_1_cons_buff_0 = aie.buffer(%tile_3_3) {address = 18432 : i32, sym_name = "direct_w_broadcast_3_1_cons_buff_0"} : memref<4352xui8>  loc(#loc54)
    %direct_w_broadcast_3_1_cons_buff_1 = aie.buffer(%tile_3_3) {address = 22784 : i32, sym_name = "direct_w_broadcast_3_1_cons_buff_1"} : memref<4352xui8>  loc(#loc54)
    %direct_w_broadcast_3_1_cons_prod_lock_0 = aie.lock(%tile_3_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_3_1_cons_prod_lock_0"} loc(#loc54)
    %direct_w_broadcast_3_1_cons_cons_lock_0 = aie.lock(%tile_3_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_3_1_cons_cons_lock_0"} loc(#loc54)
    %direct_w_broadcast_3_2_cons_buff_0 = aie.buffer(%tile_3_4) {address = 18432 : i32, sym_name = "direct_w_broadcast_3_2_cons_buff_0"} : memref<4352xui8>  loc(#loc54)
    %direct_w_broadcast_3_2_cons_buff_1 = aie.buffer(%tile_3_4) {address = 22784 : i32, sym_name = "direct_w_broadcast_3_2_cons_buff_1"} : memref<4352xui8>  loc(#loc54)
    %direct_w_broadcast_3_2_cons_prod_lock_0 = aie.lock(%tile_3_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_3_2_cons_prod_lock_0"} loc(#loc54)
    %direct_w_broadcast_3_2_cons_cons_lock_0 = aie.lock(%tile_3_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_3_2_cons_cons_lock_0"} loc(#loc54)
    %direct_w_broadcast_3_3_cons_buff_0 = aie.buffer(%tile_3_5) {address = 18432 : i32, sym_name = "direct_w_broadcast_3_3_cons_buff_0"} : memref<4352xui8>  loc(#loc54)
    %direct_w_broadcast_3_3_cons_buff_1 = aie.buffer(%tile_3_5) {address = 22784 : i32, sym_name = "direct_w_broadcast_3_3_cons_buff_1"} : memref<4352xui8>  loc(#loc54)
    %direct_w_broadcast_3_3_cons_prod_lock_0 = aie.lock(%tile_3_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_3_3_cons_prod_lock_0"} loc(#loc54)
    %direct_w_broadcast_3_3_cons_cons_lock_0 = aie.lock(%tile_3_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_3_3_cons_cons_lock_0"} loc(#loc54)
    %direct_y_host_6_buff_0 = aie.buffer(%mem_tile_6_1) {address = 0 : i32, sym_name = "direct_y_host_6_buff_0"} : memref<4096xbf16>  loc(#loc11)
    %direct_y_host_6_buff_1 = aie.buffer(%mem_tile_6_1) {address = 8192 : i32, sym_name = "direct_y_host_6_buff_1"} : memref<4096xbf16>  loc(#loc11)
    %direct_y_host_6_prod_lock_0 = aie.lock(%mem_tile_6_1, 2) {init = 2 : i32, sym_name = "direct_y_host_6_prod_lock_0"} loc(#loc11)
    %direct_y_host_6_cons_lock_0 = aie.lock(%mem_tile_6_1, 3) {init = 0 : i32, sym_name = "direct_y_host_6_cons_lock_0"} loc(#loc11)
    %direct_y_host_6_prod_lock_1 = aie.lock(%mem_tile_6_1, 4) {init = 2 : i32, sym_name = "direct_y_host_6_prod_lock_1"} loc(#loc11)
    %direct_y_host_6_cons_lock_1 = aie.lock(%mem_tile_6_1, 5) {init = 0 : i32, sym_name = "direct_y_host_6_cons_lock_1"} loc(#loc11)
    %direct_y_host_6_prod_lock_2 = aie.lock(%mem_tile_6_1, 6) {init = 2 : i32, sym_name = "direct_y_host_6_prod_lock_2"} loc(#loc11)
    %direct_y_host_6_cons_lock_2 = aie.lock(%mem_tile_6_1, 7) {init = 0 : i32, sym_name = "direct_y_host_6_cons_lock_2"} loc(#loc11)
    %direct_y_host_6_prod_lock_3 = aie.lock(%mem_tile_6_1, 8) {init = 2 : i32, sym_name = "direct_y_host_6_prod_lock_3"} loc(#loc11)
    %direct_y_host_6_cons_lock_3 = aie.lock(%mem_tile_6_1, 9) {init = 0 : i32, sym_name = "direct_y_host_6_cons_lock_3"} loc(#loc11)
    %direct_y_host_5_buff_0 = aie.buffer(%mem_tile_5_1) {address = 0 : i32, sym_name = "direct_y_host_5_buff_0"} : memref<4096xbf16>  loc(#loc16)
    %direct_y_host_5_buff_1 = aie.buffer(%mem_tile_5_1) {address = 8192 : i32, sym_name = "direct_y_host_5_buff_1"} : memref<4096xbf16>  loc(#loc16)
    %direct_y_host_5_prod_lock_0 = aie.lock(%mem_tile_5_1, 2) {init = 2 : i32, sym_name = "direct_y_host_5_prod_lock_0"} loc(#loc16)
    %direct_y_host_5_cons_lock_0 = aie.lock(%mem_tile_5_1, 3) {init = 0 : i32, sym_name = "direct_y_host_5_cons_lock_0"} loc(#loc16)
    %direct_y_host_5_prod_lock_1 = aie.lock(%mem_tile_5_1, 4) {init = 2 : i32, sym_name = "direct_y_host_5_prod_lock_1"} loc(#loc16)
    %direct_y_host_5_cons_lock_1 = aie.lock(%mem_tile_5_1, 5) {init = 0 : i32, sym_name = "direct_y_host_5_cons_lock_1"} loc(#loc16)
    %direct_y_host_5_prod_lock_2 = aie.lock(%mem_tile_5_1, 6) {init = 2 : i32, sym_name = "direct_y_host_5_prod_lock_2"} loc(#loc16)
    %direct_y_host_5_cons_lock_2 = aie.lock(%mem_tile_5_1, 7) {init = 0 : i32, sym_name = "direct_y_host_5_cons_lock_2"} loc(#loc16)
    %direct_y_host_5_prod_lock_3 = aie.lock(%mem_tile_5_1, 8) {init = 2 : i32, sym_name = "direct_y_host_5_prod_lock_3"} loc(#loc16)
    %direct_y_host_5_cons_lock_3 = aie.lock(%mem_tile_5_1, 9) {init = 0 : i32, sym_name = "direct_y_host_5_cons_lock_3"} loc(#loc16)
    %direct_w_host_2_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 2) {init = 0 : i32, sym_name = "direct_w_host_2_prod_lock_0"} loc(#loc48)
    %direct_w_host_2_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 3) {init = 0 : i32, sym_name = "direct_w_host_2_cons_lock_0"} loc(#loc48)
    %direct_w_broadcast_2_0_cons_buff_0 = aie.buffer(%tile_2_2) {address = 18432 : i32, sym_name = "direct_w_broadcast_2_0_cons_buff_0"} : memref<4352xui8>  loc(#loc55)
    %direct_w_broadcast_2_0_cons_buff_1 = aie.buffer(%tile_2_2) {address = 22784 : i32, sym_name = "direct_w_broadcast_2_0_cons_buff_1"} : memref<4352xui8>  loc(#loc55)
    %direct_w_broadcast_2_0_cons_prod_lock_0 = aie.lock(%tile_2_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_2_0_cons_prod_lock_0"} loc(#loc55)
    %direct_w_broadcast_2_0_cons_cons_lock_0 = aie.lock(%tile_2_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_2_0_cons_cons_lock_0"} loc(#loc55)
    %direct_w_broadcast_2_1_cons_buff_0 = aie.buffer(%tile_2_3) {address = 18432 : i32, sym_name = "direct_w_broadcast_2_1_cons_buff_0"} : memref<4352xui8>  loc(#loc55)
    %direct_w_broadcast_2_1_cons_buff_1 = aie.buffer(%tile_2_3) {address = 22784 : i32, sym_name = "direct_w_broadcast_2_1_cons_buff_1"} : memref<4352xui8>  loc(#loc55)
    %direct_w_broadcast_2_1_cons_prod_lock_0 = aie.lock(%tile_2_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_2_1_cons_prod_lock_0"} loc(#loc55)
    %direct_w_broadcast_2_1_cons_cons_lock_0 = aie.lock(%tile_2_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_2_1_cons_cons_lock_0"} loc(#loc55)
    %direct_w_broadcast_2_2_cons_buff_0 = aie.buffer(%tile_2_4) {address = 18432 : i32, sym_name = "direct_w_broadcast_2_2_cons_buff_0"} : memref<4352xui8>  loc(#loc55)
    %direct_w_broadcast_2_2_cons_buff_1 = aie.buffer(%tile_2_4) {address = 22784 : i32, sym_name = "direct_w_broadcast_2_2_cons_buff_1"} : memref<4352xui8>  loc(#loc55)
    %direct_w_broadcast_2_2_cons_prod_lock_0 = aie.lock(%tile_2_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_2_2_cons_prod_lock_0"} loc(#loc55)
    %direct_w_broadcast_2_2_cons_cons_lock_0 = aie.lock(%tile_2_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_2_2_cons_cons_lock_0"} loc(#loc55)
    %direct_w_broadcast_2_3_cons_buff_0 = aie.buffer(%tile_2_5) {address = 18432 : i32, sym_name = "direct_w_broadcast_2_3_cons_buff_0"} : memref<4352xui8>  loc(#loc55)
    %direct_w_broadcast_2_3_cons_buff_1 = aie.buffer(%tile_2_5) {address = 22784 : i32, sym_name = "direct_w_broadcast_2_3_cons_buff_1"} : memref<4352xui8>  loc(#loc55)
    %direct_w_broadcast_2_3_cons_prod_lock_0 = aie.lock(%tile_2_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_2_3_cons_prod_lock_0"} loc(#loc55)
    %direct_w_broadcast_2_3_cons_cons_lock_0 = aie.lock(%tile_2_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_2_3_cons_cons_lock_0"} loc(#loc55)
    %direct_y_host_4_buff_0 = aie.buffer(%mem_tile_4_1) {address = 0 : i32, sym_name = "direct_y_host_4_buff_0"} : memref<4096xbf16>  loc(#loc21)
    %direct_y_host_4_buff_1 = aie.buffer(%mem_tile_4_1) {address = 8192 : i32, sym_name = "direct_y_host_4_buff_1"} : memref<4096xbf16>  loc(#loc21)
    %direct_y_host_4_prod_lock_0 = aie.lock(%mem_tile_4_1, 2) {init = 2 : i32, sym_name = "direct_y_host_4_prod_lock_0"} loc(#loc21)
    %direct_y_host_4_cons_lock_0 = aie.lock(%mem_tile_4_1, 3) {init = 0 : i32, sym_name = "direct_y_host_4_cons_lock_0"} loc(#loc21)
    %direct_y_host_4_prod_lock_1 = aie.lock(%mem_tile_4_1, 4) {init = 2 : i32, sym_name = "direct_y_host_4_prod_lock_1"} loc(#loc21)
    %direct_y_host_4_cons_lock_1 = aie.lock(%mem_tile_4_1, 5) {init = 0 : i32, sym_name = "direct_y_host_4_cons_lock_1"} loc(#loc21)
    %direct_y_host_4_prod_lock_2 = aie.lock(%mem_tile_4_1, 6) {init = 2 : i32, sym_name = "direct_y_host_4_prod_lock_2"} loc(#loc21)
    %direct_y_host_4_cons_lock_2 = aie.lock(%mem_tile_4_1, 7) {init = 0 : i32, sym_name = "direct_y_host_4_cons_lock_2"} loc(#loc21)
    %direct_y_host_4_prod_lock_3 = aie.lock(%mem_tile_4_1, 8) {init = 2 : i32, sym_name = "direct_y_host_4_prod_lock_3"} loc(#loc21)
    %direct_y_host_4_cons_lock_3 = aie.lock(%mem_tile_4_1, 9) {init = 0 : i32, sym_name = "direct_y_host_4_cons_lock_3"} loc(#loc21)
    %direct_y_host_3_buff_0 = aie.buffer(%mem_tile_3_1) {address = 0 : i32, sym_name = "direct_y_host_3_buff_0"} : memref<4096xbf16>  loc(#loc26)
    %direct_y_host_3_buff_1 = aie.buffer(%mem_tile_3_1) {address = 8192 : i32, sym_name = "direct_y_host_3_buff_1"} : memref<4096xbf16>  loc(#loc26)
    %direct_y_host_3_prod_lock_0 = aie.lock(%mem_tile_3_1, 2) {init = 2 : i32, sym_name = "direct_y_host_3_prod_lock_0"} loc(#loc26)
    %direct_y_host_3_cons_lock_0 = aie.lock(%mem_tile_3_1, 3) {init = 0 : i32, sym_name = "direct_y_host_3_cons_lock_0"} loc(#loc26)
    %direct_y_host_3_prod_lock_1 = aie.lock(%mem_tile_3_1, 4) {init = 2 : i32, sym_name = "direct_y_host_3_prod_lock_1"} loc(#loc26)
    %direct_y_host_3_cons_lock_1 = aie.lock(%mem_tile_3_1, 5) {init = 0 : i32, sym_name = "direct_y_host_3_cons_lock_1"} loc(#loc26)
    %direct_y_host_3_prod_lock_2 = aie.lock(%mem_tile_3_1, 6) {init = 2 : i32, sym_name = "direct_y_host_3_prod_lock_2"} loc(#loc26)
    %direct_y_host_3_cons_lock_2 = aie.lock(%mem_tile_3_1, 7) {init = 0 : i32, sym_name = "direct_y_host_3_cons_lock_2"} loc(#loc26)
    %direct_y_host_3_prod_lock_3 = aie.lock(%mem_tile_3_1, 8) {init = 2 : i32, sym_name = "direct_y_host_3_prod_lock_3"} loc(#loc26)
    %direct_y_host_3_cons_lock_3 = aie.lock(%mem_tile_3_1, 9) {init = 0 : i32, sym_name = "direct_y_host_3_cons_lock_3"} loc(#loc26)
    %direct_w_host_1_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 2) {init = 0 : i32, sym_name = "direct_w_host_1_prod_lock_0"} loc(#loc50)
    %direct_w_host_1_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 3) {init = 0 : i32, sym_name = "direct_w_host_1_cons_lock_0"} loc(#loc50)
    %direct_w_broadcast_1_0_cons_buff_0 = aie.buffer(%tile_1_2) {address = 18432 : i32, sym_name = "direct_w_broadcast_1_0_cons_buff_0"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_1_0_cons_buff_1 = aie.buffer(%tile_1_2) {address = 22784 : i32, sym_name = "direct_w_broadcast_1_0_cons_buff_1"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_1_0_cons_prod_lock_0 = aie.lock(%tile_1_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_1_0_cons_prod_lock_0"} loc(#loc56)
    %direct_w_broadcast_1_0_cons_cons_lock_0 = aie.lock(%tile_1_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_1_0_cons_cons_lock_0"} loc(#loc56)
    %direct_w_broadcast_1_1_cons_buff_0 = aie.buffer(%tile_1_3) {address = 18432 : i32, sym_name = "direct_w_broadcast_1_1_cons_buff_0"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_1_1_cons_buff_1 = aie.buffer(%tile_1_3) {address = 22784 : i32, sym_name = "direct_w_broadcast_1_1_cons_buff_1"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_1_1_cons_prod_lock_0 = aie.lock(%tile_1_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_1_1_cons_prod_lock_0"} loc(#loc56)
    %direct_w_broadcast_1_1_cons_cons_lock_0 = aie.lock(%tile_1_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_1_1_cons_cons_lock_0"} loc(#loc56)
    %direct_w_broadcast_1_2_cons_buff_0 = aie.buffer(%tile_1_4) {address = 18432 : i32, sym_name = "direct_w_broadcast_1_2_cons_buff_0"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_1_2_cons_buff_1 = aie.buffer(%tile_1_4) {address = 22784 : i32, sym_name = "direct_w_broadcast_1_2_cons_buff_1"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_1_2_cons_prod_lock_0 = aie.lock(%tile_1_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_1_2_cons_prod_lock_0"} loc(#loc56)
    %direct_w_broadcast_1_2_cons_cons_lock_0 = aie.lock(%tile_1_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_1_2_cons_cons_lock_0"} loc(#loc56)
    %direct_w_broadcast_1_3_cons_buff_0 = aie.buffer(%tile_1_5) {address = 18432 : i32, sym_name = "direct_w_broadcast_1_3_cons_buff_0"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_1_3_cons_buff_1 = aie.buffer(%tile_1_5) {address = 22784 : i32, sym_name = "direct_w_broadcast_1_3_cons_buff_1"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_1_3_cons_prod_lock_0 = aie.lock(%tile_1_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_1_3_cons_prod_lock_0"} loc(#loc56)
    %direct_w_broadcast_1_3_cons_cons_lock_0 = aie.lock(%tile_1_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_1_3_cons_cons_lock_0"} loc(#loc56)
    %direct_y_host_2_buff_0 = aie.buffer(%mem_tile_2_1) {address = 0 : i32, sym_name = "direct_y_host_2_buff_0"} : memref<4096xbf16>  loc(#loc31)
    %direct_y_host_2_buff_1 = aie.buffer(%mem_tile_2_1) {address = 8192 : i32, sym_name = "direct_y_host_2_buff_1"} : memref<4096xbf16>  loc(#loc31)
    %direct_y_host_2_prod_lock_0 = aie.lock(%mem_tile_2_1, 2) {init = 2 : i32, sym_name = "direct_y_host_2_prod_lock_0"} loc(#loc31)
    %direct_y_host_2_cons_lock_0 = aie.lock(%mem_tile_2_1, 3) {init = 0 : i32, sym_name = "direct_y_host_2_cons_lock_0"} loc(#loc31)
    %direct_y_host_2_prod_lock_1 = aie.lock(%mem_tile_2_1, 4) {init = 2 : i32, sym_name = "direct_y_host_2_prod_lock_1"} loc(#loc31)
    %direct_y_host_2_cons_lock_1 = aie.lock(%mem_tile_2_1, 5) {init = 0 : i32, sym_name = "direct_y_host_2_cons_lock_1"} loc(#loc31)
    %direct_y_host_2_prod_lock_2 = aie.lock(%mem_tile_2_1, 6) {init = 2 : i32, sym_name = "direct_y_host_2_prod_lock_2"} loc(#loc31)
    %direct_y_host_2_cons_lock_2 = aie.lock(%mem_tile_2_1, 7) {init = 0 : i32, sym_name = "direct_y_host_2_cons_lock_2"} loc(#loc31)
    %direct_y_host_2_prod_lock_3 = aie.lock(%mem_tile_2_1, 8) {init = 2 : i32, sym_name = "direct_y_host_2_prod_lock_3"} loc(#loc31)
    %direct_y_host_2_cons_lock_3 = aie.lock(%mem_tile_2_1, 9) {init = 0 : i32, sym_name = "direct_y_host_2_cons_lock_3"} loc(#loc31)
    %direct_y_host_1_buff_0 = aie.buffer(%mem_tile_1_1) {address = 0 : i32, sym_name = "direct_y_host_1_buff_0"} : memref<4096xbf16>  loc(#loc37)
    %direct_y_host_1_buff_1 = aie.buffer(%mem_tile_1_1) {address = 8192 : i32, sym_name = "direct_y_host_1_buff_1"} : memref<4096xbf16>  loc(#loc37)
    %direct_y_host_1_prod_lock_0 = aie.lock(%mem_tile_1_1, 2) {init = 2 : i32, sym_name = "direct_y_host_1_prod_lock_0"} loc(#loc37)
    %direct_y_host_1_cons_lock_0 = aie.lock(%mem_tile_1_1, 3) {init = 0 : i32, sym_name = "direct_y_host_1_cons_lock_0"} loc(#loc37)
    %direct_y_host_1_prod_lock_1 = aie.lock(%mem_tile_1_1, 4) {init = 2 : i32, sym_name = "direct_y_host_1_prod_lock_1"} loc(#loc37)
    %direct_y_host_1_cons_lock_1 = aie.lock(%mem_tile_1_1, 5) {init = 0 : i32, sym_name = "direct_y_host_1_cons_lock_1"} loc(#loc37)
    %direct_y_host_1_prod_lock_2 = aie.lock(%mem_tile_1_1, 6) {init = 2 : i32, sym_name = "direct_y_host_1_prod_lock_2"} loc(#loc37)
    %direct_y_host_1_cons_lock_2 = aie.lock(%mem_tile_1_1, 7) {init = 0 : i32, sym_name = "direct_y_host_1_cons_lock_2"} loc(#loc37)
    %direct_y_host_1_prod_lock_3 = aie.lock(%mem_tile_1_1, 8) {init = 2 : i32, sym_name = "direct_y_host_1_prod_lock_3"} loc(#loc37)
    %direct_y_host_1_cons_lock_3 = aie.lock(%mem_tile_1_1, 9) {init = 0 : i32, sym_name = "direct_y_host_1_cons_lock_3"} loc(#loc37)
    %direct_w_host_0_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 2) {init = 0 : i32, sym_name = "direct_w_host_0_prod_lock_0"} loc(#loc52)
    %direct_w_host_0_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 3) {init = 0 : i32, sym_name = "direct_w_host_0_cons_lock_0"} loc(#loc52)
    %direct_w_broadcast_0_0_cons_buff_0 = aie.buffer(%tile_0_2) {address = 18432 : i32, sym_name = "direct_w_broadcast_0_0_cons_buff_0"} : memref<4352xui8>  loc(#loc57)
    %direct_w_broadcast_0_0_cons_buff_1 = aie.buffer(%tile_0_2) {address = 22784 : i32, sym_name = "direct_w_broadcast_0_0_cons_buff_1"} : memref<4352xui8>  loc(#loc57)
    %direct_w_broadcast_0_0_cons_prod_lock_0 = aie.lock(%tile_0_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_0_0_cons_prod_lock_0"} loc(#loc57)
    %direct_w_broadcast_0_0_cons_cons_lock_0 = aie.lock(%tile_0_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_0_0_cons_cons_lock_0"} loc(#loc57)
    %direct_w_broadcast_0_1_cons_buff_0 = aie.buffer(%tile_0_3) {address = 18432 : i32, sym_name = "direct_w_broadcast_0_1_cons_buff_0"} : memref<4352xui8>  loc(#loc57)
    %direct_w_broadcast_0_1_cons_buff_1 = aie.buffer(%tile_0_3) {address = 22784 : i32, sym_name = "direct_w_broadcast_0_1_cons_buff_1"} : memref<4352xui8>  loc(#loc57)
    %direct_w_broadcast_0_1_cons_prod_lock_0 = aie.lock(%tile_0_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_0_1_cons_prod_lock_0"} loc(#loc57)
    %direct_w_broadcast_0_1_cons_cons_lock_0 = aie.lock(%tile_0_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_0_1_cons_cons_lock_0"} loc(#loc57)
    %direct_w_broadcast_0_2_cons_buff_0 = aie.buffer(%tile_0_4) {address = 18432 : i32, sym_name = "direct_w_broadcast_0_2_cons_buff_0"} : memref<4352xui8>  loc(#loc57)
    %direct_w_broadcast_0_2_cons_buff_1 = aie.buffer(%tile_0_4) {address = 22784 : i32, sym_name = "direct_w_broadcast_0_2_cons_buff_1"} : memref<4352xui8>  loc(#loc57)
    %direct_w_broadcast_0_2_cons_prod_lock_0 = aie.lock(%tile_0_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_0_2_cons_prod_lock_0"} loc(#loc57)
    %direct_w_broadcast_0_2_cons_cons_lock_0 = aie.lock(%tile_0_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_0_2_cons_cons_lock_0"} loc(#loc57)
    %direct_w_broadcast_0_3_cons_buff_0 = aie.buffer(%tile_0_5) {address = 18432 : i32, sym_name = "direct_w_broadcast_0_3_cons_buff_0"} : memref<4352xui8>  loc(#loc57)
    %direct_w_broadcast_0_3_cons_buff_1 = aie.buffer(%tile_0_5) {address = 22784 : i32, sym_name = "direct_w_broadcast_0_3_cons_buff_1"} : memref<4352xui8>  loc(#loc57)
    %direct_w_broadcast_0_3_cons_prod_lock_0 = aie.lock(%tile_0_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_0_3_cons_prod_lock_0"} loc(#loc57)
    %direct_w_broadcast_0_3_cons_cons_lock_0 = aie.lock(%tile_0_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_0_3_cons_cons_lock_0"} loc(#loc57)
    %direct_y_host_0_buff_0 = aie.buffer(%mem_tile_0_1) {address = 0 : i32, sym_name = "direct_y_host_0_buff_0"} : memref<4096xbf16>  loc(#loc45)
    %direct_y_host_0_buff_1 = aie.buffer(%mem_tile_0_1) {address = 8192 : i32, sym_name = "direct_y_host_0_buff_1"} : memref<4096xbf16>  loc(#loc45)
    %direct_y_host_0_prod_lock_0 = aie.lock(%mem_tile_0_1, 2) {init = 2 : i32, sym_name = "direct_y_host_0_prod_lock_0"} loc(#loc45)
    %direct_y_host_0_cons_lock_0 = aie.lock(%mem_tile_0_1, 3) {init = 0 : i32, sym_name = "direct_y_host_0_cons_lock_0"} loc(#loc45)
    %direct_y_host_0_prod_lock_1 = aie.lock(%mem_tile_0_1, 4) {init = 2 : i32, sym_name = "direct_y_host_0_prod_lock_1"} loc(#loc45)
    %direct_y_host_0_cons_lock_1 = aie.lock(%mem_tile_0_1, 5) {init = 0 : i32, sym_name = "direct_y_host_0_cons_lock_1"} loc(#loc45)
    %direct_y_host_0_prod_lock_2 = aie.lock(%mem_tile_0_1, 6) {init = 2 : i32, sym_name = "direct_y_host_0_prod_lock_2"} loc(#loc45)
    %direct_y_host_0_cons_lock_2 = aie.lock(%mem_tile_0_1, 7) {init = 0 : i32, sym_name = "direct_y_host_0_cons_lock_2"} loc(#loc45)
    %direct_y_host_0_prod_lock_3 = aie.lock(%mem_tile_0_1, 8) {init = 2 : i32, sym_name = "direct_y_host_0_prod_lock_3"} loc(#loc45)
    %direct_y_host_0_cons_lock_3 = aie.lock(%mem_tile_0_1, 9) {init = 0 : i32, sym_name = "direct_y_host_0_cons_lock_3"} loc(#loc45)
    %direct_a_host_3_cons_buff_0 = aie.buffer(%mem_tile_3_1) {address = 16384 : i32, sym_name = "direct_a_host_3_cons_buff_0"} : memref<4096xbf16>  loc(#loc58)
    %direct_a_host_3_cons_buff_1 = aie.buffer(%mem_tile_3_1) {address = 24576 : i32, sym_name = "direct_a_host_3_cons_buff_1"} : memref<4096xbf16>  loc(#loc58)
    %direct_a_host_3_cons_prod_lock_0 = aie.lock(%mem_tile_3_1, 10) {init = 2 : i32, sym_name = "direct_a_host_3_cons_prod_lock_0"} loc(#loc58)
    %direct_a_host_3_cons_cons_lock_0 = aie.lock(%mem_tile_3_1, 11) {init = 0 : i32, sym_name = "direct_a_host_3_cons_cons_lock_0"} loc(#loc58)
    %direct_a_host_3_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 4) {init = 0 : i32, sym_name = "direct_a_host_3_prod_lock_0"} loc(#loc58)
    %direct_a_host_3_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 5) {init = 0 : i32, sym_name = "direct_a_host_3_cons_lock_0"} loc(#loc58)
    %direct_a_broadcast_3_0_cons_buff_0 = aie.buffer(%tile_0_5) {address = 2048 : i32, sym_name = "direct_a_broadcast_3_0_cons_buff_0"} : memref<4096xbf16>  loc(#loc59)
    %direct_a_broadcast_3_0_cons_prod_lock_0 = aie.lock(%tile_0_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_0_cons_prod_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_0_cons_cons_lock_0 = aie.lock(%tile_0_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_0_cons_cons_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_1_cons_buff_0 = aie.buffer(%tile_1_5) {address = 2048 : i32, sym_name = "direct_a_broadcast_3_1_cons_buff_0"} : memref<4096xbf16>  loc(#loc59)
    %direct_a_broadcast_3_1_cons_prod_lock_0 = aie.lock(%tile_1_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_1_cons_prod_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_1_cons_cons_lock_0 = aie.lock(%tile_1_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_1_cons_cons_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_2_cons_buff_0 = aie.buffer(%tile_2_5) {address = 2048 : i32, sym_name = "direct_a_broadcast_3_2_cons_buff_0"} : memref<4096xbf16>  loc(#loc59)
    %direct_a_broadcast_3_2_cons_prod_lock_0 = aie.lock(%tile_2_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_2_cons_prod_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_2_cons_cons_lock_0 = aie.lock(%tile_2_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_2_cons_cons_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_3_cons_buff_0 = aie.buffer(%tile_3_5) {address = 2048 : i32, sym_name = "direct_a_broadcast_3_3_cons_buff_0"} : memref<4096xbf16>  loc(#loc59)
    %direct_a_broadcast_3_3_cons_prod_lock_0 = aie.lock(%tile_3_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_3_cons_prod_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_3_cons_cons_lock_0 = aie.lock(%tile_3_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_3_cons_cons_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_4_cons_buff_0 = aie.buffer(%tile_4_5) {address = 2048 : i32, sym_name = "direct_a_broadcast_3_4_cons_buff_0"} : memref<4096xbf16>  loc(#loc59)
    %direct_a_broadcast_3_4_cons_prod_lock_0 = aie.lock(%tile_4_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_4_cons_prod_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_4_cons_cons_lock_0 = aie.lock(%tile_4_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_4_cons_cons_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_5_cons_buff_0 = aie.buffer(%tile_5_5) {address = 2048 : i32, sym_name = "direct_a_broadcast_3_5_cons_buff_0"} : memref<4096xbf16>  loc(#loc59)
    %direct_a_broadcast_3_5_cons_prod_lock_0 = aie.lock(%tile_5_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_5_cons_prod_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_5_cons_cons_lock_0 = aie.lock(%tile_5_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_5_cons_cons_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_6_cons_buff_0 = aie.buffer(%tile_6_5) {address = 2048 : i32, sym_name = "direct_a_broadcast_3_6_cons_buff_0"} : memref<4096xbf16>  loc(#loc59)
    %direct_a_broadcast_3_6_cons_prod_lock_0 = aie.lock(%tile_6_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_6_cons_prod_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_6_cons_cons_lock_0 = aie.lock(%tile_6_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_6_cons_cons_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_7_cons_buff_0 = aie.buffer(%tile_7_5) {address = 2048 : i32, sym_name = "direct_a_broadcast_3_7_cons_buff_0"} : memref<4096xbf16>  loc(#loc59)
    %direct_a_broadcast_3_7_cons_prod_lock_0 = aie.lock(%tile_7_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_7_cons_prod_lock_0"} loc(#loc59)
    %direct_a_broadcast_3_7_cons_cons_lock_0 = aie.lock(%tile_7_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_7_cons_cons_lock_0"} loc(#loc59)
    %direct_a_host_2_cons_buff_0 = aie.buffer(%mem_tile_2_1) {address = 16384 : i32, sym_name = "direct_a_host_2_cons_buff_0"} : memref<4096xbf16>  loc(#loc60)
    %direct_a_host_2_cons_buff_1 = aie.buffer(%mem_tile_2_1) {address = 24576 : i32, sym_name = "direct_a_host_2_cons_buff_1"} : memref<4096xbf16>  loc(#loc60)
    %direct_a_host_2_cons_prod_lock_0 = aie.lock(%mem_tile_2_1, 10) {init = 2 : i32, sym_name = "direct_a_host_2_cons_prod_lock_0"} loc(#loc60)
    %direct_a_host_2_cons_cons_lock_0 = aie.lock(%mem_tile_2_1, 11) {init = 0 : i32, sym_name = "direct_a_host_2_cons_cons_lock_0"} loc(#loc60)
    %direct_a_host_2_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 4) {init = 0 : i32, sym_name = "direct_a_host_2_prod_lock_0"} loc(#loc60)
    %direct_a_host_2_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 5) {init = 0 : i32, sym_name = "direct_a_host_2_cons_lock_0"} loc(#loc60)
    %direct_a_broadcast_2_0_cons_buff_0 = aie.buffer(%tile_0_4) {address = 2048 : i32, sym_name = "direct_a_broadcast_2_0_cons_buff_0"} : memref<4096xbf16>  loc(#loc61)
    %direct_a_broadcast_2_0_cons_prod_lock_0 = aie.lock(%tile_0_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_0_cons_prod_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_0_cons_cons_lock_0 = aie.lock(%tile_0_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_0_cons_cons_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_1_cons_buff_0 = aie.buffer(%tile_1_4) {address = 2048 : i32, sym_name = "direct_a_broadcast_2_1_cons_buff_0"} : memref<4096xbf16>  loc(#loc61)
    %direct_a_broadcast_2_1_cons_prod_lock_0 = aie.lock(%tile_1_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_1_cons_prod_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_1_cons_cons_lock_0 = aie.lock(%tile_1_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_1_cons_cons_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_2_cons_buff_0 = aie.buffer(%tile_2_4) {address = 2048 : i32, sym_name = "direct_a_broadcast_2_2_cons_buff_0"} : memref<4096xbf16>  loc(#loc61)
    %direct_a_broadcast_2_2_cons_prod_lock_0 = aie.lock(%tile_2_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_2_cons_prod_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_2_cons_cons_lock_0 = aie.lock(%tile_2_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_2_cons_cons_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_3_cons_buff_0 = aie.buffer(%tile_3_4) {address = 2048 : i32, sym_name = "direct_a_broadcast_2_3_cons_buff_0"} : memref<4096xbf16>  loc(#loc61)
    %direct_a_broadcast_2_3_cons_prod_lock_0 = aie.lock(%tile_3_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_3_cons_prod_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_3_cons_cons_lock_0 = aie.lock(%tile_3_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_3_cons_cons_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_4_cons_buff_0 = aie.buffer(%tile_4_4) {address = 2048 : i32, sym_name = "direct_a_broadcast_2_4_cons_buff_0"} : memref<4096xbf16>  loc(#loc61)
    %direct_a_broadcast_2_4_cons_prod_lock_0 = aie.lock(%tile_4_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_4_cons_prod_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_4_cons_cons_lock_0 = aie.lock(%tile_4_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_4_cons_cons_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_5_cons_buff_0 = aie.buffer(%tile_5_4) {address = 2048 : i32, sym_name = "direct_a_broadcast_2_5_cons_buff_0"} : memref<4096xbf16>  loc(#loc61)
    %direct_a_broadcast_2_5_cons_prod_lock_0 = aie.lock(%tile_5_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_5_cons_prod_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_5_cons_cons_lock_0 = aie.lock(%tile_5_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_5_cons_cons_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_6_cons_buff_0 = aie.buffer(%tile_6_4) {address = 2048 : i32, sym_name = "direct_a_broadcast_2_6_cons_buff_0"} : memref<4096xbf16>  loc(#loc61)
    %direct_a_broadcast_2_6_cons_prod_lock_0 = aie.lock(%tile_6_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_6_cons_prod_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_6_cons_cons_lock_0 = aie.lock(%tile_6_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_6_cons_cons_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_7_cons_buff_0 = aie.buffer(%tile_7_4) {address = 2048 : i32, sym_name = "direct_a_broadcast_2_7_cons_buff_0"} : memref<4096xbf16>  loc(#loc61)
    %direct_a_broadcast_2_7_cons_prod_lock_0 = aie.lock(%tile_7_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_7_cons_prod_lock_0"} loc(#loc61)
    %direct_a_broadcast_2_7_cons_cons_lock_0 = aie.lock(%tile_7_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_7_cons_cons_lock_0"} loc(#loc61)
    %direct_a_host_1_cons_buff_0 = aie.buffer(%mem_tile_1_1) {address = 16384 : i32, sym_name = "direct_a_host_1_cons_buff_0"} : memref<4096xbf16>  loc(#loc62)
    %direct_a_host_1_cons_buff_1 = aie.buffer(%mem_tile_1_1) {address = 24576 : i32, sym_name = "direct_a_host_1_cons_buff_1"} : memref<4096xbf16>  loc(#loc62)
    %direct_a_host_1_cons_prod_lock_0 = aie.lock(%mem_tile_1_1, 10) {init = 2 : i32, sym_name = "direct_a_host_1_cons_prod_lock_0"} loc(#loc62)
    %direct_a_host_1_cons_cons_lock_0 = aie.lock(%mem_tile_1_1, 11) {init = 0 : i32, sym_name = "direct_a_host_1_cons_cons_lock_0"} loc(#loc62)
    %direct_a_host_1_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 4) {init = 0 : i32, sym_name = "direct_a_host_1_prod_lock_0"} loc(#loc62)
    %direct_a_host_1_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 5) {init = 0 : i32, sym_name = "direct_a_host_1_cons_lock_0"} loc(#loc62)
    %direct_a_broadcast_1_0_cons_buff_0 = aie.buffer(%tile_0_3) {address = 2048 : i32, sym_name = "direct_a_broadcast_1_0_cons_buff_0"} : memref<4096xbf16>  loc(#loc63)
    %direct_a_broadcast_1_0_cons_prod_lock_0 = aie.lock(%tile_0_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_0_cons_prod_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_0_cons_cons_lock_0 = aie.lock(%tile_0_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_0_cons_cons_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_1_cons_buff_0 = aie.buffer(%tile_1_3) {address = 2048 : i32, sym_name = "direct_a_broadcast_1_1_cons_buff_0"} : memref<4096xbf16>  loc(#loc63)
    %direct_a_broadcast_1_1_cons_prod_lock_0 = aie.lock(%tile_1_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_1_cons_prod_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_1_cons_cons_lock_0 = aie.lock(%tile_1_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_1_cons_cons_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_2_cons_buff_0 = aie.buffer(%tile_2_3) {address = 2048 : i32, sym_name = "direct_a_broadcast_1_2_cons_buff_0"} : memref<4096xbf16>  loc(#loc63)
    %direct_a_broadcast_1_2_cons_prod_lock_0 = aie.lock(%tile_2_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_2_cons_prod_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_2_cons_cons_lock_0 = aie.lock(%tile_2_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_2_cons_cons_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_3_cons_buff_0 = aie.buffer(%tile_3_3) {address = 2048 : i32, sym_name = "direct_a_broadcast_1_3_cons_buff_0"} : memref<4096xbf16>  loc(#loc63)
    %direct_a_broadcast_1_3_cons_prod_lock_0 = aie.lock(%tile_3_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_3_cons_prod_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_3_cons_cons_lock_0 = aie.lock(%tile_3_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_3_cons_cons_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_4_cons_buff_0 = aie.buffer(%tile_4_3) {address = 2048 : i32, sym_name = "direct_a_broadcast_1_4_cons_buff_0"} : memref<4096xbf16>  loc(#loc63)
    %direct_a_broadcast_1_4_cons_prod_lock_0 = aie.lock(%tile_4_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_4_cons_prod_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_4_cons_cons_lock_0 = aie.lock(%tile_4_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_4_cons_cons_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_5_cons_buff_0 = aie.buffer(%tile_5_3) {address = 2048 : i32, sym_name = "direct_a_broadcast_1_5_cons_buff_0"} : memref<4096xbf16>  loc(#loc63)
    %direct_a_broadcast_1_5_cons_prod_lock_0 = aie.lock(%tile_5_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_5_cons_prod_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_5_cons_cons_lock_0 = aie.lock(%tile_5_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_5_cons_cons_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_6_cons_buff_0 = aie.buffer(%tile_6_3) {address = 2048 : i32, sym_name = "direct_a_broadcast_1_6_cons_buff_0"} : memref<4096xbf16>  loc(#loc63)
    %direct_a_broadcast_1_6_cons_prod_lock_0 = aie.lock(%tile_6_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_6_cons_prod_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_6_cons_cons_lock_0 = aie.lock(%tile_6_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_6_cons_cons_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_7_cons_buff_0 = aie.buffer(%tile_7_3) {address = 2048 : i32, sym_name = "direct_a_broadcast_1_7_cons_buff_0"} : memref<4096xbf16>  loc(#loc63)
    %direct_a_broadcast_1_7_cons_prod_lock_0 = aie.lock(%tile_7_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_7_cons_prod_lock_0"} loc(#loc63)
    %direct_a_broadcast_1_7_cons_cons_lock_0 = aie.lock(%tile_7_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_7_cons_cons_lock_0"} loc(#loc63)
    %direct_a_host_0_cons_buff_0 = aie.buffer(%mem_tile_0_1) {address = 16384 : i32, sym_name = "direct_a_host_0_cons_buff_0"} : memref<4096xbf16>  loc(#loc64)
    %direct_a_host_0_cons_buff_1 = aie.buffer(%mem_tile_0_1) {address = 24576 : i32, sym_name = "direct_a_host_0_cons_buff_1"} : memref<4096xbf16>  loc(#loc64)
    %direct_a_host_0_cons_prod_lock_0 = aie.lock(%mem_tile_0_1, 10) {init = 2 : i32, sym_name = "direct_a_host_0_cons_prod_lock_0"} loc(#loc64)
    %direct_a_host_0_cons_cons_lock_0 = aie.lock(%mem_tile_0_1, 11) {init = 0 : i32, sym_name = "direct_a_host_0_cons_cons_lock_0"} loc(#loc64)
    %direct_a_host_0_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 4) {init = 0 : i32, sym_name = "direct_a_host_0_prod_lock_0"} loc(#loc64)
    %direct_a_host_0_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 5) {init = 0 : i32, sym_name = "direct_a_host_0_cons_lock_0"} loc(#loc64)
    %direct_a_broadcast_0_0_cons_buff_0 = aie.buffer(%tile_0_2) {address = 2048 : i32, sym_name = "direct_a_broadcast_0_0_cons_buff_0"} : memref<4096xbf16>  loc(#loc65)
    %direct_a_broadcast_0_0_cons_prod_lock_0 = aie.lock(%tile_0_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_0_cons_prod_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_0_cons_cons_lock_0 = aie.lock(%tile_0_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_0_cons_cons_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_1_cons_buff_0 = aie.buffer(%tile_1_2) {address = 2048 : i32, sym_name = "direct_a_broadcast_0_1_cons_buff_0"} : memref<4096xbf16>  loc(#loc65)
    %direct_a_broadcast_0_1_cons_prod_lock_0 = aie.lock(%tile_1_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_1_cons_prod_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_1_cons_cons_lock_0 = aie.lock(%tile_1_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_1_cons_cons_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_2_cons_buff_0 = aie.buffer(%tile_2_2) {address = 2048 : i32, sym_name = "direct_a_broadcast_0_2_cons_buff_0"} : memref<4096xbf16>  loc(#loc65)
    %direct_a_broadcast_0_2_cons_prod_lock_0 = aie.lock(%tile_2_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_2_cons_prod_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_2_cons_cons_lock_0 = aie.lock(%tile_2_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_2_cons_cons_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_3_cons_buff_0 = aie.buffer(%tile_3_2) {address = 2048 : i32, sym_name = "direct_a_broadcast_0_3_cons_buff_0"} : memref<4096xbf16>  loc(#loc65)
    %direct_a_broadcast_0_3_cons_prod_lock_0 = aie.lock(%tile_3_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_3_cons_prod_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_3_cons_cons_lock_0 = aie.lock(%tile_3_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_3_cons_cons_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_4_cons_buff_0 = aie.buffer(%tile_4_2) {address = 2048 : i32, sym_name = "direct_a_broadcast_0_4_cons_buff_0"} : memref<4096xbf16>  loc(#loc65)
    %direct_a_broadcast_0_4_cons_prod_lock_0 = aie.lock(%tile_4_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_4_cons_prod_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_4_cons_cons_lock_0 = aie.lock(%tile_4_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_4_cons_cons_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_5_cons_buff_0 = aie.buffer(%tile_5_2) {address = 2048 : i32, sym_name = "direct_a_broadcast_0_5_cons_buff_0"} : memref<4096xbf16>  loc(#loc65)
    %direct_a_broadcast_0_5_cons_prod_lock_0 = aie.lock(%tile_5_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_5_cons_prod_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_5_cons_cons_lock_0 = aie.lock(%tile_5_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_5_cons_cons_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_6_cons_buff_0 = aie.buffer(%tile_6_2) {address = 2048 : i32, sym_name = "direct_a_broadcast_0_6_cons_buff_0"} : memref<4096xbf16>  loc(#loc65)
    %direct_a_broadcast_0_6_cons_prod_lock_0 = aie.lock(%tile_6_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_6_cons_prod_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_6_cons_cons_lock_0 = aie.lock(%tile_6_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_6_cons_cons_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_7_cons_buff_0 = aie.buffer(%tile_7_2) {address = 2048 : i32, sym_name = "direct_a_broadcast_0_7_cons_buff_0"} : memref<4096xbf16>  loc(#loc65)
    %direct_a_broadcast_0_7_cons_prod_lock_0 = aie.lock(%tile_7_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_7_cons_prod_lock_0"} loc(#loc65)
    %direct_a_broadcast_0_7_cons_cons_lock_0 = aie.lock(%tile_7_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_7_cons_cons_lock_0"} loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_7_2, DMA : 0) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_6_2, DMA : 0) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_5_2, DMA : 0) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_4_2, DMA : 0) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_3_2, DMA : 0) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_2_2, DMA : 0) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_1_2, DMA : 0) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_0_2, DMA : 0) loc(#loc65)
    aie.flow(%shim_noc_tile_0_0, DMA : 0, %mem_tile_0_1, DMA : 0) loc(#loc64)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_7_3, DMA : 0) loc(#loc63)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_6_3, DMA : 0) loc(#loc63)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_5_3, DMA : 0) loc(#loc63)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_4_3, DMA : 0) loc(#loc63)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_3_3, DMA : 0) loc(#loc63)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_2_3, DMA : 0) loc(#loc63)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_1_3, DMA : 0) loc(#loc63)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_0_3, DMA : 0) loc(#loc63)
    aie.flow(%shim_noc_tile_1_0, DMA : 0, %mem_tile_1_1, DMA : 0) loc(#loc62)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_7_4, DMA : 0) loc(#loc61)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_6_4, DMA : 0) loc(#loc61)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_5_4, DMA : 0) loc(#loc61)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_4_4, DMA : 0) loc(#loc61)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_3_4, DMA : 0) loc(#loc61)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_2_4, DMA : 0) loc(#loc61)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_1_4, DMA : 0) loc(#loc61)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_0_4, DMA : 0) loc(#loc61)
    aie.flow(%shim_noc_tile_2_0, DMA : 0, %mem_tile_2_1, DMA : 0) loc(#loc60)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_7_5, DMA : 0) loc(#loc59)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_6_5, DMA : 0) loc(#loc59)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_5_5, DMA : 0) loc(#loc59)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_4_5, DMA : 0) loc(#loc59)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_3_5, DMA : 0) loc(#loc59)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_2_5, DMA : 0) loc(#loc59)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_1_5, DMA : 0) loc(#loc59)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_0_5, DMA : 0) loc(#loc59)
    aie.flow(%shim_noc_tile_3_0, DMA : 0, %mem_tile_3_1, DMA : 0) loc(#loc58)
    aie.flow(%mem_tile_0_1, DMA : 1, %tile_0_5, DMA : 1) loc(#loc57)
    aie.flow(%mem_tile_0_1, DMA : 1, %tile_0_4, DMA : 1) loc(#loc57)
    aie.flow(%mem_tile_0_1, DMA : 1, %tile_0_3, DMA : 1) loc(#loc57)
    aie.flow(%mem_tile_0_1, DMA : 1, %tile_0_2, DMA : 1) loc(#loc57)
    aie.flow(%shim_noc_tile_0_0, DMA : 1, %mem_tile_0_1, DMA : 1) loc(#loc52)
    aie.flow(%mem_tile_1_1, DMA : 1, %tile_1_5, DMA : 1) loc(#loc56)
    aie.flow(%mem_tile_1_1, DMA : 1, %tile_1_4, DMA : 1) loc(#loc56)
    aie.flow(%mem_tile_1_1, DMA : 1, %tile_1_3, DMA : 1) loc(#loc56)
    aie.flow(%mem_tile_1_1, DMA : 1, %tile_1_2, DMA : 1) loc(#loc56)
    aie.flow(%shim_noc_tile_1_0, DMA : 1, %mem_tile_1_1, DMA : 1) loc(#loc50)
    aie.flow(%mem_tile_2_1, DMA : 1, %tile_2_5, DMA : 1) loc(#loc55)
    aie.flow(%mem_tile_2_1, DMA : 1, %tile_2_4, DMA : 1) loc(#loc55)
    aie.flow(%mem_tile_2_1, DMA : 1, %tile_2_3, DMA : 1) loc(#loc55)
    aie.flow(%mem_tile_2_1, DMA : 1, %tile_2_2, DMA : 1) loc(#loc55)
    aie.flow(%shim_noc_tile_2_0, DMA : 1, %mem_tile_2_1, DMA : 1) loc(#loc48)
    aie.flow(%mem_tile_3_1, DMA : 1, %tile_3_5, DMA : 1) loc(#loc54)
    aie.flow(%mem_tile_3_1, DMA : 1, %tile_3_4, DMA : 1) loc(#loc54)
    aie.flow(%mem_tile_3_1, DMA : 1, %tile_3_3, DMA : 1) loc(#loc54)
    aie.flow(%mem_tile_3_1, DMA : 1, %tile_3_2, DMA : 1) loc(#loc54)
    aie.flow(%shim_noc_tile_3_0, DMA : 1, %mem_tile_3_1, DMA : 1) loc(#loc46)
    aie.flow(%mem_tile_4_1, DMA : 0, %tile_4_5, DMA : 1) loc(#loc53)
    aie.flow(%mem_tile_4_1, DMA : 0, %tile_4_4, DMA : 1) loc(#loc53)
    aie.flow(%mem_tile_4_1, DMA : 0, %tile_4_3, DMA : 1) loc(#loc53)
    aie.flow(%mem_tile_4_1, DMA : 0, %tile_4_2, DMA : 1) loc(#loc53)
    aie.flow(%shim_noc_tile_4_0, DMA : 1, %mem_tile_4_1, DMA : 0) loc(#loc43)
    aie.flow(%mem_tile_5_1, DMA : 0, %tile_5_5, DMA : 1) loc(#loc51)
    aie.flow(%mem_tile_5_1, DMA : 0, %tile_5_4, DMA : 1) loc(#loc51)
    aie.flow(%mem_tile_5_1, DMA : 0, %tile_5_3, DMA : 1) loc(#loc51)
    aie.flow(%mem_tile_5_1, DMA : 0, %tile_5_2, DMA : 1) loc(#loc51)
    aie.flow(%shim_noc_tile_5_0, DMA : 1, %mem_tile_5_1, DMA : 0) loc(#loc40)
    aie.flow(%mem_tile_6_1, DMA : 0, %tile_6_5, DMA : 1) loc(#loc49)
    aie.flow(%mem_tile_6_1, DMA : 0, %tile_6_4, DMA : 1) loc(#loc49)
    aie.flow(%mem_tile_6_1, DMA : 0, %tile_6_3, DMA : 1) loc(#loc49)
    aie.flow(%mem_tile_6_1, DMA : 0, %tile_6_2, DMA : 1) loc(#loc49)
    aie.flow(%shim_noc_tile_6_0, DMA : 1, %mem_tile_6_1, DMA : 0) loc(#loc38)
    aie.flow(%mem_tile_7_1, DMA : 0, %tile_7_5, DMA : 1) loc(#loc47)
    aie.flow(%mem_tile_7_1, DMA : 0, %tile_7_4, DMA : 1) loc(#loc47)
    aie.flow(%mem_tile_7_1, DMA : 0, %tile_7_3, DMA : 1) loc(#loc47)
    aie.flow(%mem_tile_7_1, DMA : 0, %tile_7_2, DMA : 1) loc(#loc47)
    aie.flow(%shim_noc_tile_7_0, DMA : 1, %mem_tile_7_1, DMA : 0) loc(#loc34)
    aie.flow(%mem_tile_0_1, DMA : 2, %shim_noc_tile_0_0, DMA : 0) loc(#loc45)
    aie.flow(%tile_0_2, DMA : 0, %mem_tile_0_1, DMA : 2) loc(#loc44)
    aie.flow(%tile_0_3, DMA : 0, %mem_tile_0_1, DMA : 3) loc(#loc42)
    aie.flow(%tile_0_4, DMA : 0, %mem_tile_0_1, DMA : 4) loc(#loc41)
    aie.flow(%tile_0_5, DMA : 0, %mem_tile_0_1, DMA : 5) loc(#loc39)
    aie.flow(%mem_tile_1_1, DMA : 2, %shim_noc_tile_1_0, DMA : 0) loc(#loc37)
    aie.flow(%tile_1_2, DMA : 0, %mem_tile_1_1, DMA : 2) loc(#loc36)
    aie.flow(%tile_1_3, DMA : 0, %mem_tile_1_1, DMA : 3) loc(#loc35)
    aie.flow(%tile_1_4, DMA : 0, %mem_tile_1_1, DMA : 4) loc(#loc33)
    aie.flow(%tile_1_5, DMA : 0, %mem_tile_1_1, DMA : 5) loc(#loc32)
    aie.flow(%mem_tile_2_1, DMA : 2, %shim_noc_tile_2_0, DMA : 0) loc(#loc31)
    aie.flow(%tile_2_2, DMA : 0, %mem_tile_2_1, DMA : 2) loc(#loc30)
    aie.flow(%tile_2_3, DMA : 0, %mem_tile_2_1, DMA : 3) loc(#loc29)
    aie.flow(%tile_2_4, DMA : 0, %mem_tile_2_1, DMA : 4) loc(#loc28)
    aie.flow(%tile_2_5, DMA : 0, %mem_tile_2_1, DMA : 5) loc(#loc27)
    aie.flow(%mem_tile_3_1, DMA : 2, %shim_noc_tile_3_0, DMA : 0) loc(#loc26)
    aie.flow(%tile_3_2, DMA : 0, %mem_tile_3_1, DMA : 2) loc(#loc25)
    aie.flow(%tile_3_3, DMA : 0, %mem_tile_3_1, DMA : 3) loc(#loc24)
    aie.flow(%tile_3_4, DMA : 0, %mem_tile_3_1, DMA : 4) loc(#loc23)
    aie.flow(%tile_3_5, DMA : 0, %mem_tile_3_1, DMA : 5) loc(#loc22)
    aie.flow(%mem_tile_4_1, DMA : 1, %shim_noc_tile_4_0, DMA : 0) loc(#loc21)
    aie.flow(%tile_4_2, DMA : 0, %mem_tile_4_1, DMA : 1) loc(#loc20)
    aie.flow(%tile_4_3, DMA : 0, %mem_tile_4_1, DMA : 2) loc(#loc19)
    aie.flow(%tile_4_4, DMA : 0, %mem_tile_4_1, DMA : 3) loc(#loc18)
    aie.flow(%tile_4_5, DMA : 0, %mem_tile_4_1, DMA : 4) loc(#loc17)
    aie.flow(%mem_tile_5_1, DMA : 1, %shim_noc_tile_5_0, DMA : 0) loc(#loc16)
    aie.flow(%tile_5_2, DMA : 0, %mem_tile_5_1, DMA : 1) loc(#loc15)
    aie.flow(%tile_5_3, DMA : 0, %mem_tile_5_1, DMA : 2) loc(#loc14)
    aie.flow(%tile_5_4, DMA : 0, %mem_tile_5_1, DMA : 3) loc(#loc13)
    aie.flow(%tile_5_5, DMA : 0, %mem_tile_5_1, DMA : 4) loc(#loc12)
    aie.flow(%mem_tile_6_1, DMA : 1, %shim_noc_tile_6_0, DMA : 0) loc(#loc11)
    aie.flow(%tile_6_2, DMA : 0, %mem_tile_6_1, DMA : 1) loc(#loc10)
    aie.flow(%tile_6_3, DMA : 0, %mem_tile_6_1, DMA : 2) loc(#loc9)
    aie.flow(%tile_6_4, DMA : 0, %mem_tile_6_1, DMA : 3) loc(#loc8)
    aie.flow(%tile_6_5, DMA : 0, %mem_tile_6_1, DMA : 4) loc(#loc7)
    aie.flow(%mem_tile_7_1, DMA : 1, %shim_noc_tile_7_0, DMA : 0) loc(#loc6)
    aie.flow(%tile_7_2, DMA : 0, %mem_tile_7_1, DMA : 1) loc(#loc5)
    aie.flow(%tile_7_3, DMA : 0, %mem_tile_7_1, DMA : 2) loc(#loc4)
    aie.flow(%tile_7_4, DMA : 0, %mem_tile_7_1, DMA : 3) loc(#loc3)
    aie.flow(%tile_7_5, DMA : 0, %mem_tile_7_1, DMA : 4) loc(#loc2)
    %direct_acc0_0_0 = aie.buffer(%tile_0_2) {address = 27136 : i32, sym_name = "direct_acc0_0_0"} : memref<1024xf32>  loc(#loc66)
    %direct_acc1_0_0 = aie.buffer(%tile_0_2) {address = 31232 : i32, sym_name = "direct_acc1_0_0"} : memref<1024xf32>  loc(#loc67)
    %direct_dequant_0_0 = aie.buffer(%tile_0_2) {address = 10240 : i32, sym_name = "direct_dequant_0_0"} : memref<4096xbf16>  loc(#loc68)
    func.func private @w4a16_prefill_reuse_init(memref<1024xf32>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"} loc(#loc69)
    func.func private @w4a16_prefill_reuse_accumulate_low(memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"} loc(#loc70)
    func.func private @w4a16_prefill_reuse_accumulate_high(memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"} loc(#loc71)
    func.func private @w4a16_prefill_reuse_finish(memref<1024xf32>, memref<1024xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"} loc(#loc72)
    %direct_acc0_0_1 = aie.buffer(%tile_0_3) {address = 27136 : i32, sym_name = "direct_acc0_0_1"} : memref<1024xf32>  loc(#loc73)
    %direct_acc1_0_1 = aie.buffer(%tile_0_3) {address = 31232 : i32, sym_name = "direct_acc1_0_1"} : memref<1024xf32>  loc(#loc74)
    %direct_dequant_0_1 = aie.buffer(%tile_0_3) {address = 10240 : i32, sym_name = "direct_dequant_0_1"} : memref<4096xbf16>  loc(#loc75)
    %direct_acc0_0_2 = aie.buffer(%tile_0_4) {address = 27136 : i32, sym_name = "direct_acc0_0_2"} : memref<1024xf32>  loc(#loc76)
    %direct_acc1_0_2 = aie.buffer(%tile_0_4) {address = 31232 : i32, sym_name = "direct_acc1_0_2"} : memref<1024xf32>  loc(#loc77)
    %direct_dequant_0_2 = aie.buffer(%tile_0_4) {address = 10240 : i32, sym_name = "direct_dequant_0_2"} : memref<4096xbf16>  loc(#loc78)
    %direct_acc0_0_3 = aie.buffer(%tile_0_5) {address = 27136 : i32, sym_name = "direct_acc0_0_3"} : memref<1024xf32>  loc(#loc79)
    %direct_acc1_0_3 = aie.buffer(%tile_0_5) {address = 31232 : i32, sym_name = "direct_acc1_0_3"} : memref<1024xf32>  loc(#loc80)
    %direct_dequant_0_3 = aie.buffer(%tile_0_5) {address = 10240 : i32, sym_name = "direct_dequant_0_3"} : memref<4096xbf16>  loc(#loc81)
    %direct_acc0_1_0 = aie.buffer(%tile_1_2) {address = 27136 : i32, sym_name = "direct_acc0_1_0"} : memref<1024xf32>  loc(#loc82)
    %direct_acc1_1_0 = aie.buffer(%tile_1_2) {address = 31232 : i32, sym_name = "direct_acc1_1_0"} : memref<1024xf32>  loc(#loc83)
    %direct_dequant_1_0 = aie.buffer(%tile_1_2) {address = 10240 : i32, sym_name = "direct_dequant_1_0"} : memref<4096xbf16>  loc(#loc84)
    %direct_acc0_1_1 = aie.buffer(%tile_1_3) {address = 27136 : i32, sym_name = "direct_acc0_1_1"} : memref<1024xf32>  loc(#loc85)
    %direct_acc1_1_1 = aie.buffer(%tile_1_3) {address = 31232 : i32, sym_name = "direct_acc1_1_1"} : memref<1024xf32>  loc(#loc86)
    %direct_dequant_1_1 = aie.buffer(%tile_1_3) {address = 10240 : i32, sym_name = "direct_dequant_1_1"} : memref<4096xbf16>  loc(#loc87)
    %direct_acc0_1_2 = aie.buffer(%tile_1_4) {address = 27136 : i32, sym_name = "direct_acc0_1_2"} : memref<1024xf32>  loc(#loc88)
    %direct_acc1_1_2 = aie.buffer(%tile_1_4) {address = 31232 : i32, sym_name = "direct_acc1_1_2"} : memref<1024xf32>  loc(#loc89)
    %direct_dequant_1_2 = aie.buffer(%tile_1_4) {address = 10240 : i32, sym_name = "direct_dequant_1_2"} : memref<4096xbf16>  loc(#loc90)
    %direct_acc0_1_3 = aie.buffer(%tile_1_5) {address = 27136 : i32, sym_name = "direct_acc0_1_3"} : memref<1024xf32>  loc(#loc91)
    %direct_acc1_1_3 = aie.buffer(%tile_1_5) {address = 31232 : i32, sym_name = "direct_acc1_1_3"} : memref<1024xf32>  loc(#loc92)
    %direct_dequant_1_3 = aie.buffer(%tile_1_5) {address = 10240 : i32, sym_name = "direct_dequant_1_3"} : memref<4096xbf16>  loc(#loc93)
    %direct_acc0_2_0 = aie.buffer(%tile_2_2) {address = 27136 : i32, sym_name = "direct_acc0_2_0"} : memref<1024xf32>  loc(#loc94)
    %direct_acc1_2_0 = aie.buffer(%tile_2_2) {address = 31232 : i32, sym_name = "direct_acc1_2_0"} : memref<1024xf32>  loc(#loc95)
    %direct_dequant_2_0 = aie.buffer(%tile_2_2) {address = 10240 : i32, sym_name = "direct_dequant_2_0"} : memref<4096xbf16>  loc(#loc96)
    %direct_acc0_2_1 = aie.buffer(%tile_2_3) {address = 27136 : i32, sym_name = "direct_acc0_2_1"} : memref<1024xf32>  loc(#loc97)
    %direct_acc1_2_1 = aie.buffer(%tile_2_3) {address = 31232 : i32, sym_name = "direct_acc1_2_1"} : memref<1024xf32>  loc(#loc98)
    %direct_dequant_2_1 = aie.buffer(%tile_2_3) {address = 10240 : i32, sym_name = "direct_dequant_2_1"} : memref<4096xbf16>  loc(#loc99)
    %direct_acc0_2_2 = aie.buffer(%tile_2_4) {address = 27136 : i32, sym_name = "direct_acc0_2_2"} : memref<1024xf32>  loc(#loc100)
    %direct_acc1_2_2 = aie.buffer(%tile_2_4) {address = 31232 : i32, sym_name = "direct_acc1_2_2"} : memref<1024xf32>  loc(#loc101)
    %direct_dequant_2_2 = aie.buffer(%tile_2_4) {address = 10240 : i32, sym_name = "direct_dequant_2_2"} : memref<4096xbf16>  loc(#loc102)
    %direct_acc0_2_3 = aie.buffer(%tile_2_5) {address = 27136 : i32, sym_name = "direct_acc0_2_3"} : memref<1024xf32>  loc(#loc103)
    %direct_acc1_2_3 = aie.buffer(%tile_2_5) {address = 31232 : i32, sym_name = "direct_acc1_2_3"} : memref<1024xf32>  loc(#loc104)
    %direct_dequant_2_3 = aie.buffer(%tile_2_5) {address = 10240 : i32, sym_name = "direct_dequant_2_3"} : memref<4096xbf16>  loc(#loc105)
    %direct_acc0_3_0 = aie.buffer(%tile_3_2) {address = 27136 : i32, sym_name = "direct_acc0_3_0"} : memref<1024xf32>  loc(#loc106)
    %direct_acc1_3_0 = aie.buffer(%tile_3_2) {address = 31232 : i32, sym_name = "direct_acc1_3_0"} : memref<1024xf32>  loc(#loc107)
    %direct_dequant_3_0 = aie.buffer(%tile_3_2) {address = 10240 : i32, sym_name = "direct_dequant_3_0"} : memref<4096xbf16>  loc(#loc108)
    %direct_acc0_3_1 = aie.buffer(%tile_3_3) {address = 27136 : i32, sym_name = "direct_acc0_3_1"} : memref<1024xf32>  loc(#loc109)
    %direct_acc1_3_1 = aie.buffer(%tile_3_3) {address = 31232 : i32, sym_name = "direct_acc1_3_1"} : memref<1024xf32>  loc(#loc110)
    %direct_dequant_3_1 = aie.buffer(%tile_3_3) {address = 10240 : i32, sym_name = "direct_dequant_3_1"} : memref<4096xbf16>  loc(#loc111)
    %direct_acc0_3_2 = aie.buffer(%tile_3_4) {address = 27136 : i32, sym_name = "direct_acc0_3_2"} : memref<1024xf32>  loc(#loc112)
    %direct_acc1_3_2 = aie.buffer(%tile_3_4) {address = 31232 : i32, sym_name = "direct_acc1_3_2"} : memref<1024xf32>  loc(#loc113)
    %direct_dequant_3_2 = aie.buffer(%tile_3_4) {address = 10240 : i32, sym_name = "direct_dequant_3_2"} : memref<4096xbf16>  loc(#loc114)
    %direct_acc0_3_3 = aie.buffer(%tile_3_5) {address = 27136 : i32, sym_name = "direct_acc0_3_3"} : memref<1024xf32>  loc(#loc115)
    %direct_acc1_3_3 = aie.buffer(%tile_3_5) {address = 31232 : i32, sym_name = "direct_acc1_3_3"} : memref<1024xf32>  loc(#loc116)
    %direct_dequant_3_3 = aie.buffer(%tile_3_5) {address = 10240 : i32, sym_name = "direct_dequant_3_3"} : memref<4096xbf16>  loc(#loc117)
    %direct_acc0_4_0 = aie.buffer(%tile_4_2) {address = 27136 : i32, sym_name = "direct_acc0_4_0"} : memref<1024xf32>  loc(#loc118)
    %direct_acc1_4_0 = aie.buffer(%tile_4_2) {address = 31232 : i32, sym_name = "direct_acc1_4_0"} : memref<1024xf32>  loc(#loc119)
    %direct_dequant_4_0 = aie.buffer(%tile_4_2) {address = 10240 : i32, sym_name = "direct_dequant_4_0"} : memref<4096xbf16>  loc(#loc120)
    %direct_acc0_4_1 = aie.buffer(%tile_4_3) {address = 27136 : i32, sym_name = "direct_acc0_4_1"} : memref<1024xf32>  loc(#loc121)
    %direct_acc1_4_1 = aie.buffer(%tile_4_3) {address = 31232 : i32, sym_name = "direct_acc1_4_1"} : memref<1024xf32>  loc(#loc122)
    %direct_dequant_4_1 = aie.buffer(%tile_4_3) {address = 10240 : i32, sym_name = "direct_dequant_4_1"} : memref<4096xbf16>  loc(#loc123)
    %direct_acc0_4_2 = aie.buffer(%tile_4_4) {address = 27136 : i32, sym_name = "direct_acc0_4_2"} : memref<1024xf32>  loc(#loc124)
    %direct_acc1_4_2 = aie.buffer(%tile_4_4) {address = 31232 : i32, sym_name = "direct_acc1_4_2"} : memref<1024xf32>  loc(#loc125)
    %direct_dequant_4_2 = aie.buffer(%tile_4_4) {address = 10240 : i32, sym_name = "direct_dequant_4_2"} : memref<4096xbf16>  loc(#loc126)
    %direct_acc0_4_3 = aie.buffer(%tile_4_5) {address = 27136 : i32, sym_name = "direct_acc0_4_3"} : memref<1024xf32>  loc(#loc127)
    %direct_acc1_4_3 = aie.buffer(%tile_4_5) {address = 31232 : i32, sym_name = "direct_acc1_4_3"} : memref<1024xf32>  loc(#loc128)
    %direct_dequant_4_3 = aie.buffer(%tile_4_5) {address = 10240 : i32, sym_name = "direct_dequant_4_3"} : memref<4096xbf16>  loc(#loc129)
    %direct_acc0_5_0 = aie.buffer(%tile_5_2) {address = 27136 : i32, sym_name = "direct_acc0_5_0"} : memref<1024xf32>  loc(#loc130)
    %direct_acc1_5_0 = aie.buffer(%tile_5_2) {address = 31232 : i32, sym_name = "direct_acc1_5_0"} : memref<1024xf32>  loc(#loc131)
    %direct_dequant_5_0 = aie.buffer(%tile_5_2) {address = 10240 : i32, sym_name = "direct_dequant_5_0"} : memref<4096xbf16>  loc(#loc132)
    %direct_acc0_5_1 = aie.buffer(%tile_5_3) {address = 27136 : i32, sym_name = "direct_acc0_5_1"} : memref<1024xf32>  loc(#loc133)
    %direct_acc1_5_1 = aie.buffer(%tile_5_3) {address = 31232 : i32, sym_name = "direct_acc1_5_1"} : memref<1024xf32>  loc(#loc134)
    %direct_dequant_5_1 = aie.buffer(%tile_5_3) {address = 10240 : i32, sym_name = "direct_dequant_5_1"} : memref<4096xbf16>  loc(#loc135)
    %direct_acc0_5_2 = aie.buffer(%tile_5_4) {address = 27136 : i32, sym_name = "direct_acc0_5_2"} : memref<1024xf32>  loc(#loc136)
    %direct_acc1_5_2 = aie.buffer(%tile_5_4) {address = 31232 : i32, sym_name = "direct_acc1_5_2"} : memref<1024xf32>  loc(#loc137)
    %direct_dequant_5_2 = aie.buffer(%tile_5_4) {address = 10240 : i32, sym_name = "direct_dequant_5_2"} : memref<4096xbf16>  loc(#loc138)
    %direct_acc0_5_3 = aie.buffer(%tile_5_5) {address = 27136 : i32, sym_name = "direct_acc0_5_3"} : memref<1024xf32>  loc(#loc139)
    %direct_acc1_5_3 = aie.buffer(%tile_5_5) {address = 31232 : i32, sym_name = "direct_acc1_5_3"} : memref<1024xf32>  loc(#loc140)
    %direct_dequant_5_3 = aie.buffer(%tile_5_5) {address = 10240 : i32, sym_name = "direct_dequant_5_3"} : memref<4096xbf16>  loc(#loc141)
    %direct_acc0_6_0 = aie.buffer(%tile_6_2) {address = 27136 : i32, sym_name = "direct_acc0_6_0"} : memref<1024xf32>  loc(#loc142)
    %direct_acc1_6_0 = aie.buffer(%tile_6_2) {address = 31232 : i32, sym_name = "direct_acc1_6_0"} : memref<1024xf32>  loc(#loc143)
    %direct_dequant_6_0 = aie.buffer(%tile_6_2) {address = 10240 : i32, sym_name = "direct_dequant_6_0"} : memref<4096xbf16>  loc(#loc144)
    %direct_acc0_6_1 = aie.buffer(%tile_6_3) {address = 27136 : i32, sym_name = "direct_acc0_6_1"} : memref<1024xf32>  loc(#loc145)
    %direct_acc1_6_1 = aie.buffer(%tile_6_3) {address = 31232 : i32, sym_name = "direct_acc1_6_1"} : memref<1024xf32>  loc(#loc146)
    %direct_dequant_6_1 = aie.buffer(%tile_6_3) {address = 10240 : i32, sym_name = "direct_dequant_6_1"} : memref<4096xbf16>  loc(#loc147)
    %direct_acc0_6_2 = aie.buffer(%tile_6_4) {address = 27136 : i32, sym_name = "direct_acc0_6_2"} : memref<1024xf32>  loc(#loc148)
    %direct_acc1_6_2 = aie.buffer(%tile_6_4) {address = 31232 : i32, sym_name = "direct_acc1_6_2"} : memref<1024xf32>  loc(#loc149)
    %direct_dequant_6_2 = aie.buffer(%tile_6_4) {address = 10240 : i32, sym_name = "direct_dequant_6_2"} : memref<4096xbf16>  loc(#loc150)
    %direct_acc0_6_3 = aie.buffer(%tile_6_5) {address = 27136 : i32, sym_name = "direct_acc0_6_3"} : memref<1024xf32>  loc(#loc151)
    %direct_acc1_6_3 = aie.buffer(%tile_6_5) {address = 31232 : i32, sym_name = "direct_acc1_6_3"} : memref<1024xf32>  loc(#loc152)
    %direct_dequant_6_3 = aie.buffer(%tile_6_5) {address = 10240 : i32, sym_name = "direct_dequant_6_3"} : memref<4096xbf16>  loc(#loc153)
    %direct_acc0_7_0 = aie.buffer(%tile_7_2) {address = 27136 : i32, sym_name = "direct_acc0_7_0"} : memref<1024xf32>  loc(#loc154)
    %direct_acc1_7_0 = aie.buffer(%tile_7_2) {address = 31232 : i32, sym_name = "direct_acc1_7_0"} : memref<1024xf32>  loc(#loc155)
    %direct_dequant_7_0 = aie.buffer(%tile_7_2) {address = 10240 : i32, sym_name = "direct_dequant_7_0"} : memref<4096xbf16>  loc(#loc156)
    %direct_acc0_7_1 = aie.buffer(%tile_7_3) {address = 27136 : i32, sym_name = "direct_acc0_7_1"} : memref<1024xf32>  loc(#loc157)
    %direct_acc1_7_1 = aie.buffer(%tile_7_3) {address = 31232 : i32, sym_name = "direct_acc1_7_1"} : memref<1024xf32>  loc(#loc158)
    %direct_dequant_7_1 = aie.buffer(%tile_7_3) {address = 10240 : i32, sym_name = "direct_dequant_7_1"} : memref<4096xbf16>  loc(#loc159)
    %direct_acc0_7_2 = aie.buffer(%tile_7_4) {address = 27136 : i32, sym_name = "direct_acc0_7_2"} : memref<1024xf32>  loc(#loc160)
    %direct_acc1_7_2 = aie.buffer(%tile_7_4) {address = 31232 : i32, sym_name = "direct_acc1_7_2"} : memref<1024xf32>  loc(#loc161)
    %direct_dequant_7_2 = aie.buffer(%tile_7_4) {address = 10240 : i32, sym_name = "direct_dequant_7_2"} : memref<4096xbf16>  loc(#loc162)
    %direct_acc0_7_3 = aie.buffer(%tile_7_5) {address = 27136 : i32, sym_name = "direct_acc0_7_3"} : memref<1024xf32>  loc(#loc163)
    %direct_acc1_7_3 = aie.buffer(%tile_7_5) {address = 31232 : i32, sym_name = "direct_acc1_7_3"} : memref<1024xf32>  loc(#loc164)
    %direct_dequant_7_3 = aie.buffer(%tile_7_5) {address = 10240 : i32, sym_name = "direct_dequant_7_3"} : memref<4096xbf16>  loc(#loc165)
    %core_0_2 = aie.core(%tile_0_2) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc168)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":263:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":259:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":259:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc168)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc168)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_0_0) : (memref<1024xf32>) -> () loc(#loc170)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc171)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":272:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":259:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc171)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc171)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc173)
      aie.use_lock(%direct_w_broadcast_0_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc174)
      %7 = arith.index_cast %5 : i32 to index loc(#loc175)
      %8 = arith.index_cast %7 : index to i64 loc(#loc175)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc175)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_0_cons_buff_0 : memref<4352xui8>) loc(#loc175)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_0_cons_buff_1 : memref<4352xui8>) loc(#loc175)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_0_cons_buff_0 : memref<4352xui8>) loc(#loc175)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":276:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_0_0_cons_buff_0, %9, %direct_acc0_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc176)
      aie.use_lock(%direct_a_broadcast_0_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc177)
      aie.use_lock(%direct_w_broadcast_0_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc178)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc178)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc178)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc178)
      %13 = arith.addi %4, %c1 : index loc(#loc171)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc171)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_0_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc179)
      %14 = arith.index_cast %2 : i32 to index loc(#loc180)
      %15 = arith.index_cast %14 : index to i64 loc(#loc180)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc180)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_0_buff_0 : memref<1024xbf16>) loc(#loc180)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_0_buff_1 : memref<1024xbf16>) loc(#loc180)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_0_buff_0 : memref<1024xbf16>) loc(#loc180)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":282:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_0, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc181)
      aie.use_lock(%direct_y_worker_0_0_cons_lock_0, Release, %c1_i32) loc(#loc182)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc182)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc182)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc182)
      %20 = arith.addi %0, %c1 : index loc(#loc168)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc168)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc183)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc166)
    %core_0_3 = aie.core(%tile_0_3) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc185)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":293:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":289:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":289:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc185)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc185)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_0_1) : (memref<1024xf32>) -> () loc(#loc187)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc188)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":302:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":289:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc188)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc188)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc190)
      aie.use_lock(%direct_w_broadcast_0_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc191)
      %7 = arith.index_cast %5 : i32 to index loc(#loc192)
      %8 = arith.index_cast %7 : index to i64 loc(#loc192)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc192)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_1_cons_buff_0 : memref<4352xui8>) loc(#loc192)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_1_cons_buff_1 : memref<4352xui8>) loc(#loc192)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_1_cons_buff_0 : memref<4352xui8>) loc(#loc192)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":306:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_1_0_cons_buff_0, %9, %direct_acc0_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc193)
      aie.use_lock(%direct_a_broadcast_1_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc194)
      aie.use_lock(%direct_w_broadcast_0_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc195)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc195)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc195)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc195)
      %13 = arith.addi %4, %c1 : index loc(#loc188)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc188)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_0_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc196)
      %14 = arith.index_cast %2 : i32 to index loc(#loc197)
      %15 = arith.index_cast %14 : index to i64 loc(#loc197)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc197)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_1_buff_0 : memref<1024xbf16>) loc(#loc197)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_1_buff_1 : memref<1024xbf16>) loc(#loc197)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_1_buff_0 : memref<1024xbf16>) loc(#loc197)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":312:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_1, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc198)
      aie.use_lock(%direct_y_worker_0_1_cons_lock_0, Release, %c1_i32) loc(#loc199)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc199)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc199)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc199)
      %20 = arith.addi %0, %c1 : index loc(#loc185)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc185)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc200)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc184)
    %core_0_4 = aie.core(%tile_0_4) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc202)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":323:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":319:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":319:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc202)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc202)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_0_2) : (memref<1024xf32>) -> () loc(#loc204)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc205)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":332:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":319:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc205)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc205)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc207)
      aie.use_lock(%direct_w_broadcast_0_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc208)
      %7 = arith.index_cast %5 : i32 to index loc(#loc209)
      %8 = arith.index_cast %7 : index to i64 loc(#loc209)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc209)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_2_cons_buff_0 : memref<4352xui8>) loc(#loc209)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_2_cons_buff_1 : memref<4352xui8>) loc(#loc209)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_2_cons_buff_0 : memref<4352xui8>) loc(#loc209)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":336:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_2_0_cons_buff_0, %9, %direct_acc0_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc210)
      aie.use_lock(%direct_a_broadcast_2_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc211)
      aie.use_lock(%direct_w_broadcast_0_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc212)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc212)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc212)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc212)
      %13 = arith.addi %4, %c1 : index loc(#loc205)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc205)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_0_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc213)
      %14 = arith.index_cast %2 : i32 to index loc(#loc214)
      %15 = arith.index_cast %14 : index to i64 loc(#loc214)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc214)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_2_buff_0 : memref<1024xbf16>) loc(#loc214)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_2_buff_1 : memref<1024xbf16>) loc(#loc214)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_2_buff_0 : memref<1024xbf16>) loc(#loc214)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":342:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_2, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc215)
      aie.use_lock(%direct_y_worker_0_2_cons_lock_0, Release, %c1_i32) loc(#loc216)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc216)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc216)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc216)
      %20 = arith.addi %0, %c1 : index loc(#loc202)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc202)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc217)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc201)
    %core_0_5 = aie.core(%tile_0_5) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc219)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":353:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":349:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":349:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc219)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc219)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_0_3) : (memref<1024xf32>) -> () loc(#loc221)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc222)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":362:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":349:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc222)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc222)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc224)
      aie.use_lock(%direct_w_broadcast_0_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc225)
      %7 = arith.index_cast %5 : i32 to index loc(#loc226)
      %8 = arith.index_cast %7 : index to i64 loc(#loc226)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc226)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_3_cons_buff_0 : memref<4352xui8>) loc(#loc226)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_3_cons_buff_1 : memref<4352xui8>) loc(#loc226)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_3_cons_buff_0 : memref<4352xui8>) loc(#loc226)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":366:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_3_0_cons_buff_0, %9, %direct_acc0_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc227)
      aie.use_lock(%direct_a_broadcast_3_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc228)
      aie.use_lock(%direct_w_broadcast_0_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc229)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc229)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc229)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc229)
      %13 = arith.addi %4, %c1 : index loc(#loc222)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc222)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_0_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc230)
      %14 = arith.index_cast %2 : i32 to index loc(#loc231)
      %15 = arith.index_cast %14 : index to i64 loc(#loc231)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc231)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_3_buff_0 : memref<1024xbf16>) loc(#loc231)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_3_buff_1 : memref<1024xbf16>) loc(#loc231)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_3_buff_0 : memref<1024xbf16>) loc(#loc231)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":372:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_3, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc232)
      aie.use_lock(%direct_y_worker_0_3_cons_lock_0, Release, %c1_i32) loc(#loc233)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc233)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc233)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc233)
      %20 = arith.addi %0, %c1 : index loc(#loc219)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc219)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc234)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc218)
    %core_1_2 = aie.core(%tile_1_2) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc236)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":383:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":379:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":379:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc236)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc236)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_1_0) : (memref<1024xf32>) -> () loc(#loc238)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc239)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":392:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":379:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc239)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc239)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc241)
      aie.use_lock(%direct_w_broadcast_1_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc242)
      %7 = arith.index_cast %5 : i32 to index loc(#loc243)
      %8 = arith.index_cast %7 : index to i64 loc(#loc243)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc243)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_0_cons_buff_0 : memref<4352xui8>) loc(#loc243)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_0_cons_buff_1 : memref<4352xui8>) loc(#loc243)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_0_cons_buff_0 : memref<4352xui8>) loc(#loc243)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":396:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_0_1_cons_buff_0, %9, %direct_acc0_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc244)
      aie.use_lock(%direct_a_broadcast_0_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc245)
      aie.use_lock(%direct_w_broadcast_1_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc246)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc246)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc246)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc246)
      %13 = arith.addi %4, %c1 : index loc(#loc239)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc239)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_1_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc247)
      %14 = arith.index_cast %2 : i32 to index loc(#loc248)
      %15 = arith.index_cast %14 : index to i64 loc(#loc248)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc248)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_0_buff_0 : memref<1024xbf16>) loc(#loc248)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_0_buff_1 : memref<1024xbf16>) loc(#loc248)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_0_buff_0 : memref<1024xbf16>) loc(#loc248)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":402:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_0, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc249)
      aie.use_lock(%direct_y_worker_1_0_cons_lock_0, Release, %c1_i32) loc(#loc250)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc250)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc250)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc250)
      %20 = arith.addi %0, %c1 : index loc(#loc236)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc236)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc251)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc235)
    %core_1_3 = aie.core(%tile_1_3) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc253)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":413:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":409:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":409:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc253)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc253)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_1_1) : (memref<1024xf32>) -> () loc(#loc255)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc256)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":422:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":409:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc256)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc256)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc258)
      aie.use_lock(%direct_w_broadcast_1_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc259)
      %7 = arith.index_cast %5 : i32 to index loc(#loc260)
      %8 = arith.index_cast %7 : index to i64 loc(#loc260)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc260)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_1_cons_buff_0 : memref<4352xui8>) loc(#loc260)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_1_cons_buff_1 : memref<4352xui8>) loc(#loc260)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_1_cons_buff_0 : memref<4352xui8>) loc(#loc260)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":426:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_1_1_cons_buff_0, %9, %direct_acc0_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc261)
      aie.use_lock(%direct_a_broadcast_1_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc262)
      aie.use_lock(%direct_w_broadcast_1_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc263)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc263)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc263)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc263)
      %13 = arith.addi %4, %c1 : index loc(#loc256)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc256)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_1_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc264)
      %14 = arith.index_cast %2 : i32 to index loc(#loc265)
      %15 = arith.index_cast %14 : index to i64 loc(#loc265)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc265)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_1_buff_0 : memref<1024xbf16>) loc(#loc265)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_1_buff_1 : memref<1024xbf16>) loc(#loc265)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_1_buff_0 : memref<1024xbf16>) loc(#loc265)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":432:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_1, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc266)
      aie.use_lock(%direct_y_worker_1_1_cons_lock_0, Release, %c1_i32) loc(#loc267)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc267)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc267)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc267)
      %20 = arith.addi %0, %c1 : index loc(#loc253)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc253)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc268)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc252)
    %core_1_4 = aie.core(%tile_1_4) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc270)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":443:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":439:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":439:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc270)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc270)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_1_2) : (memref<1024xf32>) -> () loc(#loc272)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc273)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":452:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":439:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc273)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc273)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc275)
      aie.use_lock(%direct_w_broadcast_1_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc276)
      %7 = arith.index_cast %5 : i32 to index loc(#loc277)
      %8 = arith.index_cast %7 : index to i64 loc(#loc277)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc277)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_2_cons_buff_0 : memref<4352xui8>) loc(#loc277)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_2_cons_buff_1 : memref<4352xui8>) loc(#loc277)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_2_cons_buff_0 : memref<4352xui8>) loc(#loc277)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":456:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_2_1_cons_buff_0, %9, %direct_acc0_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc278)
      aie.use_lock(%direct_a_broadcast_2_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc279)
      aie.use_lock(%direct_w_broadcast_1_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc280)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc280)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc280)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc280)
      %13 = arith.addi %4, %c1 : index loc(#loc273)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc273)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_1_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc281)
      %14 = arith.index_cast %2 : i32 to index loc(#loc282)
      %15 = arith.index_cast %14 : index to i64 loc(#loc282)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc282)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_2_buff_0 : memref<1024xbf16>) loc(#loc282)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_2_buff_1 : memref<1024xbf16>) loc(#loc282)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_2_buff_0 : memref<1024xbf16>) loc(#loc282)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":462:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_2, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc283)
      aie.use_lock(%direct_y_worker_1_2_cons_lock_0, Release, %c1_i32) loc(#loc284)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc284)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc284)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc284)
      %20 = arith.addi %0, %c1 : index loc(#loc270)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc270)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc285)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc269)
    %core_1_5 = aie.core(%tile_1_5) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc287)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":473:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":469:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":469:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc287)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc287)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_1_3) : (memref<1024xf32>) -> () loc(#loc289)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc290)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":482:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":469:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc290)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc290)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc292)
      aie.use_lock(%direct_w_broadcast_1_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc293)
      %7 = arith.index_cast %5 : i32 to index loc(#loc294)
      %8 = arith.index_cast %7 : index to i64 loc(#loc294)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc294)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_3_cons_buff_0 : memref<4352xui8>) loc(#loc294)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_3_cons_buff_1 : memref<4352xui8>) loc(#loc294)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_3_cons_buff_0 : memref<4352xui8>) loc(#loc294)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":486:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_3_1_cons_buff_0, %9, %direct_acc0_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc295)
      aie.use_lock(%direct_a_broadcast_3_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc296)
      aie.use_lock(%direct_w_broadcast_1_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc297)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc297)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc297)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc297)
      %13 = arith.addi %4, %c1 : index loc(#loc290)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc290)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_1_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc298)
      %14 = arith.index_cast %2 : i32 to index loc(#loc299)
      %15 = arith.index_cast %14 : index to i64 loc(#loc299)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc299)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_3_buff_0 : memref<1024xbf16>) loc(#loc299)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_3_buff_1 : memref<1024xbf16>) loc(#loc299)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_3_buff_0 : memref<1024xbf16>) loc(#loc299)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":492:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_3, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc300)
      aie.use_lock(%direct_y_worker_1_3_cons_lock_0, Release, %c1_i32) loc(#loc301)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc301)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc301)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc301)
      %20 = arith.addi %0, %c1 : index loc(#loc287)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc287)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc302)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc286)
    %core_2_2 = aie.core(%tile_2_2) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc304)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":503:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":499:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":499:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc304)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc304)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_2_0) : (memref<1024xf32>) -> () loc(#loc306)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc307)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":512:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":499:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc307)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc307)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc309)
      aie.use_lock(%direct_w_broadcast_2_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc310)
      %7 = arith.index_cast %5 : i32 to index loc(#loc311)
      %8 = arith.index_cast %7 : index to i64 loc(#loc311)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc311)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_0_cons_buff_0 : memref<4352xui8>) loc(#loc311)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_0_cons_buff_1 : memref<4352xui8>) loc(#loc311)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_0_cons_buff_0 : memref<4352xui8>) loc(#loc311)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":516:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_0_2_cons_buff_0, %9, %direct_acc0_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc312)
      aie.use_lock(%direct_a_broadcast_0_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc313)
      aie.use_lock(%direct_w_broadcast_2_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc314)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc314)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc314)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc314)
      %13 = arith.addi %4, %c1 : index loc(#loc307)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc307)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_2_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc315)
      %14 = arith.index_cast %2 : i32 to index loc(#loc316)
      %15 = arith.index_cast %14 : index to i64 loc(#loc316)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc316)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_0_buff_0 : memref<1024xbf16>) loc(#loc316)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_0_buff_1 : memref<1024xbf16>) loc(#loc316)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_0_buff_0 : memref<1024xbf16>) loc(#loc316)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":522:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_0, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc317)
      aie.use_lock(%direct_y_worker_2_0_cons_lock_0, Release, %c1_i32) loc(#loc318)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc318)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc318)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc318)
      %20 = arith.addi %0, %c1 : index loc(#loc304)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc304)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc319)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc303)
    %core_2_3 = aie.core(%tile_2_3) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc321)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":533:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":529:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":529:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc321)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc321)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_2_1) : (memref<1024xf32>) -> () loc(#loc323)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc324)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":542:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":529:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc324)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc324)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc326)
      aie.use_lock(%direct_w_broadcast_2_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc327)
      %7 = arith.index_cast %5 : i32 to index loc(#loc328)
      %8 = arith.index_cast %7 : index to i64 loc(#loc328)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc328)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_1_cons_buff_0 : memref<4352xui8>) loc(#loc328)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_1_cons_buff_1 : memref<4352xui8>) loc(#loc328)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_1_cons_buff_0 : memref<4352xui8>) loc(#loc328)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":546:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_1_2_cons_buff_0, %9, %direct_acc0_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc329)
      aie.use_lock(%direct_a_broadcast_1_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc330)
      aie.use_lock(%direct_w_broadcast_2_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc331)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc331)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc331)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc331)
      %13 = arith.addi %4, %c1 : index loc(#loc324)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc324)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_2_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc332)
      %14 = arith.index_cast %2 : i32 to index loc(#loc333)
      %15 = arith.index_cast %14 : index to i64 loc(#loc333)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc333)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_1_buff_0 : memref<1024xbf16>) loc(#loc333)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_1_buff_1 : memref<1024xbf16>) loc(#loc333)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_1_buff_0 : memref<1024xbf16>) loc(#loc333)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":552:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_1, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc334)
      aie.use_lock(%direct_y_worker_2_1_cons_lock_0, Release, %c1_i32) loc(#loc335)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc335)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc335)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc335)
      %20 = arith.addi %0, %c1 : index loc(#loc321)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc321)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc336)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc320)
    %core_2_4 = aie.core(%tile_2_4) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc338)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":563:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":559:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":559:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc338)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc338)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_2_2) : (memref<1024xf32>) -> () loc(#loc340)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc341)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":572:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":559:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc341)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc341)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc343)
      aie.use_lock(%direct_w_broadcast_2_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc344)
      %7 = arith.index_cast %5 : i32 to index loc(#loc345)
      %8 = arith.index_cast %7 : index to i64 loc(#loc345)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc345)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_2_cons_buff_0 : memref<4352xui8>) loc(#loc345)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_2_cons_buff_1 : memref<4352xui8>) loc(#loc345)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_2_cons_buff_0 : memref<4352xui8>) loc(#loc345)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":576:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_2_2_cons_buff_0, %9, %direct_acc0_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc346)
      aie.use_lock(%direct_a_broadcast_2_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc347)
      aie.use_lock(%direct_w_broadcast_2_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc348)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc348)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc348)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc348)
      %13 = arith.addi %4, %c1 : index loc(#loc341)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc341)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_2_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc349)
      %14 = arith.index_cast %2 : i32 to index loc(#loc350)
      %15 = arith.index_cast %14 : index to i64 loc(#loc350)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc350)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_2_buff_0 : memref<1024xbf16>) loc(#loc350)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_2_buff_1 : memref<1024xbf16>) loc(#loc350)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_2_buff_0 : memref<1024xbf16>) loc(#loc350)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":582:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_2, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc351)
      aie.use_lock(%direct_y_worker_2_2_cons_lock_0, Release, %c1_i32) loc(#loc352)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc352)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc352)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc352)
      %20 = arith.addi %0, %c1 : index loc(#loc338)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc338)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc353)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc337)
    %core_2_5 = aie.core(%tile_2_5) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc355)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":593:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":589:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":589:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc355)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc355)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_2_3) : (memref<1024xf32>) -> () loc(#loc357)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc358)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":602:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":589:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc358)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc358)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc360)
      aie.use_lock(%direct_w_broadcast_2_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc361)
      %7 = arith.index_cast %5 : i32 to index loc(#loc362)
      %8 = arith.index_cast %7 : index to i64 loc(#loc362)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc362)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_3_cons_buff_0 : memref<4352xui8>) loc(#loc362)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_3_cons_buff_1 : memref<4352xui8>) loc(#loc362)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_3_cons_buff_0 : memref<4352xui8>) loc(#loc362)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":606:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_3_2_cons_buff_0, %9, %direct_acc0_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc363)
      aie.use_lock(%direct_a_broadcast_3_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc364)
      aie.use_lock(%direct_w_broadcast_2_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc365)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc365)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc365)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc365)
      %13 = arith.addi %4, %c1 : index loc(#loc358)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc358)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_2_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc366)
      %14 = arith.index_cast %2 : i32 to index loc(#loc367)
      %15 = arith.index_cast %14 : index to i64 loc(#loc367)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc367)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_3_buff_0 : memref<1024xbf16>) loc(#loc367)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_3_buff_1 : memref<1024xbf16>) loc(#loc367)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_3_buff_0 : memref<1024xbf16>) loc(#loc367)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":612:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_3, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc368)
      aie.use_lock(%direct_y_worker_2_3_cons_lock_0, Release, %c1_i32) loc(#loc369)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc369)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc369)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc369)
      %20 = arith.addi %0, %c1 : index loc(#loc355)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc355)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc370)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc354)
    %core_3_2 = aie.core(%tile_3_2) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc372)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":623:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":619:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":619:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc372)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc372)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_3_0) : (memref<1024xf32>) -> () loc(#loc374)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc375)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":632:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":619:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc375)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc375)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc377)
      aie.use_lock(%direct_w_broadcast_3_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc378)
      %7 = arith.index_cast %5 : i32 to index loc(#loc379)
      %8 = arith.index_cast %7 : index to i64 loc(#loc379)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc379)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_0_cons_buff_0 : memref<4352xui8>) loc(#loc379)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_0_cons_buff_1 : memref<4352xui8>) loc(#loc379)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_0_cons_buff_0 : memref<4352xui8>) loc(#loc379)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":636:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_0_3_cons_buff_0, %9, %direct_acc0_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc380)
      aie.use_lock(%direct_a_broadcast_0_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc381)
      aie.use_lock(%direct_w_broadcast_3_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc382)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc382)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc382)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc382)
      %13 = arith.addi %4, %c1 : index loc(#loc375)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc375)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_3_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc383)
      %14 = arith.index_cast %2 : i32 to index loc(#loc384)
      %15 = arith.index_cast %14 : index to i64 loc(#loc384)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc384)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_0_buff_0 : memref<1024xbf16>) loc(#loc384)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_0_buff_1 : memref<1024xbf16>) loc(#loc384)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_0_buff_0 : memref<1024xbf16>) loc(#loc384)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":642:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_0, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc385)
      aie.use_lock(%direct_y_worker_3_0_cons_lock_0, Release, %c1_i32) loc(#loc386)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc386)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc386)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc386)
      %20 = arith.addi %0, %c1 : index loc(#loc372)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc372)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc387)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc371)
    %core_3_3 = aie.core(%tile_3_3) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc389)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":653:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":649:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":649:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc389)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc389)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_3_1) : (memref<1024xf32>) -> () loc(#loc391)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc392)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":662:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":649:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc392)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc392)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc394)
      aie.use_lock(%direct_w_broadcast_3_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc395)
      %7 = arith.index_cast %5 : i32 to index loc(#loc396)
      %8 = arith.index_cast %7 : index to i64 loc(#loc396)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc396)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_1_cons_buff_0 : memref<4352xui8>) loc(#loc396)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_1_cons_buff_1 : memref<4352xui8>) loc(#loc396)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_1_cons_buff_0 : memref<4352xui8>) loc(#loc396)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":666:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_1_3_cons_buff_0, %9, %direct_acc0_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc397)
      aie.use_lock(%direct_a_broadcast_1_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc398)
      aie.use_lock(%direct_w_broadcast_3_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc399)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc399)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc399)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc399)
      %13 = arith.addi %4, %c1 : index loc(#loc392)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc392)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_3_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc400)
      %14 = arith.index_cast %2 : i32 to index loc(#loc401)
      %15 = arith.index_cast %14 : index to i64 loc(#loc401)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc401)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_1_buff_0 : memref<1024xbf16>) loc(#loc401)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_1_buff_1 : memref<1024xbf16>) loc(#loc401)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_1_buff_0 : memref<1024xbf16>) loc(#loc401)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":672:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_1, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc402)
      aie.use_lock(%direct_y_worker_3_1_cons_lock_0, Release, %c1_i32) loc(#loc403)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc403)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc403)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc403)
      %20 = arith.addi %0, %c1 : index loc(#loc389)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc389)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc404)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc388)
    %core_3_4 = aie.core(%tile_3_4) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc406)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":683:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":679:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":679:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc406)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc406)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_3_2) : (memref<1024xf32>) -> () loc(#loc408)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc409)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":692:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":679:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc409)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc409)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc411)
      aie.use_lock(%direct_w_broadcast_3_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc412)
      %7 = arith.index_cast %5 : i32 to index loc(#loc413)
      %8 = arith.index_cast %7 : index to i64 loc(#loc413)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc413)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_2_cons_buff_0 : memref<4352xui8>) loc(#loc413)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_2_cons_buff_1 : memref<4352xui8>) loc(#loc413)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_2_cons_buff_0 : memref<4352xui8>) loc(#loc413)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":696:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_2_3_cons_buff_0, %9, %direct_acc0_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc414)
      aie.use_lock(%direct_a_broadcast_2_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc415)
      aie.use_lock(%direct_w_broadcast_3_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc416)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc416)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc416)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc416)
      %13 = arith.addi %4, %c1 : index loc(#loc409)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc409)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_3_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc417)
      %14 = arith.index_cast %2 : i32 to index loc(#loc418)
      %15 = arith.index_cast %14 : index to i64 loc(#loc418)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc418)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_2_buff_0 : memref<1024xbf16>) loc(#loc418)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_2_buff_1 : memref<1024xbf16>) loc(#loc418)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_2_buff_0 : memref<1024xbf16>) loc(#loc418)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":702:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_2, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc419)
      aie.use_lock(%direct_y_worker_3_2_cons_lock_0, Release, %c1_i32) loc(#loc420)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc420)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc420)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc420)
      %20 = arith.addi %0, %c1 : index loc(#loc406)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc406)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc421)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc405)
    %core_3_5 = aie.core(%tile_3_5) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc423)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":713:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":709:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":709:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc423)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc423)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_3_3) : (memref<1024xf32>) -> () loc(#loc425)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc426)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":722:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":709:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc426)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc426)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc428)
      aie.use_lock(%direct_w_broadcast_3_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc429)
      %7 = arith.index_cast %5 : i32 to index loc(#loc430)
      %8 = arith.index_cast %7 : index to i64 loc(#loc430)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc430)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_3_cons_buff_0 : memref<4352xui8>) loc(#loc430)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_3_cons_buff_1 : memref<4352xui8>) loc(#loc430)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_3_cons_buff_0 : memref<4352xui8>) loc(#loc430)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":726:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_3_3_cons_buff_0, %9, %direct_acc0_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc431)
      aie.use_lock(%direct_a_broadcast_3_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc432)
      aie.use_lock(%direct_w_broadcast_3_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc433)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc433)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc433)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc433)
      %13 = arith.addi %4, %c1 : index loc(#loc426)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc426)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_3_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc434)
      %14 = arith.index_cast %2 : i32 to index loc(#loc435)
      %15 = arith.index_cast %14 : index to i64 loc(#loc435)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc435)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_3_buff_0 : memref<1024xbf16>) loc(#loc435)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_3_buff_1 : memref<1024xbf16>) loc(#loc435)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_3_buff_0 : memref<1024xbf16>) loc(#loc435)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":732:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_3, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc436)
      aie.use_lock(%direct_y_worker_3_3_cons_lock_0, Release, %c1_i32) loc(#loc437)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc437)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc437)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc437)
      %20 = arith.addi %0, %c1 : index loc(#loc423)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc423)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc438)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc422)
    %core_4_2 = aie.core(%tile_4_2) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc440)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":743:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":739:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":739:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc440)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc440)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_4_0) : (memref<1024xf32>) -> () loc(#loc442)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc443)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":752:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":739:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc443)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc443)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc445)
      aie.use_lock(%direct_w_broadcast_4_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc446)
      %7 = arith.index_cast %5 : i32 to index loc(#loc447)
      %8 = arith.index_cast %7 : index to i64 loc(#loc447)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc447)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_0_cons_buff_0 : memref<4352xui8>) loc(#loc447)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_0_cons_buff_1 : memref<4352xui8>) loc(#loc447)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_0_cons_buff_0 : memref<4352xui8>) loc(#loc447)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":756:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_0_4_cons_buff_0, %9, %direct_acc0_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc448)
      aie.use_lock(%direct_a_broadcast_0_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc449)
      aie.use_lock(%direct_w_broadcast_4_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc450)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc450)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc450)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc450)
      %13 = arith.addi %4, %c1 : index loc(#loc443)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc443)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_4_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc451)
      %14 = arith.index_cast %2 : i32 to index loc(#loc452)
      %15 = arith.index_cast %14 : index to i64 loc(#loc452)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc452)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_0_buff_0 : memref<1024xbf16>) loc(#loc452)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_0_buff_1 : memref<1024xbf16>) loc(#loc452)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_0_buff_0 : memref<1024xbf16>) loc(#loc452)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":762:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_0, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc453)
      aie.use_lock(%direct_y_worker_4_0_cons_lock_0, Release, %c1_i32) loc(#loc454)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc454)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc454)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc454)
      %20 = arith.addi %0, %c1 : index loc(#loc440)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc440)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc455)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc439)
    %core_4_3 = aie.core(%tile_4_3) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc457)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":773:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":769:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":769:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc457)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc457)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_4_1) : (memref<1024xf32>) -> () loc(#loc459)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc460)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":782:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":769:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc460)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc460)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc462)
      aie.use_lock(%direct_w_broadcast_4_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc463)
      %7 = arith.index_cast %5 : i32 to index loc(#loc464)
      %8 = arith.index_cast %7 : index to i64 loc(#loc464)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc464)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_1_cons_buff_0 : memref<4352xui8>) loc(#loc464)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_1_cons_buff_1 : memref<4352xui8>) loc(#loc464)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_1_cons_buff_0 : memref<4352xui8>) loc(#loc464)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":786:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_1_4_cons_buff_0, %9, %direct_acc0_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc465)
      aie.use_lock(%direct_a_broadcast_1_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc466)
      aie.use_lock(%direct_w_broadcast_4_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc467)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc467)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc467)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc467)
      %13 = arith.addi %4, %c1 : index loc(#loc460)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc460)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_4_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc468)
      %14 = arith.index_cast %2 : i32 to index loc(#loc469)
      %15 = arith.index_cast %14 : index to i64 loc(#loc469)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc469)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_1_buff_0 : memref<1024xbf16>) loc(#loc469)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_1_buff_1 : memref<1024xbf16>) loc(#loc469)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_1_buff_0 : memref<1024xbf16>) loc(#loc469)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":792:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_1, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc470)
      aie.use_lock(%direct_y_worker_4_1_cons_lock_0, Release, %c1_i32) loc(#loc471)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc471)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc471)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc471)
      %20 = arith.addi %0, %c1 : index loc(#loc457)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc457)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc472)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc456)
    %core_4_4 = aie.core(%tile_4_4) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc474)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":803:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":799:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":799:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc474)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc474)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_4_2) : (memref<1024xf32>) -> () loc(#loc476)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc477)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":812:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":799:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc477)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc477)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc479)
      aie.use_lock(%direct_w_broadcast_4_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc480)
      %7 = arith.index_cast %5 : i32 to index loc(#loc481)
      %8 = arith.index_cast %7 : index to i64 loc(#loc481)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc481)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_2_cons_buff_0 : memref<4352xui8>) loc(#loc481)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_2_cons_buff_1 : memref<4352xui8>) loc(#loc481)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_2_cons_buff_0 : memref<4352xui8>) loc(#loc481)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":816:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_2_4_cons_buff_0, %9, %direct_acc0_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc482)
      aie.use_lock(%direct_a_broadcast_2_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc483)
      aie.use_lock(%direct_w_broadcast_4_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc484)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc484)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc484)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc484)
      %13 = arith.addi %4, %c1 : index loc(#loc477)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc477)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_4_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc485)
      %14 = arith.index_cast %2 : i32 to index loc(#loc486)
      %15 = arith.index_cast %14 : index to i64 loc(#loc486)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc486)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_2_buff_0 : memref<1024xbf16>) loc(#loc486)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_2_buff_1 : memref<1024xbf16>) loc(#loc486)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_2_buff_0 : memref<1024xbf16>) loc(#loc486)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":822:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_2, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc487)
      aie.use_lock(%direct_y_worker_4_2_cons_lock_0, Release, %c1_i32) loc(#loc488)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc488)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc488)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc488)
      %20 = arith.addi %0, %c1 : index loc(#loc474)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc474)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc489)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc473)
    %core_4_5 = aie.core(%tile_4_5) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc491)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":833:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":829:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":829:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc491)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc491)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_4_3) : (memref<1024xf32>) -> () loc(#loc493)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc494)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":842:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":829:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc494)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc494)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc496)
      aie.use_lock(%direct_w_broadcast_4_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc497)
      %7 = arith.index_cast %5 : i32 to index loc(#loc498)
      %8 = arith.index_cast %7 : index to i64 loc(#loc498)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc498)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_3_cons_buff_0 : memref<4352xui8>) loc(#loc498)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_3_cons_buff_1 : memref<4352xui8>) loc(#loc498)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_3_cons_buff_0 : memref<4352xui8>) loc(#loc498)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":846:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_3_4_cons_buff_0, %9, %direct_acc0_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc499)
      aie.use_lock(%direct_a_broadcast_3_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc500)
      aie.use_lock(%direct_w_broadcast_4_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc501)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc501)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc501)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc501)
      %13 = arith.addi %4, %c1 : index loc(#loc494)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc494)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_4_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc502)
      %14 = arith.index_cast %2 : i32 to index loc(#loc503)
      %15 = arith.index_cast %14 : index to i64 loc(#loc503)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc503)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_3_buff_0 : memref<1024xbf16>) loc(#loc503)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_3_buff_1 : memref<1024xbf16>) loc(#loc503)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_3_buff_0 : memref<1024xbf16>) loc(#loc503)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":852:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_3, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc504)
      aie.use_lock(%direct_y_worker_4_3_cons_lock_0, Release, %c1_i32) loc(#loc505)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc505)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc505)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc505)
      %20 = arith.addi %0, %c1 : index loc(#loc491)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc491)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc506)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc490)
    %core_5_2 = aie.core(%tile_5_2) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc508)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":863:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":859:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":859:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc508)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc508)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_5_0) : (memref<1024xf32>) -> () loc(#loc510)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc511)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":872:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":859:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc511)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc511)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc513)
      aie.use_lock(%direct_w_broadcast_5_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc514)
      %7 = arith.index_cast %5 : i32 to index loc(#loc515)
      %8 = arith.index_cast %7 : index to i64 loc(#loc515)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc515)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_0_cons_buff_0 : memref<4352xui8>) loc(#loc515)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_0_cons_buff_1 : memref<4352xui8>) loc(#loc515)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_0_cons_buff_0 : memref<4352xui8>) loc(#loc515)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":876:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_0_5_cons_buff_0, %9, %direct_acc0_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc516)
      aie.use_lock(%direct_a_broadcast_0_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc517)
      aie.use_lock(%direct_w_broadcast_5_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc518)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc518)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc518)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc518)
      %13 = arith.addi %4, %c1 : index loc(#loc511)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc511)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_5_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc519)
      %14 = arith.index_cast %2 : i32 to index loc(#loc520)
      %15 = arith.index_cast %14 : index to i64 loc(#loc520)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc520)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_0_buff_0 : memref<1024xbf16>) loc(#loc520)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_0_buff_1 : memref<1024xbf16>) loc(#loc520)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_0_buff_0 : memref<1024xbf16>) loc(#loc520)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":882:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_0, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc521)
      aie.use_lock(%direct_y_worker_5_0_cons_lock_0, Release, %c1_i32) loc(#loc522)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc522)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc522)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc522)
      %20 = arith.addi %0, %c1 : index loc(#loc508)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc508)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc523)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc507)
    %core_5_3 = aie.core(%tile_5_3) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc525)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":893:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":889:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":889:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc525)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc525)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_5_1) : (memref<1024xf32>) -> () loc(#loc527)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc528)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":902:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":889:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc528)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc528)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc530)
      aie.use_lock(%direct_w_broadcast_5_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc531)
      %7 = arith.index_cast %5 : i32 to index loc(#loc532)
      %8 = arith.index_cast %7 : index to i64 loc(#loc532)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc532)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_1_cons_buff_0 : memref<4352xui8>) loc(#loc532)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_1_cons_buff_1 : memref<4352xui8>) loc(#loc532)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_1_cons_buff_0 : memref<4352xui8>) loc(#loc532)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":906:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_1_5_cons_buff_0, %9, %direct_acc0_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc533)
      aie.use_lock(%direct_a_broadcast_1_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc534)
      aie.use_lock(%direct_w_broadcast_5_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc535)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc535)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc535)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc535)
      %13 = arith.addi %4, %c1 : index loc(#loc528)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc528)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_5_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc536)
      %14 = arith.index_cast %2 : i32 to index loc(#loc537)
      %15 = arith.index_cast %14 : index to i64 loc(#loc537)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc537)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_1_buff_0 : memref<1024xbf16>) loc(#loc537)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_1_buff_1 : memref<1024xbf16>) loc(#loc537)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_1_buff_0 : memref<1024xbf16>) loc(#loc537)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":912:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_1, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc538)
      aie.use_lock(%direct_y_worker_5_1_cons_lock_0, Release, %c1_i32) loc(#loc539)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc539)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc539)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc539)
      %20 = arith.addi %0, %c1 : index loc(#loc525)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc525)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc540)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc524)
    %core_5_4 = aie.core(%tile_5_4) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc542)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":923:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":919:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":919:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc542)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc542)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_5_2) : (memref<1024xf32>) -> () loc(#loc544)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc545)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":932:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":919:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc545)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc545)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc547)
      aie.use_lock(%direct_w_broadcast_5_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc548)
      %7 = arith.index_cast %5 : i32 to index loc(#loc549)
      %8 = arith.index_cast %7 : index to i64 loc(#loc549)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc549)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_2_cons_buff_0 : memref<4352xui8>) loc(#loc549)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_2_cons_buff_1 : memref<4352xui8>) loc(#loc549)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_2_cons_buff_0 : memref<4352xui8>) loc(#loc549)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":936:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_2_5_cons_buff_0, %9, %direct_acc0_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc550)
      aie.use_lock(%direct_a_broadcast_2_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc551)
      aie.use_lock(%direct_w_broadcast_5_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc552)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc552)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc552)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc552)
      %13 = arith.addi %4, %c1 : index loc(#loc545)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc545)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_5_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc553)
      %14 = arith.index_cast %2 : i32 to index loc(#loc554)
      %15 = arith.index_cast %14 : index to i64 loc(#loc554)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc554)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_2_buff_0 : memref<1024xbf16>) loc(#loc554)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_2_buff_1 : memref<1024xbf16>) loc(#loc554)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_2_buff_0 : memref<1024xbf16>) loc(#loc554)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":942:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_2, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc555)
      aie.use_lock(%direct_y_worker_5_2_cons_lock_0, Release, %c1_i32) loc(#loc556)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc556)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc556)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc556)
      %20 = arith.addi %0, %c1 : index loc(#loc542)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc542)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc557)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc541)
    %core_5_5 = aie.core(%tile_5_5) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc559)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":953:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":949:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":949:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc559)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc559)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_5_3) : (memref<1024xf32>) -> () loc(#loc561)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc562)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":962:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":949:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc562)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc562)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc564)
      aie.use_lock(%direct_w_broadcast_5_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc565)
      %7 = arith.index_cast %5 : i32 to index loc(#loc566)
      %8 = arith.index_cast %7 : index to i64 loc(#loc566)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc566)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_3_cons_buff_0 : memref<4352xui8>) loc(#loc566)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_3_cons_buff_1 : memref<4352xui8>) loc(#loc566)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_3_cons_buff_0 : memref<4352xui8>) loc(#loc566)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":966:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_3_5_cons_buff_0, %9, %direct_acc0_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc567)
      aie.use_lock(%direct_a_broadcast_3_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc568)
      aie.use_lock(%direct_w_broadcast_5_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc569)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc569)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc569)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc569)
      %13 = arith.addi %4, %c1 : index loc(#loc562)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc562)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_5_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc570)
      %14 = arith.index_cast %2 : i32 to index loc(#loc571)
      %15 = arith.index_cast %14 : index to i64 loc(#loc571)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc571)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_3_buff_0 : memref<1024xbf16>) loc(#loc571)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_3_buff_1 : memref<1024xbf16>) loc(#loc571)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_3_buff_0 : memref<1024xbf16>) loc(#loc571)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":972:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_3, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc572)
      aie.use_lock(%direct_y_worker_5_3_cons_lock_0, Release, %c1_i32) loc(#loc573)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc573)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc573)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc573)
      %20 = arith.addi %0, %c1 : index loc(#loc559)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc559)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc574)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc558)
    %core_6_2 = aie.core(%tile_6_2) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc576)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":983:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":979:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":979:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc576)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc576)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_6_0) : (memref<1024xf32>) -> () loc(#loc578)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc579)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":992:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":979:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc579)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc579)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc581)
      aie.use_lock(%direct_w_broadcast_6_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc582)
      %7 = arith.index_cast %5 : i32 to index loc(#loc583)
      %8 = arith.index_cast %7 : index to i64 loc(#loc583)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc583)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_0_cons_buff_0 : memref<4352xui8>) loc(#loc583)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_0_cons_buff_1 : memref<4352xui8>) loc(#loc583)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_0_cons_buff_0 : memref<4352xui8>) loc(#loc583)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":996:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_0_6_cons_buff_0, %9, %direct_acc0_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc584)
      aie.use_lock(%direct_a_broadcast_0_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc585)
      aie.use_lock(%direct_w_broadcast_6_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc586)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc586)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc586)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc586)
      %13 = arith.addi %4, %c1 : index loc(#loc579)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc579)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_6_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc587)
      %14 = arith.index_cast %2 : i32 to index loc(#loc588)
      %15 = arith.index_cast %14 : index to i64 loc(#loc588)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc588)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_0_buff_0 : memref<1024xbf16>) loc(#loc588)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_0_buff_1 : memref<1024xbf16>) loc(#loc588)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_0_buff_0 : memref<1024xbf16>) loc(#loc588)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1002:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_0, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc589)
      aie.use_lock(%direct_y_worker_6_0_cons_lock_0, Release, %c1_i32) loc(#loc590)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc590)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc590)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc590)
      %20 = arith.addi %0, %c1 : index loc(#loc576)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc576)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc591)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc575)
    %core_6_3 = aie.core(%tile_6_3) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc593)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1013:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1009:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1009:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc593)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc593)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_6_1) : (memref<1024xf32>) -> () loc(#loc595)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc596)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1022:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1009:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc596)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc596)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc598)
      aie.use_lock(%direct_w_broadcast_6_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc599)
      %7 = arith.index_cast %5 : i32 to index loc(#loc600)
      %8 = arith.index_cast %7 : index to i64 loc(#loc600)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc600)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_1_cons_buff_0 : memref<4352xui8>) loc(#loc600)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_1_cons_buff_1 : memref<4352xui8>) loc(#loc600)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_1_cons_buff_0 : memref<4352xui8>) loc(#loc600)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1026:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_1_6_cons_buff_0, %9, %direct_acc0_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc601)
      aie.use_lock(%direct_a_broadcast_1_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc602)
      aie.use_lock(%direct_w_broadcast_6_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc603)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc603)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc603)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc603)
      %13 = arith.addi %4, %c1 : index loc(#loc596)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc596)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_6_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc604)
      %14 = arith.index_cast %2 : i32 to index loc(#loc605)
      %15 = arith.index_cast %14 : index to i64 loc(#loc605)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc605)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_1_buff_0 : memref<1024xbf16>) loc(#loc605)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_1_buff_1 : memref<1024xbf16>) loc(#loc605)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_1_buff_0 : memref<1024xbf16>) loc(#loc605)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1032:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_1, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc606)
      aie.use_lock(%direct_y_worker_6_1_cons_lock_0, Release, %c1_i32) loc(#loc607)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc607)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc607)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc607)
      %20 = arith.addi %0, %c1 : index loc(#loc593)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc593)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc608)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc592)
    %core_6_4 = aie.core(%tile_6_4) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc610)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1043:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1039:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1039:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc610)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc610)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_6_2) : (memref<1024xf32>) -> () loc(#loc612)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc613)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1052:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1039:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc613)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc613)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc615)
      aie.use_lock(%direct_w_broadcast_6_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc616)
      %7 = arith.index_cast %5 : i32 to index loc(#loc617)
      %8 = arith.index_cast %7 : index to i64 loc(#loc617)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc617)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_2_cons_buff_0 : memref<4352xui8>) loc(#loc617)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_2_cons_buff_1 : memref<4352xui8>) loc(#loc617)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_2_cons_buff_0 : memref<4352xui8>) loc(#loc617)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1056:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_2_6_cons_buff_0, %9, %direct_acc0_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc618)
      aie.use_lock(%direct_a_broadcast_2_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc619)
      aie.use_lock(%direct_w_broadcast_6_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc620)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc620)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc620)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc620)
      %13 = arith.addi %4, %c1 : index loc(#loc613)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc613)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_6_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc621)
      %14 = arith.index_cast %2 : i32 to index loc(#loc622)
      %15 = arith.index_cast %14 : index to i64 loc(#loc622)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc622)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_2_buff_0 : memref<1024xbf16>) loc(#loc622)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_2_buff_1 : memref<1024xbf16>) loc(#loc622)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_2_buff_0 : memref<1024xbf16>) loc(#loc622)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1062:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_2, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc623)
      aie.use_lock(%direct_y_worker_6_2_cons_lock_0, Release, %c1_i32) loc(#loc624)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc624)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc624)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc624)
      %20 = arith.addi %0, %c1 : index loc(#loc610)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc610)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc625)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc609)
    %core_6_5 = aie.core(%tile_6_5) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc627)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1073:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1069:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1069:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc627)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc627)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_6_3) : (memref<1024xf32>) -> () loc(#loc629)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc630)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1082:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1069:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc630)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc630)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc632)
      aie.use_lock(%direct_w_broadcast_6_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc633)
      %7 = arith.index_cast %5 : i32 to index loc(#loc634)
      %8 = arith.index_cast %7 : index to i64 loc(#loc634)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc634)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_3_cons_buff_0 : memref<4352xui8>) loc(#loc634)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_3_cons_buff_1 : memref<4352xui8>) loc(#loc634)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_3_cons_buff_0 : memref<4352xui8>) loc(#loc634)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1086:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_3_6_cons_buff_0, %9, %direct_acc0_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc635)
      aie.use_lock(%direct_a_broadcast_3_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc636)
      aie.use_lock(%direct_w_broadcast_6_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc637)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc637)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc637)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc637)
      %13 = arith.addi %4, %c1 : index loc(#loc630)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc630)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_6_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc638)
      %14 = arith.index_cast %2 : i32 to index loc(#loc639)
      %15 = arith.index_cast %14 : index to i64 loc(#loc639)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc639)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_3_buff_0 : memref<1024xbf16>) loc(#loc639)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_3_buff_1 : memref<1024xbf16>) loc(#loc639)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_3_buff_0 : memref<1024xbf16>) loc(#loc639)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1092:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_3, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc640)
      aie.use_lock(%direct_y_worker_6_3_cons_lock_0, Release, %c1_i32) loc(#loc641)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc641)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc641)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc641)
      %20 = arith.addi %0, %c1 : index loc(#loc627)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc627)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc642)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc626)
    %core_7_2 = aie.core(%tile_7_2) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc644)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1103:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1099:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1099:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc644)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc644)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_7_0) : (memref<1024xf32>) -> () loc(#loc646)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc647)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1112:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1099:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc647)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc647)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc649)
      aie.use_lock(%direct_w_broadcast_7_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc650)
      %7 = arith.index_cast %5 : i32 to index loc(#loc651)
      %8 = arith.index_cast %7 : index to i64 loc(#loc651)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc651)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_0_cons_buff_0 : memref<4352xui8>) loc(#loc651)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_0_cons_buff_1 : memref<4352xui8>) loc(#loc651)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_0_cons_buff_0 : memref<4352xui8>) loc(#loc651)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1116:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_0_7_cons_buff_0, %9, %direct_acc0_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc652)
      aie.use_lock(%direct_a_broadcast_0_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc653)
      aie.use_lock(%direct_w_broadcast_7_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc654)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc654)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc654)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc654)
      %13 = arith.addi %4, %c1 : index loc(#loc647)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc647)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_7_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc655)
      %14 = arith.index_cast %2 : i32 to index loc(#loc656)
      %15 = arith.index_cast %14 : index to i64 loc(#loc656)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc656)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_0_buff_0 : memref<1024xbf16>) loc(#loc656)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_0_buff_1 : memref<1024xbf16>) loc(#loc656)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_0_buff_0 : memref<1024xbf16>) loc(#loc656)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1122:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_0, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc657)
      aie.use_lock(%direct_y_worker_7_0_cons_lock_0, Release, %c1_i32) loc(#loc658)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc658)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc658)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc658)
      %20 = arith.addi %0, %c1 : index loc(#loc644)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc644)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc659)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc643)
    %core_7_3 = aie.core(%tile_7_3) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc661)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1133:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1129:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1129:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc661)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc661)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_7_1) : (memref<1024xf32>) -> () loc(#loc663)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc664)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1142:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1129:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc664)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc664)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc666)
      aie.use_lock(%direct_w_broadcast_7_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc667)
      %7 = arith.index_cast %5 : i32 to index loc(#loc668)
      %8 = arith.index_cast %7 : index to i64 loc(#loc668)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc668)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_1_cons_buff_0 : memref<4352xui8>) loc(#loc668)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_1_cons_buff_1 : memref<4352xui8>) loc(#loc668)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_1_cons_buff_0 : memref<4352xui8>) loc(#loc668)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1146:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_1_7_cons_buff_0, %9, %direct_acc0_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc669)
      aie.use_lock(%direct_a_broadcast_1_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc670)
      aie.use_lock(%direct_w_broadcast_7_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc671)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc671)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc671)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc671)
      %13 = arith.addi %4, %c1 : index loc(#loc664)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc664)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_7_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc672)
      %14 = arith.index_cast %2 : i32 to index loc(#loc673)
      %15 = arith.index_cast %14 : index to i64 loc(#loc673)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc673)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_1_buff_0 : memref<1024xbf16>) loc(#loc673)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_1_buff_1 : memref<1024xbf16>) loc(#loc673)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_1_buff_0 : memref<1024xbf16>) loc(#loc673)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1152:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_1, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc674)
      aie.use_lock(%direct_y_worker_7_1_cons_lock_0, Release, %c1_i32) loc(#loc675)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc675)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc675)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc675)
      %20 = arith.addi %0, %c1 : index loc(#loc661)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc661)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc676)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc660)
    %core_7_4 = aie.core(%tile_7_4) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc678)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1163:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1159:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1159:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc678)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc678)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_7_2) : (memref<1024xf32>) -> () loc(#loc680)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc681)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1172:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1159:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc681)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc681)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc683)
      aie.use_lock(%direct_w_broadcast_7_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc684)
      %7 = arith.index_cast %5 : i32 to index loc(#loc685)
      %8 = arith.index_cast %7 : index to i64 loc(#loc685)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc685)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_2_cons_buff_0 : memref<4352xui8>) loc(#loc685)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_2_cons_buff_1 : memref<4352xui8>) loc(#loc685)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_2_cons_buff_0 : memref<4352xui8>) loc(#loc685)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1176:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_2_7_cons_buff_0, %9, %direct_acc0_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc686)
      aie.use_lock(%direct_a_broadcast_2_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc687)
      aie.use_lock(%direct_w_broadcast_7_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc688)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc688)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc688)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc688)
      %13 = arith.addi %4, %c1 : index loc(#loc681)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc681)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_7_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc689)
      %14 = arith.index_cast %2 : i32 to index loc(#loc690)
      %15 = arith.index_cast %14 : index to i64 loc(#loc690)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc690)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_2_buff_0 : memref<1024xbf16>) loc(#loc690)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_2_buff_1 : memref<1024xbf16>) loc(#loc690)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_2_buff_0 : memref<1024xbf16>) loc(#loc690)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1182:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_2, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc691)
      aie.use_lock(%direct_y_worker_7_2_cons_lock_0, Release, %c1_i32) loc(#loc692)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc692)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc692)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc692)
      %20 = arith.addi %0, %c1 : index loc(#loc678)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc678)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc693)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc677)
    %core_7_5 = aie.core(%tile_7_5) {
      %c1 = arith.constant 1 : index loc(#loc167)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc167)
      %c0 = arith.constant 0 : index loc(#loc167)
      %c2 = arith.constant 2 : index loc(#loc167)
      %c0_i32 = arith.constant 0 : i32 loc(#loc167)
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %c2_i32 = arith.constant 2 : i32 loc(#loc167)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc695)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1193:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1189:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1189:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc695)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc695)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_7_3) : (memref<1024xf32>) -> () loc(#loc697)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc698)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1202:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1189:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc698)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc698)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc700)
      aie.use_lock(%direct_w_broadcast_7_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc701)
      %7 = arith.index_cast %5 : i32 to index loc(#loc702)
      %8 = arith.index_cast %7 : index to i64 loc(#loc702)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc702)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_3_cons_buff_0 : memref<4352xui8>) loc(#loc702)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_3_cons_buff_1 : memref<4352xui8>) loc(#loc702)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_3_cons_buff_0 : memref<4352xui8>) loc(#loc702)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1206:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_3_7_cons_buff_0, %9, %direct_acc0_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> () loc(#loc703)
      aie.use_lock(%direct_a_broadcast_3_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc704)
      aie.use_lock(%direct_w_broadcast_7_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc705)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc705)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc705)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc705)
      %13 = arith.addi %4, %c1 : index loc(#loc698)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc698)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_7_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc706)
      %14 = arith.index_cast %2 : i32 to index loc(#loc707)
      %15 = arith.index_cast %14 : index to i64 loc(#loc707)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc707)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_3_buff_0 : memref<1024xbf16>) loc(#loc707)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_3_buff_1 : memref<1024xbf16>) loc(#loc707)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_3_buff_0 : memref<1024xbf16>) loc(#loc707)
    ^bb13(%16: memref<1024xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1212:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_3, %16) : (memref<1024xf32>, memref<1024xbf16>) -> () loc(#loc708)
      aie.use_lock(%direct_y_worker_7_3_cons_lock_0, Release, %c1_i32) loc(#loc709)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc709)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc709)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc709)
      %20 = arith.addi %0, %c1 : index loc(#loc695)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc695)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc710)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc694)
    aie.runtime_sequence(%arg0: memref<32768xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1219:26), %arg1: memref<278528xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1219:53), %arg2: memref<32768xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1219:80)) {
      %0 = aiex.dma_configure_task_for @direct_y_host_0_shim_alloc {
        aie.dma_bd(%arg2 : memref<32768xbf16> offset = 0 len = 4096 sizes = [1, 1, 8, 512] strides = [0, 0, 4096, 1]) loc(#loc716)
        aie.end loc(#loc717)
      } {issue_token = true} loc(#loc715)
      aiex.dma_start_task(%0) loc(#loc718)
      %1 = aiex.dma_configure_task_for @direct_y_host_1_shim_alloc {
        aie.dma_bd(%arg2 : memref<32768xbf16> offset = 512 len = 4096 sizes = [1, 1, 8, 512] strides = [0, 0, 4096, 1]) loc(#loc720)
        aie.end loc(#loc721)
      } {issue_token = true} loc(#loc719)
      aiex.dma_start_task(%1) loc(#loc722)
      %2 = aiex.dma_configure_task_for @direct_y_host_2_shim_alloc {
        aie.dma_bd(%arg2 : memref<32768xbf16> offset = 1024 len = 4096 sizes = [1, 1, 8, 512] strides = [0, 0, 4096, 1]) loc(#loc724)
        aie.end loc(#loc725)
      } {issue_token = true} loc(#loc723)
      aiex.dma_start_task(%2) loc(#loc726)
      %3 = aiex.dma_configure_task_for @direct_y_host_3_shim_alloc {
        aie.dma_bd(%arg2 : memref<32768xbf16> offset = 1536 len = 4096 sizes = [1, 1, 8, 512] strides = [0, 0, 4096, 1]) loc(#loc728)
        aie.end loc(#loc729)
      } {issue_token = true} loc(#loc727)
      aiex.dma_start_task(%3) loc(#loc730)
      %4 = aiex.dma_configure_task_for @direct_y_host_4_shim_alloc {
        aie.dma_bd(%arg2 : memref<32768xbf16> offset = 2048 len = 4096 sizes = [1, 1, 8, 512] strides = [0, 0, 4096, 1]) loc(#loc732)
        aie.end loc(#loc733)
      } {issue_token = true} loc(#loc731)
      aiex.dma_start_task(%4) loc(#loc734)
      %5 = aiex.dma_configure_task_for @direct_y_host_5_shim_alloc {
        aie.dma_bd(%arg2 : memref<32768xbf16> offset = 2560 len = 4096 sizes = [1, 1, 8, 512] strides = [0, 0, 4096, 1]) loc(#loc736)
        aie.end loc(#loc737)
      } {issue_token = true} loc(#loc735)
      aiex.dma_start_task(%5) loc(#loc738)
      %6 = aiex.dma_configure_task_for @direct_y_host_6_shim_alloc {
        aie.dma_bd(%arg2 : memref<32768xbf16> offset = 3072 len = 4096 sizes = [1, 1, 8, 512] strides = [0, 0, 4096, 1]) loc(#loc740)
        aie.end loc(#loc741)
      } {issue_token = true} loc(#loc739)
      aiex.dma_start_task(%6) loc(#loc742)
      %7 = aiex.dma_configure_task_for @direct_y_host_7_shim_alloc {
        aie.dma_bd(%arg2 : memref<32768xbf16> offset = 3584 len = 4096 sizes = [1, 1, 8, 512] strides = [0, 0, 4096, 1]) loc(#loc744)
        aie.end loc(#loc745)
      } {issue_token = true} loc(#loc743)
      aiex.dma_start_task(%7) loc(#loc746)
      %8 = aiex.dma_configure_task_for @direct_a_host_0_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 0 len = 8192 sizes = [1, 8, 2, 512] strides = [0, 512, 4096, 1]) loc(#loc748)
        aie.end loc(#loc749)
      } loc(#loc747)
      aiex.dma_start_task(%8) loc(#loc750)
      %9 = aiex.dma_configure_task_for @direct_a_host_1_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 8192 len = 8192 sizes = [1, 8, 2, 512] strides = [0, 512, 4096, 1]) loc(#loc752)
        aie.end loc(#loc753)
      } loc(#loc751)
      aiex.dma_start_task(%9) loc(#loc754)
      %10 = aiex.dma_configure_task_for @direct_a_host_2_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 16384 len = 8192 sizes = [1, 8, 2, 512] strides = [0, 512, 4096, 1]) loc(#loc756)
        aie.end loc(#loc757)
      } loc(#loc755)
      aiex.dma_start_task(%10) loc(#loc758)
      %11 = aiex.dma_configure_task_for @direct_a_host_3_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 24576 len = 8192 sizes = [1, 8, 2, 512] strides = [0, 512, 4096, 1]) loc(#loc760)
        aie.end loc(#loc761)
      } loc(#loc759)
      aiex.dma_start_task(%11) loc(#loc762)
      %12 = aiex.dma_configure_task_for @direct_w_host_0_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 4352 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc764)
        aie.end loc(#loc765)
      } loc(#loc763)
      aiex.dma_start_task(%12) loc(#loc766)
      %13 = aiex.dma_configure_task_for @direct_w_host_1_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 39168 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc768)
        aie.end loc(#loc769)
      } loc(#loc767)
      aiex.dma_start_task(%13) loc(#loc770)
      %14 = aiex.dma_configure_task_for @direct_w_host_2_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 39168 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc772)
        aie.end loc(#loc773)
      } loc(#loc771)
      aiex.dma_start_task(%14) loc(#loc774)
      %15 = aiex.dma_configure_task_for @direct_w_host_3_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 73984 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc776)
        aie.end loc(#loc777)
      } loc(#loc775)
      aiex.dma_start_task(%15) loc(#loc778)
      %16 = aiex.dma_configure_task_for @direct_w_host_4_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 73984 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc780)
        aie.end loc(#loc781)
      } loc(#loc779)
      aiex.dma_start_task(%16) loc(#loc782)
      %17 = aiex.dma_configure_task_for @direct_w_host_5_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 108800 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc784)
        aie.end loc(#loc785)
      } loc(#loc783)
      aiex.dma_start_task(%17) loc(#loc786)
      %18 = aiex.dma_configure_task_for @direct_w_host_6_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 108800 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc788)
        aie.end loc(#loc789)
      } loc(#loc787)
      aiex.dma_start_task(%18) loc(#loc790)
      %19 = aiex.dma_configure_task_for @direct_w_host_7_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 143616 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc792)
        aie.end loc(#loc793)
      } loc(#loc791)
      aiex.dma_start_task(%19) loc(#loc794)
      aiex.dma_await_task(%0) loc(#loc795)
      aiex.dma_await_task(%1) loc(#loc796)
      aiex.dma_await_task(%2) loc(#loc797)
      aiex.dma_await_task(%3) loc(#loc798)
      aiex.dma_await_task(%4) loc(#loc799)
      aiex.dma_await_task(%5) loc(#loc800)
      aiex.dma_await_task(%6) loc(#loc801)
      aiex.dma_await_task(%7) loc(#loc802)
      aiex.dma_free_task(%0) loc(#loc803)
      aiex.dma_free_task(%1) loc(#loc804)
      aiex.dma_free_task(%2) loc(#loc805)
      aiex.dma_free_task(%3) loc(#loc806)
      aiex.dma_free_task(%4) loc(#loc807)
      aiex.dma_free_task(%5) loc(#loc808)
      aiex.dma_free_task(%6) loc(#loc809)
      aiex.dma_free_task(%7) loc(#loc810)
      aiex.dma_free_task(%8) loc(#loc811)
      aiex.dma_free_task(%9) loc(#loc812)
      aiex.dma_free_task(%10) loc(#loc813)
      aiex.dma_free_task(%11) loc(#loc814)
      aiex.dma_free_task(%12) loc(#loc815)
      aiex.dma_free_task(%13) loc(#loc816)
      aiex.dma_free_task(%14) loc(#loc817)
      aiex.dma_free_task(%15) loc(#loc818)
      aiex.dma_free_task(%16) loc(#loc819)
      aiex.dma_free_task(%17) loc(#loc820)
      aiex.dma_free_task(%18) loc(#loc821)
      aiex.dma_free_task(%19) loc(#loc822)
    } loc(#loc711)
    %memtile_dma_0_1 = aie.memtile_dma(%mem_tile_0_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc64)
      aie.dma_bd(%direct_a_host_0_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096 sizes = [2, 4, 512] strides = [512, 1024, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc64)
      aie.use_lock(%direct_a_host_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc64)
      aie.next_bd ^bb2 loc(#loc64)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc64)
      aie.dma_bd(%direct_a_host_0_cons_buff_1 : memref<4096xbf16> offset = 0 len = 4096 sizes = [2, 4, 512] strides = [512, 1024, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc64)
      aie.use_lock(%direct_a_host_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc64)
      aie.next_bd ^bb1 loc(#loc64)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc64)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc64)
      aie.dma_bd(%direct_a_host_0_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc64)
      aie.use_lock(%direct_a_host_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc64)
      aie.next_bd ^bb5 loc(#loc64)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc64)
      aie.dma_bd(%direct_a_host_0_cons_buff_1 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc64)
      aie.use_lock(%direct_a_host_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc64)
      aie.next_bd ^bb4 loc(#loc64)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc57)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      aie.dma_bd(%direct_w_host_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc52)
      aie.use_lock(%direct_w_host_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc52)
      aie.next_bd ^bb8 loc(#loc52)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      aie.dma_bd(%direct_w_host_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc52)
      aie.use_lock(%direct_w_host_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc52)
      aie.next_bd ^bb7 loc(#loc52)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc52)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      aie.dma_bd(%direct_w_host_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc52)
      aie.use_lock(%direct_w_host_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc52)
      aie.next_bd ^bb11 loc(#loc52)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      aie.dma_bd(%direct_w_host_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc52)
      aie.use_lock(%direct_w_host_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc52)
      aie.next_bd ^bb10 loc(#loc52)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc45)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_prod_lock_0, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb14 loc(#loc45)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_0_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_prod_lock_1, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb15 loc(#loc45)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_0_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_prod_lock_2, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb16 loc(#loc45)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_0_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_prod_lock_3, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb17 loc(#loc45)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_prod_lock_0, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb18 loc(#loc45)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_0_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_prod_lock_1, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb19 loc(#loc45)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_0_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_prod_lock_2, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb20 loc(#loc45)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_0_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_prod_lock_3, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb13 loc(#loc45)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc44)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_cons_lock_0, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb23 loc(#loc45)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_cons_lock_0, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb22 loc(#loc45)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc42)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_0_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_cons_lock_1, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb26 loc(#loc45)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_0_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_cons_lock_1, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb25 loc(#loc45)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc41)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_0_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_cons_lock_2, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb29 loc(#loc45)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_0_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_cons_lock_2, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb28 loc(#loc45)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc39)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_0_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_cons_lock_3, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb32 loc(#loc45)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_0_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc45)
      aie.use_lock(%direct_y_host_0_cons_lock_3, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb31 loc(#loc45)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc65)
    } loc(#loc65)
    %mem_0_2 = aie.mem(%tile_0_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_a_broadcast_0_0_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc65)
      aie.use_lock(%direct_a_broadcast_0_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb1 loc(#loc65)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc57)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_0_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_w_broadcast_0_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc57)
      aie.use_lock(%direct_w_broadcast_0_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb4 loc(#loc57)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_0_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_w_broadcast_0_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc57)
      aie.use_lock(%direct_w_broadcast_0_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb3 loc(#loc57)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc44)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_0_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_y_worker_0_0_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc44)
      aie.use_lock(%direct_y_worker_0_0_prod_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb7 loc(#loc44)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_0_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_y_worker_0_0_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc44)
      aie.use_lock(%direct_y_worker_0_0_prod_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb6 loc(#loc44)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc65)
    } loc(#loc65)
    %mem_1_2 = aie.mem(%tile_1_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_a_broadcast_0_1_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc65)
      aie.use_lock(%direct_a_broadcast_0_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb1 loc(#loc65)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc56)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_1_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_1_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_1_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb4 loc(#loc56)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_1_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_1_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_1_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb3 loc(#loc56)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc36)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_1_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_worker_1_0_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc36)
      aie.use_lock(%direct_y_worker_1_0_prod_lock_0, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb7 loc(#loc36)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_1_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_worker_1_0_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc36)
      aie.use_lock(%direct_y_worker_1_0_prod_lock_0, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb6 loc(#loc36)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc65)
    } loc(#loc65)
    %mem_2_2 = aie.mem(%tile_2_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_a_broadcast_0_2_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc65)
      aie.use_lock(%direct_a_broadcast_0_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb1 loc(#loc65)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc55)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_2_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_broadcast_2_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc55)
      aie.use_lock(%direct_w_broadcast_2_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb4 loc(#loc55)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_2_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_broadcast_2_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc55)
      aie.use_lock(%direct_w_broadcast_2_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb3 loc(#loc55)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc30)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_2_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc30)
      aie.dma_bd(%direct_y_worker_2_0_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc30)
      aie.use_lock(%direct_y_worker_2_0_prod_lock_0, Release, %c1_i32) loc(#loc30)
      aie.next_bd ^bb7 loc(#loc30)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_2_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc30)
      aie.dma_bd(%direct_y_worker_2_0_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc30)
      aie.use_lock(%direct_y_worker_2_0_prod_lock_0, Release, %c1_i32) loc(#loc30)
      aie.next_bd ^bb6 loc(#loc30)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc65)
    } loc(#loc65)
    %mem_3_2 = aie.mem(%tile_3_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_a_broadcast_0_3_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc65)
      aie.use_lock(%direct_a_broadcast_0_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb1 loc(#loc65)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc54)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_3_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_w_broadcast_3_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc54)
      aie.use_lock(%direct_w_broadcast_3_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb4 loc(#loc54)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_3_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_w_broadcast_3_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc54)
      aie.use_lock(%direct_w_broadcast_3_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb3 loc(#loc54)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc25)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_3_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc25)
      aie.dma_bd(%direct_y_worker_3_0_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc25)
      aie.use_lock(%direct_y_worker_3_0_prod_lock_0, Release, %c1_i32) loc(#loc25)
      aie.next_bd ^bb7 loc(#loc25)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_3_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc25)
      aie.dma_bd(%direct_y_worker_3_0_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc25)
      aie.use_lock(%direct_y_worker_3_0_prod_lock_0, Release, %c1_i32) loc(#loc25)
      aie.next_bd ^bb6 loc(#loc25)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc65)
    } loc(#loc65)
    %mem_4_2 = aie.mem(%tile_4_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_a_broadcast_0_4_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc65)
      aie.use_lock(%direct_a_broadcast_0_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb1 loc(#loc65)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc53)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_4_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb4 loc(#loc53)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_4_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb3 loc(#loc53)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc20)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_4_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc20)
      aie.dma_bd(%direct_y_worker_4_0_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc20)
      aie.use_lock(%direct_y_worker_4_0_prod_lock_0, Release, %c1_i32) loc(#loc20)
      aie.next_bd ^bb7 loc(#loc20)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_4_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc20)
      aie.dma_bd(%direct_y_worker_4_0_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc20)
      aie.use_lock(%direct_y_worker_4_0_prod_lock_0, Release, %c1_i32) loc(#loc20)
      aie.next_bd ^bb6 loc(#loc20)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc65)
    } loc(#loc65)
    %mem_5_2 = aie.mem(%tile_5_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_a_broadcast_0_5_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc65)
      aie.use_lock(%direct_a_broadcast_0_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb1 loc(#loc65)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc51)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_5_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_w_broadcast_5_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc51)
      aie.use_lock(%direct_w_broadcast_5_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb4 loc(#loc51)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_5_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_w_broadcast_5_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc51)
      aie.use_lock(%direct_w_broadcast_5_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb3 loc(#loc51)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc15)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_5_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc15)
      aie.dma_bd(%direct_y_worker_5_0_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc15)
      aie.use_lock(%direct_y_worker_5_0_prod_lock_0, Release, %c1_i32) loc(#loc15)
      aie.next_bd ^bb7 loc(#loc15)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_5_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc15)
      aie.dma_bd(%direct_y_worker_5_0_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc15)
      aie.use_lock(%direct_y_worker_5_0_prod_lock_0, Release, %c1_i32) loc(#loc15)
      aie.next_bd ^bb6 loc(#loc15)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc65)
    } loc(#loc65)
    %mem_6_2 = aie.mem(%tile_6_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_a_broadcast_0_6_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc65)
      aie.use_lock(%direct_a_broadcast_0_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb1 loc(#loc65)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc49)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_6_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_broadcast_6_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc49)
      aie.use_lock(%direct_w_broadcast_6_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb4 loc(#loc49)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_6_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_broadcast_6_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc49)
      aie.use_lock(%direct_w_broadcast_6_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb3 loc(#loc49)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc10)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_6_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%direct_y_worker_6_0_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc10)
      aie.use_lock(%direct_y_worker_6_0_prod_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb7 loc(#loc10)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_6_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%direct_y_worker_6_0_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc10)
      aie.use_lock(%direct_y_worker_6_0_prod_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb6 loc(#loc10)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc65)
    } loc(#loc65)
    %mem_7_2 = aie.mem(%tile_7_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc65)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_a_broadcast_0_7_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc65)
      aie.use_lock(%direct_a_broadcast_0_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb1 loc(#loc65)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc47)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_7_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_7_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_7_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb4 loc(#loc47)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_7_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_7_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_7_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb3 loc(#loc47)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc5)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_7_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc5)
      aie.dma_bd(%direct_y_worker_7_0_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc5)
      aie.use_lock(%direct_y_worker_7_0_prod_lock_0, Release, %c1_i32) loc(#loc5)
      aie.next_bd ^bb7 loc(#loc5)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_7_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc5)
      aie.dma_bd(%direct_y_worker_7_0_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc5)
      aie.use_lock(%direct_y_worker_7_0_prod_lock_0, Release, %c1_i32) loc(#loc5)
      aie.next_bd ^bb6 loc(#loc5)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc65)
    } loc(#loc65)
    aie.shim_dma_allocation @direct_a_host_0_shim_alloc(%shim_noc_tile_0_0, MM2S, 0) loc(#loc64)
    %memtile_dma_1_1 = aie.memtile_dma(%mem_tile_1_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_a_host_1_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096 sizes = [2, 4, 512] strides = [512, 1024, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc62)
      aie.use_lock(%direct_a_host_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb2 loc(#loc62)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_a_host_1_cons_buff_1 : memref<4096xbf16> offset = 0 len = 4096 sizes = [2, 4, 512] strides = [512, 1024, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc62)
      aie.use_lock(%direct_a_host_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb1 loc(#loc62)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc62)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_a_host_1_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc62)
      aie.use_lock(%direct_a_host_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb5 loc(#loc62)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_a_host_1_cons_buff_1 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc62)
      aie.use_lock(%direct_a_host_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb4 loc(#loc62)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc56)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_host_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc50)
      aie.use_lock(%direct_w_host_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb8 loc(#loc50)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_host_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc50)
      aie.use_lock(%direct_w_host_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb7 loc(#loc50)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc50)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_host_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc50)
      aie.use_lock(%direct_w_host_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb11 loc(#loc50)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_host_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc50)
      aie.use_lock(%direct_w_host_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb10 loc(#loc50)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc37)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_prod_lock_0, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb14 loc(#loc37)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_1_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_prod_lock_1, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb15 loc(#loc37)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_1_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_prod_lock_2, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb16 loc(#loc37)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_1_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_prod_lock_3, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb17 loc(#loc37)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_prod_lock_0, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb18 loc(#loc37)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_1_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_prod_lock_1, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb19 loc(#loc37)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_1_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_prod_lock_2, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb20 loc(#loc37)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_1_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_prod_lock_3, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb13 loc(#loc37)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc36)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_cons_lock_0, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb23 loc(#loc37)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_cons_lock_0, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb22 loc(#loc37)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc35)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_1_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_cons_lock_1, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb26 loc(#loc37)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_1_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_cons_lock_1, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb25 loc(#loc37)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc33)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_1_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_cons_lock_2, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb29 loc(#loc37)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_1_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_cons_lock_2, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb28 loc(#loc37)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc32)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_1_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_cons_lock_3, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb32 loc(#loc37)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_1_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc37)
      aie.use_lock(%direct_y_host_1_cons_lock_3, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb31 loc(#loc37)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc63)
    } loc(#loc63)
    %mem_0_3 = aie.mem(%tile_0_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_broadcast_1_0_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_broadcast_1_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc57)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_0_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_w_broadcast_0_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc57)
      aie.use_lock(%direct_w_broadcast_0_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb4 loc(#loc57)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_0_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_w_broadcast_0_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc57)
      aie.use_lock(%direct_w_broadcast_0_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb3 loc(#loc57)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc42)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_0_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc42)
      aie.dma_bd(%direct_y_worker_0_1_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc42)
      aie.use_lock(%direct_y_worker_0_1_prod_lock_0, Release, %c1_i32) loc(#loc42)
      aie.next_bd ^bb7 loc(#loc42)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_0_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc42)
      aie.dma_bd(%direct_y_worker_0_1_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc42)
      aie.use_lock(%direct_y_worker_0_1_prod_lock_0, Release, %c1_i32) loc(#loc42)
      aie.next_bd ^bb6 loc(#loc42)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc63)
    } loc(#loc63)
    %mem_1_3 = aie.mem(%tile_1_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_broadcast_1_1_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_broadcast_1_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc56)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_1_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_1_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_1_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb4 loc(#loc56)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_1_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_1_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_1_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb3 loc(#loc56)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc35)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_1_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc35)
      aie.dma_bd(%direct_y_worker_1_1_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc35)
      aie.use_lock(%direct_y_worker_1_1_prod_lock_0, Release, %c1_i32) loc(#loc35)
      aie.next_bd ^bb7 loc(#loc35)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_1_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc35)
      aie.dma_bd(%direct_y_worker_1_1_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc35)
      aie.use_lock(%direct_y_worker_1_1_prod_lock_0, Release, %c1_i32) loc(#loc35)
      aie.next_bd ^bb6 loc(#loc35)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc63)
    } loc(#loc63)
    %mem_2_3 = aie.mem(%tile_2_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_broadcast_1_2_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_broadcast_1_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc55)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_2_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_broadcast_2_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc55)
      aie.use_lock(%direct_w_broadcast_2_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb4 loc(#loc55)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_2_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_broadcast_2_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc55)
      aie.use_lock(%direct_w_broadcast_2_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb3 loc(#loc55)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc29)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_2_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc29)
      aie.dma_bd(%direct_y_worker_2_1_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc29)
      aie.use_lock(%direct_y_worker_2_1_prod_lock_0, Release, %c1_i32) loc(#loc29)
      aie.next_bd ^bb7 loc(#loc29)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_2_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc29)
      aie.dma_bd(%direct_y_worker_2_1_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc29)
      aie.use_lock(%direct_y_worker_2_1_prod_lock_0, Release, %c1_i32) loc(#loc29)
      aie.next_bd ^bb6 loc(#loc29)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc63)
    } loc(#loc63)
    %mem_3_3 = aie.mem(%tile_3_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_broadcast_1_3_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_broadcast_1_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc54)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_3_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_w_broadcast_3_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc54)
      aie.use_lock(%direct_w_broadcast_3_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb4 loc(#loc54)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_3_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_w_broadcast_3_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc54)
      aie.use_lock(%direct_w_broadcast_3_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb3 loc(#loc54)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc24)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_3_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc24)
      aie.dma_bd(%direct_y_worker_3_1_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc24)
      aie.use_lock(%direct_y_worker_3_1_prod_lock_0, Release, %c1_i32) loc(#loc24)
      aie.next_bd ^bb7 loc(#loc24)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_3_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc24)
      aie.dma_bd(%direct_y_worker_3_1_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc24)
      aie.use_lock(%direct_y_worker_3_1_prod_lock_0, Release, %c1_i32) loc(#loc24)
      aie.next_bd ^bb6 loc(#loc24)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc63)
    } loc(#loc63)
    %mem_4_3 = aie.mem(%tile_4_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_broadcast_1_4_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_broadcast_1_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc53)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_4_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb4 loc(#loc53)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_4_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb3 loc(#loc53)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc19)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_4_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc19)
      aie.dma_bd(%direct_y_worker_4_1_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc19)
      aie.use_lock(%direct_y_worker_4_1_prod_lock_0, Release, %c1_i32) loc(#loc19)
      aie.next_bd ^bb7 loc(#loc19)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_4_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc19)
      aie.dma_bd(%direct_y_worker_4_1_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc19)
      aie.use_lock(%direct_y_worker_4_1_prod_lock_0, Release, %c1_i32) loc(#loc19)
      aie.next_bd ^bb6 loc(#loc19)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc63)
    } loc(#loc63)
    %mem_5_3 = aie.mem(%tile_5_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_broadcast_1_5_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_broadcast_1_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc51)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_5_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_w_broadcast_5_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc51)
      aie.use_lock(%direct_w_broadcast_5_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb4 loc(#loc51)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_5_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_w_broadcast_5_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc51)
      aie.use_lock(%direct_w_broadcast_5_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb3 loc(#loc51)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc14)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_5_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc14)
      aie.dma_bd(%direct_y_worker_5_1_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc14)
      aie.use_lock(%direct_y_worker_5_1_prod_lock_0, Release, %c1_i32) loc(#loc14)
      aie.next_bd ^bb7 loc(#loc14)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_5_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc14)
      aie.dma_bd(%direct_y_worker_5_1_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc14)
      aie.use_lock(%direct_y_worker_5_1_prod_lock_0, Release, %c1_i32) loc(#loc14)
      aie.next_bd ^bb6 loc(#loc14)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc63)
    } loc(#loc63)
    %mem_6_3 = aie.mem(%tile_6_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_broadcast_1_6_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_broadcast_1_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc49)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_6_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_broadcast_6_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc49)
      aie.use_lock(%direct_w_broadcast_6_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb4 loc(#loc49)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_6_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_broadcast_6_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc49)
      aie.use_lock(%direct_w_broadcast_6_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb3 loc(#loc49)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc9)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_6_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc9)
      aie.dma_bd(%direct_y_worker_6_1_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc9)
      aie.use_lock(%direct_y_worker_6_1_prod_lock_0, Release, %c1_i32) loc(#loc9)
      aie.next_bd ^bb7 loc(#loc9)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_6_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc9)
      aie.dma_bd(%direct_y_worker_6_1_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc9)
      aie.use_lock(%direct_y_worker_6_1_prod_lock_0, Release, %c1_i32) loc(#loc9)
      aie.next_bd ^bb6 loc(#loc9)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc63)
    } loc(#loc63)
    %mem_7_3 = aie.mem(%tile_7_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc63)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_broadcast_1_7_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_broadcast_1_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc47)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_7_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_7_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_7_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb4 loc(#loc47)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_7_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_7_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_7_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb3 loc(#loc47)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc4)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_7_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc4)
      aie.dma_bd(%direct_y_worker_7_1_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc4)
      aie.use_lock(%direct_y_worker_7_1_prod_lock_0, Release, %c1_i32) loc(#loc4)
      aie.next_bd ^bb7 loc(#loc4)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_7_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc4)
      aie.dma_bd(%direct_y_worker_7_1_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc4)
      aie.use_lock(%direct_y_worker_7_1_prod_lock_0, Release, %c1_i32) loc(#loc4)
      aie.next_bd ^bb6 loc(#loc4)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc63)
    } loc(#loc63)
    aie.shim_dma_allocation @direct_a_host_1_shim_alloc(%shim_noc_tile_1_0, MM2S, 0) loc(#loc62)
    %memtile_dma_2_1 = aie.memtile_dma(%mem_tile_2_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      aie.dma_bd(%direct_a_host_2_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096 sizes = [2, 4, 512] strides = [512, 1024, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc60)
      aie.use_lock(%direct_a_host_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc60)
      aie.next_bd ^bb2 loc(#loc60)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      aie.dma_bd(%direct_a_host_2_cons_buff_1 : memref<4096xbf16> offset = 0 len = 4096 sizes = [2, 4, 512] strides = [512, 1024, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc60)
      aie.use_lock(%direct_a_host_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc60)
      aie.next_bd ^bb1 loc(#loc60)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc60)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      aie.dma_bd(%direct_a_host_2_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc60)
      aie.use_lock(%direct_a_host_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc60)
      aie.next_bd ^bb5 loc(#loc60)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      aie.dma_bd(%direct_a_host_2_cons_buff_1 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc60)
      aie.use_lock(%direct_a_host_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc60)
      aie.next_bd ^bb4 loc(#loc60)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc55)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc48)
      aie.dma_bd(%direct_w_host_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc48)
      aie.use_lock(%direct_w_host_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc48)
      aie.next_bd ^bb8 loc(#loc48)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc48)
      aie.dma_bd(%direct_w_host_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc48)
      aie.use_lock(%direct_w_host_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc48)
      aie.next_bd ^bb7 loc(#loc48)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc48)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc48)
      aie.dma_bd(%direct_w_host_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc48)
      aie.use_lock(%direct_w_host_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc48)
      aie.next_bd ^bb11 loc(#loc48)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc48)
      aie.dma_bd(%direct_w_host_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc48)
      aie.use_lock(%direct_w_host_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc48)
      aie.next_bd ^bb10 loc(#loc48)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc31)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_0, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb14 loc(#loc31)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_2_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_1, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb15 loc(#loc31)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_2_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_2, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb16 loc(#loc31)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_2_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_3, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb17 loc(#loc31)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_0, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb18 loc(#loc31)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_2_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_1, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb19 loc(#loc31)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_2_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_2, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb20 loc(#loc31)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_2_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_3, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb13 loc(#loc31)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc30)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_0, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb23 loc(#loc31)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_0, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb22 loc(#loc31)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc29)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_2_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_1, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb26 loc(#loc31)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_2_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_1, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb25 loc(#loc31)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc28)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_2_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_2, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb29 loc(#loc31)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_2_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_2, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb28 loc(#loc31)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc27)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_2_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_3, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb32 loc(#loc31)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_2_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_3, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb31 loc(#loc31)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc61)
    } loc(#loc61)
    %mem_0_4 = aie.mem(%tile_0_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_a_broadcast_2_0_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc61)
      aie.use_lock(%direct_a_broadcast_2_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb1 loc(#loc61)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc57)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_0_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_w_broadcast_0_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc57)
      aie.use_lock(%direct_w_broadcast_0_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb4 loc(#loc57)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_0_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_w_broadcast_0_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc57)
      aie.use_lock(%direct_w_broadcast_0_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb3 loc(#loc57)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc41)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_0_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_worker_0_2_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc41)
      aie.use_lock(%direct_y_worker_0_2_prod_lock_0, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb7 loc(#loc41)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_0_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_worker_0_2_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc41)
      aie.use_lock(%direct_y_worker_0_2_prod_lock_0, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb6 loc(#loc41)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc61)
    } loc(#loc61)
    %mem_1_4 = aie.mem(%tile_1_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_a_broadcast_2_1_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc61)
      aie.use_lock(%direct_a_broadcast_2_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb1 loc(#loc61)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc56)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_1_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_1_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_1_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb4 loc(#loc56)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_1_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_1_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_1_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb3 loc(#loc56)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc33)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_1_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc33)
      aie.dma_bd(%direct_y_worker_1_2_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc33)
      aie.use_lock(%direct_y_worker_1_2_prod_lock_0, Release, %c1_i32) loc(#loc33)
      aie.next_bd ^bb7 loc(#loc33)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_1_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc33)
      aie.dma_bd(%direct_y_worker_1_2_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc33)
      aie.use_lock(%direct_y_worker_1_2_prod_lock_0, Release, %c1_i32) loc(#loc33)
      aie.next_bd ^bb6 loc(#loc33)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc61)
    } loc(#loc61)
    %mem_2_4 = aie.mem(%tile_2_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_a_broadcast_2_2_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc61)
      aie.use_lock(%direct_a_broadcast_2_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb1 loc(#loc61)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc55)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_2_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_broadcast_2_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc55)
      aie.use_lock(%direct_w_broadcast_2_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb4 loc(#loc55)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_2_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_broadcast_2_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc55)
      aie.use_lock(%direct_w_broadcast_2_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb3 loc(#loc55)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc28)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_2_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc28)
      aie.dma_bd(%direct_y_worker_2_2_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc28)
      aie.use_lock(%direct_y_worker_2_2_prod_lock_0, Release, %c1_i32) loc(#loc28)
      aie.next_bd ^bb7 loc(#loc28)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_2_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc28)
      aie.dma_bd(%direct_y_worker_2_2_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc28)
      aie.use_lock(%direct_y_worker_2_2_prod_lock_0, Release, %c1_i32) loc(#loc28)
      aie.next_bd ^bb6 loc(#loc28)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc61)
    } loc(#loc61)
    %mem_3_4 = aie.mem(%tile_3_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_a_broadcast_2_3_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc61)
      aie.use_lock(%direct_a_broadcast_2_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb1 loc(#loc61)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc54)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_3_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_w_broadcast_3_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc54)
      aie.use_lock(%direct_w_broadcast_3_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb4 loc(#loc54)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_3_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_w_broadcast_3_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc54)
      aie.use_lock(%direct_w_broadcast_3_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb3 loc(#loc54)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc23)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_3_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc23)
      aie.dma_bd(%direct_y_worker_3_2_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc23)
      aie.use_lock(%direct_y_worker_3_2_prod_lock_0, Release, %c1_i32) loc(#loc23)
      aie.next_bd ^bb7 loc(#loc23)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_3_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc23)
      aie.dma_bd(%direct_y_worker_3_2_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc23)
      aie.use_lock(%direct_y_worker_3_2_prod_lock_0, Release, %c1_i32) loc(#loc23)
      aie.next_bd ^bb6 loc(#loc23)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc61)
    } loc(#loc61)
    %mem_4_4 = aie.mem(%tile_4_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_a_broadcast_2_4_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc61)
      aie.use_lock(%direct_a_broadcast_2_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb1 loc(#loc61)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc53)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_4_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb4 loc(#loc53)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_4_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb3 loc(#loc53)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc18)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_4_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc18)
      aie.dma_bd(%direct_y_worker_4_2_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc18)
      aie.use_lock(%direct_y_worker_4_2_prod_lock_0, Release, %c1_i32) loc(#loc18)
      aie.next_bd ^bb7 loc(#loc18)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_4_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc18)
      aie.dma_bd(%direct_y_worker_4_2_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc18)
      aie.use_lock(%direct_y_worker_4_2_prod_lock_0, Release, %c1_i32) loc(#loc18)
      aie.next_bd ^bb6 loc(#loc18)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc61)
    } loc(#loc61)
    %mem_5_4 = aie.mem(%tile_5_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_a_broadcast_2_5_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc61)
      aie.use_lock(%direct_a_broadcast_2_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb1 loc(#loc61)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc51)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_5_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_w_broadcast_5_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc51)
      aie.use_lock(%direct_w_broadcast_5_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb4 loc(#loc51)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_5_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_w_broadcast_5_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc51)
      aie.use_lock(%direct_w_broadcast_5_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb3 loc(#loc51)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc13)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_5_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc13)
      aie.dma_bd(%direct_y_worker_5_2_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc13)
      aie.use_lock(%direct_y_worker_5_2_prod_lock_0, Release, %c1_i32) loc(#loc13)
      aie.next_bd ^bb7 loc(#loc13)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_5_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc13)
      aie.dma_bd(%direct_y_worker_5_2_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc13)
      aie.use_lock(%direct_y_worker_5_2_prod_lock_0, Release, %c1_i32) loc(#loc13)
      aie.next_bd ^bb6 loc(#loc13)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc61)
    } loc(#loc61)
    %mem_6_4 = aie.mem(%tile_6_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_a_broadcast_2_6_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc61)
      aie.use_lock(%direct_a_broadcast_2_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb1 loc(#loc61)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc49)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_6_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_broadcast_6_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc49)
      aie.use_lock(%direct_w_broadcast_6_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb4 loc(#loc49)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_6_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_broadcast_6_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc49)
      aie.use_lock(%direct_w_broadcast_6_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb3 loc(#loc49)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc8)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_6_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc8)
      aie.dma_bd(%direct_y_worker_6_2_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc8)
      aie.use_lock(%direct_y_worker_6_2_prod_lock_0, Release, %c1_i32) loc(#loc8)
      aie.next_bd ^bb7 loc(#loc8)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_6_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc8)
      aie.dma_bd(%direct_y_worker_6_2_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc8)
      aie.use_lock(%direct_y_worker_6_2_prod_lock_0, Release, %c1_i32) loc(#loc8)
      aie.next_bd ^bb6 loc(#loc8)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc61)
    } loc(#loc61)
    %mem_7_4 = aie.mem(%tile_7_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc61)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_a_broadcast_2_7_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc61)
      aie.use_lock(%direct_a_broadcast_2_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb1 loc(#loc61)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc47)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_7_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_7_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_7_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb4 loc(#loc47)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_7_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_7_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_7_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb3 loc(#loc47)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc3)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_7_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%direct_y_worker_7_2_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc3)
      aie.use_lock(%direct_y_worker_7_2_prod_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb7 loc(#loc3)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_7_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%direct_y_worker_7_2_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc3)
      aie.use_lock(%direct_y_worker_7_2_prod_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb6 loc(#loc3)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc61)
    } loc(#loc61)
    aie.shim_dma_allocation @direct_a_host_2_shim_alloc(%shim_noc_tile_2_0, MM2S, 0) loc(#loc60)
    %memtile_dma_3_1 = aie.memtile_dma(%mem_tile_3_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc58)
      aie.dma_bd(%direct_a_host_3_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096 sizes = [2, 4, 512] strides = [512, 1024, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc58)
      aie.use_lock(%direct_a_host_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc58)
      aie.next_bd ^bb2 loc(#loc58)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc58)
      aie.dma_bd(%direct_a_host_3_cons_buff_1 : memref<4096xbf16> offset = 0 len = 4096 sizes = [2, 4, 512] strides = [512, 1024, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc58)
      aie.use_lock(%direct_a_host_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc58)
      aie.next_bd ^bb1 loc(#loc58)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc58)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc58)
      aie.dma_bd(%direct_a_host_3_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc58)
      aie.use_lock(%direct_a_host_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc58)
      aie.next_bd ^bb5 loc(#loc58)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc58)
      aie.dma_bd(%direct_a_host_3_cons_buff_1 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc58)
      aie.use_lock(%direct_a_host_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc58)
      aie.next_bd ^bb4 loc(#loc58)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc54)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc46)
      aie.dma_bd(%direct_w_host_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc46)
      aie.use_lock(%direct_w_host_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc46)
      aie.next_bd ^bb8 loc(#loc46)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc46)
      aie.dma_bd(%direct_w_host_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc46)
      aie.use_lock(%direct_w_host_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc46)
      aie.next_bd ^bb7 loc(#loc46)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc46)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc46)
      aie.dma_bd(%direct_w_host_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc46)
      aie.use_lock(%direct_w_host_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc46)
      aie.next_bd ^bb11 loc(#loc46)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc46)
      aie.dma_bd(%direct_w_host_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc46)
      aie.use_lock(%direct_w_host_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc46)
      aie.next_bd ^bb10 loc(#loc46)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc26)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_0, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb14 loc(#loc26)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_3_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_1, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb15 loc(#loc26)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_3_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_2, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb16 loc(#loc26)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_3_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_3, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb17 loc(#loc26)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_0, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb18 loc(#loc26)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_3_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_1, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb19 loc(#loc26)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_3_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_2, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb20 loc(#loc26)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_3_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_3, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb13 loc(#loc26)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc25)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_0, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb23 loc(#loc26)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_0, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb22 loc(#loc26)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc24)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_3_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_1, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb26 loc(#loc26)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_3_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_1, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb25 loc(#loc26)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc23)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_3_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_2, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb29 loc(#loc26)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_3_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_2, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb28 loc(#loc26)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc22)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_3_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_3, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb32 loc(#loc26)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_3_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_3, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb31 loc(#loc26)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc59)
    } loc(#loc59)
    %mem_0_5 = aie.mem(%tile_0_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_a_broadcast_3_0_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc59)
      aie.use_lock(%direct_a_broadcast_3_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb1 loc(#loc59)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc57)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_0_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_w_broadcast_0_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc57)
      aie.use_lock(%direct_w_broadcast_0_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb4 loc(#loc57)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_0_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_w_broadcast_0_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc57)
      aie.use_lock(%direct_w_broadcast_0_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb3 loc(#loc57)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc39)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_0_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc39)
      aie.dma_bd(%direct_y_worker_0_3_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc39)
      aie.use_lock(%direct_y_worker_0_3_prod_lock_0, Release, %c1_i32) loc(#loc39)
      aie.next_bd ^bb7 loc(#loc39)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_0_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc39)
      aie.dma_bd(%direct_y_worker_0_3_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc39)
      aie.use_lock(%direct_y_worker_0_3_prod_lock_0, Release, %c1_i32) loc(#loc39)
      aie.next_bd ^bb6 loc(#loc39)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc59)
    } loc(#loc59)
    %mem_1_5 = aie.mem(%tile_1_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_a_broadcast_3_1_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc59)
      aie.use_lock(%direct_a_broadcast_3_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb1 loc(#loc59)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc56)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_1_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_1_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_1_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb4 loc(#loc56)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_1_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_1_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_1_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb3 loc(#loc56)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc32)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_1_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc32)
      aie.dma_bd(%direct_y_worker_1_3_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc32)
      aie.use_lock(%direct_y_worker_1_3_prod_lock_0, Release, %c1_i32) loc(#loc32)
      aie.next_bd ^bb7 loc(#loc32)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_1_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc32)
      aie.dma_bd(%direct_y_worker_1_3_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc32)
      aie.use_lock(%direct_y_worker_1_3_prod_lock_0, Release, %c1_i32) loc(#loc32)
      aie.next_bd ^bb6 loc(#loc32)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc59)
    } loc(#loc59)
    %mem_2_5 = aie.mem(%tile_2_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_a_broadcast_3_2_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc59)
      aie.use_lock(%direct_a_broadcast_3_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb1 loc(#loc59)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc55)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_2_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_broadcast_2_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc55)
      aie.use_lock(%direct_w_broadcast_2_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb4 loc(#loc55)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_2_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_broadcast_2_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc55)
      aie.use_lock(%direct_w_broadcast_2_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb3 loc(#loc55)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc27)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_2_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc27)
      aie.dma_bd(%direct_y_worker_2_3_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc27)
      aie.use_lock(%direct_y_worker_2_3_prod_lock_0, Release, %c1_i32) loc(#loc27)
      aie.next_bd ^bb7 loc(#loc27)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_2_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc27)
      aie.dma_bd(%direct_y_worker_2_3_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc27)
      aie.use_lock(%direct_y_worker_2_3_prod_lock_0, Release, %c1_i32) loc(#loc27)
      aie.next_bd ^bb6 loc(#loc27)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc59)
    } loc(#loc59)
    %mem_3_5 = aie.mem(%tile_3_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_a_broadcast_3_3_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc59)
      aie.use_lock(%direct_a_broadcast_3_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb1 loc(#loc59)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc54)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_3_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_w_broadcast_3_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc54)
      aie.use_lock(%direct_w_broadcast_3_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb4 loc(#loc54)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_3_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_w_broadcast_3_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc54)
      aie.use_lock(%direct_w_broadcast_3_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb3 loc(#loc54)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc22)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_3_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc22)
      aie.dma_bd(%direct_y_worker_3_3_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc22)
      aie.use_lock(%direct_y_worker_3_3_prod_lock_0, Release, %c1_i32) loc(#loc22)
      aie.next_bd ^bb7 loc(#loc22)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_3_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc22)
      aie.dma_bd(%direct_y_worker_3_3_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc22)
      aie.use_lock(%direct_y_worker_3_3_prod_lock_0, Release, %c1_i32) loc(#loc22)
      aie.next_bd ^bb6 loc(#loc22)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc59)
    } loc(#loc59)
    %mem_4_5 = aie.mem(%tile_4_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_a_broadcast_3_4_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc59)
      aie.use_lock(%direct_a_broadcast_3_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb1 loc(#loc59)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc53)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_4_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb4 loc(#loc53)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_4_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb3 loc(#loc53)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc17)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_4_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc17)
      aie.dma_bd(%direct_y_worker_4_3_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc17)
      aie.use_lock(%direct_y_worker_4_3_prod_lock_0, Release, %c1_i32) loc(#loc17)
      aie.next_bd ^bb7 loc(#loc17)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_4_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc17)
      aie.dma_bd(%direct_y_worker_4_3_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc17)
      aie.use_lock(%direct_y_worker_4_3_prod_lock_0, Release, %c1_i32) loc(#loc17)
      aie.next_bd ^bb6 loc(#loc17)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc59)
    } loc(#loc59)
    %mem_5_5 = aie.mem(%tile_5_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_a_broadcast_3_5_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc59)
      aie.use_lock(%direct_a_broadcast_3_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb1 loc(#loc59)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc51)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_5_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_w_broadcast_5_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc51)
      aie.use_lock(%direct_w_broadcast_5_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb4 loc(#loc51)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_5_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_w_broadcast_5_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc51)
      aie.use_lock(%direct_w_broadcast_5_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb3 loc(#loc51)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc12)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_5_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc12)
      aie.dma_bd(%direct_y_worker_5_3_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc12)
      aie.use_lock(%direct_y_worker_5_3_prod_lock_0, Release, %c1_i32) loc(#loc12)
      aie.next_bd ^bb7 loc(#loc12)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_5_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc12)
      aie.dma_bd(%direct_y_worker_5_3_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc12)
      aie.use_lock(%direct_y_worker_5_3_prod_lock_0, Release, %c1_i32) loc(#loc12)
      aie.next_bd ^bb6 loc(#loc12)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc59)
    } loc(#loc59)
    %mem_6_5 = aie.mem(%tile_6_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_a_broadcast_3_6_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc59)
      aie.use_lock(%direct_a_broadcast_3_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb1 loc(#loc59)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc49)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_6_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_broadcast_6_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc49)
      aie.use_lock(%direct_w_broadcast_6_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb4 loc(#loc49)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_6_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_broadcast_6_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc49)
      aie.use_lock(%direct_w_broadcast_6_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb3 loc(#loc49)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc7)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_6_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc7)
      aie.dma_bd(%direct_y_worker_6_3_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc7)
      aie.use_lock(%direct_y_worker_6_3_prod_lock_0, Release, %c1_i32) loc(#loc7)
      aie.next_bd ^bb7 loc(#loc7)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_6_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc7)
      aie.dma_bd(%direct_y_worker_6_3_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc7)
      aie.use_lock(%direct_y_worker_6_3_prod_lock_0, Release, %c1_i32) loc(#loc7)
      aie.next_bd ^bb6 loc(#loc7)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc59)
    } loc(#loc59)
    %mem_7_5 = aie.mem(%tile_7_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc59)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_a_broadcast_3_7_cons_buff_0 : memref<4096xbf16> offset = 0 len = 4096) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc59)
      aie.use_lock(%direct_a_broadcast_3_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb1 loc(#loc59)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc47)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_7_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_7_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_7_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb4 loc(#loc47)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_7_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_7_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_7_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb3 loc(#loc47)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc2)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_7_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%direct_y_worker_7_3_buff_0 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc2)
      aie.use_lock(%direct_y_worker_7_3_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb7 loc(#loc2)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_7_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%direct_y_worker_7_3_buff_1 : memref<1024xbf16> offset = 0 len = 1024) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc2)
      aie.use_lock(%direct_y_worker_7_3_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb6 loc(#loc2)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc59)
    } loc(#loc59)
    aie.shim_dma_allocation @direct_a_host_3_shim_alloc(%shim_noc_tile_3_0, MM2S, 0) loc(#loc58)
    aie.shim_dma_allocation @direct_w_host_0_shim_alloc(%shim_noc_tile_0_0, MM2S, 1) loc(#loc52)
    aie.shim_dma_allocation @direct_w_host_1_shim_alloc(%shim_noc_tile_1_0, MM2S, 1) loc(#loc50)
    aie.shim_dma_allocation @direct_w_host_2_shim_alloc(%shim_noc_tile_2_0, MM2S, 1) loc(#loc48)
    aie.shim_dma_allocation @direct_w_host_3_shim_alloc(%shim_noc_tile_3_0, MM2S, 1) loc(#loc46)
    %memtile_dma_4_1 = aie.memtile_dma(%mem_tile_4_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc53)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_w_host_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc43)
      aie.dma_bd(%direct_w_host_4_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc43)
      aie.use_lock(%direct_w_host_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc43)
      aie.next_bd ^bb2 loc(#loc43)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_w_host_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc43)
      aie.dma_bd(%direct_w_host_4_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc43)
      aie.use_lock(%direct_w_host_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc43)
      aie.next_bd ^bb1 loc(#loc43)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc43)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_w_host_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc43)
      aie.dma_bd(%direct_w_host_4_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc43)
      aie.use_lock(%direct_w_host_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc43)
      aie.next_bd ^bb5 loc(#loc43)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_w_host_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc43)
      aie.dma_bd(%direct_w_host_4_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc43)
      aie.use_lock(%direct_w_host_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc43)
      aie.next_bd ^bb4 loc(#loc43)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb15) loc(#loc21)
    ^bb7:  // 2 preds: ^bb6, ^bb14
      aie.use_lock(%direct_y_host_4_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_0, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb8 loc(#loc21)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_y_host_4_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 25 : i32, next_bd_id = 26 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_1, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb9 loc(#loc21)
    ^bb9:  // pred: ^bb8
      aie.use_lock(%direct_y_host_4_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_2, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb10 loc(#loc21)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%direct_y_host_4_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 27 : i32, next_bd_id = 28 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_3, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb11 loc(#loc21)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_y_host_4_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_0, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb12 loc(#loc21)
    ^bb12:  // pred: ^bb11
      aie.use_lock(%direct_y_host_4_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 29 : i32, next_bd_id = 30 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_1, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb13 loc(#loc21)
    ^bb13:  // pred: ^bb12
      aie.use_lock(%direct_y_host_4_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_2, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb14 loc(#loc21)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_4_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 31 : i32, next_bd_id = 24 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_3, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb7 loc(#loc21)
    ^bb15:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb16, ^bb18) loc(#loc20)
    ^bb16:  // 2 preds: ^bb15, ^bb17
      aie.use_lock(%direct_y_host_4_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 32 : i32, next_bd_id = 33 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_0, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb17 loc(#loc21)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_4_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 33 : i32, next_bd_id = 32 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_0, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb16 loc(#loc21)
    ^bb18:  // pred: ^bb15
      %4 = aie.dma_start(S2MM, 2, ^bb19, ^bb21) loc(#loc19)
    ^bb19:  // 2 preds: ^bb18, ^bb20
      aie.use_lock(%direct_y_host_4_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_1, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb20 loc(#loc21)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_4_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 5 : i32, next_bd_id = 4 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_1, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb19 loc(#loc21)
    ^bb21:  // pred: ^bb18
      %5 = aie.dma_start(S2MM, 3, ^bb22, ^bb24) loc(#loc18)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_4_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 34 : i32, next_bd_id = 35 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_2, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb23 loc(#loc21)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_4_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 35 : i32, next_bd_id = 34 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_2, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb22 loc(#loc21)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 4, ^bb25, ^bb27) loc(#loc17)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_4_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_3, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb26 loc(#loc21)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_4_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 7 : i32, next_bd_id = 6 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_3, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb25 loc(#loc21)
    ^bb27:  // pred: ^bb24
      aie.end loc(#loc53)
    } loc(#loc53)
    aie.shim_dma_allocation @direct_w_host_4_shim_alloc(%shim_noc_tile_4_0, MM2S, 1) loc(#loc43)
    %memtile_dma_5_1 = aie.memtile_dma(%mem_tile_5_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc51)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_w_host_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc40)
      aie.dma_bd(%direct_w_host_5_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc40)
      aie.use_lock(%direct_w_host_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc40)
      aie.next_bd ^bb2 loc(#loc40)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_w_host_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc40)
      aie.dma_bd(%direct_w_host_5_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc40)
      aie.use_lock(%direct_w_host_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc40)
      aie.next_bd ^bb1 loc(#loc40)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc40)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_w_host_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc40)
      aie.dma_bd(%direct_w_host_5_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc40)
      aie.use_lock(%direct_w_host_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc40)
      aie.next_bd ^bb5 loc(#loc40)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_w_host_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc40)
      aie.dma_bd(%direct_w_host_5_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc40)
      aie.use_lock(%direct_w_host_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc40)
      aie.next_bd ^bb4 loc(#loc40)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb15) loc(#loc16)
    ^bb7:  // 2 preds: ^bb6, ^bb14
      aie.use_lock(%direct_y_host_5_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb8 loc(#loc16)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_y_host_5_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 25 : i32, next_bd_id = 26 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_1, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb9 loc(#loc16)
    ^bb9:  // pred: ^bb8
      aie.use_lock(%direct_y_host_5_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_2, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb10 loc(#loc16)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%direct_y_host_5_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 27 : i32, next_bd_id = 28 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_3, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb11 loc(#loc16)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_y_host_5_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb12 loc(#loc16)
    ^bb12:  // pred: ^bb11
      aie.use_lock(%direct_y_host_5_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 29 : i32, next_bd_id = 30 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_1, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb13 loc(#loc16)
    ^bb13:  // pred: ^bb12
      aie.use_lock(%direct_y_host_5_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_2, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb14 loc(#loc16)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_5_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 31 : i32, next_bd_id = 24 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_3, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb7 loc(#loc16)
    ^bb15:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb16, ^bb18) loc(#loc15)
    ^bb16:  // 2 preds: ^bb15, ^bb17
      aie.use_lock(%direct_y_host_5_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 32 : i32, next_bd_id = 33 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb17 loc(#loc16)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_5_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 33 : i32, next_bd_id = 32 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb16 loc(#loc16)
    ^bb18:  // pred: ^bb15
      %4 = aie.dma_start(S2MM, 2, ^bb19, ^bb21) loc(#loc14)
    ^bb19:  // 2 preds: ^bb18, ^bb20
      aie.use_lock(%direct_y_host_5_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_1, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb20 loc(#loc16)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_5_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 5 : i32, next_bd_id = 4 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_1, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb19 loc(#loc16)
    ^bb21:  // pred: ^bb18
      %5 = aie.dma_start(S2MM, 3, ^bb22, ^bb24) loc(#loc13)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_5_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 34 : i32, next_bd_id = 35 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_2, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb23 loc(#loc16)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_5_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 35 : i32, next_bd_id = 34 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_2, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb22 loc(#loc16)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 4, ^bb25, ^bb27) loc(#loc12)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_5_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_3, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb26 loc(#loc16)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_5_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 7 : i32, next_bd_id = 6 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_3, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb25 loc(#loc16)
    ^bb27:  // pred: ^bb24
      aie.end loc(#loc51)
    } loc(#loc51)
    aie.shim_dma_allocation @direct_w_host_5_shim_alloc(%shim_noc_tile_5_0, MM2S, 1) loc(#loc40)
    %memtile_dma_6_1 = aie.memtile_dma(%mem_tile_6_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc49)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_w_host_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc38)
      aie.dma_bd(%direct_w_host_6_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc38)
      aie.use_lock(%direct_w_host_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc38)
      aie.next_bd ^bb2 loc(#loc38)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_w_host_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc38)
      aie.dma_bd(%direct_w_host_6_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc38)
      aie.use_lock(%direct_w_host_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc38)
      aie.next_bd ^bb1 loc(#loc38)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc38)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_w_host_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc38)
      aie.dma_bd(%direct_w_host_6_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc38)
      aie.use_lock(%direct_w_host_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc38)
      aie.next_bd ^bb5 loc(#loc38)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_w_host_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc38)
      aie.dma_bd(%direct_w_host_6_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc38)
      aie.use_lock(%direct_w_host_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc38)
      aie.next_bd ^bb4 loc(#loc38)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb15) loc(#loc11)
    ^bb7:  // 2 preds: ^bb6, ^bb14
      aie.use_lock(%direct_y_host_6_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb8 loc(#loc11)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_y_host_6_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 25 : i32, next_bd_id = 26 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_1, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb9 loc(#loc11)
    ^bb9:  // pred: ^bb8
      aie.use_lock(%direct_y_host_6_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_2, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb10 loc(#loc11)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%direct_y_host_6_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 27 : i32, next_bd_id = 28 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_3, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb11 loc(#loc11)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_y_host_6_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb12 loc(#loc11)
    ^bb12:  // pred: ^bb11
      aie.use_lock(%direct_y_host_6_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 29 : i32, next_bd_id = 30 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_1, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb13 loc(#loc11)
    ^bb13:  // pred: ^bb12
      aie.use_lock(%direct_y_host_6_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_2, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb14 loc(#loc11)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_6_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 31 : i32, next_bd_id = 24 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_3, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb7 loc(#loc11)
    ^bb15:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb16, ^bb18) loc(#loc10)
    ^bb16:  // 2 preds: ^bb15, ^bb17
      aie.use_lock(%direct_y_host_6_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 32 : i32, next_bd_id = 33 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb17 loc(#loc11)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_6_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 33 : i32, next_bd_id = 32 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb16 loc(#loc11)
    ^bb18:  // pred: ^bb15
      %4 = aie.dma_start(S2MM, 2, ^bb19, ^bb21) loc(#loc9)
    ^bb19:  // 2 preds: ^bb18, ^bb20
      aie.use_lock(%direct_y_host_6_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_1, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb20 loc(#loc11)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_6_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 5 : i32, next_bd_id = 4 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_1, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb19 loc(#loc11)
    ^bb21:  // pred: ^bb18
      %5 = aie.dma_start(S2MM, 3, ^bb22, ^bb24) loc(#loc8)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_6_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 34 : i32, next_bd_id = 35 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_2, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb23 loc(#loc11)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_6_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 35 : i32, next_bd_id = 34 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_2, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb22 loc(#loc11)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 4, ^bb25, ^bb27) loc(#loc7)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_6_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_3, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb26 loc(#loc11)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_6_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 7 : i32, next_bd_id = 6 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_3, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb25 loc(#loc11)
    ^bb27:  // pred: ^bb24
      aie.end loc(#loc49)
    } loc(#loc49)
    aie.shim_dma_allocation @direct_w_host_6_shim_alloc(%shim_noc_tile_6_0, MM2S, 1) loc(#loc38)
    %memtile_dma_7_1 = aie.memtile_dma(%mem_tile_7_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc167)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc47)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_w_host_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc34)
      aie.dma_bd(%direct_w_host_7_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc34)
      aie.use_lock(%direct_w_host_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc34)
      aie.next_bd ^bb2 loc(#loc34)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_w_host_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc34)
      aie.dma_bd(%direct_w_host_7_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc34)
      aie.use_lock(%direct_w_host_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc34)
      aie.next_bd ^bb1 loc(#loc34)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc34)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_w_host_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc34)
      aie.dma_bd(%direct_w_host_7_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc34)
      aie.use_lock(%direct_w_host_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc34)
      aie.next_bd ^bb5 loc(#loc34)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_w_host_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc34)
      aie.dma_bd(%direct_w_host_7_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc34)
      aie.use_lock(%direct_w_host_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc34)
      aie.next_bd ^bb4 loc(#loc34)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb15) loc(#loc6)
    ^bb7:  // 2 preds: ^bb6, ^bb14
      aie.use_lock(%direct_y_host_7_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb8 loc(#loc6)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_y_host_7_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 25 : i32, next_bd_id = 26 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_1, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb9 loc(#loc6)
    ^bb9:  // pred: ^bb8
      aie.use_lock(%direct_y_host_7_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_2, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb10 loc(#loc6)
    ^bb10:  // pred: ^bb9
      aie.use_lock(%direct_y_host_7_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 27 : i32, next_bd_id = 28 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_3, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb11 loc(#loc6)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_y_host_7_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb12 loc(#loc6)
    ^bb12:  // pred: ^bb11
      aie.use_lock(%direct_y_host_7_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 29 : i32, next_bd_id = 30 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_1, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb13 loc(#loc6)
    ^bb13:  // pred: ^bb12
      aie.use_lock(%direct_y_host_7_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_2, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb14 loc(#loc6)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_7_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 31 : i32, next_bd_id = 24 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_3, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb7 loc(#loc6)
    ^bb15:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb16, ^bb18) loc(#loc5)
    ^bb16:  // 2 preds: ^bb15, ^bb17
      aie.use_lock(%direct_y_host_7_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 32 : i32, next_bd_id = 33 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb17 loc(#loc6)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_7_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<4096xbf16> offset = 0 len = 1024) {bd_id = 33 : i32, next_bd_id = 32 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb16 loc(#loc6)
    ^bb18:  // pred: ^bb15
      %4 = aie.dma_start(S2MM, 2, ^bb19, ^bb21) loc(#loc4)
    ^bb19:  // 2 preds: ^bb18, ^bb20
      aie.use_lock(%direct_y_host_7_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_1, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb20 loc(#loc6)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_7_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<4096xbf16> offset = 1024 len = 1024) {bd_id = 5 : i32, next_bd_id = 4 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_1, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb19 loc(#loc6)
    ^bb21:  // pred: ^bb18
      %5 = aie.dma_start(S2MM, 3, ^bb22, ^bb24) loc(#loc3)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_7_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 34 : i32, next_bd_id = 35 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_2, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb23 loc(#loc6)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_7_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<4096xbf16> offset = 2048 len = 1024) {bd_id = 35 : i32, next_bd_id = 34 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_2, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb22 loc(#loc6)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 4, ^bb25, ^bb27) loc(#loc2)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_7_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_3, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb26 loc(#loc6)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_7_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<4096xbf16> offset = 3072 len = 1024) {bd_id = 7 : i32, next_bd_id = 6 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_3, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb25 loc(#loc6)
    ^bb27:  // pred: ^bb24
      aie.end loc(#loc47)
    } loc(#loc47)
    aie.shim_dma_allocation @direct_w_host_7_shim_alloc(%shim_noc_tile_7_0, MM2S, 1) loc(#loc34)
    aie.shim_dma_allocation @direct_y_host_0_shim_alloc(%shim_noc_tile_0_0, S2MM, 0) loc(#loc45)
    aie.shim_dma_allocation @direct_y_host_1_shim_alloc(%shim_noc_tile_1_0, S2MM, 0) loc(#loc37)
    aie.shim_dma_allocation @direct_y_host_2_shim_alloc(%shim_noc_tile_2_0, S2MM, 0) loc(#loc31)
    aie.shim_dma_allocation @direct_y_host_3_shim_alloc(%shim_noc_tile_3_0, S2MM, 0) loc(#loc26)
    aie.shim_dma_allocation @direct_y_host_4_shim_alloc(%shim_noc_tile_4_0, S2MM, 0) loc(#loc21)
    aie.shim_dma_allocation @direct_y_host_5_shim_alloc(%shim_noc_tile_5_0, S2MM, 0) loc(#loc16)
    aie.shim_dma_allocation @direct_y_host_6_shim_alloc(%shim_noc_tile_6_0, S2MM, 0) loc(#loc11)
    aie.shim_dma_allocation @direct_y_host_7_shim_alloc(%shim_noc_tile_7_0, S2MM, 0) loc(#loc6)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_7_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_7_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_6_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_6_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_5_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_5_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_4_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_4_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_3_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_3_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_2_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_2_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_1_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_1_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_0_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_0_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
  } loc(#loc1)
} loc(#loc)
#loc = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1:1)
#loc1 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":2:3)
#loc2 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":157:5)
#loc3 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":156:5)
#loc4 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":155:5)
#loc5 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":154:5)
#loc6 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":153:5)
#loc7 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":151:5)
#loc8 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":150:5)
#loc9 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":149:5)
#loc10 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":148:5)
#loc11 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":147:5)
#loc12 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":145:5)
#loc13 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":144:5)
#loc14 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":143:5)
#loc15 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":142:5)
#loc16 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":141:5)
#loc17 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":139:5)
#loc18 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":138:5)
#loc19 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":137:5)
#loc20 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":136:5)
#loc21 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":135:5)
#loc22 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":133:5)
#loc23 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":132:5)
#loc24 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":131:5)
#loc25 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":130:5)
#loc26 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":129:5)
#loc27 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":127:5)
#loc28 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":126:5)
#loc29 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":125:5)
#loc30 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":124:5)
#loc31 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":123:5)
#loc32 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":121:5)
#loc33 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":120:5)
#loc34 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":109:5)
#loc35 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":119:5)
#loc36 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":118:5)
#loc37 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":117:5)
#loc38 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":106:5)
#loc39 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":115:5)
#loc40 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":103:5)
#loc41 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":114:5)
#loc42 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":113:5)
#loc43 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":100:5)
#loc44 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":112:5)
#loc45 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":111:5)
#loc46 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":97:5)
#loc47 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":108:5)
#loc48 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":94:5)
#loc49 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":105:5)
#loc50 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":91:5)
#loc51 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":102:5)
#loc52 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":88:5)
#loc53 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":99:5)
#loc54 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":96:5)
#loc55 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":93:5)
#loc56 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":90:5)
#loc57 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":87:5)
#loc58 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":85:5)
#loc59 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":84:5)
#loc60 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":82:5)
#loc61 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":81:5)
#loc62 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":79:5)
#loc63 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":78:5)
#loc64 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":76:5)
#loc65 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":75:5)
#loc66 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":159:24)
#loc67 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":160:24)
#loc68 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":161:27)
#loc69 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":162:5)
#loc70 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":163:5)
#loc71 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":164:5)
#loc72 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":165:5)
#loc73 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":166:24)
#loc74 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":167:24)
#loc75 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":168:27)
#loc76 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":169:24)
#loc77 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":170:24)
#loc78 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":171:27)
#loc79 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":172:24)
#loc80 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":173:24)
#loc81 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":174:27)
#loc82 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":175:24)
#loc83 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":176:24)
#loc84 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":177:27)
#loc85 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":178:24)
#loc86 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":179:24)
#loc87 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":180:27)
#loc88 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":181:24)
#loc89 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":182:24)
#loc90 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":183:27)
#loc91 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":184:24)
#loc92 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":185:24)
#loc93 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":186:27)
#loc94 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":187:24)
#loc95 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":188:24)
#loc96 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":189:27)
#loc97 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":190:24)
#loc98 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":191:24)
#loc99 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":192:27)
#loc100 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":193:24)
#loc101 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":194:24)
#loc102 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":195:27)
#loc103 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":196:24)
#loc104 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":197:24)
#loc105 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":198:27)
#loc106 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":199:24)
#loc107 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":200:24)
#loc108 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":201:27)
#loc109 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":202:24)
#loc110 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":203:24)
#loc111 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":204:27)
#loc112 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":205:24)
#loc113 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":206:24)
#loc114 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":207:27)
#loc115 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":208:24)
#loc116 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":209:24)
#loc117 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":210:27)
#loc118 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":211:24)
#loc119 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":212:24)
#loc120 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":213:27)
#loc121 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":214:24)
#loc122 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":215:24)
#loc123 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":216:27)
#loc124 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":217:24)
#loc125 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":218:24)
#loc126 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":219:27)
#loc127 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":220:24)
#loc128 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":221:24)
#loc129 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":222:27)
#loc130 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":223:24)
#loc131 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":224:24)
#loc132 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":225:27)
#loc133 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":226:24)
#loc134 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":227:24)
#loc135 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":228:27)
#loc136 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":229:24)
#loc137 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":230:24)
#loc138 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":231:27)
#loc139 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":232:24)
#loc140 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":233:24)
#loc141 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":234:27)
#loc142 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":235:24)
#loc143 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":236:24)
#loc144 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":237:27)
#loc145 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":238:24)
#loc146 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":239:24)
#loc147 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":240:27)
#loc148 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":241:24)
#loc149 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":242:24)
#loc150 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":243:27)
#loc151 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":244:24)
#loc152 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":245:24)
#loc153 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":246:27)
#loc154 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":247:24)
#loc155 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":248:24)
#loc156 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":249:27)
#loc157 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":250:24)
#loc158 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":251:24)
#loc159 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":252:27)
#loc160 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":253:24)
#loc161 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":254:24)
#loc162 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":255:27)
#loc163 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":256:24)
#loc164 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":257:24)
#loc165 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":258:27)
#loc167 = loc(unknown)
#loc168 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":263:7)
#loc170 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":268:11)
#loc171 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":272:11)
#loc173 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":273:18)
#loc174 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":275:18)
#loc176 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":277:13)
#loc177 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":278:13)
#loc178 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":279:13)
#loc179 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":281:16)
#loc181 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":283:11)
#loc182 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":284:11)
#loc183 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":287:7)
#loc185 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":293:7)
#loc187 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":298:11)
#loc188 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":302:11)
#loc190 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":303:18)
#loc191 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":305:18)
#loc193 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":307:13)
#loc194 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":308:13)
#loc195 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":309:13)
#loc196 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":311:16)
#loc198 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":313:11)
#loc199 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":314:11)
#loc200 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":317:7)
#loc202 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":323:7)
#loc204 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":328:11)
#loc205 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":332:11)
#loc207 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":333:18)
#loc208 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":335:18)
#loc210 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":337:13)
#loc211 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":338:13)
#loc212 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":339:13)
#loc213 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":341:16)
#loc215 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":343:11)
#loc216 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":344:11)
#loc217 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":347:7)
#loc219 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":353:7)
#loc221 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":358:11)
#loc222 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":362:11)
#loc224 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":363:18)
#loc225 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":365:18)
#loc227 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":367:13)
#loc228 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":368:13)
#loc229 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":369:13)
#loc230 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":371:16)
#loc232 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":373:11)
#loc233 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":374:11)
#loc234 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":377:7)
#loc236 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":383:7)
#loc238 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":388:11)
#loc239 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":392:11)
#loc241 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":393:18)
#loc242 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":395:18)
#loc244 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":397:13)
#loc245 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":398:13)
#loc246 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":399:13)
#loc247 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":401:16)
#loc249 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":403:11)
#loc250 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":404:11)
#loc251 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":407:7)
#loc253 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":413:7)
#loc255 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":418:11)
#loc256 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":422:11)
#loc258 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":423:18)
#loc259 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":425:18)
#loc261 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":427:13)
#loc262 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":428:13)
#loc263 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":429:13)
#loc264 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":431:16)
#loc266 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":433:11)
#loc267 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":434:11)
#loc268 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":437:7)
#loc270 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":443:7)
#loc272 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":448:11)
#loc273 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":452:11)
#loc275 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":453:18)
#loc276 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":455:18)
#loc278 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":457:13)
#loc279 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":458:13)
#loc280 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":459:13)
#loc281 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":461:16)
#loc283 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":463:11)
#loc284 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":464:11)
#loc285 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":467:7)
#loc287 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":473:7)
#loc289 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":478:11)
#loc290 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":482:11)
#loc292 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":483:18)
#loc293 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":485:18)
#loc295 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":487:13)
#loc296 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":488:13)
#loc297 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":489:13)
#loc298 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":491:16)
#loc300 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":493:11)
#loc301 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":494:11)
#loc302 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":497:7)
#loc304 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":503:7)
#loc306 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":508:11)
#loc307 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":512:11)
#loc309 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":513:18)
#loc310 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":515:18)
#loc312 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":517:13)
#loc313 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":518:13)
#loc314 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":519:13)
#loc315 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":521:16)
#loc317 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":523:11)
#loc318 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":524:11)
#loc319 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":527:7)
#loc321 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":533:7)
#loc323 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":538:11)
#loc324 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":542:11)
#loc326 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":543:18)
#loc327 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":545:18)
#loc329 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":547:13)
#loc330 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":548:13)
#loc331 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":549:13)
#loc332 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":551:16)
#loc334 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":553:11)
#loc335 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":554:11)
#loc336 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":557:7)
#loc338 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":563:7)
#loc340 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":568:11)
#loc341 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":572:11)
#loc343 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":573:18)
#loc344 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":575:18)
#loc346 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":577:13)
#loc347 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":578:13)
#loc348 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":579:13)
#loc349 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":581:16)
#loc351 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":583:11)
#loc352 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":584:11)
#loc353 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":587:7)
#loc355 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":593:7)
#loc357 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":598:11)
#loc358 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":602:11)
#loc360 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":603:18)
#loc361 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":605:18)
#loc363 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":607:13)
#loc364 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":608:13)
#loc365 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":609:13)
#loc366 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":611:16)
#loc368 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":613:11)
#loc369 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":614:11)
#loc370 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":617:7)
#loc372 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":623:7)
#loc374 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":628:11)
#loc375 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":632:11)
#loc377 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":633:18)
#loc378 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":635:18)
#loc380 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":637:13)
#loc381 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":638:13)
#loc382 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":639:13)
#loc383 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":641:16)
#loc385 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":643:11)
#loc386 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":644:11)
#loc387 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":647:7)
#loc389 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":653:7)
#loc391 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":658:11)
#loc392 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":662:11)
#loc394 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":663:18)
#loc395 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":665:18)
#loc397 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":667:13)
#loc398 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":668:13)
#loc399 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":669:13)
#loc400 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":671:16)
#loc402 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":673:11)
#loc403 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":674:11)
#loc404 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":677:7)
#loc406 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":683:7)
#loc408 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":688:11)
#loc409 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":692:11)
#loc411 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":693:18)
#loc412 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":695:18)
#loc414 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":697:13)
#loc415 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":698:13)
#loc416 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":699:13)
#loc417 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":701:16)
#loc419 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":703:11)
#loc420 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":704:11)
#loc421 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":707:7)
#loc423 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":713:7)
#loc425 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":718:11)
#loc426 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":722:11)
#loc428 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":723:18)
#loc429 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":725:18)
#loc431 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":727:13)
#loc432 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":728:13)
#loc433 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":729:13)
#loc434 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":731:16)
#loc436 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":733:11)
#loc437 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":734:11)
#loc438 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":737:7)
#loc440 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":743:7)
#loc442 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":748:11)
#loc443 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":752:11)
#loc445 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":753:18)
#loc446 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":755:18)
#loc448 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":757:13)
#loc449 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":758:13)
#loc450 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":759:13)
#loc451 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":761:16)
#loc453 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":763:11)
#loc454 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":764:11)
#loc455 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":767:7)
#loc457 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":773:7)
#loc459 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":778:11)
#loc460 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":782:11)
#loc462 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":783:18)
#loc463 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":785:18)
#loc465 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":787:13)
#loc466 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":788:13)
#loc467 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":789:13)
#loc468 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":791:16)
#loc470 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":793:11)
#loc471 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":794:11)
#loc472 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":797:7)
#loc474 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":803:7)
#loc476 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":808:11)
#loc477 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":812:11)
#loc479 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":813:18)
#loc480 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":815:18)
#loc482 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":817:13)
#loc483 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":818:13)
#loc484 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":819:13)
#loc485 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":821:16)
#loc487 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":823:11)
#loc488 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":824:11)
#loc489 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":827:7)
#loc491 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":833:7)
#loc493 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":838:11)
#loc494 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":842:11)
#loc496 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":843:18)
#loc497 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":845:18)
#loc499 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":847:13)
#loc500 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":848:13)
#loc501 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":849:13)
#loc502 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":851:16)
#loc504 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":853:11)
#loc505 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":854:11)
#loc506 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":857:7)
#loc508 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":863:7)
#loc510 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":868:11)
#loc511 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":872:11)
#loc513 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":873:18)
#loc514 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":875:18)
#loc516 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":877:13)
#loc517 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":878:13)
#loc518 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":879:13)
#loc519 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":881:16)
#loc521 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":883:11)
#loc522 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":884:11)
#loc523 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":887:7)
#loc525 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":893:7)
#loc527 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":898:11)
#loc528 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":902:11)
#loc530 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":903:18)
#loc531 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":905:18)
#loc533 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":907:13)
#loc534 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":908:13)
#loc535 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":909:13)
#loc536 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":911:16)
#loc538 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":913:11)
#loc539 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":914:11)
#loc540 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":917:7)
#loc542 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":923:7)
#loc544 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":928:11)
#loc545 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":932:11)
#loc547 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":933:18)
#loc548 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":935:18)
#loc550 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":937:13)
#loc551 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":938:13)
#loc552 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":939:13)
#loc553 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":941:16)
#loc555 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":943:11)
#loc556 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":944:11)
#loc557 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":947:7)
#loc559 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":953:7)
#loc561 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":958:11)
#loc562 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":962:11)
#loc564 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":963:18)
#loc565 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":965:18)
#loc567 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":967:13)
#loc568 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":968:13)
#loc569 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":969:13)
#loc570 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":971:16)
#loc572 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":973:11)
#loc573 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":974:11)
#loc574 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":977:7)
#loc576 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":983:7)
#loc578 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":988:11)
#loc579 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":992:11)
#loc581 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":993:18)
#loc582 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":995:18)
#loc584 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":997:13)
#loc585 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":998:13)
#loc586 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":999:13)
#loc587 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1001:16)
#loc589 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1003:11)
#loc590 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1004:11)
#loc591 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1007:7)
#loc593 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1013:7)
#loc595 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1018:11)
#loc596 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1022:11)
#loc598 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1023:18)
#loc599 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1025:18)
#loc601 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1027:13)
#loc602 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1028:13)
#loc603 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1029:13)
#loc604 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1031:16)
#loc606 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1033:11)
#loc607 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1034:11)
#loc608 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1037:7)
#loc610 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1043:7)
#loc612 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1048:11)
#loc613 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1052:11)
#loc615 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1053:18)
#loc616 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1055:18)
#loc618 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1057:13)
#loc619 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1058:13)
#loc620 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1059:13)
#loc621 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1061:16)
#loc623 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1063:11)
#loc624 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1064:11)
#loc625 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1067:7)
#loc627 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1073:7)
#loc629 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1078:11)
#loc630 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1082:11)
#loc632 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1083:18)
#loc633 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1085:18)
#loc635 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1087:13)
#loc636 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1088:13)
#loc637 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1089:13)
#loc638 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1091:16)
#loc640 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1093:11)
#loc641 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1094:11)
#loc642 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1097:7)
#loc644 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1103:7)
#loc646 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1108:11)
#loc647 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1112:11)
#loc649 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1113:18)
#loc650 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1115:18)
#loc652 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1117:13)
#loc653 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1118:13)
#loc654 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1119:13)
#loc655 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1121:16)
#loc657 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1123:11)
#loc658 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1124:11)
#loc659 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1127:7)
#loc661 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1133:7)
#loc663 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1138:11)
#loc664 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1142:11)
#loc666 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1143:18)
#loc667 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1145:18)
#loc669 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1147:13)
#loc670 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1148:13)
#loc671 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1149:13)
#loc672 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1151:16)
#loc674 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1153:11)
#loc675 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1154:11)
#loc676 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1157:7)
#loc678 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1163:7)
#loc680 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1168:11)
#loc681 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1172:11)
#loc683 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1173:18)
#loc684 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1175:18)
#loc686 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1177:13)
#loc687 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1178:13)
#loc688 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1179:13)
#loc689 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1181:16)
#loc691 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1183:11)
#loc692 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1184:11)
#loc693 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1187:7)
#loc695 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1193:7)
#loc697 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1198:11)
#loc698 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1202:11)
#loc700 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1203:18)
#loc701 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1205:18)
#loc703 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1207:13)
#loc704 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1208:13)
#loc705 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1209:13)
#loc706 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1211:16)
#loc708 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1213:11)
#loc709 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1214:11)
#loc710 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1217:7)
#loc711 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1219:5)
#loc715 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1220:12)
#loc716 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1221:9)
#loc717 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1222:9)
#loc718 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1224:7)
#loc719 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1225:12)
#loc720 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1226:9)
#loc721 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1227:9)
#loc722 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1229:7)
#loc723 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1230:12)
#loc724 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1231:9)
#loc725 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1232:9)
#loc726 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1234:7)
#loc727 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1235:12)
#loc728 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1236:9)
#loc729 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1237:9)
#loc730 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1239:7)
#loc731 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1240:12)
#loc732 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1241:9)
#loc733 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1242:9)
#loc734 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1244:7)
#loc735 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1245:12)
#loc736 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1246:9)
#loc737 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1247:9)
#loc738 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1249:7)
#loc739 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1250:12)
#loc740 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1251:9)
#loc741 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1252:9)
#loc742 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1254:7)
#loc743 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1255:12)
#loc744 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1256:9)
#loc745 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1257:9)
#loc746 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1259:7)
#loc747 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1260:12)
#loc748 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1261:9)
#loc749 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1262:9)
#loc750 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1264:7)
#loc751 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1265:12)
#loc752 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1266:9)
#loc753 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1267:9)
#loc754 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1269:7)
#loc755 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1270:13)
#loc756 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1271:9)
#loc757 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1272:9)
#loc758 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1274:7)
#loc759 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1275:13)
#loc760 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1276:9)
#loc761 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1277:9)
#loc762 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1279:7)
#loc763 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1280:13)
#loc764 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1281:9)
#loc765 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1282:9)
#loc766 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1284:7)
#loc767 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1285:13)
#loc768 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1286:9)
#loc769 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1287:9)
#loc770 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1289:7)
#loc771 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1290:13)
#loc772 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1291:9)
#loc773 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1292:9)
#loc774 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1294:7)
#loc775 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1295:13)
#loc776 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1296:9)
#loc777 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1297:9)
#loc778 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1299:7)
#loc779 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1300:13)
#loc780 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1301:9)
#loc781 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1302:9)
#loc782 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1304:7)
#loc783 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1305:13)
#loc784 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1306:9)
#loc785 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1307:9)
#loc786 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1309:7)
#loc787 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1310:13)
#loc788 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1311:9)
#loc789 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1312:9)
#loc790 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1314:7)
#loc791 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1315:13)
#loc792 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1316:9)
#loc793 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1317:9)
#loc794 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1319:7)
#loc795 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1320:7)
#loc796 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1321:7)
#loc797 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1322:7)
#loc798 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1323:7)
#loc799 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1324:7)
#loc800 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1325:7)
#loc801 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1326:7)
#loc802 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1327:7)
#loc803 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1328:7)
#loc804 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1329:7)
#loc805 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1330:7)
#loc806 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1331:7)
#loc807 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1332:7)
#loc808 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1333:7)
#loc809 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1334:7)
#loc810 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1335:7)
#loc811 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1336:7)
#loc812 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1337:7)
#loc813 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1338:7)
#loc814 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1339:7)
#loc815 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1340:7)
#loc816 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1341:7)
#loc817 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1342:7)
#loc818 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1343:7)
#loc819 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1344:7)
#loc820 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1345:7)
#loc821 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1346:7)
#loc822 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n256_091d087a42215875/final.prj/aie.mlir":1347:7)
