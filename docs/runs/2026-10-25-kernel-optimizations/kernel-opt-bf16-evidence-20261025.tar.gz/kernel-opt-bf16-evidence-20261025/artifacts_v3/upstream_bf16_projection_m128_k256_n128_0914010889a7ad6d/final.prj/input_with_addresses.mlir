#loc174 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":279:17)
#loc177 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":283:15)
#loc180 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":292:19)
#loc183 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":296:18)
#loc188 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":302:16)
#loc192 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":309:17)
#loc194 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":313:15)
#loc197 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":322:19)
#loc200 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":326:18)
#loc205 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":332:16)
#loc209 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":339:17)
#loc211 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":343:15)
#loc214 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":352:19)
#loc217 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":356:18)
#loc222 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":362:16)
#loc226 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":369:17)
#loc228 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":373:15)
#loc231 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":382:19)
#loc234 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":386:18)
#loc239 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":392:16)
#loc243 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":399:17)
#loc245 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":403:15)
#loc248 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":412:19)
#loc251 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":416:18)
#loc256 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":422:16)
#loc260 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":429:17)
#loc262 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":433:15)
#loc265 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":442:19)
#loc268 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":446:18)
#loc273 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":452:16)
#loc277 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":459:17)
#loc279 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":463:15)
#loc282 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":472:19)
#loc285 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":476:18)
#loc290 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":482:16)
#loc294 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":489:17)
#loc296 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":493:15)
#loc299 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":502:19)
#loc302 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":506:18)
#loc307 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":512:16)
#loc311 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":519:17)
#loc313 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":523:15)
#loc316 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":532:19)
#loc319 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":536:18)
#loc324 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":542:16)
#loc328 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":549:17)
#loc330 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":553:15)
#loc333 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":562:19)
#loc336 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":566:18)
#loc341 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":572:16)
#loc345 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":579:17)
#loc347 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":583:15)
#loc350 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":592:19)
#loc353 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":596:18)
#loc358 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":602:16)
#loc362 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":609:17)
#loc364 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":613:15)
#loc367 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":622:19)
#loc370 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":626:18)
#loc375 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":632:16)
#loc379 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":639:17)
#loc381 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":643:15)
#loc384 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":652:19)
#loc387 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":656:18)
#loc392 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":662:16)
#loc396 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":669:17)
#loc398 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":673:15)
#loc401 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":682:19)
#loc404 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":686:18)
#loc409 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":692:16)
#loc413 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":699:17)
#loc415 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":703:15)
#loc418 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":712:19)
#loc421 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":716:18)
#loc426 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":722:16)
#loc430 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":729:17)
#loc432 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":733:15)
#loc435 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":742:19)
#loc438 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":746:18)
#loc443 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":752:16)
#loc447 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":759:17)
#loc449 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":763:15)
#loc452 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":772:19)
#loc455 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":776:18)
#loc460 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":782:16)
#loc464 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":789:17)
#loc466 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":793:15)
#loc469 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":802:19)
#loc472 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":806:18)
#loc477 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":812:16)
#loc481 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":819:17)
#loc483 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":823:15)
#loc486 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":832:19)
#loc489 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":836:18)
#loc494 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":842:16)
#loc498 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":849:17)
#loc500 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":853:15)
#loc503 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":862:19)
#loc506 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":866:18)
#loc511 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":872:16)
#loc515 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":879:17)
#loc517 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":883:15)
#loc520 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":892:19)
#loc523 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":896:18)
#loc528 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":902:16)
#loc532 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":909:17)
#loc534 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":913:15)
#loc537 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":922:19)
#loc540 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":926:18)
#loc545 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":932:16)
#loc549 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":939:17)
#loc551 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":943:15)
#loc554 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":952:19)
#loc557 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":956:18)
#loc562 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":962:16)
#loc566 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":969:17)
#loc568 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":973:15)
#loc571 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":982:19)
#loc574 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":986:18)
#loc579 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":992:16)
#loc583 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":999:17)
#loc585 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1003:15)
#loc588 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1012:19)
#loc591 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1016:18)
#loc596 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1022:16)
#loc600 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1029:17)
#loc602 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1033:15)
#loc605 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1042:19)
#loc608 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1046:18)
#loc613 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1052:16)
#loc617 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1059:17)
#loc619 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1063:15)
#loc622 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1072:19)
#loc625 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1076:18)
#loc630 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1082:16)
#loc634 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1089:17)
#loc636 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1093:15)
#loc639 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1102:19)
#loc642 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1106:18)
#loc647 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1112:16)
#loc651 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1119:17)
#loc653 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1123:15)
#loc656 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1132:19)
#loc659 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1136:18)
#loc664 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1142:16)
#loc668 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1149:17)
#loc670 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1153:15)
#loc673 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1162:19)
#loc676 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1166:18)
#loc681 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1172:16)
#loc685 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1179:17)
#loc687 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1183:15)
#loc690 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1192:19)
#loc693 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1196:18)
#loc698 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1202:16)
#loc702 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1209:17)
#loc704 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1213:15)
#loc707 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1222:19)
#loc710 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1226:18)
#loc715 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1232:16)
#loc720 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1239:26)
#loc721 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1239:53)
#loc722 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1239:80)
module {
  aie.device(npu2) {
    %shim_noc_tile_7_0 = aie.tile(7, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_6_0 = aie.tile(6, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_5_0 = aie.tile(5, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_4_0 = aie.tile(4, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_3_0 = aie.tile(3, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_2_0 = aie.tile(2, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_1_0 = aie.tile(1, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %shim_noc_tile_0_0 = aie.tile(0, 0) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 15>} loc(#loc1)
    %mem_tile_7_1 = aie.tile(7, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_6_1 = aie.tile(6, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_5_1 = aie.tile(5, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_4_1 = aie.tile(4, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_3_1 = aie.tile(3, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_2_1 = aie.tile(2, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_1_1 = aie.tile(1, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %mem_tile_0_1 = aie.tile(0, 1) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 26>} loc(#loc1)
    %tile_7_5 = aie.tile(7, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_7_4 = aie.tile(7, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_7_3 = aie.tile(7, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_7_2 = aie.tile(7, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_6_5 = aie.tile(6, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_6_4 = aie.tile(6, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_6_3 = aie.tile(6, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_6_2 = aie.tile(6, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_5_5 = aie.tile(5, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_5_4 = aie.tile(5, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_5_3 = aie.tile(5, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_5_2 = aie.tile(5, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_4_5 = aie.tile(4, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_4_4 = aie.tile(4, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_4_3 = aie.tile(4, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_4_2 = aie.tile(4, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_3_5 = aie.tile(3, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_3_4 = aie.tile(3, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_3_3 = aie.tile(3, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_3_2 = aie.tile(3, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_2_5 = aie.tile(2, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_2_4 = aie.tile(2, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_2_3 = aie.tile(2, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_2_2 = aie.tile(2, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_1_5 = aie.tile(1, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_1_4 = aie.tile(1, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_1_3 = aie.tile(1, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_1_2 = aie.tile(1, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %tile_0_5 = aie.tile(0, 5) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 31>} loc(#loc1)
    %tile_0_4 = aie.tile(0, 4) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 30>} loc(#loc1)
    %tile_0_3 = aie.tile(0, 3) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 29>} loc(#loc1)
    %tile_0_2 = aie.tile(0, 2) {controller_id = #aie.packet_info<pkt_type = 0, pkt_id = 27>} loc(#loc1)
    %direct_y_worker_7_3_buff_0 = aie.buffer(%tile_7_5) {address = 27136 : i32, sym_name = "direct_y_worker_7_3_buff_0"} : memref<512xbf16>  loc(#loc2)
    %direct_y_worker_7_3_buff_1 = aie.buffer(%tile_7_5) {address = 28160 : i32, sym_name = "direct_y_worker_7_3_buff_1"} : memref<512xbf16>  loc(#loc2)
    %direct_y_worker_7_3_prod_lock_0 = aie.lock(%tile_7_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_7_3_prod_lock_0"} loc(#loc2)
    %direct_y_worker_7_3_cons_lock_0 = aie.lock(%tile_7_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_7_3_cons_lock_0"} loc(#loc2)
    %direct_y_worker_7_2_buff_0 = aie.buffer(%tile_7_4) {address = 27136 : i32, sym_name = "direct_y_worker_7_2_buff_0"} : memref<512xbf16>  loc(#loc3)
    %direct_y_worker_7_2_buff_1 = aie.buffer(%tile_7_4) {address = 28160 : i32, sym_name = "direct_y_worker_7_2_buff_1"} : memref<512xbf16>  loc(#loc3)
    %direct_y_worker_7_2_prod_lock_0 = aie.lock(%tile_7_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_7_2_prod_lock_0"} loc(#loc3)
    %direct_y_worker_7_2_cons_lock_0 = aie.lock(%tile_7_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_7_2_cons_lock_0"} loc(#loc3)
    %direct_y_worker_7_1_buff_0 = aie.buffer(%tile_7_3) {address = 27136 : i32, sym_name = "direct_y_worker_7_1_buff_0"} : memref<512xbf16>  loc(#loc4)
    %direct_y_worker_7_1_buff_1 = aie.buffer(%tile_7_3) {address = 28160 : i32, sym_name = "direct_y_worker_7_1_buff_1"} : memref<512xbf16>  loc(#loc4)
    %direct_y_worker_7_1_prod_lock_0 = aie.lock(%tile_7_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_7_1_prod_lock_0"} loc(#loc4)
    %direct_y_worker_7_1_cons_lock_0 = aie.lock(%tile_7_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_7_1_cons_lock_0"} loc(#loc4)
    %direct_y_worker_7_0_buff_0 = aie.buffer(%tile_7_2) {address = 27136 : i32, sym_name = "direct_y_worker_7_0_buff_0"} : memref<512xbf16>  loc(#loc5)
    %direct_y_worker_7_0_buff_1 = aie.buffer(%tile_7_2) {address = 28160 : i32, sym_name = "direct_y_worker_7_0_buff_1"} : memref<512xbf16>  loc(#loc5)
    %direct_y_worker_7_0_prod_lock_0 = aie.lock(%tile_7_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_7_0_prod_lock_0"} loc(#loc5)
    %direct_y_worker_7_0_cons_lock_0 = aie.lock(%tile_7_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_7_0_cons_lock_0"} loc(#loc5)
    %direct_y_host_7_cons_prod_lock_0 = aie.lock(%shim_noc_tile_7_0, 0) {init = 0 : i32, sym_name = "direct_y_host_7_cons_prod_lock_0"} loc(#loc6)
    %direct_y_host_7_cons_cons_lock_0 = aie.lock(%shim_noc_tile_7_0, 1) {init = 0 : i32, sym_name = "direct_y_host_7_cons_cons_lock_0"} loc(#loc6)
    %direct_y_worker_6_3_buff_0 = aie.buffer(%tile_6_5) {address = 27136 : i32, sym_name = "direct_y_worker_6_3_buff_0"} : memref<512xbf16>  loc(#loc7)
    %direct_y_worker_6_3_buff_1 = aie.buffer(%tile_6_5) {address = 28160 : i32, sym_name = "direct_y_worker_6_3_buff_1"} : memref<512xbf16>  loc(#loc7)
    %direct_y_worker_6_3_prod_lock_0 = aie.lock(%tile_6_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_6_3_prod_lock_0"} loc(#loc7)
    %direct_y_worker_6_3_cons_lock_0 = aie.lock(%tile_6_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_6_3_cons_lock_0"} loc(#loc7)
    %direct_y_worker_6_2_buff_0 = aie.buffer(%tile_6_4) {address = 27136 : i32, sym_name = "direct_y_worker_6_2_buff_0"} : memref<512xbf16>  loc(#loc8)
    %direct_y_worker_6_2_buff_1 = aie.buffer(%tile_6_4) {address = 28160 : i32, sym_name = "direct_y_worker_6_2_buff_1"} : memref<512xbf16>  loc(#loc8)
    %direct_y_worker_6_2_prod_lock_0 = aie.lock(%tile_6_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_6_2_prod_lock_0"} loc(#loc8)
    %direct_y_worker_6_2_cons_lock_0 = aie.lock(%tile_6_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_6_2_cons_lock_0"} loc(#loc8)
    %direct_y_worker_6_1_buff_0 = aie.buffer(%tile_6_3) {address = 27136 : i32, sym_name = "direct_y_worker_6_1_buff_0"} : memref<512xbf16>  loc(#loc9)
    %direct_y_worker_6_1_buff_1 = aie.buffer(%tile_6_3) {address = 28160 : i32, sym_name = "direct_y_worker_6_1_buff_1"} : memref<512xbf16>  loc(#loc9)
    %direct_y_worker_6_1_prod_lock_0 = aie.lock(%tile_6_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_6_1_prod_lock_0"} loc(#loc9)
    %direct_y_worker_6_1_cons_lock_0 = aie.lock(%tile_6_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_6_1_cons_lock_0"} loc(#loc9)
    %direct_y_worker_6_0_buff_0 = aie.buffer(%tile_6_2) {address = 27136 : i32, sym_name = "direct_y_worker_6_0_buff_0"} : memref<512xbf16>  loc(#loc10)
    %direct_y_worker_6_0_buff_1 = aie.buffer(%tile_6_2) {address = 28160 : i32, sym_name = "direct_y_worker_6_0_buff_1"} : memref<512xbf16>  loc(#loc10)
    %direct_y_worker_6_0_prod_lock_0 = aie.lock(%tile_6_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_6_0_prod_lock_0"} loc(#loc10)
    %direct_y_worker_6_0_cons_lock_0 = aie.lock(%tile_6_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_6_0_cons_lock_0"} loc(#loc10)
    %direct_y_host_6_cons_prod_lock_0 = aie.lock(%shim_noc_tile_6_0, 0) {init = 0 : i32, sym_name = "direct_y_host_6_cons_prod_lock_0"} loc(#loc11)
    %direct_y_host_6_cons_cons_lock_0 = aie.lock(%shim_noc_tile_6_0, 1) {init = 0 : i32, sym_name = "direct_y_host_6_cons_cons_lock_0"} loc(#loc11)
    %direct_y_worker_5_3_buff_0 = aie.buffer(%tile_5_5) {address = 27136 : i32, sym_name = "direct_y_worker_5_3_buff_0"} : memref<512xbf16>  loc(#loc12)
    %direct_y_worker_5_3_buff_1 = aie.buffer(%tile_5_5) {address = 28160 : i32, sym_name = "direct_y_worker_5_3_buff_1"} : memref<512xbf16>  loc(#loc12)
    %direct_y_worker_5_3_prod_lock_0 = aie.lock(%tile_5_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_5_3_prod_lock_0"} loc(#loc12)
    %direct_y_worker_5_3_cons_lock_0 = aie.lock(%tile_5_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_5_3_cons_lock_0"} loc(#loc12)
    %direct_y_worker_5_2_buff_0 = aie.buffer(%tile_5_4) {address = 27136 : i32, sym_name = "direct_y_worker_5_2_buff_0"} : memref<512xbf16>  loc(#loc13)
    %direct_y_worker_5_2_buff_1 = aie.buffer(%tile_5_4) {address = 28160 : i32, sym_name = "direct_y_worker_5_2_buff_1"} : memref<512xbf16>  loc(#loc13)
    %direct_y_worker_5_2_prod_lock_0 = aie.lock(%tile_5_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_5_2_prod_lock_0"} loc(#loc13)
    %direct_y_worker_5_2_cons_lock_0 = aie.lock(%tile_5_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_5_2_cons_lock_0"} loc(#loc13)
    %direct_y_worker_5_1_buff_0 = aie.buffer(%tile_5_3) {address = 27136 : i32, sym_name = "direct_y_worker_5_1_buff_0"} : memref<512xbf16>  loc(#loc14)
    %direct_y_worker_5_1_buff_1 = aie.buffer(%tile_5_3) {address = 28160 : i32, sym_name = "direct_y_worker_5_1_buff_1"} : memref<512xbf16>  loc(#loc14)
    %direct_y_worker_5_1_prod_lock_0 = aie.lock(%tile_5_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_5_1_prod_lock_0"} loc(#loc14)
    %direct_y_worker_5_1_cons_lock_0 = aie.lock(%tile_5_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_5_1_cons_lock_0"} loc(#loc14)
    %direct_y_worker_5_0_buff_0 = aie.buffer(%tile_5_2) {address = 27136 : i32, sym_name = "direct_y_worker_5_0_buff_0"} : memref<512xbf16>  loc(#loc15)
    %direct_y_worker_5_0_buff_1 = aie.buffer(%tile_5_2) {address = 28160 : i32, sym_name = "direct_y_worker_5_0_buff_1"} : memref<512xbf16>  loc(#loc15)
    %direct_y_worker_5_0_prod_lock_0 = aie.lock(%tile_5_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_5_0_prod_lock_0"} loc(#loc15)
    %direct_y_worker_5_0_cons_lock_0 = aie.lock(%tile_5_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_5_0_cons_lock_0"} loc(#loc15)
    %direct_y_host_5_cons_prod_lock_0 = aie.lock(%shim_noc_tile_5_0, 0) {init = 0 : i32, sym_name = "direct_y_host_5_cons_prod_lock_0"} loc(#loc16)
    %direct_y_host_5_cons_cons_lock_0 = aie.lock(%shim_noc_tile_5_0, 1) {init = 0 : i32, sym_name = "direct_y_host_5_cons_cons_lock_0"} loc(#loc16)
    %direct_y_worker_4_3_buff_0 = aie.buffer(%tile_4_5) {address = 27136 : i32, sym_name = "direct_y_worker_4_3_buff_0"} : memref<512xbf16>  loc(#loc17)
    %direct_y_worker_4_3_buff_1 = aie.buffer(%tile_4_5) {address = 28160 : i32, sym_name = "direct_y_worker_4_3_buff_1"} : memref<512xbf16>  loc(#loc17)
    %direct_y_worker_4_3_prod_lock_0 = aie.lock(%tile_4_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_4_3_prod_lock_0"} loc(#loc17)
    %direct_y_worker_4_3_cons_lock_0 = aie.lock(%tile_4_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_4_3_cons_lock_0"} loc(#loc17)
    %direct_y_worker_4_2_buff_0 = aie.buffer(%tile_4_4) {address = 27136 : i32, sym_name = "direct_y_worker_4_2_buff_0"} : memref<512xbf16>  loc(#loc18)
    %direct_y_worker_4_2_buff_1 = aie.buffer(%tile_4_4) {address = 28160 : i32, sym_name = "direct_y_worker_4_2_buff_1"} : memref<512xbf16>  loc(#loc18)
    %direct_y_worker_4_2_prod_lock_0 = aie.lock(%tile_4_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_4_2_prod_lock_0"} loc(#loc18)
    %direct_y_worker_4_2_cons_lock_0 = aie.lock(%tile_4_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_4_2_cons_lock_0"} loc(#loc18)
    %direct_y_worker_4_1_buff_0 = aie.buffer(%tile_4_3) {address = 27136 : i32, sym_name = "direct_y_worker_4_1_buff_0"} : memref<512xbf16>  loc(#loc19)
    %direct_y_worker_4_1_buff_1 = aie.buffer(%tile_4_3) {address = 28160 : i32, sym_name = "direct_y_worker_4_1_buff_1"} : memref<512xbf16>  loc(#loc19)
    %direct_y_worker_4_1_prod_lock_0 = aie.lock(%tile_4_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_4_1_prod_lock_0"} loc(#loc19)
    %direct_y_worker_4_1_cons_lock_0 = aie.lock(%tile_4_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_4_1_cons_lock_0"} loc(#loc19)
    %direct_y_worker_4_0_buff_0 = aie.buffer(%tile_4_2) {address = 27136 : i32, sym_name = "direct_y_worker_4_0_buff_0"} : memref<512xbf16>  loc(#loc20)
    %direct_y_worker_4_0_buff_1 = aie.buffer(%tile_4_2) {address = 28160 : i32, sym_name = "direct_y_worker_4_0_buff_1"} : memref<512xbf16>  loc(#loc20)
    %direct_y_worker_4_0_prod_lock_0 = aie.lock(%tile_4_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_4_0_prod_lock_0"} loc(#loc20)
    %direct_y_worker_4_0_cons_lock_0 = aie.lock(%tile_4_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_4_0_cons_lock_0"} loc(#loc20)
    %direct_y_host_4_cons_prod_lock_0 = aie.lock(%shim_noc_tile_4_0, 0) {init = 0 : i32, sym_name = "direct_y_host_4_cons_prod_lock_0"} loc(#loc21)
    %direct_y_host_4_cons_cons_lock_0 = aie.lock(%shim_noc_tile_4_0, 1) {init = 0 : i32, sym_name = "direct_y_host_4_cons_cons_lock_0"} loc(#loc21)
    %direct_y_worker_3_3_buff_0 = aie.buffer(%tile_3_5) {address = 27136 : i32, sym_name = "direct_y_worker_3_3_buff_0"} : memref<512xbf16>  loc(#loc22)
    %direct_y_worker_3_3_buff_1 = aie.buffer(%tile_3_5) {address = 28160 : i32, sym_name = "direct_y_worker_3_3_buff_1"} : memref<512xbf16>  loc(#loc22)
    %direct_y_worker_3_3_prod_lock_0 = aie.lock(%tile_3_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_3_3_prod_lock_0"} loc(#loc22)
    %direct_y_worker_3_3_cons_lock_0 = aie.lock(%tile_3_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_3_3_cons_lock_0"} loc(#loc22)
    %direct_y_worker_3_2_buff_0 = aie.buffer(%tile_3_4) {address = 27136 : i32, sym_name = "direct_y_worker_3_2_buff_0"} : memref<512xbf16>  loc(#loc23)
    %direct_y_worker_3_2_buff_1 = aie.buffer(%tile_3_4) {address = 28160 : i32, sym_name = "direct_y_worker_3_2_buff_1"} : memref<512xbf16>  loc(#loc23)
    %direct_y_worker_3_2_prod_lock_0 = aie.lock(%tile_3_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_3_2_prod_lock_0"} loc(#loc23)
    %direct_y_worker_3_2_cons_lock_0 = aie.lock(%tile_3_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_3_2_cons_lock_0"} loc(#loc23)
    %direct_y_worker_3_1_buff_0 = aie.buffer(%tile_3_3) {address = 27136 : i32, sym_name = "direct_y_worker_3_1_buff_0"} : memref<512xbf16>  loc(#loc24)
    %direct_y_worker_3_1_buff_1 = aie.buffer(%tile_3_3) {address = 28160 : i32, sym_name = "direct_y_worker_3_1_buff_1"} : memref<512xbf16>  loc(#loc24)
    %direct_y_worker_3_1_prod_lock_0 = aie.lock(%tile_3_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_3_1_prod_lock_0"} loc(#loc24)
    %direct_y_worker_3_1_cons_lock_0 = aie.lock(%tile_3_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_3_1_cons_lock_0"} loc(#loc24)
    %direct_y_worker_3_0_buff_0 = aie.buffer(%tile_3_2) {address = 27136 : i32, sym_name = "direct_y_worker_3_0_buff_0"} : memref<512xbf16>  loc(#loc25)
    %direct_y_worker_3_0_buff_1 = aie.buffer(%tile_3_2) {address = 28160 : i32, sym_name = "direct_y_worker_3_0_buff_1"} : memref<512xbf16>  loc(#loc25)
    %direct_y_worker_3_0_prod_lock_0 = aie.lock(%tile_3_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_3_0_prod_lock_0"} loc(#loc25)
    %direct_y_worker_3_0_cons_lock_0 = aie.lock(%tile_3_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_3_0_cons_lock_0"} loc(#loc25)
    %direct_y_host_3_cons_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 0) {init = 0 : i32, sym_name = "direct_y_host_3_cons_prod_lock_0"} loc(#loc26)
    %direct_y_host_3_cons_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 1) {init = 0 : i32, sym_name = "direct_y_host_3_cons_cons_lock_0"} loc(#loc26)
    %direct_y_worker_2_3_buff_0 = aie.buffer(%tile_2_5) {address = 27136 : i32, sym_name = "direct_y_worker_2_3_buff_0"} : memref<512xbf16>  loc(#loc27)
    %direct_y_worker_2_3_buff_1 = aie.buffer(%tile_2_5) {address = 28160 : i32, sym_name = "direct_y_worker_2_3_buff_1"} : memref<512xbf16>  loc(#loc27)
    %direct_y_worker_2_3_prod_lock_0 = aie.lock(%tile_2_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_2_3_prod_lock_0"} loc(#loc27)
    %direct_y_worker_2_3_cons_lock_0 = aie.lock(%tile_2_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_2_3_cons_lock_0"} loc(#loc27)
    %direct_y_worker_2_2_buff_0 = aie.buffer(%tile_2_4) {address = 27136 : i32, sym_name = "direct_y_worker_2_2_buff_0"} : memref<512xbf16>  loc(#loc28)
    %direct_y_worker_2_2_buff_1 = aie.buffer(%tile_2_4) {address = 28160 : i32, sym_name = "direct_y_worker_2_2_buff_1"} : memref<512xbf16>  loc(#loc28)
    %direct_y_worker_2_2_prod_lock_0 = aie.lock(%tile_2_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_2_2_prod_lock_0"} loc(#loc28)
    %direct_y_worker_2_2_cons_lock_0 = aie.lock(%tile_2_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_2_2_cons_lock_0"} loc(#loc28)
    %direct_y_worker_2_1_buff_0 = aie.buffer(%tile_2_3) {address = 27136 : i32, sym_name = "direct_y_worker_2_1_buff_0"} : memref<512xbf16>  loc(#loc29)
    %direct_y_worker_2_1_buff_1 = aie.buffer(%tile_2_3) {address = 28160 : i32, sym_name = "direct_y_worker_2_1_buff_1"} : memref<512xbf16>  loc(#loc29)
    %direct_y_worker_2_1_prod_lock_0 = aie.lock(%tile_2_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_2_1_prod_lock_0"} loc(#loc29)
    %direct_y_worker_2_1_cons_lock_0 = aie.lock(%tile_2_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_2_1_cons_lock_0"} loc(#loc29)
    %direct_y_worker_2_0_buff_0 = aie.buffer(%tile_2_2) {address = 27136 : i32, sym_name = "direct_y_worker_2_0_buff_0"} : memref<512xbf16>  loc(#loc30)
    %direct_y_worker_2_0_buff_1 = aie.buffer(%tile_2_2) {address = 28160 : i32, sym_name = "direct_y_worker_2_0_buff_1"} : memref<512xbf16>  loc(#loc30)
    %direct_y_worker_2_0_prod_lock_0 = aie.lock(%tile_2_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_2_0_prod_lock_0"} loc(#loc30)
    %direct_y_worker_2_0_cons_lock_0 = aie.lock(%tile_2_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_2_0_cons_lock_0"} loc(#loc30)
    %direct_y_host_2_cons_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 0) {init = 0 : i32, sym_name = "direct_y_host_2_cons_prod_lock_0"} loc(#loc31)
    %direct_y_host_2_cons_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 1) {init = 0 : i32, sym_name = "direct_y_host_2_cons_cons_lock_0"} loc(#loc31)
    %direct_y_worker_1_3_buff_0 = aie.buffer(%tile_1_5) {address = 27136 : i32, sym_name = "direct_y_worker_1_3_buff_0"} : memref<512xbf16>  loc(#loc32)
    %direct_y_worker_1_3_buff_1 = aie.buffer(%tile_1_5) {address = 28160 : i32, sym_name = "direct_y_worker_1_3_buff_1"} : memref<512xbf16>  loc(#loc32)
    %direct_y_worker_1_3_prod_lock_0 = aie.lock(%tile_1_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_1_3_prod_lock_0"} loc(#loc32)
    %direct_y_worker_1_3_cons_lock_0 = aie.lock(%tile_1_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_1_3_cons_lock_0"} loc(#loc32)
    %direct_y_worker_1_2_buff_0 = aie.buffer(%tile_1_4) {address = 27136 : i32, sym_name = "direct_y_worker_1_2_buff_0"} : memref<512xbf16>  loc(#loc33)
    %direct_y_worker_1_2_buff_1 = aie.buffer(%tile_1_4) {address = 28160 : i32, sym_name = "direct_y_worker_1_2_buff_1"} : memref<512xbf16>  loc(#loc33)
    %direct_y_worker_1_2_prod_lock_0 = aie.lock(%tile_1_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_1_2_prod_lock_0"} loc(#loc33)
    %direct_y_worker_1_2_cons_lock_0 = aie.lock(%tile_1_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_1_2_cons_lock_0"} loc(#loc33)
    %direct_y_host_7_buff_0 = aie.buffer(%mem_tile_7_1) {address = 8704 : i32, sym_name = "direct_y_host_7_buff_0"} : memref<2048xbf16>  loc(#loc6)
    %direct_y_host_7_buff_1 = aie.buffer(%mem_tile_7_1) {address = 12800 : i32, sym_name = "direct_y_host_7_buff_1"} : memref<2048xbf16>  loc(#loc6)
    %direct_y_host_7_prod_lock_0 = aie.lock(%mem_tile_7_1, 0) {init = 2 : i32, sym_name = "direct_y_host_7_prod_lock_0"} loc(#loc6)
    %direct_y_host_7_cons_lock_0 = aie.lock(%mem_tile_7_1, 1) {init = 0 : i32, sym_name = "direct_y_host_7_cons_lock_0"} loc(#loc6)
    %direct_y_host_7_prod_lock_1 = aie.lock(%mem_tile_7_1, 2) {init = 2 : i32, sym_name = "direct_y_host_7_prod_lock_1"} loc(#loc6)
    %direct_y_host_7_cons_lock_1 = aie.lock(%mem_tile_7_1, 3) {init = 0 : i32, sym_name = "direct_y_host_7_cons_lock_1"} loc(#loc6)
    %direct_y_host_7_prod_lock_2 = aie.lock(%mem_tile_7_1, 4) {init = 2 : i32, sym_name = "direct_y_host_7_prod_lock_2"} loc(#loc6)
    %direct_y_host_7_cons_lock_2 = aie.lock(%mem_tile_7_1, 5) {init = 0 : i32, sym_name = "direct_y_host_7_cons_lock_2"} loc(#loc6)
    %direct_y_host_7_prod_lock_3 = aie.lock(%mem_tile_7_1, 6) {init = 2 : i32, sym_name = "direct_y_host_7_prod_lock_3"} loc(#loc6)
    %direct_y_host_7_cons_lock_3 = aie.lock(%mem_tile_7_1, 7) {init = 0 : i32, sym_name = "direct_y_host_7_cons_lock_3"} loc(#loc6)
    %direct_y_worker_1_1_buff_0 = aie.buffer(%tile_1_3) {address = 27136 : i32, sym_name = "direct_y_worker_1_1_buff_0"} : memref<512xbf16>  loc(#loc34)
    %direct_y_worker_1_1_buff_1 = aie.buffer(%tile_1_3) {address = 28160 : i32, sym_name = "direct_y_worker_1_1_buff_1"} : memref<512xbf16>  loc(#loc34)
    %direct_y_worker_1_1_prod_lock_0 = aie.lock(%tile_1_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_1_1_prod_lock_0"} loc(#loc34)
    %direct_y_worker_1_1_cons_lock_0 = aie.lock(%tile_1_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_1_1_cons_lock_0"} loc(#loc34)
    %direct_y_host_6_buff_0 = aie.buffer(%mem_tile_6_1) {address = 8704 : i32, sym_name = "direct_y_host_6_buff_0"} : memref<2048xbf16>  loc(#loc11)
    %direct_y_host_6_buff_1 = aie.buffer(%mem_tile_6_1) {address = 12800 : i32, sym_name = "direct_y_host_6_buff_1"} : memref<2048xbf16>  loc(#loc11)
    %direct_y_host_6_prod_lock_0 = aie.lock(%mem_tile_6_1, 0) {init = 2 : i32, sym_name = "direct_y_host_6_prod_lock_0"} loc(#loc11)
    %direct_y_host_6_cons_lock_0 = aie.lock(%mem_tile_6_1, 1) {init = 0 : i32, sym_name = "direct_y_host_6_cons_lock_0"} loc(#loc11)
    %direct_y_host_6_prod_lock_1 = aie.lock(%mem_tile_6_1, 2) {init = 2 : i32, sym_name = "direct_y_host_6_prod_lock_1"} loc(#loc11)
    %direct_y_host_6_cons_lock_1 = aie.lock(%mem_tile_6_1, 3) {init = 0 : i32, sym_name = "direct_y_host_6_cons_lock_1"} loc(#loc11)
    %direct_y_host_6_prod_lock_2 = aie.lock(%mem_tile_6_1, 4) {init = 2 : i32, sym_name = "direct_y_host_6_prod_lock_2"} loc(#loc11)
    %direct_y_host_6_cons_lock_2 = aie.lock(%mem_tile_6_1, 5) {init = 0 : i32, sym_name = "direct_y_host_6_cons_lock_2"} loc(#loc11)
    %direct_y_host_6_prod_lock_3 = aie.lock(%mem_tile_6_1, 6) {init = 2 : i32, sym_name = "direct_y_host_6_prod_lock_3"} loc(#loc11)
    %direct_y_host_6_cons_lock_3 = aie.lock(%mem_tile_6_1, 7) {init = 0 : i32, sym_name = "direct_y_host_6_cons_lock_3"} loc(#loc11)
    %direct_y_worker_1_0_buff_0 = aie.buffer(%tile_1_2) {address = 27136 : i32, sym_name = "direct_y_worker_1_0_buff_0"} : memref<512xbf16>  loc(#loc35)
    %direct_y_worker_1_0_buff_1 = aie.buffer(%tile_1_2) {address = 28160 : i32, sym_name = "direct_y_worker_1_0_buff_1"} : memref<512xbf16>  loc(#loc35)
    %direct_y_worker_1_0_prod_lock_0 = aie.lock(%tile_1_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_1_0_prod_lock_0"} loc(#loc35)
    %direct_y_worker_1_0_cons_lock_0 = aie.lock(%tile_1_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_1_0_cons_lock_0"} loc(#loc35)
    %direct_y_host_1_cons_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 0) {init = 0 : i32, sym_name = "direct_y_host_1_cons_prod_lock_0"} loc(#loc36)
    %direct_y_host_1_cons_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 1) {init = 0 : i32, sym_name = "direct_y_host_1_cons_cons_lock_0"} loc(#loc36)
    %direct_y_host_5_buff_0 = aie.buffer(%mem_tile_5_1) {address = 8704 : i32, sym_name = "direct_y_host_5_buff_0"} : memref<2048xbf16>  loc(#loc16)
    %direct_y_host_5_buff_1 = aie.buffer(%mem_tile_5_1) {address = 12800 : i32, sym_name = "direct_y_host_5_buff_1"} : memref<2048xbf16>  loc(#loc16)
    %direct_y_host_5_prod_lock_0 = aie.lock(%mem_tile_5_1, 0) {init = 2 : i32, sym_name = "direct_y_host_5_prod_lock_0"} loc(#loc16)
    %direct_y_host_5_cons_lock_0 = aie.lock(%mem_tile_5_1, 1) {init = 0 : i32, sym_name = "direct_y_host_5_cons_lock_0"} loc(#loc16)
    %direct_y_host_5_prod_lock_1 = aie.lock(%mem_tile_5_1, 2) {init = 2 : i32, sym_name = "direct_y_host_5_prod_lock_1"} loc(#loc16)
    %direct_y_host_5_cons_lock_1 = aie.lock(%mem_tile_5_1, 3) {init = 0 : i32, sym_name = "direct_y_host_5_cons_lock_1"} loc(#loc16)
    %direct_y_host_5_prod_lock_2 = aie.lock(%mem_tile_5_1, 4) {init = 2 : i32, sym_name = "direct_y_host_5_prod_lock_2"} loc(#loc16)
    %direct_y_host_5_cons_lock_2 = aie.lock(%mem_tile_5_1, 5) {init = 0 : i32, sym_name = "direct_y_host_5_cons_lock_2"} loc(#loc16)
    %direct_y_host_5_prod_lock_3 = aie.lock(%mem_tile_5_1, 6) {init = 2 : i32, sym_name = "direct_y_host_5_prod_lock_3"} loc(#loc16)
    %direct_y_host_5_cons_lock_3 = aie.lock(%mem_tile_5_1, 7) {init = 0 : i32, sym_name = "direct_y_host_5_cons_lock_3"} loc(#loc16)
    %direct_y_host_4_buff_0 = aie.buffer(%mem_tile_4_1) {address = 8704 : i32, sym_name = "direct_y_host_4_buff_0"} : memref<2048xbf16>  loc(#loc21)
    %direct_y_host_4_buff_1 = aie.buffer(%mem_tile_4_1) {address = 12800 : i32, sym_name = "direct_y_host_4_buff_1"} : memref<2048xbf16>  loc(#loc21)
    %direct_y_host_4_prod_lock_0 = aie.lock(%mem_tile_4_1, 0) {init = 2 : i32, sym_name = "direct_y_host_4_prod_lock_0"} loc(#loc21)
    %direct_y_host_4_cons_lock_0 = aie.lock(%mem_tile_4_1, 1) {init = 0 : i32, sym_name = "direct_y_host_4_cons_lock_0"} loc(#loc21)
    %direct_y_host_4_prod_lock_1 = aie.lock(%mem_tile_4_1, 2) {init = 2 : i32, sym_name = "direct_y_host_4_prod_lock_1"} loc(#loc21)
    %direct_y_host_4_cons_lock_1 = aie.lock(%mem_tile_4_1, 3) {init = 0 : i32, sym_name = "direct_y_host_4_cons_lock_1"} loc(#loc21)
    %direct_y_host_4_prod_lock_2 = aie.lock(%mem_tile_4_1, 4) {init = 2 : i32, sym_name = "direct_y_host_4_prod_lock_2"} loc(#loc21)
    %direct_y_host_4_cons_lock_2 = aie.lock(%mem_tile_4_1, 5) {init = 0 : i32, sym_name = "direct_y_host_4_cons_lock_2"} loc(#loc21)
    %direct_y_host_4_prod_lock_3 = aie.lock(%mem_tile_4_1, 6) {init = 2 : i32, sym_name = "direct_y_host_4_prod_lock_3"} loc(#loc21)
    %direct_y_host_4_cons_lock_3 = aie.lock(%mem_tile_4_1, 7) {init = 0 : i32, sym_name = "direct_y_host_4_cons_lock_3"} loc(#loc21)
    %direct_y_worker_0_3_buff_0 = aie.buffer(%tile_0_5) {address = 27136 : i32, sym_name = "direct_y_worker_0_3_buff_0"} : memref<512xbf16>  loc(#loc37)
    %direct_y_worker_0_3_buff_1 = aie.buffer(%tile_0_5) {address = 28160 : i32, sym_name = "direct_y_worker_0_3_buff_1"} : memref<512xbf16>  loc(#loc37)
    %direct_y_worker_0_3_prod_lock_0 = aie.lock(%tile_0_5, 0) {init = 2 : i32, sym_name = "direct_y_worker_0_3_prod_lock_0"} loc(#loc37)
    %direct_y_worker_0_3_cons_lock_0 = aie.lock(%tile_0_5, 1) {init = 0 : i32, sym_name = "direct_y_worker_0_3_cons_lock_0"} loc(#loc37)
    %direct_y_host_3_buff_0 = aie.buffer(%mem_tile_3_1) {address = 8704 : i32, sym_name = "direct_y_host_3_buff_0"} : memref<2048xbf16>  loc(#loc26)
    %direct_y_host_3_buff_1 = aie.buffer(%mem_tile_3_1) {address = 12800 : i32, sym_name = "direct_y_host_3_buff_1"} : memref<2048xbf16>  loc(#loc26)
    %direct_y_host_3_prod_lock_0 = aie.lock(%mem_tile_3_1, 0) {init = 2 : i32, sym_name = "direct_y_host_3_prod_lock_0"} loc(#loc26)
    %direct_y_host_3_cons_lock_0 = aie.lock(%mem_tile_3_1, 1) {init = 0 : i32, sym_name = "direct_y_host_3_cons_lock_0"} loc(#loc26)
    %direct_y_host_3_prod_lock_1 = aie.lock(%mem_tile_3_1, 2) {init = 2 : i32, sym_name = "direct_y_host_3_prod_lock_1"} loc(#loc26)
    %direct_y_host_3_cons_lock_1 = aie.lock(%mem_tile_3_1, 3) {init = 0 : i32, sym_name = "direct_y_host_3_cons_lock_1"} loc(#loc26)
    %direct_y_host_3_prod_lock_2 = aie.lock(%mem_tile_3_1, 4) {init = 2 : i32, sym_name = "direct_y_host_3_prod_lock_2"} loc(#loc26)
    %direct_y_host_3_cons_lock_2 = aie.lock(%mem_tile_3_1, 5) {init = 0 : i32, sym_name = "direct_y_host_3_cons_lock_2"} loc(#loc26)
    %direct_y_host_3_prod_lock_3 = aie.lock(%mem_tile_3_1, 6) {init = 2 : i32, sym_name = "direct_y_host_3_prod_lock_3"} loc(#loc26)
    %direct_y_host_3_cons_lock_3 = aie.lock(%mem_tile_3_1, 7) {init = 0 : i32, sym_name = "direct_y_host_3_cons_lock_3"} loc(#loc26)
    %direct_y_worker_0_2_buff_0 = aie.buffer(%tile_0_4) {address = 27136 : i32, sym_name = "direct_y_worker_0_2_buff_0"} : memref<512xbf16>  loc(#loc38)
    %direct_y_worker_0_2_buff_1 = aie.buffer(%tile_0_4) {address = 28160 : i32, sym_name = "direct_y_worker_0_2_buff_1"} : memref<512xbf16>  loc(#loc38)
    %direct_y_worker_0_2_prod_lock_0 = aie.lock(%tile_0_4, 0) {init = 2 : i32, sym_name = "direct_y_worker_0_2_prod_lock_0"} loc(#loc38)
    %direct_y_worker_0_2_cons_lock_0 = aie.lock(%tile_0_4, 1) {init = 0 : i32, sym_name = "direct_y_worker_0_2_cons_lock_0"} loc(#loc38)
    %direct_y_host_2_buff_0 = aie.buffer(%mem_tile_2_1) {address = 8704 : i32, sym_name = "direct_y_host_2_buff_0"} : memref<2048xbf16>  loc(#loc31)
    %direct_y_host_2_buff_1 = aie.buffer(%mem_tile_2_1) {address = 12800 : i32, sym_name = "direct_y_host_2_buff_1"} : memref<2048xbf16>  loc(#loc31)
    %direct_y_host_2_prod_lock_0 = aie.lock(%mem_tile_2_1, 0) {init = 2 : i32, sym_name = "direct_y_host_2_prod_lock_0"} loc(#loc31)
    %direct_y_host_2_cons_lock_0 = aie.lock(%mem_tile_2_1, 1) {init = 0 : i32, sym_name = "direct_y_host_2_cons_lock_0"} loc(#loc31)
    %direct_y_host_2_prod_lock_1 = aie.lock(%mem_tile_2_1, 2) {init = 2 : i32, sym_name = "direct_y_host_2_prod_lock_1"} loc(#loc31)
    %direct_y_host_2_cons_lock_1 = aie.lock(%mem_tile_2_1, 3) {init = 0 : i32, sym_name = "direct_y_host_2_cons_lock_1"} loc(#loc31)
    %direct_y_host_2_prod_lock_2 = aie.lock(%mem_tile_2_1, 4) {init = 2 : i32, sym_name = "direct_y_host_2_prod_lock_2"} loc(#loc31)
    %direct_y_host_2_cons_lock_2 = aie.lock(%mem_tile_2_1, 5) {init = 0 : i32, sym_name = "direct_y_host_2_cons_lock_2"} loc(#loc31)
    %direct_y_host_2_prod_lock_3 = aie.lock(%mem_tile_2_1, 6) {init = 2 : i32, sym_name = "direct_y_host_2_prod_lock_3"} loc(#loc31)
    %direct_y_host_2_cons_lock_3 = aie.lock(%mem_tile_2_1, 7) {init = 0 : i32, sym_name = "direct_y_host_2_cons_lock_3"} loc(#loc31)
    %direct_y_worker_0_1_buff_0 = aie.buffer(%tile_0_3) {address = 27136 : i32, sym_name = "direct_y_worker_0_1_buff_0"} : memref<512xbf16>  loc(#loc39)
    %direct_y_worker_0_1_buff_1 = aie.buffer(%tile_0_3) {address = 28160 : i32, sym_name = "direct_y_worker_0_1_buff_1"} : memref<512xbf16>  loc(#loc39)
    %direct_y_worker_0_1_prod_lock_0 = aie.lock(%tile_0_3, 0) {init = 2 : i32, sym_name = "direct_y_worker_0_1_prod_lock_0"} loc(#loc39)
    %direct_y_worker_0_1_cons_lock_0 = aie.lock(%tile_0_3, 1) {init = 0 : i32, sym_name = "direct_y_worker_0_1_cons_lock_0"} loc(#loc39)
    %direct_y_host_1_buff_0 = aie.buffer(%mem_tile_1_1) {address = 8704 : i32, sym_name = "direct_y_host_1_buff_0"} : memref<2048xbf16>  loc(#loc36)
    %direct_y_host_1_buff_1 = aie.buffer(%mem_tile_1_1) {address = 12800 : i32, sym_name = "direct_y_host_1_buff_1"} : memref<2048xbf16>  loc(#loc36)
    %direct_y_host_1_prod_lock_0 = aie.lock(%mem_tile_1_1, 0) {init = 2 : i32, sym_name = "direct_y_host_1_prod_lock_0"} loc(#loc36)
    %direct_y_host_1_cons_lock_0 = aie.lock(%mem_tile_1_1, 1) {init = 0 : i32, sym_name = "direct_y_host_1_cons_lock_0"} loc(#loc36)
    %direct_y_host_1_prod_lock_1 = aie.lock(%mem_tile_1_1, 2) {init = 2 : i32, sym_name = "direct_y_host_1_prod_lock_1"} loc(#loc36)
    %direct_y_host_1_cons_lock_1 = aie.lock(%mem_tile_1_1, 3) {init = 0 : i32, sym_name = "direct_y_host_1_cons_lock_1"} loc(#loc36)
    %direct_y_host_1_prod_lock_2 = aie.lock(%mem_tile_1_1, 4) {init = 2 : i32, sym_name = "direct_y_host_1_prod_lock_2"} loc(#loc36)
    %direct_y_host_1_cons_lock_2 = aie.lock(%mem_tile_1_1, 5) {init = 0 : i32, sym_name = "direct_y_host_1_cons_lock_2"} loc(#loc36)
    %direct_y_host_1_prod_lock_3 = aie.lock(%mem_tile_1_1, 6) {init = 2 : i32, sym_name = "direct_y_host_1_prod_lock_3"} loc(#loc36)
    %direct_y_host_1_cons_lock_3 = aie.lock(%mem_tile_1_1, 7) {init = 0 : i32, sym_name = "direct_y_host_1_cons_lock_3"} loc(#loc36)
    %direct_y_worker_0_0_buff_0 = aie.buffer(%tile_0_2) {address = 27136 : i32, sym_name = "direct_y_worker_0_0_buff_0"} : memref<512xbf16>  loc(#loc40)
    %direct_y_worker_0_0_buff_1 = aie.buffer(%tile_0_2) {address = 28160 : i32, sym_name = "direct_y_worker_0_0_buff_1"} : memref<512xbf16>  loc(#loc40)
    %direct_y_worker_0_0_prod_lock_0 = aie.lock(%tile_0_2, 0) {init = 2 : i32, sym_name = "direct_y_worker_0_0_prod_lock_0"} loc(#loc40)
    %direct_y_worker_0_0_cons_lock_0 = aie.lock(%tile_0_2, 1) {init = 0 : i32, sym_name = "direct_y_worker_0_0_cons_lock_0"} loc(#loc40)
    %direct_y_host_0_cons_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 0) {init = 0 : i32, sym_name = "direct_y_host_0_cons_prod_lock_0"} loc(#loc41)
    %direct_y_host_0_cons_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 1) {init = 0 : i32, sym_name = "direct_y_host_0_cons_cons_lock_0"} loc(#loc41)
    %direct_y_host_0_buff_0 = aie.buffer(%mem_tile_0_1) {address = 8704 : i32, sym_name = "direct_y_host_0_buff_0"} : memref<2048xbf16>  loc(#loc41)
    %direct_y_host_0_buff_1 = aie.buffer(%mem_tile_0_1) {address = 12800 : i32, sym_name = "direct_y_host_0_buff_1"} : memref<2048xbf16>  loc(#loc41)
    %direct_y_host_0_prod_lock_0 = aie.lock(%mem_tile_0_1, 0) {init = 2 : i32, sym_name = "direct_y_host_0_prod_lock_0"} loc(#loc41)
    %direct_y_host_0_cons_lock_0 = aie.lock(%mem_tile_0_1, 1) {init = 0 : i32, sym_name = "direct_y_host_0_cons_lock_0"} loc(#loc41)
    %direct_y_host_0_prod_lock_1 = aie.lock(%mem_tile_0_1, 2) {init = 2 : i32, sym_name = "direct_y_host_0_prod_lock_1"} loc(#loc41)
    %direct_y_host_0_cons_lock_1 = aie.lock(%mem_tile_0_1, 3) {init = 0 : i32, sym_name = "direct_y_host_0_cons_lock_1"} loc(#loc41)
    %direct_y_host_0_prod_lock_2 = aie.lock(%mem_tile_0_1, 4) {init = 2 : i32, sym_name = "direct_y_host_0_prod_lock_2"} loc(#loc41)
    %direct_y_host_0_cons_lock_2 = aie.lock(%mem_tile_0_1, 5) {init = 0 : i32, sym_name = "direct_y_host_0_cons_lock_2"} loc(#loc41)
    %direct_y_host_0_prod_lock_3 = aie.lock(%mem_tile_0_1, 6) {init = 2 : i32, sym_name = "direct_y_host_0_prod_lock_3"} loc(#loc41)
    %direct_y_host_0_cons_lock_3 = aie.lock(%mem_tile_0_1, 7) {init = 0 : i32, sym_name = "direct_y_host_0_cons_lock_3"} loc(#loc41)
    %direct_a_host_7_cons_buff_0 = aie.buffer(%mem_tile_7_1) {address = 16896 : i32, sym_name = "direct_a_host_7_cons_buff_0"} : memref<2048xbf16>  loc(#loc42)
    %direct_a_host_7_cons_buff_1 = aie.buffer(%mem_tile_7_1) {address = 20992 : i32, sym_name = "direct_a_host_7_cons_buff_1"} : memref<2048xbf16>  loc(#loc42)
    %direct_a_host_7_cons_prod_lock_0 = aie.lock(%mem_tile_7_1, 8) {init = 2 : i32, sym_name = "direct_a_host_7_cons_prod_lock_0"} loc(#loc42)
    %direct_a_host_7_cons_cons_lock_0 = aie.lock(%mem_tile_7_1, 9) {init = 0 : i32, sym_name = "direct_a_host_7_cons_cons_lock_0"} loc(#loc42)
    %direct_w_host_7_prod_lock_0 = aie.lock(%shim_noc_tile_7_0, 2) {init = 0 : i32, sym_name = "direct_w_host_7_prod_lock_0"} loc(#loc43)
    %direct_w_host_7_cons_lock_0 = aie.lock(%shim_noc_tile_7_0, 3) {init = 0 : i32, sym_name = "direct_w_host_7_cons_lock_0"} loc(#loc43)
    %direct_w_broadcast_7_0_cons_buff_0 = aie.buffer(%tile_7_2) {address = 10240 : i32, sym_name = "direct_w_broadcast_7_0_cons_buff_0"} : memref<4352xui8>  loc(#loc44)
    %direct_w_broadcast_7_0_cons_buff_1 = aie.buffer(%tile_7_2) {address = 14592 : i32, sym_name = "direct_w_broadcast_7_0_cons_buff_1"} : memref<4352xui8>  loc(#loc44)
    %direct_w_broadcast_7_0_cons_prod_lock_0 = aie.lock(%tile_7_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_7_0_cons_prod_lock_0"} loc(#loc44)
    %direct_w_broadcast_7_0_cons_cons_lock_0 = aie.lock(%tile_7_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_7_0_cons_cons_lock_0"} loc(#loc44)
    %direct_w_broadcast_7_1_cons_buff_0 = aie.buffer(%tile_7_3) {address = 10240 : i32, sym_name = "direct_w_broadcast_7_1_cons_buff_0"} : memref<4352xui8>  loc(#loc44)
    %direct_w_broadcast_7_1_cons_buff_1 = aie.buffer(%tile_7_3) {address = 14592 : i32, sym_name = "direct_w_broadcast_7_1_cons_buff_1"} : memref<4352xui8>  loc(#loc44)
    %direct_w_broadcast_7_1_cons_prod_lock_0 = aie.lock(%tile_7_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_7_1_cons_prod_lock_0"} loc(#loc44)
    %direct_w_broadcast_7_1_cons_cons_lock_0 = aie.lock(%tile_7_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_7_1_cons_cons_lock_0"} loc(#loc44)
    %direct_w_broadcast_7_2_cons_buff_0 = aie.buffer(%tile_7_4) {address = 10240 : i32, sym_name = "direct_w_broadcast_7_2_cons_buff_0"} : memref<4352xui8>  loc(#loc44)
    %direct_w_broadcast_7_2_cons_buff_1 = aie.buffer(%tile_7_4) {address = 14592 : i32, sym_name = "direct_w_broadcast_7_2_cons_buff_1"} : memref<4352xui8>  loc(#loc44)
    %direct_w_broadcast_7_2_cons_prod_lock_0 = aie.lock(%tile_7_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_7_2_cons_prod_lock_0"} loc(#loc44)
    %direct_w_broadcast_7_2_cons_cons_lock_0 = aie.lock(%tile_7_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_7_2_cons_cons_lock_0"} loc(#loc44)
    %direct_w_broadcast_7_3_cons_buff_0 = aie.buffer(%tile_7_5) {address = 10240 : i32, sym_name = "direct_w_broadcast_7_3_cons_buff_0"} : memref<4352xui8>  loc(#loc44)
    %direct_w_broadcast_7_3_cons_buff_1 = aie.buffer(%tile_7_5) {address = 14592 : i32, sym_name = "direct_w_broadcast_7_3_cons_buff_1"} : memref<4352xui8>  loc(#loc44)
    %direct_w_broadcast_7_3_cons_prod_lock_0 = aie.lock(%tile_7_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_7_3_cons_prod_lock_0"} loc(#loc44)
    %direct_w_broadcast_7_3_cons_cons_lock_0 = aie.lock(%tile_7_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_7_3_cons_cons_lock_0"} loc(#loc44)
    %direct_a_host_6_cons_buff_0 = aie.buffer(%mem_tile_6_1) {address = 16896 : i32, sym_name = "direct_a_host_6_cons_buff_0"} : memref<2048xbf16>  loc(#loc45)
    %direct_a_host_6_cons_buff_1 = aie.buffer(%mem_tile_6_1) {address = 20992 : i32, sym_name = "direct_a_host_6_cons_buff_1"} : memref<2048xbf16>  loc(#loc45)
    %direct_a_host_6_cons_prod_lock_0 = aie.lock(%mem_tile_6_1, 8) {init = 2 : i32, sym_name = "direct_a_host_6_cons_prod_lock_0"} loc(#loc45)
    %direct_a_host_6_cons_cons_lock_0 = aie.lock(%mem_tile_6_1, 9) {init = 0 : i32, sym_name = "direct_a_host_6_cons_cons_lock_0"} loc(#loc45)
    %direct_w_host_6_prod_lock_0 = aie.lock(%shim_noc_tile_6_0, 2) {init = 0 : i32, sym_name = "direct_w_host_6_prod_lock_0"} loc(#loc46)
    %direct_w_host_6_cons_lock_0 = aie.lock(%shim_noc_tile_6_0, 3) {init = 0 : i32, sym_name = "direct_w_host_6_cons_lock_0"} loc(#loc46)
    %direct_w_broadcast_6_0_cons_buff_0 = aie.buffer(%tile_6_2) {address = 10240 : i32, sym_name = "direct_w_broadcast_6_0_cons_buff_0"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_6_0_cons_buff_1 = aie.buffer(%tile_6_2) {address = 14592 : i32, sym_name = "direct_w_broadcast_6_0_cons_buff_1"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_6_0_cons_prod_lock_0 = aie.lock(%tile_6_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_6_0_cons_prod_lock_0"} loc(#loc47)
    %direct_w_broadcast_6_0_cons_cons_lock_0 = aie.lock(%tile_6_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_6_0_cons_cons_lock_0"} loc(#loc47)
    %direct_w_broadcast_6_1_cons_buff_0 = aie.buffer(%tile_6_3) {address = 10240 : i32, sym_name = "direct_w_broadcast_6_1_cons_buff_0"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_6_1_cons_buff_1 = aie.buffer(%tile_6_3) {address = 14592 : i32, sym_name = "direct_w_broadcast_6_1_cons_buff_1"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_6_1_cons_prod_lock_0 = aie.lock(%tile_6_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_6_1_cons_prod_lock_0"} loc(#loc47)
    %direct_w_broadcast_6_1_cons_cons_lock_0 = aie.lock(%tile_6_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_6_1_cons_cons_lock_0"} loc(#loc47)
    %direct_w_broadcast_6_2_cons_buff_0 = aie.buffer(%tile_6_4) {address = 10240 : i32, sym_name = "direct_w_broadcast_6_2_cons_buff_0"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_6_2_cons_buff_1 = aie.buffer(%tile_6_4) {address = 14592 : i32, sym_name = "direct_w_broadcast_6_2_cons_buff_1"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_6_2_cons_prod_lock_0 = aie.lock(%tile_6_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_6_2_cons_prod_lock_0"} loc(#loc47)
    %direct_w_broadcast_6_2_cons_cons_lock_0 = aie.lock(%tile_6_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_6_2_cons_cons_lock_0"} loc(#loc47)
    %direct_w_broadcast_6_3_cons_buff_0 = aie.buffer(%tile_6_5) {address = 10240 : i32, sym_name = "direct_w_broadcast_6_3_cons_buff_0"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_6_3_cons_buff_1 = aie.buffer(%tile_6_5) {address = 14592 : i32, sym_name = "direct_w_broadcast_6_3_cons_buff_1"} : memref<4352xui8>  loc(#loc47)
    %direct_w_broadcast_6_3_cons_prod_lock_0 = aie.lock(%tile_6_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_6_3_cons_prod_lock_0"} loc(#loc47)
    %direct_w_broadcast_6_3_cons_cons_lock_0 = aie.lock(%tile_6_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_6_3_cons_cons_lock_0"} loc(#loc47)
    %direct_a_host_5_cons_buff_0 = aie.buffer(%mem_tile_5_1) {address = 16896 : i32, sym_name = "direct_a_host_5_cons_buff_0"} : memref<2048xbf16>  loc(#loc48)
    %direct_a_host_5_cons_buff_1 = aie.buffer(%mem_tile_5_1) {address = 20992 : i32, sym_name = "direct_a_host_5_cons_buff_1"} : memref<2048xbf16>  loc(#loc48)
    %direct_a_host_5_cons_prod_lock_0 = aie.lock(%mem_tile_5_1, 8) {init = 2 : i32, sym_name = "direct_a_host_5_cons_prod_lock_0"} loc(#loc48)
    %direct_a_host_5_cons_cons_lock_0 = aie.lock(%mem_tile_5_1, 9) {init = 0 : i32, sym_name = "direct_a_host_5_cons_cons_lock_0"} loc(#loc48)
    %direct_w_host_5_prod_lock_0 = aie.lock(%shim_noc_tile_5_0, 2) {init = 0 : i32, sym_name = "direct_w_host_5_prod_lock_0"} loc(#loc49)
    %direct_w_host_5_cons_lock_0 = aie.lock(%shim_noc_tile_5_0, 3) {init = 0 : i32, sym_name = "direct_w_host_5_cons_lock_0"} loc(#loc49)
    %direct_w_broadcast_5_0_cons_buff_0 = aie.buffer(%tile_5_2) {address = 10240 : i32, sym_name = "direct_w_broadcast_5_0_cons_buff_0"} : memref<4352xui8>  loc(#loc50)
    %direct_w_broadcast_5_0_cons_buff_1 = aie.buffer(%tile_5_2) {address = 14592 : i32, sym_name = "direct_w_broadcast_5_0_cons_buff_1"} : memref<4352xui8>  loc(#loc50)
    %direct_w_broadcast_5_0_cons_prod_lock_0 = aie.lock(%tile_5_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_5_0_cons_prod_lock_0"} loc(#loc50)
    %direct_w_broadcast_5_0_cons_cons_lock_0 = aie.lock(%tile_5_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_5_0_cons_cons_lock_0"} loc(#loc50)
    %direct_w_broadcast_5_1_cons_buff_0 = aie.buffer(%tile_5_3) {address = 10240 : i32, sym_name = "direct_w_broadcast_5_1_cons_buff_0"} : memref<4352xui8>  loc(#loc50)
    %direct_w_broadcast_5_1_cons_buff_1 = aie.buffer(%tile_5_3) {address = 14592 : i32, sym_name = "direct_w_broadcast_5_1_cons_buff_1"} : memref<4352xui8>  loc(#loc50)
    %direct_w_broadcast_5_1_cons_prod_lock_0 = aie.lock(%tile_5_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_5_1_cons_prod_lock_0"} loc(#loc50)
    %direct_w_broadcast_5_1_cons_cons_lock_0 = aie.lock(%tile_5_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_5_1_cons_cons_lock_0"} loc(#loc50)
    %direct_w_broadcast_5_2_cons_buff_0 = aie.buffer(%tile_5_4) {address = 10240 : i32, sym_name = "direct_w_broadcast_5_2_cons_buff_0"} : memref<4352xui8>  loc(#loc50)
    %direct_w_broadcast_5_2_cons_buff_1 = aie.buffer(%tile_5_4) {address = 14592 : i32, sym_name = "direct_w_broadcast_5_2_cons_buff_1"} : memref<4352xui8>  loc(#loc50)
    %direct_w_broadcast_5_2_cons_prod_lock_0 = aie.lock(%tile_5_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_5_2_cons_prod_lock_0"} loc(#loc50)
    %direct_w_broadcast_5_2_cons_cons_lock_0 = aie.lock(%tile_5_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_5_2_cons_cons_lock_0"} loc(#loc50)
    %direct_w_broadcast_5_3_cons_buff_0 = aie.buffer(%tile_5_5) {address = 10240 : i32, sym_name = "direct_w_broadcast_5_3_cons_buff_0"} : memref<4352xui8>  loc(#loc50)
    %direct_w_broadcast_5_3_cons_buff_1 = aie.buffer(%tile_5_5) {address = 14592 : i32, sym_name = "direct_w_broadcast_5_3_cons_buff_1"} : memref<4352xui8>  loc(#loc50)
    %direct_w_broadcast_5_3_cons_prod_lock_0 = aie.lock(%tile_5_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_5_3_cons_prod_lock_0"} loc(#loc50)
    %direct_w_broadcast_5_3_cons_cons_lock_0 = aie.lock(%tile_5_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_5_3_cons_cons_lock_0"} loc(#loc50)
    %direct_a_host_4_cons_buff_0 = aie.buffer(%mem_tile_4_1) {address = 16896 : i32, sym_name = "direct_a_host_4_cons_buff_0"} : memref<2048xbf16>  loc(#loc51)
    %direct_a_host_4_cons_buff_1 = aie.buffer(%mem_tile_4_1) {address = 20992 : i32, sym_name = "direct_a_host_4_cons_buff_1"} : memref<2048xbf16>  loc(#loc51)
    %direct_a_host_4_cons_prod_lock_0 = aie.lock(%mem_tile_4_1, 8) {init = 2 : i32, sym_name = "direct_a_host_4_cons_prod_lock_0"} loc(#loc51)
    %direct_a_host_4_cons_cons_lock_0 = aie.lock(%mem_tile_4_1, 9) {init = 0 : i32, sym_name = "direct_a_host_4_cons_cons_lock_0"} loc(#loc51)
    %direct_w_host_4_prod_lock_0 = aie.lock(%shim_noc_tile_4_0, 2) {init = 0 : i32, sym_name = "direct_w_host_4_prod_lock_0"} loc(#loc52)
    %direct_w_host_4_cons_lock_0 = aie.lock(%shim_noc_tile_4_0, 3) {init = 0 : i32, sym_name = "direct_w_host_4_cons_lock_0"} loc(#loc52)
    %direct_w_broadcast_4_0_cons_buff_0 = aie.buffer(%tile_4_2) {address = 10240 : i32, sym_name = "direct_w_broadcast_4_0_cons_buff_0"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_0_cons_buff_1 = aie.buffer(%tile_4_2) {address = 14592 : i32, sym_name = "direct_w_broadcast_4_0_cons_buff_1"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_0_cons_prod_lock_0 = aie.lock(%tile_4_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_4_0_cons_prod_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_0_cons_cons_lock_0 = aie.lock(%tile_4_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_4_0_cons_cons_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_1_cons_buff_0 = aie.buffer(%tile_4_3) {address = 10240 : i32, sym_name = "direct_w_broadcast_4_1_cons_buff_0"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_1_cons_buff_1 = aie.buffer(%tile_4_3) {address = 14592 : i32, sym_name = "direct_w_broadcast_4_1_cons_buff_1"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_1_cons_prod_lock_0 = aie.lock(%tile_4_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_4_1_cons_prod_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_1_cons_cons_lock_0 = aie.lock(%tile_4_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_4_1_cons_cons_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_2_cons_buff_0 = aie.buffer(%tile_4_4) {address = 10240 : i32, sym_name = "direct_w_broadcast_4_2_cons_buff_0"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_2_cons_buff_1 = aie.buffer(%tile_4_4) {address = 14592 : i32, sym_name = "direct_w_broadcast_4_2_cons_buff_1"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_2_cons_prod_lock_0 = aie.lock(%tile_4_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_4_2_cons_prod_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_2_cons_cons_lock_0 = aie.lock(%tile_4_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_4_2_cons_cons_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_3_cons_buff_0 = aie.buffer(%tile_4_5) {address = 10240 : i32, sym_name = "direct_w_broadcast_4_3_cons_buff_0"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_3_cons_buff_1 = aie.buffer(%tile_4_5) {address = 14592 : i32, sym_name = "direct_w_broadcast_4_3_cons_buff_1"} : memref<4352xui8>  loc(#loc53)
    %direct_w_broadcast_4_3_cons_prod_lock_0 = aie.lock(%tile_4_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_4_3_cons_prod_lock_0"} loc(#loc53)
    %direct_w_broadcast_4_3_cons_cons_lock_0 = aie.lock(%tile_4_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_4_3_cons_cons_lock_0"} loc(#loc53)
    %direct_a_host_3_cons_buff_0 = aie.buffer(%mem_tile_3_1) {address = 16896 : i32, sym_name = "direct_a_host_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc54)
    %direct_a_host_3_cons_buff_1 = aie.buffer(%mem_tile_3_1) {address = 20992 : i32, sym_name = "direct_a_host_3_cons_buff_1"} : memref<2048xbf16>  loc(#loc54)
    %direct_a_host_3_cons_prod_lock_0 = aie.lock(%mem_tile_3_1, 8) {init = 2 : i32, sym_name = "direct_a_host_3_cons_prod_lock_0"} loc(#loc54)
    %direct_a_host_3_cons_cons_lock_0 = aie.lock(%mem_tile_3_1, 9) {init = 0 : i32, sym_name = "direct_a_host_3_cons_cons_lock_0"} loc(#loc54)
    %direct_w_host_3_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 2) {init = 0 : i32, sym_name = "direct_w_host_3_prod_lock_0"} loc(#loc55)
    %direct_w_host_3_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 3) {init = 0 : i32, sym_name = "direct_w_host_3_cons_lock_0"} loc(#loc55)
    %direct_w_broadcast_3_0_cons_buff_0 = aie.buffer(%tile_3_2) {address = 10240 : i32, sym_name = "direct_w_broadcast_3_0_cons_buff_0"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_3_0_cons_buff_1 = aie.buffer(%tile_3_2) {address = 14592 : i32, sym_name = "direct_w_broadcast_3_0_cons_buff_1"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_3_0_cons_prod_lock_0 = aie.lock(%tile_3_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_3_0_cons_prod_lock_0"} loc(#loc56)
    %direct_w_broadcast_3_0_cons_cons_lock_0 = aie.lock(%tile_3_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_3_0_cons_cons_lock_0"} loc(#loc56)
    %direct_w_broadcast_3_1_cons_buff_0 = aie.buffer(%tile_3_3) {address = 10240 : i32, sym_name = "direct_w_broadcast_3_1_cons_buff_0"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_3_1_cons_buff_1 = aie.buffer(%tile_3_3) {address = 14592 : i32, sym_name = "direct_w_broadcast_3_1_cons_buff_1"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_3_1_cons_prod_lock_0 = aie.lock(%tile_3_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_3_1_cons_prod_lock_0"} loc(#loc56)
    %direct_w_broadcast_3_1_cons_cons_lock_0 = aie.lock(%tile_3_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_3_1_cons_cons_lock_0"} loc(#loc56)
    %direct_w_broadcast_3_2_cons_buff_0 = aie.buffer(%tile_3_4) {address = 10240 : i32, sym_name = "direct_w_broadcast_3_2_cons_buff_0"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_3_2_cons_buff_1 = aie.buffer(%tile_3_4) {address = 14592 : i32, sym_name = "direct_w_broadcast_3_2_cons_buff_1"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_3_2_cons_prod_lock_0 = aie.lock(%tile_3_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_3_2_cons_prod_lock_0"} loc(#loc56)
    %direct_w_broadcast_3_2_cons_cons_lock_0 = aie.lock(%tile_3_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_3_2_cons_cons_lock_0"} loc(#loc56)
    %direct_w_broadcast_3_3_cons_buff_0 = aie.buffer(%tile_3_5) {address = 10240 : i32, sym_name = "direct_w_broadcast_3_3_cons_buff_0"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_3_3_cons_buff_1 = aie.buffer(%tile_3_5) {address = 14592 : i32, sym_name = "direct_w_broadcast_3_3_cons_buff_1"} : memref<4352xui8>  loc(#loc56)
    %direct_w_broadcast_3_3_cons_prod_lock_0 = aie.lock(%tile_3_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_3_3_cons_prod_lock_0"} loc(#loc56)
    %direct_w_broadcast_3_3_cons_cons_lock_0 = aie.lock(%tile_3_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_3_3_cons_cons_lock_0"} loc(#loc56)
    %direct_a_host_2_cons_buff_0 = aie.buffer(%mem_tile_2_1) {address = 16896 : i32, sym_name = "direct_a_host_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc57)
    %direct_a_host_2_cons_buff_1 = aie.buffer(%mem_tile_2_1) {address = 20992 : i32, sym_name = "direct_a_host_2_cons_buff_1"} : memref<2048xbf16>  loc(#loc57)
    %direct_a_host_2_cons_prod_lock_0 = aie.lock(%mem_tile_2_1, 8) {init = 2 : i32, sym_name = "direct_a_host_2_cons_prod_lock_0"} loc(#loc57)
    %direct_a_host_2_cons_cons_lock_0 = aie.lock(%mem_tile_2_1, 9) {init = 0 : i32, sym_name = "direct_a_host_2_cons_cons_lock_0"} loc(#loc57)
    %direct_w_host_2_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 2) {init = 0 : i32, sym_name = "direct_w_host_2_prod_lock_0"} loc(#loc58)
    %direct_w_host_2_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 3) {init = 0 : i32, sym_name = "direct_w_host_2_cons_lock_0"} loc(#loc58)
    %direct_w_broadcast_2_0_cons_buff_0 = aie.buffer(%tile_2_2) {address = 10240 : i32, sym_name = "direct_w_broadcast_2_0_cons_buff_0"} : memref<4352xui8>  loc(#loc59)
    %direct_w_broadcast_2_0_cons_buff_1 = aie.buffer(%tile_2_2) {address = 14592 : i32, sym_name = "direct_w_broadcast_2_0_cons_buff_1"} : memref<4352xui8>  loc(#loc59)
    %direct_w_broadcast_2_0_cons_prod_lock_0 = aie.lock(%tile_2_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_2_0_cons_prod_lock_0"} loc(#loc59)
    %direct_w_broadcast_2_0_cons_cons_lock_0 = aie.lock(%tile_2_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_2_0_cons_cons_lock_0"} loc(#loc59)
    %direct_w_broadcast_2_1_cons_buff_0 = aie.buffer(%tile_2_3) {address = 10240 : i32, sym_name = "direct_w_broadcast_2_1_cons_buff_0"} : memref<4352xui8>  loc(#loc59)
    %direct_w_broadcast_2_1_cons_buff_1 = aie.buffer(%tile_2_3) {address = 14592 : i32, sym_name = "direct_w_broadcast_2_1_cons_buff_1"} : memref<4352xui8>  loc(#loc59)
    %direct_w_broadcast_2_1_cons_prod_lock_0 = aie.lock(%tile_2_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_2_1_cons_prod_lock_0"} loc(#loc59)
    %direct_w_broadcast_2_1_cons_cons_lock_0 = aie.lock(%tile_2_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_2_1_cons_cons_lock_0"} loc(#loc59)
    %direct_w_broadcast_2_2_cons_buff_0 = aie.buffer(%tile_2_4) {address = 10240 : i32, sym_name = "direct_w_broadcast_2_2_cons_buff_0"} : memref<4352xui8>  loc(#loc59)
    %direct_w_broadcast_2_2_cons_buff_1 = aie.buffer(%tile_2_4) {address = 14592 : i32, sym_name = "direct_w_broadcast_2_2_cons_buff_1"} : memref<4352xui8>  loc(#loc59)
    %direct_w_broadcast_2_2_cons_prod_lock_0 = aie.lock(%tile_2_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_2_2_cons_prod_lock_0"} loc(#loc59)
    %direct_w_broadcast_2_2_cons_cons_lock_0 = aie.lock(%tile_2_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_2_2_cons_cons_lock_0"} loc(#loc59)
    %direct_w_broadcast_2_3_cons_buff_0 = aie.buffer(%tile_2_5) {address = 10240 : i32, sym_name = "direct_w_broadcast_2_3_cons_buff_0"} : memref<4352xui8>  loc(#loc59)
    %direct_w_broadcast_2_3_cons_buff_1 = aie.buffer(%tile_2_5) {address = 14592 : i32, sym_name = "direct_w_broadcast_2_3_cons_buff_1"} : memref<4352xui8>  loc(#loc59)
    %direct_w_broadcast_2_3_cons_prod_lock_0 = aie.lock(%tile_2_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_2_3_cons_prod_lock_0"} loc(#loc59)
    %direct_w_broadcast_2_3_cons_cons_lock_0 = aie.lock(%tile_2_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_2_3_cons_cons_lock_0"} loc(#loc59)
    %direct_a_host_1_cons_buff_0 = aie.buffer(%mem_tile_1_1) {address = 16896 : i32, sym_name = "direct_a_host_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc60)
    %direct_a_host_1_cons_buff_1 = aie.buffer(%mem_tile_1_1) {address = 20992 : i32, sym_name = "direct_a_host_1_cons_buff_1"} : memref<2048xbf16>  loc(#loc60)
    %direct_a_host_1_cons_prod_lock_0 = aie.lock(%mem_tile_1_1, 8) {init = 2 : i32, sym_name = "direct_a_host_1_cons_prod_lock_0"} loc(#loc60)
    %direct_a_host_1_cons_cons_lock_0 = aie.lock(%mem_tile_1_1, 9) {init = 0 : i32, sym_name = "direct_a_host_1_cons_cons_lock_0"} loc(#loc60)
    %direct_w_host_1_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 2) {init = 0 : i32, sym_name = "direct_w_host_1_prod_lock_0"} loc(#loc61)
    %direct_w_host_1_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 3) {init = 0 : i32, sym_name = "direct_w_host_1_cons_lock_0"} loc(#loc61)
    %direct_w_broadcast_1_0_cons_buff_0 = aie.buffer(%tile_1_2) {address = 10240 : i32, sym_name = "direct_w_broadcast_1_0_cons_buff_0"} : memref<4352xui8>  loc(#loc62)
    %direct_w_broadcast_1_0_cons_buff_1 = aie.buffer(%tile_1_2) {address = 14592 : i32, sym_name = "direct_w_broadcast_1_0_cons_buff_1"} : memref<4352xui8>  loc(#loc62)
    %direct_w_broadcast_1_0_cons_prod_lock_0 = aie.lock(%tile_1_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_1_0_cons_prod_lock_0"} loc(#loc62)
    %direct_w_broadcast_1_0_cons_cons_lock_0 = aie.lock(%tile_1_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_1_0_cons_cons_lock_0"} loc(#loc62)
    %direct_w_broadcast_1_1_cons_buff_0 = aie.buffer(%tile_1_3) {address = 10240 : i32, sym_name = "direct_w_broadcast_1_1_cons_buff_0"} : memref<4352xui8>  loc(#loc62)
    %direct_w_broadcast_1_1_cons_buff_1 = aie.buffer(%tile_1_3) {address = 14592 : i32, sym_name = "direct_w_broadcast_1_1_cons_buff_1"} : memref<4352xui8>  loc(#loc62)
    %direct_w_broadcast_1_1_cons_prod_lock_0 = aie.lock(%tile_1_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_1_1_cons_prod_lock_0"} loc(#loc62)
    %direct_w_broadcast_1_1_cons_cons_lock_0 = aie.lock(%tile_1_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_1_1_cons_cons_lock_0"} loc(#loc62)
    %direct_w_broadcast_1_2_cons_buff_0 = aie.buffer(%tile_1_4) {address = 10240 : i32, sym_name = "direct_w_broadcast_1_2_cons_buff_0"} : memref<4352xui8>  loc(#loc62)
    %direct_w_broadcast_1_2_cons_buff_1 = aie.buffer(%tile_1_4) {address = 14592 : i32, sym_name = "direct_w_broadcast_1_2_cons_buff_1"} : memref<4352xui8>  loc(#loc62)
    %direct_w_broadcast_1_2_cons_prod_lock_0 = aie.lock(%tile_1_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_1_2_cons_prod_lock_0"} loc(#loc62)
    %direct_w_broadcast_1_2_cons_cons_lock_0 = aie.lock(%tile_1_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_1_2_cons_cons_lock_0"} loc(#loc62)
    %direct_w_broadcast_1_3_cons_buff_0 = aie.buffer(%tile_1_5) {address = 10240 : i32, sym_name = "direct_w_broadcast_1_3_cons_buff_0"} : memref<4352xui8>  loc(#loc62)
    %direct_w_broadcast_1_3_cons_buff_1 = aie.buffer(%tile_1_5) {address = 14592 : i32, sym_name = "direct_w_broadcast_1_3_cons_buff_1"} : memref<4352xui8>  loc(#loc62)
    %direct_w_broadcast_1_3_cons_prod_lock_0 = aie.lock(%tile_1_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_1_3_cons_prod_lock_0"} loc(#loc62)
    %direct_w_broadcast_1_3_cons_cons_lock_0 = aie.lock(%tile_1_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_1_3_cons_cons_lock_0"} loc(#loc62)
    %direct_a_host_0_cons_buff_0 = aie.buffer(%mem_tile_0_1) {address = 16896 : i32, sym_name = "direct_a_host_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc63)
    %direct_a_host_0_cons_buff_1 = aie.buffer(%mem_tile_0_1) {address = 20992 : i32, sym_name = "direct_a_host_0_cons_buff_1"} : memref<2048xbf16>  loc(#loc63)
    %direct_a_host_0_cons_prod_lock_0 = aie.lock(%mem_tile_0_1, 8) {init = 2 : i32, sym_name = "direct_a_host_0_cons_prod_lock_0"} loc(#loc63)
    %direct_a_host_0_cons_cons_lock_0 = aie.lock(%mem_tile_0_1, 9) {init = 0 : i32, sym_name = "direct_a_host_0_cons_cons_lock_0"} loc(#loc63)
    %direct_w_host_0_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 2) {init = 0 : i32, sym_name = "direct_w_host_0_prod_lock_0"} loc(#loc64)
    %direct_w_host_0_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 3) {init = 0 : i32, sym_name = "direct_w_host_0_cons_lock_0"} loc(#loc64)
    %direct_w_broadcast_0_0_cons_buff_0 = aie.buffer(%tile_0_2) {address = 10240 : i32, sym_name = "direct_w_broadcast_0_0_cons_buff_0"} : memref<4352xui8>  loc(#loc65)
    %direct_w_broadcast_0_0_cons_buff_1 = aie.buffer(%tile_0_2) {address = 14592 : i32, sym_name = "direct_w_broadcast_0_0_cons_buff_1"} : memref<4352xui8>  loc(#loc65)
    %direct_w_broadcast_0_0_cons_prod_lock_0 = aie.lock(%tile_0_2, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_0_0_cons_prod_lock_0"} loc(#loc65)
    %direct_w_broadcast_0_0_cons_cons_lock_0 = aie.lock(%tile_0_2, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_0_0_cons_cons_lock_0"} loc(#loc65)
    %direct_w_broadcast_0_1_cons_buff_0 = aie.buffer(%tile_0_3) {address = 10240 : i32, sym_name = "direct_w_broadcast_0_1_cons_buff_0"} : memref<4352xui8>  loc(#loc65)
    %direct_w_broadcast_0_1_cons_buff_1 = aie.buffer(%tile_0_3) {address = 14592 : i32, sym_name = "direct_w_broadcast_0_1_cons_buff_1"} : memref<4352xui8>  loc(#loc65)
    %direct_w_broadcast_0_1_cons_prod_lock_0 = aie.lock(%tile_0_3, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_0_1_cons_prod_lock_0"} loc(#loc65)
    %direct_w_broadcast_0_1_cons_cons_lock_0 = aie.lock(%tile_0_3, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_0_1_cons_cons_lock_0"} loc(#loc65)
    %direct_w_broadcast_0_2_cons_buff_0 = aie.buffer(%tile_0_4) {address = 10240 : i32, sym_name = "direct_w_broadcast_0_2_cons_buff_0"} : memref<4352xui8>  loc(#loc65)
    %direct_w_broadcast_0_2_cons_buff_1 = aie.buffer(%tile_0_4) {address = 14592 : i32, sym_name = "direct_w_broadcast_0_2_cons_buff_1"} : memref<4352xui8>  loc(#loc65)
    %direct_w_broadcast_0_2_cons_prod_lock_0 = aie.lock(%tile_0_4, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_0_2_cons_prod_lock_0"} loc(#loc65)
    %direct_w_broadcast_0_2_cons_cons_lock_0 = aie.lock(%tile_0_4, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_0_2_cons_cons_lock_0"} loc(#loc65)
    %direct_w_broadcast_0_3_cons_buff_0 = aie.buffer(%tile_0_5) {address = 10240 : i32, sym_name = "direct_w_broadcast_0_3_cons_buff_0"} : memref<4352xui8>  loc(#loc65)
    %direct_w_broadcast_0_3_cons_buff_1 = aie.buffer(%tile_0_5) {address = 14592 : i32, sym_name = "direct_w_broadcast_0_3_cons_buff_1"} : memref<4352xui8>  loc(#loc65)
    %direct_w_broadcast_0_3_cons_prod_lock_0 = aie.lock(%tile_0_5, 2) {init = 2 : i32, sym_name = "direct_w_broadcast_0_3_cons_prod_lock_0"} loc(#loc65)
    %direct_w_broadcast_0_3_cons_cons_lock_0 = aie.lock(%tile_0_5, 3) {init = 0 : i32, sym_name = "direct_w_broadcast_0_3_cons_cons_lock_0"} loc(#loc65)
    %direct_w_host_7_cons_buff_0 = aie.buffer(%mem_tile_7_1) {address = 0 : i32, sym_name = "direct_w_host_7_cons_buff_0"} : memref<4352xui8>  loc(#loc43)
    %direct_w_host_7_cons_buff_1 = aie.buffer(%mem_tile_7_1) {address = 4352 : i32, sym_name = "direct_w_host_7_cons_buff_1"} : memref<4352xui8>  loc(#loc43)
    %direct_w_host_7_cons_prod_lock_0 = aie.lock(%mem_tile_7_1, 10) {init = 2 : i32, sym_name = "direct_w_host_7_cons_prod_lock_0"} loc(#loc43)
    %direct_w_host_7_cons_cons_lock_0 = aie.lock(%mem_tile_7_1, 11) {init = 0 : i32, sym_name = "direct_w_host_7_cons_cons_lock_0"} loc(#loc43)
    %direct_a_host_7_prod_lock_0 = aie.lock(%shim_noc_tile_7_0, 4) {init = 0 : i32, sym_name = "direct_a_host_7_prod_lock_0"} loc(#loc42)
    %direct_a_host_7_cons_lock_0 = aie.lock(%shim_noc_tile_7_0, 5) {init = 0 : i32, sym_name = "direct_a_host_7_cons_lock_0"} loc(#loc42)
    %direct_a_broadcast_7_0_cons_buff_0 = aie.buffer(%tile_4_5) {address = 18944 : i32, sym_name = "direct_a_broadcast_7_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc66)
    %direct_a_broadcast_7_0_cons_prod_lock_0 = aie.lock(%tile_4_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_7_0_cons_prod_lock_0"} loc(#loc66)
    %direct_a_broadcast_7_0_cons_cons_lock_0 = aie.lock(%tile_4_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_7_0_cons_cons_lock_0"} loc(#loc66)
    %direct_a_broadcast_7_1_cons_buff_0 = aie.buffer(%tile_5_5) {address = 18944 : i32, sym_name = "direct_a_broadcast_7_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc66)
    %direct_a_broadcast_7_1_cons_prod_lock_0 = aie.lock(%tile_5_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_7_1_cons_prod_lock_0"} loc(#loc66)
    %direct_a_broadcast_7_1_cons_cons_lock_0 = aie.lock(%tile_5_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_7_1_cons_cons_lock_0"} loc(#loc66)
    %direct_a_broadcast_7_2_cons_buff_0 = aie.buffer(%tile_6_5) {address = 18944 : i32, sym_name = "direct_a_broadcast_7_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc66)
    %direct_a_broadcast_7_2_cons_prod_lock_0 = aie.lock(%tile_6_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_7_2_cons_prod_lock_0"} loc(#loc66)
    %direct_a_broadcast_7_2_cons_cons_lock_0 = aie.lock(%tile_6_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_7_2_cons_cons_lock_0"} loc(#loc66)
    %direct_a_broadcast_7_3_cons_buff_0 = aie.buffer(%tile_7_5) {address = 18944 : i32, sym_name = "direct_a_broadcast_7_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc66)
    %direct_a_broadcast_7_3_cons_prod_lock_0 = aie.lock(%tile_7_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_7_3_cons_prod_lock_0"} loc(#loc66)
    %direct_a_broadcast_7_3_cons_cons_lock_0 = aie.lock(%tile_7_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_7_3_cons_cons_lock_0"} loc(#loc66)
    %direct_w_host_6_cons_buff_0 = aie.buffer(%mem_tile_6_1) {address = 0 : i32, sym_name = "direct_w_host_6_cons_buff_0"} : memref<4352xui8>  loc(#loc46)
    %direct_w_host_6_cons_buff_1 = aie.buffer(%mem_tile_6_1) {address = 4352 : i32, sym_name = "direct_w_host_6_cons_buff_1"} : memref<4352xui8>  loc(#loc46)
    %direct_w_host_6_cons_prod_lock_0 = aie.lock(%mem_tile_6_1, 10) {init = 2 : i32, sym_name = "direct_w_host_6_cons_prod_lock_0"} loc(#loc46)
    %direct_w_host_6_cons_cons_lock_0 = aie.lock(%mem_tile_6_1, 11) {init = 0 : i32, sym_name = "direct_w_host_6_cons_cons_lock_0"} loc(#loc46)
    %direct_a_host_6_prod_lock_0 = aie.lock(%shim_noc_tile_6_0, 4) {init = 0 : i32, sym_name = "direct_a_host_6_prod_lock_0"} loc(#loc45)
    %direct_a_host_6_cons_lock_0 = aie.lock(%shim_noc_tile_6_0, 5) {init = 0 : i32, sym_name = "direct_a_host_6_cons_lock_0"} loc(#loc45)
    %direct_a_broadcast_6_0_cons_buff_0 = aie.buffer(%tile_4_4) {address = 18944 : i32, sym_name = "direct_a_broadcast_6_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc67)
    %direct_a_broadcast_6_0_cons_prod_lock_0 = aie.lock(%tile_4_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_6_0_cons_prod_lock_0"} loc(#loc67)
    %direct_a_broadcast_6_0_cons_cons_lock_0 = aie.lock(%tile_4_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_6_0_cons_cons_lock_0"} loc(#loc67)
    %direct_a_broadcast_6_1_cons_buff_0 = aie.buffer(%tile_5_4) {address = 18944 : i32, sym_name = "direct_a_broadcast_6_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc67)
    %direct_a_broadcast_6_1_cons_prod_lock_0 = aie.lock(%tile_5_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_6_1_cons_prod_lock_0"} loc(#loc67)
    %direct_a_broadcast_6_1_cons_cons_lock_0 = aie.lock(%tile_5_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_6_1_cons_cons_lock_0"} loc(#loc67)
    %direct_a_broadcast_6_2_cons_buff_0 = aie.buffer(%tile_6_4) {address = 18944 : i32, sym_name = "direct_a_broadcast_6_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc67)
    %direct_a_broadcast_6_2_cons_prod_lock_0 = aie.lock(%tile_6_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_6_2_cons_prod_lock_0"} loc(#loc67)
    %direct_a_broadcast_6_2_cons_cons_lock_0 = aie.lock(%tile_6_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_6_2_cons_cons_lock_0"} loc(#loc67)
    %direct_a_broadcast_6_3_cons_buff_0 = aie.buffer(%tile_7_4) {address = 18944 : i32, sym_name = "direct_a_broadcast_6_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc67)
    %direct_a_broadcast_6_3_cons_prod_lock_0 = aie.lock(%tile_7_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_6_3_cons_prod_lock_0"} loc(#loc67)
    %direct_a_broadcast_6_3_cons_cons_lock_0 = aie.lock(%tile_7_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_6_3_cons_cons_lock_0"} loc(#loc67)
    %direct_w_host_5_cons_buff_0 = aie.buffer(%mem_tile_5_1) {address = 0 : i32, sym_name = "direct_w_host_5_cons_buff_0"} : memref<4352xui8>  loc(#loc49)
    %direct_w_host_5_cons_buff_1 = aie.buffer(%mem_tile_5_1) {address = 4352 : i32, sym_name = "direct_w_host_5_cons_buff_1"} : memref<4352xui8>  loc(#loc49)
    %direct_w_host_5_cons_prod_lock_0 = aie.lock(%mem_tile_5_1, 10) {init = 2 : i32, sym_name = "direct_w_host_5_cons_prod_lock_0"} loc(#loc49)
    %direct_w_host_5_cons_cons_lock_0 = aie.lock(%mem_tile_5_1, 11) {init = 0 : i32, sym_name = "direct_w_host_5_cons_cons_lock_0"} loc(#loc49)
    %direct_a_host_5_prod_lock_0 = aie.lock(%shim_noc_tile_5_0, 4) {init = 0 : i32, sym_name = "direct_a_host_5_prod_lock_0"} loc(#loc48)
    %direct_a_host_5_cons_lock_0 = aie.lock(%shim_noc_tile_5_0, 5) {init = 0 : i32, sym_name = "direct_a_host_5_cons_lock_0"} loc(#loc48)
    %direct_a_broadcast_5_0_cons_buff_0 = aie.buffer(%tile_4_3) {address = 18944 : i32, sym_name = "direct_a_broadcast_5_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc68)
    %direct_a_broadcast_5_0_cons_prod_lock_0 = aie.lock(%tile_4_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_5_0_cons_prod_lock_0"} loc(#loc68)
    %direct_a_broadcast_5_0_cons_cons_lock_0 = aie.lock(%tile_4_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_5_0_cons_cons_lock_0"} loc(#loc68)
    %direct_a_broadcast_5_1_cons_buff_0 = aie.buffer(%tile_5_3) {address = 18944 : i32, sym_name = "direct_a_broadcast_5_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc68)
    %direct_a_broadcast_5_1_cons_prod_lock_0 = aie.lock(%tile_5_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_5_1_cons_prod_lock_0"} loc(#loc68)
    %direct_a_broadcast_5_1_cons_cons_lock_0 = aie.lock(%tile_5_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_5_1_cons_cons_lock_0"} loc(#loc68)
    %direct_a_broadcast_5_2_cons_buff_0 = aie.buffer(%tile_6_3) {address = 18944 : i32, sym_name = "direct_a_broadcast_5_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc68)
    %direct_a_broadcast_5_2_cons_prod_lock_0 = aie.lock(%tile_6_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_5_2_cons_prod_lock_0"} loc(#loc68)
    %direct_a_broadcast_5_2_cons_cons_lock_0 = aie.lock(%tile_6_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_5_2_cons_cons_lock_0"} loc(#loc68)
    %direct_a_broadcast_5_3_cons_buff_0 = aie.buffer(%tile_7_3) {address = 18944 : i32, sym_name = "direct_a_broadcast_5_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc68)
    %direct_a_broadcast_5_3_cons_prod_lock_0 = aie.lock(%tile_7_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_5_3_cons_prod_lock_0"} loc(#loc68)
    %direct_a_broadcast_5_3_cons_cons_lock_0 = aie.lock(%tile_7_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_5_3_cons_cons_lock_0"} loc(#loc68)
    %direct_w_host_4_cons_buff_0 = aie.buffer(%mem_tile_4_1) {address = 0 : i32, sym_name = "direct_w_host_4_cons_buff_0"} : memref<4352xui8>  loc(#loc52)
    %direct_w_host_4_cons_buff_1 = aie.buffer(%mem_tile_4_1) {address = 4352 : i32, sym_name = "direct_w_host_4_cons_buff_1"} : memref<4352xui8>  loc(#loc52)
    %direct_w_host_4_cons_prod_lock_0 = aie.lock(%mem_tile_4_1, 10) {init = 2 : i32, sym_name = "direct_w_host_4_cons_prod_lock_0"} loc(#loc52)
    %direct_w_host_4_cons_cons_lock_0 = aie.lock(%mem_tile_4_1, 11) {init = 0 : i32, sym_name = "direct_w_host_4_cons_cons_lock_0"} loc(#loc52)
    %direct_a_host_4_prod_lock_0 = aie.lock(%shim_noc_tile_4_0, 4) {init = 0 : i32, sym_name = "direct_a_host_4_prod_lock_0"} loc(#loc51)
    %direct_a_host_4_cons_lock_0 = aie.lock(%shim_noc_tile_4_0, 5) {init = 0 : i32, sym_name = "direct_a_host_4_cons_lock_0"} loc(#loc51)
    %direct_a_broadcast_4_0_cons_buff_0 = aie.buffer(%tile_4_2) {address = 18944 : i32, sym_name = "direct_a_broadcast_4_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc69)
    %direct_a_broadcast_4_0_cons_prod_lock_0 = aie.lock(%tile_4_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_4_0_cons_prod_lock_0"} loc(#loc69)
    %direct_a_broadcast_4_0_cons_cons_lock_0 = aie.lock(%tile_4_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_4_0_cons_cons_lock_0"} loc(#loc69)
    %direct_a_broadcast_4_1_cons_buff_0 = aie.buffer(%tile_5_2) {address = 18944 : i32, sym_name = "direct_a_broadcast_4_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc69)
    %direct_a_broadcast_4_1_cons_prod_lock_0 = aie.lock(%tile_5_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_4_1_cons_prod_lock_0"} loc(#loc69)
    %direct_a_broadcast_4_1_cons_cons_lock_0 = aie.lock(%tile_5_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_4_1_cons_cons_lock_0"} loc(#loc69)
    %direct_a_broadcast_4_2_cons_buff_0 = aie.buffer(%tile_6_2) {address = 18944 : i32, sym_name = "direct_a_broadcast_4_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc69)
    %direct_a_broadcast_4_2_cons_prod_lock_0 = aie.lock(%tile_6_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_4_2_cons_prod_lock_0"} loc(#loc69)
    %direct_a_broadcast_4_2_cons_cons_lock_0 = aie.lock(%tile_6_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_4_2_cons_cons_lock_0"} loc(#loc69)
    %direct_a_broadcast_4_3_cons_buff_0 = aie.buffer(%tile_7_2) {address = 18944 : i32, sym_name = "direct_a_broadcast_4_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc69)
    %direct_a_broadcast_4_3_cons_prod_lock_0 = aie.lock(%tile_7_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_4_3_cons_prod_lock_0"} loc(#loc69)
    %direct_a_broadcast_4_3_cons_cons_lock_0 = aie.lock(%tile_7_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_4_3_cons_cons_lock_0"} loc(#loc69)
    %direct_w_host_3_cons_buff_0 = aie.buffer(%mem_tile_3_1) {address = 0 : i32, sym_name = "direct_w_host_3_cons_buff_0"} : memref<4352xui8>  loc(#loc55)
    %direct_w_host_3_cons_buff_1 = aie.buffer(%mem_tile_3_1) {address = 4352 : i32, sym_name = "direct_w_host_3_cons_buff_1"} : memref<4352xui8>  loc(#loc55)
    %direct_w_host_3_cons_prod_lock_0 = aie.lock(%mem_tile_3_1, 10) {init = 2 : i32, sym_name = "direct_w_host_3_cons_prod_lock_0"} loc(#loc55)
    %direct_w_host_3_cons_cons_lock_0 = aie.lock(%mem_tile_3_1, 11) {init = 0 : i32, sym_name = "direct_w_host_3_cons_cons_lock_0"} loc(#loc55)
    %direct_a_host_3_prod_lock_0 = aie.lock(%shim_noc_tile_3_0, 4) {init = 0 : i32, sym_name = "direct_a_host_3_prod_lock_0"} loc(#loc54)
    %direct_a_host_3_cons_lock_0 = aie.lock(%shim_noc_tile_3_0, 5) {init = 0 : i32, sym_name = "direct_a_host_3_cons_lock_0"} loc(#loc54)
    %direct_a_broadcast_3_0_cons_buff_0 = aie.buffer(%tile_0_5) {address = 18944 : i32, sym_name = "direct_a_broadcast_3_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc70)
    %direct_a_broadcast_3_0_cons_prod_lock_0 = aie.lock(%tile_0_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_0_cons_prod_lock_0"} loc(#loc70)
    %direct_a_broadcast_3_0_cons_cons_lock_0 = aie.lock(%tile_0_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_0_cons_cons_lock_0"} loc(#loc70)
    %direct_a_broadcast_3_1_cons_buff_0 = aie.buffer(%tile_1_5) {address = 18944 : i32, sym_name = "direct_a_broadcast_3_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc70)
    %direct_a_broadcast_3_1_cons_prod_lock_0 = aie.lock(%tile_1_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_1_cons_prod_lock_0"} loc(#loc70)
    %direct_a_broadcast_3_1_cons_cons_lock_0 = aie.lock(%tile_1_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_1_cons_cons_lock_0"} loc(#loc70)
    %direct_a_broadcast_3_2_cons_buff_0 = aie.buffer(%tile_2_5) {address = 18944 : i32, sym_name = "direct_a_broadcast_3_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc70)
    %direct_a_broadcast_3_2_cons_prod_lock_0 = aie.lock(%tile_2_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_2_cons_prod_lock_0"} loc(#loc70)
    %direct_a_broadcast_3_2_cons_cons_lock_0 = aie.lock(%tile_2_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_2_cons_cons_lock_0"} loc(#loc70)
    %direct_a_broadcast_3_3_cons_buff_0 = aie.buffer(%tile_3_5) {address = 18944 : i32, sym_name = "direct_a_broadcast_3_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc70)
    %direct_a_broadcast_3_3_cons_prod_lock_0 = aie.lock(%tile_3_5, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_3_3_cons_prod_lock_0"} loc(#loc70)
    %direct_a_broadcast_3_3_cons_cons_lock_0 = aie.lock(%tile_3_5, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_3_3_cons_cons_lock_0"} loc(#loc70)
    %direct_w_host_2_cons_buff_0 = aie.buffer(%mem_tile_2_1) {address = 0 : i32, sym_name = "direct_w_host_2_cons_buff_0"} : memref<4352xui8>  loc(#loc58)
    %direct_w_host_2_cons_buff_1 = aie.buffer(%mem_tile_2_1) {address = 4352 : i32, sym_name = "direct_w_host_2_cons_buff_1"} : memref<4352xui8>  loc(#loc58)
    %direct_w_host_2_cons_prod_lock_0 = aie.lock(%mem_tile_2_1, 10) {init = 2 : i32, sym_name = "direct_w_host_2_cons_prod_lock_0"} loc(#loc58)
    %direct_w_host_2_cons_cons_lock_0 = aie.lock(%mem_tile_2_1, 11) {init = 0 : i32, sym_name = "direct_w_host_2_cons_cons_lock_0"} loc(#loc58)
    %direct_a_host_2_prod_lock_0 = aie.lock(%shim_noc_tile_2_0, 4) {init = 0 : i32, sym_name = "direct_a_host_2_prod_lock_0"} loc(#loc57)
    %direct_a_host_2_cons_lock_0 = aie.lock(%shim_noc_tile_2_0, 5) {init = 0 : i32, sym_name = "direct_a_host_2_cons_lock_0"} loc(#loc57)
    %direct_a_broadcast_2_0_cons_buff_0 = aie.buffer(%tile_0_4) {address = 18944 : i32, sym_name = "direct_a_broadcast_2_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc71)
    %direct_a_broadcast_2_0_cons_prod_lock_0 = aie.lock(%tile_0_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_0_cons_prod_lock_0"} loc(#loc71)
    %direct_a_broadcast_2_0_cons_cons_lock_0 = aie.lock(%tile_0_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_0_cons_cons_lock_0"} loc(#loc71)
    %direct_a_broadcast_2_1_cons_buff_0 = aie.buffer(%tile_1_4) {address = 18944 : i32, sym_name = "direct_a_broadcast_2_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc71)
    %direct_a_broadcast_2_1_cons_prod_lock_0 = aie.lock(%tile_1_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_1_cons_prod_lock_0"} loc(#loc71)
    %direct_a_broadcast_2_1_cons_cons_lock_0 = aie.lock(%tile_1_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_1_cons_cons_lock_0"} loc(#loc71)
    %direct_a_broadcast_2_2_cons_buff_0 = aie.buffer(%tile_2_4) {address = 18944 : i32, sym_name = "direct_a_broadcast_2_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc71)
    %direct_a_broadcast_2_2_cons_prod_lock_0 = aie.lock(%tile_2_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_2_cons_prod_lock_0"} loc(#loc71)
    %direct_a_broadcast_2_2_cons_cons_lock_0 = aie.lock(%tile_2_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_2_cons_cons_lock_0"} loc(#loc71)
    %direct_a_broadcast_2_3_cons_buff_0 = aie.buffer(%tile_3_4) {address = 18944 : i32, sym_name = "direct_a_broadcast_2_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc71)
    %direct_a_broadcast_2_3_cons_prod_lock_0 = aie.lock(%tile_3_4, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_2_3_cons_prod_lock_0"} loc(#loc71)
    %direct_a_broadcast_2_3_cons_cons_lock_0 = aie.lock(%tile_3_4, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_2_3_cons_cons_lock_0"} loc(#loc71)
    %direct_w_host_1_cons_buff_0 = aie.buffer(%mem_tile_1_1) {address = 0 : i32, sym_name = "direct_w_host_1_cons_buff_0"} : memref<4352xui8>  loc(#loc61)
    %direct_w_host_1_cons_buff_1 = aie.buffer(%mem_tile_1_1) {address = 4352 : i32, sym_name = "direct_w_host_1_cons_buff_1"} : memref<4352xui8>  loc(#loc61)
    %direct_w_host_1_cons_prod_lock_0 = aie.lock(%mem_tile_1_1, 10) {init = 2 : i32, sym_name = "direct_w_host_1_cons_prod_lock_0"} loc(#loc61)
    %direct_w_host_1_cons_cons_lock_0 = aie.lock(%mem_tile_1_1, 11) {init = 0 : i32, sym_name = "direct_w_host_1_cons_cons_lock_0"} loc(#loc61)
    %direct_a_host_1_prod_lock_0 = aie.lock(%shim_noc_tile_1_0, 4) {init = 0 : i32, sym_name = "direct_a_host_1_prod_lock_0"} loc(#loc60)
    %direct_a_host_1_cons_lock_0 = aie.lock(%shim_noc_tile_1_0, 5) {init = 0 : i32, sym_name = "direct_a_host_1_cons_lock_0"} loc(#loc60)
    %direct_a_broadcast_1_0_cons_buff_0 = aie.buffer(%tile_0_3) {address = 18944 : i32, sym_name = "direct_a_broadcast_1_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc72)
    %direct_a_broadcast_1_0_cons_prod_lock_0 = aie.lock(%tile_0_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_0_cons_prod_lock_0"} loc(#loc72)
    %direct_a_broadcast_1_0_cons_cons_lock_0 = aie.lock(%tile_0_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_0_cons_cons_lock_0"} loc(#loc72)
    %direct_a_broadcast_1_1_cons_buff_0 = aie.buffer(%tile_1_3) {address = 18944 : i32, sym_name = "direct_a_broadcast_1_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc72)
    %direct_a_broadcast_1_1_cons_prod_lock_0 = aie.lock(%tile_1_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_1_cons_prod_lock_0"} loc(#loc72)
    %direct_a_broadcast_1_1_cons_cons_lock_0 = aie.lock(%tile_1_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_1_cons_cons_lock_0"} loc(#loc72)
    %direct_a_broadcast_1_2_cons_buff_0 = aie.buffer(%tile_2_3) {address = 18944 : i32, sym_name = "direct_a_broadcast_1_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc72)
    %direct_a_broadcast_1_2_cons_prod_lock_0 = aie.lock(%tile_2_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_2_cons_prod_lock_0"} loc(#loc72)
    %direct_a_broadcast_1_2_cons_cons_lock_0 = aie.lock(%tile_2_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_2_cons_cons_lock_0"} loc(#loc72)
    %direct_a_broadcast_1_3_cons_buff_0 = aie.buffer(%tile_3_3) {address = 18944 : i32, sym_name = "direct_a_broadcast_1_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc72)
    %direct_a_broadcast_1_3_cons_prod_lock_0 = aie.lock(%tile_3_3, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_1_3_cons_prod_lock_0"} loc(#loc72)
    %direct_a_broadcast_1_3_cons_cons_lock_0 = aie.lock(%tile_3_3, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_1_3_cons_cons_lock_0"} loc(#loc72)
    %direct_w_host_0_cons_buff_0 = aie.buffer(%mem_tile_0_1) {address = 0 : i32, sym_name = "direct_w_host_0_cons_buff_0"} : memref<4352xui8>  loc(#loc64)
    %direct_w_host_0_cons_buff_1 = aie.buffer(%mem_tile_0_1) {address = 4352 : i32, sym_name = "direct_w_host_0_cons_buff_1"} : memref<4352xui8>  loc(#loc64)
    %direct_w_host_0_cons_prod_lock_0 = aie.lock(%mem_tile_0_1, 10) {init = 2 : i32, sym_name = "direct_w_host_0_cons_prod_lock_0"} loc(#loc64)
    %direct_w_host_0_cons_cons_lock_0 = aie.lock(%mem_tile_0_1, 11) {init = 0 : i32, sym_name = "direct_w_host_0_cons_cons_lock_0"} loc(#loc64)
    %direct_a_host_0_prod_lock_0 = aie.lock(%shim_noc_tile_0_0, 4) {init = 0 : i32, sym_name = "direct_a_host_0_prod_lock_0"} loc(#loc63)
    %direct_a_host_0_cons_lock_0 = aie.lock(%shim_noc_tile_0_0, 5) {init = 0 : i32, sym_name = "direct_a_host_0_cons_lock_0"} loc(#loc63)
    %direct_a_broadcast_0_0_cons_buff_0 = aie.buffer(%tile_0_2) {address = 18944 : i32, sym_name = "direct_a_broadcast_0_0_cons_buff_0"} : memref<2048xbf16>  loc(#loc73)
    %direct_a_broadcast_0_0_cons_prod_lock_0 = aie.lock(%tile_0_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_0_cons_prod_lock_0"} loc(#loc73)
    %direct_a_broadcast_0_0_cons_cons_lock_0 = aie.lock(%tile_0_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_0_cons_cons_lock_0"} loc(#loc73)
    %direct_a_broadcast_0_1_cons_buff_0 = aie.buffer(%tile_1_2) {address = 18944 : i32, sym_name = "direct_a_broadcast_0_1_cons_buff_0"} : memref<2048xbf16>  loc(#loc73)
    %direct_a_broadcast_0_1_cons_prod_lock_0 = aie.lock(%tile_1_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_1_cons_prod_lock_0"} loc(#loc73)
    %direct_a_broadcast_0_1_cons_cons_lock_0 = aie.lock(%tile_1_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_1_cons_cons_lock_0"} loc(#loc73)
    %direct_a_broadcast_0_2_cons_buff_0 = aie.buffer(%tile_2_2) {address = 18944 : i32, sym_name = "direct_a_broadcast_0_2_cons_buff_0"} : memref<2048xbf16>  loc(#loc73)
    %direct_a_broadcast_0_2_cons_prod_lock_0 = aie.lock(%tile_2_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_2_cons_prod_lock_0"} loc(#loc73)
    %direct_a_broadcast_0_2_cons_cons_lock_0 = aie.lock(%tile_2_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_2_cons_cons_lock_0"} loc(#loc73)
    %direct_a_broadcast_0_3_cons_buff_0 = aie.buffer(%tile_3_2) {address = 18944 : i32, sym_name = "direct_a_broadcast_0_3_cons_buff_0"} : memref<2048xbf16>  loc(#loc73)
    %direct_a_broadcast_0_3_cons_prod_lock_0 = aie.lock(%tile_3_2, 4) {init = 1 : i32, sym_name = "direct_a_broadcast_0_3_cons_prod_lock_0"} loc(#loc73)
    %direct_a_broadcast_0_3_cons_cons_lock_0 = aie.lock(%tile_3_2, 5) {init = 0 : i32, sym_name = "direct_a_broadcast_0_3_cons_cons_lock_0"} loc(#loc73)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_3_2, DMA : 0) loc(#loc73)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_2_2, DMA : 0) loc(#loc73)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_1_2, DMA : 0) loc(#loc73)
    aie.flow(%mem_tile_0_1, DMA : 0, %tile_0_2, DMA : 0) loc(#loc73)
    aie.flow(%shim_noc_tile_0_0, DMA : 0, %mem_tile_0_1, DMA : 0) loc(#loc63)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_3_3, DMA : 0) loc(#loc72)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_2_3, DMA : 0) loc(#loc72)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_1_3, DMA : 0) loc(#loc72)
    aie.flow(%mem_tile_1_1, DMA : 0, %tile_0_3, DMA : 0) loc(#loc72)
    aie.flow(%shim_noc_tile_1_0, DMA : 0, %mem_tile_1_1, DMA : 0) loc(#loc60)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_3_4, DMA : 0) loc(#loc71)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_2_4, DMA : 0) loc(#loc71)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_1_4, DMA : 0) loc(#loc71)
    aie.flow(%mem_tile_2_1, DMA : 0, %tile_0_4, DMA : 0) loc(#loc71)
    aie.flow(%shim_noc_tile_2_0, DMA : 0, %mem_tile_2_1, DMA : 0) loc(#loc57)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_3_5, DMA : 0) loc(#loc70)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_2_5, DMA : 0) loc(#loc70)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_1_5, DMA : 0) loc(#loc70)
    aie.flow(%mem_tile_3_1, DMA : 0, %tile_0_5, DMA : 0) loc(#loc70)
    aie.flow(%shim_noc_tile_3_0, DMA : 0, %mem_tile_3_1, DMA : 0) loc(#loc54)
    aie.flow(%mem_tile_4_1, DMA : 0, %tile_7_2, DMA : 0) loc(#loc69)
    aie.flow(%mem_tile_4_1, DMA : 0, %tile_6_2, DMA : 0) loc(#loc69)
    aie.flow(%mem_tile_4_1, DMA : 0, %tile_5_2, DMA : 0) loc(#loc69)
    aie.flow(%mem_tile_4_1, DMA : 0, %tile_4_2, DMA : 0) loc(#loc69)
    aie.flow(%shim_noc_tile_4_0, DMA : 0, %mem_tile_4_1, DMA : 0) loc(#loc51)
    aie.flow(%mem_tile_5_1, DMA : 0, %tile_7_3, DMA : 0) loc(#loc68)
    aie.flow(%mem_tile_5_1, DMA : 0, %tile_6_3, DMA : 0) loc(#loc68)
    aie.flow(%mem_tile_5_1, DMA : 0, %tile_5_3, DMA : 0) loc(#loc68)
    aie.flow(%mem_tile_5_1, DMA : 0, %tile_4_3, DMA : 0) loc(#loc68)
    aie.flow(%shim_noc_tile_5_0, DMA : 0, %mem_tile_5_1, DMA : 0) loc(#loc48)
    aie.flow(%mem_tile_6_1, DMA : 0, %tile_7_4, DMA : 0) loc(#loc67)
    aie.flow(%mem_tile_6_1, DMA : 0, %tile_6_4, DMA : 0) loc(#loc67)
    aie.flow(%mem_tile_6_1, DMA : 0, %tile_5_4, DMA : 0) loc(#loc67)
    aie.flow(%mem_tile_6_1, DMA : 0, %tile_4_4, DMA : 0) loc(#loc67)
    aie.flow(%shim_noc_tile_6_0, DMA : 0, %mem_tile_6_1, DMA : 0) loc(#loc45)
    aie.flow(%mem_tile_7_1, DMA : 0, %tile_7_5, DMA : 0) loc(#loc66)
    aie.flow(%mem_tile_7_1, DMA : 0, %tile_6_5, DMA : 0) loc(#loc66)
    aie.flow(%mem_tile_7_1, DMA : 0, %tile_5_5, DMA : 0) loc(#loc66)
    aie.flow(%mem_tile_7_1, DMA : 0, %tile_4_5, DMA : 0) loc(#loc66)
    aie.flow(%shim_noc_tile_7_0, DMA : 0, %mem_tile_7_1, DMA : 0) loc(#loc42)
    aie.flow(%mem_tile_0_1, DMA : 1, %tile_0_5, DMA : 1) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 1, %tile_0_4, DMA : 1) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 1, %tile_0_3, DMA : 1) loc(#loc65)
    aie.flow(%mem_tile_0_1, DMA : 1, %tile_0_2, DMA : 1) loc(#loc65)
    aie.flow(%shim_noc_tile_0_0, DMA : 1, %mem_tile_0_1, DMA : 1) loc(#loc64)
    aie.flow(%mem_tile_1_1, DMA : 1, %tile_1_5, DMA : 1) loc(#loc62)
    aie.flow(%mem_tile_1_1, DMA : 1, %tile_1_4, DMA : 1) loc(#loc62)
    aie.flow(%mem_tile_1_1, DMA : 1, %tile_1_3, DMA : 1) loc(#loc62)
    aie.flow(%mem_tile_1_1, DMA : 1, %tile_1_2, DMA : 1) loc(#loc62)
    aie.flow(%shim_noc_tile_1_0, DMA : 1, %mem_tile_1_1, DMA : 1) loc(#loc61)
    aie.flow(%mem_tile_2_1, DMA : 1, %tile_2_5, DMA : 1) loc(#loc59)
    aie.flow(%mem_tile_2_1, DMA : 1, %tile_2_4, DMA : 1) loc(#loc59)
    aie.flow(%mem_tile_2_1, DMA : 1, %tile_2_3, DMA : 1) loc(#loc59)
    aie.flow(%mem_tile_2_1, DMA : 1, %tile_2_2, DMA : 1) loc(#loc59)
    aie.flow(%shim_noc_tile_2_0, DMA : 1, %mem_tile_2_1, DMA : 1) loc(#loc58)
    aie.flow(%mem_tile_3_1, DMA : 1, %tile_3_5, DMA : 1) loc(#loc56)
    aie.flow(%mem_tile_3_1, DMA : 1, %tile_3_4, DMA : 1) loc(#loc56)
    aie.flow(%mem_tile_3_1, DMA : 1, %tile_3_3, DMA : 1) loc(#loc56)
    aie.flow(%mem_tile_3_1, DMA : 1, %tile_3_2, DMA : 1) loc(#loc56)
    aie.flow(%shim_noc_tile_3_0, DMA : 1, %mem_tile_3_1, DMA : 1) loc(#loc55)
    aie.flow(%mem_tile_4_1, DMA : 1, %tile_4_5, DMA : 1) loc(#loc53)
    aie.flow(%mem_tile_4_1, DMA : 1, %tile_4_4, DMA : 1) loc(#loc53)
    aie.flow(%mem_tile_4_1, DMA : 1, %tile_4_3, DMA : 1) loc(#loc53)
    aie.flow(%mem_tile_4_1, DMA : 1, %tile_4_2, DMA : 1) loc(#loc53)
    aie.flow(%shim_noc_tile_4_0, DMA : 1, %mem_tile_4_1, DMA : 1) loc(#loc52)
    aie.flow(%mem_tile_5_1, DMA : 1, %tile_5_5, DMA : 1) loc(#loc50)
    aie.flow(%mem_tile_5_1, DMA : 1, %tile_5_4, DMA : 1) loc(#loc50)
    aie.flow(%mem_tile_5_1, DMA : 1, %tile_5_3, DMA : 1) loc(#loc50)
    aie.flow(%mem_tile_5_1, DMA : 1, %tile_5_2, DMA : 1) loc(#loc50)
    aie.flow(%shim_noc_tile_5_0, DMA : 1, %mem_tile_5_1, DMA : 1) loc(#loc49)
    aie.flow(%mem_tile_6_1, DMA : 1, %tile_6_5, DMA : 1) loc(#loc47)
    aie.flow(%mem_tile_6_1, DMA : 1, %tile_6_4, DMA : 1) loc(#loc47)
    aie.flow(%mem_tile_6_1, DMA : 1, %tile_6_3, DMA : 1) loc(#loc47)
    aie.flow(%mem_tile_6_1, DMA : 1, %tile_6_2, DMA : 1) loc(#loc47)
    aie.flow(%shim_noc_tile_6_0, DMA : 1, %mem_tile_6_1, DMA : 1) loc(#loc46)
    aie.flow(%mem_tile_7_1, DMA : 1, %tile_7_5, DMA : 1) loc(#loc44)
    aie.flow(%mem_tile_7_1, DMA : 1, %tile_7_4, DMA : 1) loc(#loc44)
    aie.flow(%mem_tile_7_1, DMA : 1, %tile_7_3, DMA : 1) loc(#loc44)
    aie.flow(%mem_tile_7_1, DMA : 1, %tile_7_2, DMA : 1) loc(#loc44)
    aie.flow(%shim_noc_tile_7_0, DMA : 1, %mem_tile_7_1, DMA : 1) loc(#loc43)
    aie.flow(%mem_tile_0_1, DMA : 2, %shim_noc_tile_0_0, DMA : 0) loc(#loc41)
    aie.flow(%tile_0_2, DMA : 0, %mem_tile_0_1, DMA : 2) loc(#loc40)
    aie.flow(%tile_0_3, DMA : 0, %mem_tile_0_1, DMA : 3) loc(#loc39)
    aie.flow(%tile_0_4, DMA : 0, %mem_tile_0_1, DMA : 4) loc(#loc38)
    aie.flow(%tile_0_5, DMA : 0, %mem_tile_0_1, DMA : 5) loc(#loc37)
    aie.flow(%mem_tile_1_1, DMA : 2, %shim_noc_tile_1_0, DMA : 0) loc(#loc36)
    aie.flow(%tile_1_2, DMA : 0, %mem_tile_1_1, DMA : 2) loc(#loc35)
    aie.flow(%tile_1_3, DMA : 0, %mem_tile_1_1, DMA : 3) loc(#loc34)
    aie.flow(%tile_1_4, DMA : 0, %mem_tile_1_1, DMA : 4) loc(#loc33)
    aie.flow(%tile_1_5, DMA : 0, %mem_tile_1_1, DMA : 5) loc(#loc32)
    aie.flow(%mem_tile_2_1, DMA : 2, %shim_noc_tile_2_0, DMA : 0) loc(#loc31)
    aie.flow(%tile_2_2, DMA : 0, %mem_tile_2_1, DMA : 2) loc(#loc30)
    aie.flow(%tile_2_3, DMA : 0, %mem_tile_2_1, DMA : 3) loc(#loc29)
    aie.flow(%tile_2_4, DMA : 0, %mem_tile_2_1, DMA : 4) loc(#loc28)
    aie.flow(%tile_2_5, DMA : 0, %mem_tile_2_1, DMA : 5) loc(#loc27)
    aie.flow(%mem_tile_3_1, DMA : 2, %shim_noc_tile_3_0, DMA : 0) loc(#loc26)
    aie.flow(%tile_3_2, DMA : 0, %mem_tile_3_1, DMA : 2) loc(#loc25)
    aie.flow(%tile_3_3, DMA : 0, %mem_tile_3_1, DMA : 3) loc(#loc24)
    aie.flow(%tile_3_4, DMA : 0, %mem_tile_3_1, DMA : 4) loc(#loc23)
    aie.flow(%tile_3_5, DMA : 0, %mem_tile_3_1, DMA : 5) loc(#loc22)
    aie.flow(%mem_tile_4_1, DMA : 2, %shim_noc_tile_4_0, DMA : 0) loc(#loc21)
    aie.flow(%tile_4_2, DMA : 0, %mem_tile_4_1, DMA : 2) loc(#loc20)
    aie.flow(%tile_4_3, DMA : 0, %mem_tile_4_1, DMA : 3) loc(#loc19)
    aie.flow(%tile_4_4, DMA : 0, %mem_tile_4_1, DMA : 4) loc(#loc18)
    aie.flow(%tile_4_5, DMA : 0, %mem_tile_4_1, DMA : 5) loc(#loc17)
    aie.flow(%mem_tile_5_1, DMA : 2, %shim_noc_tile_5_0, DMA : 0) loc(#loc16)
    aie.flow(%tile_5_2, DMA : 0, %mem_tile_5_1, DMA : 2) loc(#loc15)
    aie.flow(%tile_5_3, DMA : 0, %mem_tile_5_1, DMA : 3) loc(#loc14)
    aie.flow(%tile_5_4, DMA : 0, %mem_tile_5_1, DMA : 4) loc(#loc13)
    aie.flow(%tile_5_5, DMA : 0, %mem_tile_5_1, DMA : 5) loc(#loc12)
    aie.flow(%mem_tile_6_1, DMA : 2, %shim_noc_tile_6_0, DMA : 0) loc(#loc11)
    aie.flow(%tile_6_2, DMA : 0, %mem_tile_6_1, DMA : 2) loc(#loc10)
    aie.flow(%tile_6_3, DMA : 0, %mem_tile_6_1, DMA : 3) loc(#loc9)
    aie.flow(%tile_6_4, DMA : 0, %mem_tile_6_1, DMA : 4) loc(#loc8)
    aie.flow(%tile_6_5, DMA : 0, %mem_tile_6_1, DMA : 5) loc(#loc7)
    aie.flow(%mem_tile_7_1, DMA : 2, %shim_noc_tile_7_0, DMA : 0) loc(#loc6)
    aie.flow(%tile_7_2, DMA : 0, %mem_tile_7_1, DMA : 2) loc(#loc5)
    aie.flow(%tile_7_3, DMA : 0, %mem_tile_7_1, DMA : 3) loc(#loc4)
    aie.flow(%tile_7_4, DMA : 0, %mem_tile_7_1, DMA : 4) loc(#loc3)
    aie.flow(%tile_7_5, DMA : 0, %mem_tile_7_1, DMA : 5) loc(#loc2)
    %direct_acc0_0_0 = aie.buffer(%tile_0_2) {address = 23040 : i32, sym_name = "direct_acc0_0_0"} : memref<512xf32>  loc(#loc74)
    %direct_acc1_0_0 = aie.buffer(%tile_0_2) {address = 25088 : i32, sym_name = "direct_acc1_0_0"} : memref<512xf32>  loc(#loc75)
    %direct_dequant_0_0 = aie.buffer(%tile_0_2) {address = 2048 : i32, sym_name = "direct_dequant_0_0"} : memref<4096xbf16>  loc(#loc76)
    func.func private @w4a16_prefill_reuse_init(memref<512xf32>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"} loc(#loc77)
    func.func private @w4a16_prefill_reuse_accumulate_low(memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"} loc(#loc78)
    func.func private @w4a16_prefill_reuse_accumulate_high(memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"} loc(#loc79)
    func.func private @w4a16_prefill_reuse_finish(memref<512xf32>, memref<512xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"} loc(#loc80)
    %direct_acc0_0_1 = aie.buffer(%tile_0_3) {address = 23040 : i32, sym_name = "direct_acc0_0_1"} : memref<512xf32>  loc(#loc81)
    %direct_acc1_0_1 = aie.buffer(%tile_0_3) {address = 25088 : i32, sym_name = "direct_acc1_0_1"} : memref<512xf32>  loc(#loc82)
    %direct_dequant_0_1 = aie.buffer(%tile_0_3) {address = 2048 : i32, sym_name = "direct_dequant_0_1"} : memref<4096xbf16>  loc(#loc83)
    %direct_acc0_0_2 = aie.buffer(%tile_0_4) {address = 23040 : i32, sym_name = "direct_acc0_0_2"} : memref<512xf32>  loc(#loc84)
    %direct_acc1_0_2 = aie.buffer(%tile_0_4) {address = 25088 : i32, sym_name = "direct_acc1_0_2"} : memref<512xf32>  loc(#loc85)
    %direct_dequant_0_2 = aie.buffer(%tile_0_4) {address = 2048 : i32, sym_name = "direct_dequant_0_2"} : memref<4096xbf16>  loc(#loc86)
    %direct_acc0_0_3 = aie.buffer(%tile_0_5) {address = 23040 : i32, sym_name = "direct_acc0_0_3"} : memref<512xf32>  loc(#loc87)
    %direct_acc1_0_3 = aie.buffer(%tile_0_5) {address = 25088 : i32, sym_name = "direct_acc1_0_3"} : memref<512xf32>  loc(#loc88)
    %direct_dequant_0_3 = aie.buffer(%tile_0_5) {address = 2048 : i32, sym_name = "direct_dequant_0_3"} : memref<4096xbf16>  loc(#loc89)
    %direct_acc0_1_0 = aie.buffer(%tile_1_2) {address = 23040 : i32, sym_name = "direct_acc0_1_0"} : memref<512xf32>  loc(#loc90)
    %direct_acc1_1_0 = aie.buffer(%tile_1_2) {address = 25088 : i32, sym_name = "direct_acc1_1_0"} : memref<512xf32>  loc(#loc91)
    %direct_dequant_1_0 = aie.buffer(%tile_1_2) {address = 2048 : i32, sym_name = "direct_dequant_1_0"} : memref<4096xbf16>  loc(#loc92)
    %direct_acc0_1_1 = aie.buffer(%tile_1_3) {address = 23040 : i32, sym_name = "direct_acc0_1_1"} : memref<512xf32>  loc(#loc93)
    %direct_acc1_1_1 = aie.buffer(%tile_1_3) {address = 25088 : i32, sym_name = "direct_acc1_1_1"} : memref<512xf32>  loc(#loc94)
    %direct_dequant_1_1 = aie.buffer(%tile_1_3) {address = 2048 : i32, sym_name = "direct_dequant_1_1"} : memref<4096xbf16>  loc(#loc95)
    %direct_acc0_1_2 = aie.buffer(%tile_1_4) {address = 23040 : i32, sym_name = "direct_acc0_1_2"} : memref<512xf32>  loc(#loc96)
    %direct_acc1_1_2 = aie.buffer(%tile_1_4) {address = 25088 : i32, sym_name = "direct_acc1_1_2"} : memref<512xf32>  loc(#loc97)
    %direct_dequant_1_2 = aie.buffer(%tile_1_4) {address = 2048 : i32, sym_name = "direct_dequant_1_2"} : memref<4096xbf16>  loc(#loc98)
    %direct_acc0_1_3 = aie.buffer(%tile_1_5) {address = 23040 : i32, sym_name = "direct_acc0_1_3"} : memref<512xf32>  loc(#loc99)
    %direct_acc1_1_3 = aie.buffer(%tile_1_5) {address = 25088 : i32, sym_name = "direct_acc1_1_3"} : memref<512xf32>  loc(#loc100)
    %direct_dequant_1_3 = aie.buffer(%tile_1_5) {address = 2048 : i32, sym_name = "direct_dequant_1_3"} : memref<4096xbf16>  loc(#loc101)
    %direct_acc0_2_0 = aie.buffer(%tile_2_2) {address = 23040 : i32, sym_name = "direct_acc0_2_0"} : memref<512xf32>  loc(#loc102)
    %direct_acc1_2_0 = aie.buffer(%tile_2_2) {address = 25088 : i32, sym_name = "direct_acc1_2_0"} : memref<512xf32>  loc(#loc103)
    %direct_dequant_2_0 = aie.buffer(%tile_2_2) {address = 2048 : i32, sym_name = "direct_dequant_2_0"} : memref<4096xbf16>  loc(#loc104)
    %direct_acc0_2_1 = aie.buffer(%tile_2_3) {address = 23040 : i32, sym_name = "direct_acc0_2_1"} : memref<512xf32>  loc(#loc105)
    %direct_acc1_2_1 = aie.buffer(%tile_2_3) {address = 25088 : i32, sym_name = "direct_acc1_2_1"} : memref<512xf32>  loc(#loc106)
    %direct_dequant_2_1 = aie.buffer(%tile_2_3) {address = 2048 : i32, sym_name = "direct_dequant_2_1"} : memref<4096xbf16>  loc(#loc107)
    %direct_acc0_2_2 = aie.buffer(%tile_2_4) {address = 23040 : i32, sym_name = "direct_acc0_2_2"} : memref<512xf32>  loc(#loc108)
    %direct_acc1_2_2 = aie.buffer(%tile_2_4) {address = 25088 : i32, sym_name = "direct_acc1_2_2"} : memref<512xf32>  loc(#loc109)
    %direct_dequant_2_2 = aie.buffer(%tile_2_4) {address = 2048 : i32, sym_name = "direct_dequant_2_2"} : memref<4096xbf16>  loc(#loc110)
    %direct_acc0_2_3 = aie.buffer(%tile_2_5) {address = 23040 : i32, sym_name = "direct_acc0_2_3"} : memref<512xf32>  loc(#loc111)
    %direct_acc1_2_3 = aie.buffer(%tile_2_5) {address = 25088 : i32, sym_name = "direct_acc1_2_3"} : memref<512xf32>  loc(#loc112)
    %direct_dequant_2_3 = aie.buffer(%tile_2_5) {address = 2048 : i32, sym_name = "direct_dequant_2_3"} : memref<4096xbf16>  loc(#loc113)
    %direct_acc0_3_0 = aie.buffer(%tile_3_2) {address = 23040 : i32, sym_name = "direct_acc0_3_0"} : memref<512xf32>  loc(#loc114)
    %direct_acc1_3_0 = aie.buffer(%tile_3_2) {address = 25088 : i32, sym_name = "direct_acc1_3_0"} : memref<512xf32>  loc(#loc115)
    %direct_dequant_3_0 = aie.buffer(%tile_3_2) {address = 2048 : i32, sym_name = "direct_dequant_3_0"} : memref<4096xbf16>  loc(#loc116)
    %direct_acc0_3_1 = aie.buffer(%tile_3_3) {address = 23040 : i32, sym_name = "direct_acc0_3_1"} : memref<512xf32>  loc(#loc117)
    %direct_acc1_3_1 = aie.buffer(%tile_3_3) {address = 25088 : i32, sym_name = "direct_acc1_3_1"} : memref<512xf32>  loc(#loc118)
    %direct_dequant_3_1 = aie.buffer(%tile_3_3) {address = 2048 : i32, sym_name = "direct_dequant_3_1"} : memref<4096xbf16>  loc(#loc119)
    %direct_acc0_3_2 = aie.buffer(%tile_3_4) {address = 23040 : i32, sym_name = "direct_acc0_3_2"} : memref<512xf32>  loc(#loc120)
    %direct_acc1_3_2 = aie.buffer(%tile_3_4) {address = 25088 : i32, sym_name = "direct_acc1_3_2"} : memref<512xf32>  loc(#loc121)
    %direct_dequant_3_2 = aie.buffer(%tile_3_4) {address = 2048 : i32, sym_name = "direct_dequant_3_2"} : memref<4096xbf16>  loc(#loc122)
    %direct_acc0_3_3 = aie.buffer(%tile_3_5) {address = 23040 : i32, sym_name = "direct_acc0_3_3"} : memref<512xf32>  loc(#loc123)
    %direct_acc1_3_3 = aie.buffer(%tile_3_5) {address = 25088 : i32, sym_name = "direct_acc1_3_3"} : memref<512xf32>  loc(#loc124)
    %direct_dequant_3_3 = aie.buffer(%tile_3_5) {address = 2048 : i32, sym_name = "direct_dequant_3_3"} : memref<4096xbf16>  loc(#loc125)
    %direct_acc0_4_0 = aie.buffer(%tile_4_2) {address = 23040 : i32, sym_name = "direct_acc0_4_0"} : memref<512xf32>  loc(#loc126)
    %direct_acc1_4_0 = aie.buffer(%tile_4_2) {address = 25088 : i32, sym_name = "direct_acc1_4_0"} : memref<512xf32>  loc(#loc127)
    %direct_dequant_4_0 = aie.buffer(%tile_4_2) {address = 2048 : i32, sym_name = "direct_dequant_4_0"} : memref<4096xbf16>  loc(#loc128)
    %direct_acc0_4_1 = aie.buffer(%tile_4_3) {address = 23040 : i32, sym_name = "direct_acc0_4_1"} : memref<512xf32>  loc(#loc129)
    %direct_acc1_4_1 = aie.buffer(%tile_4_3) {address = 25088 : i32, sym_name = "direct_acc1_4_1"} : memref<512xf32>  loc(#loc130)
    %direct_dequant_4_1 = aie.buffer(%tile_4_3) {address = 2048 : i32, sym_name = "direct_dequant_4_1"} : memref<4096xbf16>  loc(#loc131)
    %direct_acc0_4_2 = aie.buffer(%tile_4_4) {address = 23040 : i32, sym_name = "direct_acc0_4_2"} : memref<512xf32>  loc(#loc132)
    %direct_acc1_4_2 = aie.buffer(%tile_4_4) {address = 25088 : i32, sym_name = "direct_acc1_4_2"} : memref<512xf32>  loc(#loc133)
    %direct_dequant_4_2 = aie.buffer(%tile_4_4) {address = 2048 : i32, sym_name = "direct_dequant_4_2"} : memref<4096xbf16>  loc(#loc134)
    %direct_acc0_4_3 = aie.buffer(%tile_4_5) {address = 23040 : i32, sym_name = "direct_acc0_4_3"} : memref<512xf32>  loc(#loc135)
    %direct_acc1_4_3 = aie.buffer(%tile_4_5) {address = 25088 : i32, sym_name = "direct_acc1_4_3"} : memref<512xf32>  loc(#loc136)
    %direct_dequant_4_3 = aie.buffer(%tile_4_5) {address = 2048 : i32, sym_name = "direct_dequant_4_3"} : memref<4096xbf16>  loc(#loc137)
    %direct_acc0_5_0 = aie.buffer(%tile_5_2) {address = 23040 : i32, sym_name = "direct_acc0_5_0"} : memref<512xf32>  loc(#loc138)
    %direct_acc1_5_0 = aie.buffer(%tile_5_2) {address = 25088 : i32, sym_name = "direct_acc1_5_0"} : memref<512xf32>  loc(#loc139)
    %direct_dequant_5_0 = aie.buffer(%tile_5_2) {address = 2048 : i32, sym_name = "direct_dequant_5_0"} : memref<4096xbf16>  loc(#loc140)
    %direct_acc0_5_1 = aie.buffer(%tile_5_3) {address = 23040 : i32, sym_name = "direct_acc0_5_1"} : memref<512xf32>  loc(#loc141)
    %direct_acc1_5_1 = aie.buffer(%tile_5_3) {address = 25088 : i32, sym_name = "direct_acc1_5_1"} : memref<512xf32>  loc(#loc142)
    %direct_dequant_5_1 = aie.buffer(%tile_5_3) {address = 2048 : i32, sym_name = "direct_dequant_5_1"} : memref<4096xbf16>  loc(#loc143)
    %direct_acc0_5_2 = aie.buffer(%tile_5_4) {address = 23040 : i32, sym_name = "direct_acc0_5_2"} : memref<512xf32>  loc(#loc144)
    %direct_acc1_5_2 = aie.buffer(%tile_5_4) {address = 25088 : i32, sym_name = "direct_acc1_5_2"} : memref<512xf32>  loc(#loc145)
    %direct_dequant_5_2 = aie.buffer(%tile_5_4) {address = 2048 : i32, sym_name = "direct_dequant_5_2"} : memref<4096xbf16>  loc(#loc146)
    %direct_acc0_5_3 = aie.buffer(%tile_5_5) {address = 23040 : i32, sym_name = "direct_acc0_5_3"} : memref<512xf32>  loc(#loc147)
    %direct_acc1_5_3 = aie.buffer(%tile_5_5) {address = 25088 : i32, sym_name = "direct_acc1_5_3"} : memref<512xf32>  loc(#loc148)
    %direct_dequant_5_3 = aie.buffer(%tile_5_5) {address = 2048 : i32, sym_name = "direct_dequant_5_3"} : memref<4096xbf16>  loc(#loc149)
    %direct_acc0_6_0 = aie.buffer(%tile_6_2) {address = 23040 : i32, sym_name = "direct_acc0_6_0"} : memref<512xf32>  loc(#loc150)
    %direct_acc1_6_0 = aie.buffer(%tile_6_2) {address = 25088 : i32, sym_name = "direct_acc1_6_0"} : memref<512xf32>  loc(#loc151)
    %direct_dequant_6_0 = aie.buffer(%tile_6_2) {address = 2048 : i32, sym_name = "direct_dequant_6_0"} : memref<4096xbf16>  loc(#loc152)
    %direct_acc0_6_1 = aie.buffer(%tile_6_3) {address = 23040 : i32, sym_name = "direct_acc0_6_1"} : memref<512xf32>  loc(#loc153)
    %direct_acc1_6_1 = aie.buffer(%tile_6_3) {address = 25088 : i32, sym_name = "direct_acc1_6_1"} : memref<512xf32>  loc(#loc154)
    %direct_dequant_6_1 = aie.buffer(%tile_6_3) {address = 2048 : i32, sym_name = "direct_dequant_6_1"} : memref<4096xbf16>  loc(#loc155)
    %direct_acc0_6_2 = aie.buffer(%tile_6_4) {address = 23040 : i32, sym_name = "direct_acc0_6_2"} : memref<512xf32>  loc(#loc156)
    %direct_acc1_6_2 = aie.buffer(%tile_6_4) {address = 25088 : i32, sym_name = "direct_acc1_6_2"} : memref<512xf32>  loc(#loc157)
    %direct_dequant_6_2 = aie.buffer(%tile_6_4) {address = 2048 : i32, sym_name = "direct_dequant_6_2"} : memref<4096xbf16>  loc(#loc158)
    %direct_acc0_6_3 = aie.buffer(%tile_6_5) {address = 23040 : i32, sym_name = "direct_acc0_6_3"} : memref<512xf32>  loc(#loc159)
    %direct_acc1_6_3 = aie.buffer(%tile_6_5) {address = 25088 : i32, sym_name = "direct_acc1_6_3"} : memref<512xf32>  loc(#loc160)
    %direct_dequant_6_3 = aie.buffer(%tile_6_5) {address = 2048 : i32, sym_name = "direct_dequant_6_3"} : memref<4096xbf16>  loc(#loc161)
    %direct_acc0_7_0 = aie.buffer(%tile_7_2) {address = 23040 : i32, sym_name = "direct_acc0_7_0"} : memref<512xf32>  loc(#loc162)
    %direct_acc1_7_0 = aie.buffer(%tile_7_2) {address = 25088 : i32, sym_name = "direct_acc1_7_0"} : memref<512xf32>  loc(#loc163)
    %direct_dequant_7_0 = aie.buffer(%tile_7_2) {address = 2048 : i32, sym_name = "direct_dequant_7_0"} : memref<4096xbf16>  loc(#loc164)
    %direct_acc0_7_1 = aie.buffer(%tile_7_3) {address = 23040 : i32, sym_name = "direct_acc0_7_1"} : memref<512xf32>  loc(#loc165)
    %direct_acc1_7_1 = aie.buffer(%tile_7_3) {address = 25088 : i32, sym_name = "direct_acc1_7_1"} : memref<512xf32>  loc(#loc166)
    %direct_dequant_7_1 = aie.buffer(%tile_7_3) {address = 2048 : i32, sym_name = "direct_dequant_7_1"} : memref<4096xbf16>  loc(#loc167)
    %direct_acc0_7_2 = aie.buffer(%tile_7_4) {address = 23040 : i32, sym_name = "direct_acc0_7_2"} : memref<512xf32>  loc(#loc168)
    %direct_acc1_7_2 = aie.buffer(%tile_7_4) {address = 25088 : i32, sym_name = "direct_acc1_7_2"} : memref<512xf32>  loc(#loc169)
    %direct_dequant_7_2 = aie.buffer(%tile_7_4) {address = 2048 : i32, sym_name = "direct_dequant_7_2"} : memref<4096xbf16>  loc(#loc170)
    %direct_acc0_7_3 = aie.buffer(%tile_7_5) {address = 23040 : i32, sym_name = "direct_acc0_7_3"} : memref<512xf32>  loc(#loc171)
    %direct_acc1_7_3 = aie.buffer(%tile_7_5) {address = 25088 : i32, sym_name = "direct_acc1_7_3"} : memref<512xf32>  loc(#loc172)
    %direct_dequant_7_3 = aie.buffer(%tile_7_5) {address = 2048 : i32, sym_name = "direct_dequant_7_3"} : memref<4096xbf16>  loc(#loc173)
    %core_0_2 = aie.core(%tile_0_2) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc176)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":283:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":279:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":279:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc176)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc176)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_0_0) : (memref<512xf32>) -> () loc(#loc178)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc179)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":292:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":279:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc179)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc179)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc181)
      aie.use_lock(%direct_w_broadcast_0_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc182)
      %7 = arith.index_cast %5 : i32 to index loc(#loc183)
      %8 = arith.index_cast %7 : index to i64 loc(#loc183)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc183)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_0_cons_buff_0 : memref<4352xui8>) loc(#loc183)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_0_cons_buff_1 : memref<4352xui8>) loc(#loc183)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_0_cons_buff_0 : memref<4352xui8>) loc(#loc183)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":296:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_0_0_cons_buff_0, %9, %direct_acc0_0_0, %direct_dequant_0_0) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc184)
      aie.use_lock(%direct_a_broadcast_0_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc185)
      aie.use_lock(%direct_w_broadcast_0_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc186)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc186)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc186)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc186)
      %13 = arith.addi %4, %c1 : index loc(#loc179)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc179)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_0_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc187)
      %14 = arith.index_cast %2 : i32 to index loc(#loc188)
      %15 = arith.index_cast %14 : index to i64 loc(#loc188)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc188)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_0_buff_0 : memref<512xbf16>) loc(#loc188)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_0_buff_1 : memref<512xbf16>) loc(#loc188)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_0_buff_0 : memref<512xbf16>) loc(#loc188)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":302:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_0, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc189)
      aie.use_lock(%direct_y_worker_0_0_cons_lock_0, Release, %c1_i32) loc(#loc190)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc190)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc190)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc190)
      %20 = arith.addi %0, %c1 : index loc(#loc176)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc176)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc191)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc174)
    %core_0_3 = aie.core(%tile_0_3) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc193)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":313:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":309:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":309:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc193)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc193)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_0_1) : (memref<512xf32>) -> () loc(#loc195)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc196)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":322:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":309:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc196)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc196)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc198)
      aie.use_lock(%direct_w_broadcast_0_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc199)
      %7 = arith.index_cast %5 : i32 to index loc(#loc200)
      %8 = arith.index_cast %7 : index to i64 loc(#loc200)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc200)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_1_cons_buff_0 : memref<4352xui8>) loc(#loc200)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_1_cons_buff_1 : memref<4352xui8>) loc(#loc200)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_1_cons_buff_0 : memref<4352xui8>) loc(#loc200)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":326:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_1_0_cons_buff_0, %9, %direct_acc0_0_1, %direct_dequant_0_1) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc201)
      aie.use_lock(%direct_a_broadcast_1_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc202)
      aie.use_lock(%direct_w_broadcast_0_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc203)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc203)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc203)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc203)
      %13 = arith.addi %4, %c1 : index loc(#loc196)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc196)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_0_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc204)
      %14 = arith.index_cast %2 : i32 to index loc(#loc205)
      %15 = arith.index_cast %14 : index to i64 loc(#loc205)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc205)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_1_buff_0 : memref<512xbf16>) loc(#loc205)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_1_buff_1 : memref<512xbf16>) loc(#loc205)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_1_buff_0 : memref<512xbf16>) loc(#loc205)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":332:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_1, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc206)
      aie.use_lock(%direct_y_worker_0_1_cons_lock_0, Release, %c1_i32) loc(#loc207)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc207)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc207)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc207)
      %20 = arith.addi %0, %c1 : index loc(#loc193)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc193)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc208)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc192)
    %core_0_4 = aie.core(%tile_0_4) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc210)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":343:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":339:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":339:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc210)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc210)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_0_2) : (memref<512xf32>) -> () loc(#loc212)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc213)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":352:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":339:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc213)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc213)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc215)
      aie.use_lock(%direct_w_broadcast_0_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc216)
      %7 = arith.index_cast %5 : i32 to index loc(#loc217)
      %8 = arith.index_cast %7 : index to i64 loc(#loc217)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc217)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_2_cons_buff_0 : memref<4352xui8>) loc(#loc217)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_2_cons_buff_1 : memref<4352xui8>) loc(#loc217)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_2_cons_buff_0 : memref<4352xui8>) loc(#loc217)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":356:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_2_0_cons_buff_0, %9, %direct_acc0_0_2, %direct_dequant_0_2) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc218)
      aie.use_lock(%direct_a_broadcast_2_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc219)
      aie.use_lock(%direct_w_broadcast_0_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc220)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc220)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc220)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc220)
      %13 = arith.addi %4, %c1 : index loc(#loc213)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc213)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_0_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc221)
      %14 = arith.index_cast %2 : i32 to index loc(#loc222)
      %15 = arith.index_cast %14 : index to i64 loc(#loc222)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc222)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_2_buff_0 : memref<512xbf16>) loc(#loc222)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_2_buff_1 : memref<512xbf16>) loc(#loc222)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_2_buff_0 : memref<512xbf16>) loc(#loc222)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":362:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_2, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc223)
      aie.use_lock(%direct_y_worker_0_2_cons_lock_0, Release, %c1_i32) loc(#loc224)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc224)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc224)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc224)
      %20 = arith.addi %0, %c1 : index loc(#loc210)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc210)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc225)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc209)
    %core_0_5 = aie.core(%tile_0_5) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc227)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":373:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":369:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":369:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc227)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc227)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_0_3) : (memref<512xf32>) -> () loc(#loc229)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc230)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":382:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":369:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc230)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc230)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc232)
      aie.use_lock(%direct_w_broadcast_0_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc233)
      %7 = arith.index_cast %5 : i32 to index loc(#loc234)
      %8 = arith.index_cast %7 : index to i64 loc(#loc234)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc234)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_3_cons_buff_0 : memref<4352xui8>) loc(#loc234)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_3_cons_buff_1 : memref<4352xui8>) loc(#loc234)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_0_3_cons_buff_0 : memref<4352xui8>) loc(#loc234)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":386:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_3_0_cons_buff_0, %9, %direct_acc0_0_3, %direct_dequant_0_3) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc235)
      aie.use_lock(%direct_a_broadcast_3_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc236)
      aie.use_lock(%direct_w_broadcast_0_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc237)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc237)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc237)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc237)
      %13 = arith.addi %4, %c1 : index loc(#loc230)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc230)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_0_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc238)
      %14 = arith.index_cast %2 : i32 to index loc(#loc239)
      %15 = arith.index_cast %14 : index to i64 loc(#loc239)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc239)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_3_buff_0 : memref<512xbf16>) loc(#loc239)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_3_buff_1 : memref<512xbf16>) loc(#loc239)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_0_3_buff_0 : memref<512xbf16>) loc(#loc239)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":392:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_3, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc240)
      aie.use_lock(%direct_y_worker_0_3_cons_lock_0, Release, %c1_i32) loc(#loc241)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc241)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc241)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc241)
      %20 = arith.addi %0, %c1 : index loc(#loc227)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc227)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc242)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc226)
    %core_1_2 = aie.core(%tile_1_2) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc244)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":403:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":399:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":399:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc244)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc244)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_1_0) : (memref<512xf32>) -> () loc(#loc246)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc247)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":412:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":399:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc247)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc247)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc249)
      aie.use_lock(%direct_w_broadcast_1_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc250)
      %7 = arith.index_cast %5 : i32 to index loc(#loc251)
      %8 = arith.index_cast %7 : index to i64 loc(#loc251)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc251)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_0_cons_buff_0 : memref<4352xui8>) loc(#loc251)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_0_cons_buff_1 : memref<4352xui8>) loc(#loc251)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_0_cons_buff_0 : memref<4352xui8>) loc(#loc251)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":416:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_0_1_cons_buff_0, %9, %direct_acc0_1_0, %direct_dequant_1_0) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc252)
      aie.use_lock(%direct_a_broadcast_0_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc253)
      aie.use_lock(%direct_w_broadcast_1_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc254)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc254)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc254)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc254)
      %13 = arith.addi %4, %c1 : index loc(#loc247)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc247)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_1_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc255)
      %14 = arith.index_cast %2 : i32 to index loc(#loc256)
      %15 = arith.index_cast %14 : index to i64 loc(#loc256)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc256)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_0_buff_0 : memref<512xbf16>) loc(#loc256)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_0_buff_1 : memref<512xbf16>) loc(#loc256)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_0_buff_0 : memref<512xbf16>) loc(#loc256)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":422:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_0, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc257)
      aie.use_lock(%direct_y_worker_1_0_cons_lock_0, Release, %c1_i32) loc(#loc258)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc258)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc258)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc258)
      %20 = arith.addi %0, %c1 : index loc(#loc244)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc244)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc259)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc243)
    %core_1_3 = aie.core(%tile_1_3) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc261)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":433:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":429:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":429:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc261)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc261)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_1_1) : (memref<512xf32>) -> () loc(#loc263)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc264)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":442:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":429:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc264)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc264)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc266)
      aie.use_lock(%direct_w_broadcast_1_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc267)
      %7 = arith.index_cast %5 : i32 to index loc(#loc268)
      %8 = arith.index_cast %7 : index to i64 loc(#loc268)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc268)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_1_cons_buff_0 : memref<4352xui8>) loc(#loc268)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_1_cons_buff_1 : memref<4352xui8>) loc(#loc268)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_1_cons_buff_0 : memref<4352xui8>) loc(#loc268)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":446:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_1_1_cons_buff_0, %9, %direct_acc0_1_1, %direct_dequant_1_1) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc269)
      aie.use_lock(%direct_a_broadcast_1_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc270)
      aie.use_lock(%direct_w_broadcast_1_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc271)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc271)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc271)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc271)
      %13 = arith.addi %4, %c1 : index loc(#loc264)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc264)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_1_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc272)
      %14 = arith.index_cast %2 : i32 to index loc(#loc273)
      %15 = arith.index_cast %14 : index to i64 loc(#loc273)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc273)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_1_buff_0 : memref<512xbf16>) loc(#loc273)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_1_buff_1 : memref<512xbf16>) loc(#loc273)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_1_buff_0 : memref<512xbf16>) loc(#loc273)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":452:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_1, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc274)
      aie.use_lock(%direct_y_worker_1_1_cons_lock_0, Release, %c1_i32) loc(#loc275)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc275)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc275)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc275)
      %20 = arith.addi %0, %c1 : index loc(#loc261)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc261)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc276)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc260)
    %core_1_4 = aie.core(%tile_1_4) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc278)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":463:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":459:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":459:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc278)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc278)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_1_2) : (memref<512xf32>) -> () loc(#loc280)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc281)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":472:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":459:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc281)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc281)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc283)
      aie.use_lock(%direct_w_broadcast_1_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc284)
      %7 = arith.index_cast %5 : i32 to index loc(#loc285)
      %8 = arith.index_cast %7 : index to i64 loc(#loc285)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc285)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_2_cons_buff_0 : memref<4352xui8>) loc(#loc285)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_2_cons_buff_1 : memref<4352xui8>) loc(#loc285)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_2_cons_buff_0 : memref<4352xui8>) loc(#loc285)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":476:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_2_1_cons_buff_0, %9, %direct_acc0_1_2, %direct_dequant_1_2) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc286)
      aie.use_lock(%direct_a_broadcast_2_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc287)
      aie.use_lock(%direct_w_broadcast_1_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc288)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc288)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc288)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc288)
      %13 = arith.addi %4, %c1 : index loc(#loc281)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc281)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_1_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc289)
      %14 = arith.index_cast %2 : i32 to index loc(#loc290)
      %15 = arith.index_cast %14 : index to i64 loc(#loc290)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc290)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_2_buff_0 : memref<512xbf16>) loc(#loc290)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_2_buff_1 : memref<512xbf16>) loc(#loc290)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_2_buff_0 : memref<512xbf16>) loc(#loc290)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":482:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_2, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc291)
      aie.use_lock(%direct_y_worker_1_2_cons_lock_0, Release, %c1_i32) loc(#loc292)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc292)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc292)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc292)
      %20 = arith.addi %0, %c1 : index loc(#loc278)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc278)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc293)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc277)
    %core_1_5 = aie.core(%tile_1_5) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc295)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":493:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":489:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":489:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc295)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc295)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_1_3) : (memref<512xf32>) -> () loc(#loc297)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc298)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":502:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":489:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc298)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc298)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc300)
      aie.use_lock(%direct_w_broadcast_1_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc301)
      %7 = arith.index_cast %5 : i32 to index loc(#loc302)
      %8 = arith.index_cast %7 : index to i64 loc(#loc302)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc302)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_3_cons_buff_0 : memref<4352xui8>) loc(#loc302)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_3_cons_buff_1 : memref<4352xui8>) loc(#loc302)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_1_3_cons_buff_0 : memref<4352xui8>) loc(#loc302)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":506:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_3_1_cons_buff_0, %9, %direct_acc0_1_3, %direct_dequant_1_3) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc303)
      aie.use_lock(%direct_a_broadcast_3_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc304)
      aie.use_lock(%direct_w_broadcast_1_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc305)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc305)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc305)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc305)
      %13 = arith.addi %4, %c1 : index loc(#loc298)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc298)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_1_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc306)
      %14 = arith.index_cast %2 : i32 to index loc(#loc307)
      %15 = arith.index_cast %14 : index to i64 loc(#loc307)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc307)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_3_buff_0 : memref<512xbf16>) loc(#loc307)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_3_buff_1 : memref<512xbf16>) loc(#loc307)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_1_3_buff_0 : memref<512xbf16>) loc(#loc307)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":512:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_3, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc308)
      aie.use_lock(%direct_y_worker_1_3_cons_lock_0, Release, %c1_i32) loc(#loc309)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc309)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc309)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc309)
      %20 = arith.addi %0, %c1 : index loc(#loc295)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc295)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc310)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc294)
    %core_2_2 = aie.core(%tile_2_2) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc312)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":523:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":519:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":519:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc312)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc312)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_2_0) : (memref<512xf32>) -> () loc(#loc314)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc315)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":532:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":519:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc315)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc315)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc317)
      aie.use_lock(%direct_w_broadcast_2_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc318)
      %7 = arith.index_cast %5 : i32 to index loc(#loc319)
      %8 = arith.index_cast %7 : index to i64 loc(#loc319)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc319)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_0_cons_buff_0 : memref<4352xui8>) loc(#loc319)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_0_cons_buff_1 : memref<4352xui8>) loc(#loc319)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_0_cons_buff_0 : memref<4352xui8>) loc(#loc319)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":536:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_0_2_cons_buff_0, %9, %direct_acc0_2_0, %direct_dequant_2_0) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc320)
      aie.use_lock(%direct_a_broadcast_0_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc321)
      aie.use_lock(%direct_w_broadcast_2_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc322)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc322)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc322)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc322)
      %13 = arith.addi %4, %c1 : index loc(#loc315)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc315)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_2_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc323)
      %14 = arith.index_cast %2 : i32 to index loc(#loc324)
      %15 = arith.index_cast %14 : index to i64 loc(#loc324)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc324)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_0_buff_0 : memref<512xbf16>) loc(#loc324)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_0_buff_1 : memref<512xbf16>) loc(#loc324)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_0_buff_0 : memref<512xbf16>) loc(#loc324)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":542:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_0, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc325)
      aie.use_lock(%direct_y_worker_2_0_cons_lock_0, Release, %c1_i32) loc(#loc326)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc326)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc326)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc326)
      %20 = arith.addi %0, %c1 : index loc(#loc312)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc312)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc327)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc311)
    %core_2_3 = aie.core(%tile_2_3) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc329)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":553:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":549:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":549:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc329)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc329)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_2_1) : (memref<512xf32>) -> () loc(#loc331)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc332)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":562:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":549:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc332)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc332)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc334)
      aie.use_lock(%direct_w_broadcast_2_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc335)
      %7 = arith.index_cast %5 : i32 to index loc(#loc336)
      %8 = arith.index_cast %7 : index to i64 loc(#loc336)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc336)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_1_cons_buff_0 : memref<4352xui8>) loc(#loc336)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_1_cons_buff_1 : memref<4352xui8>) loc(#loc336)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_1_cons_buff_0 : memref<4352xui8>) loc(#loc336)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":566:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_1_2_cons_buff_0, %9, %direct_acc0_2_1, %direct_dequant_2_1) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc337)
      aie.use_lock(%direct_a_broadcast_1_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc338)
      aie.use_lock(%direct_w_broadcast_2_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc339)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc339)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc339)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc339)
      %13 = arith.addi %4, %c1 : index loc(#loc332)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc332)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_2_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc340)
      %14 = arith.index_cast %2 : i32 to index loc(#loc341)
      %15 = arith.index_cast %14 : index to i64 loc(#loc341)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc341)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_1_buff_0 : memref<512xbf16>) loc(#loc341)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_1_buff_1 : memref<512xbf16>) loc(#loc341)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_1_buff_0 : memref<512xbf16>) loc(#loc341)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":572:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_1, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc342)
      aie.use_lock(%direct_y_worker_2_1_cons_lock_0, Release, %c1_i32) loc(#loc343)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc343)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc343)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc343)
      %20 = arith.addi %0, %c1 : index loc(#loc329)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc329)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc344)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc328)
    %core_2_4 = aie.core(%tile_2_4) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc346)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":583:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":579:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":579:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc346)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc346)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_2_2) : (memref<512xf32>) -> () loc(#loc348)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc349)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":592:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":579:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc349)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc349)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc351)
      aie.use_lock(%direct_w_broadcast_2_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc352)
      %7 = arith.index_cast %5 : i32 to index loc(#loc353)
      %8 = arith.index_cast %7 : index to i64 loc(#loc353)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc353)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_2_cons_buff_0 : memref<4352xui8>) loc(#loc353)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_2_cons_buff_1 : memref<4352xui8>) loc(#loc353)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_2_cons_buff_0 : memref<4352xui8>) loc(#loc353)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":596:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_2_2_cons_buff_0, %9, %direct_acc0_2_2, %direct_dequant_2_2) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc354)
      aie.use_lock(%direct_a_broadcast_2_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc355)
      aie.use_lock(%direct_w_broadcast_2_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc356)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc356)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc356)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc356)
      %13 = arith.addi %4, %c1 : index loc(#loc349)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc349)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_2_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc357)
      %14 = arith.index_cast %2 : i32 to index loc(#loc358)
      %15 = arith.index_cast %14 : index to i64 loc(#loc358)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc358)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_2_buff_0 : memref<512xbf16>) loc(#loc358)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_2_buff_1 : memref<512xbf16>) loc(#loc358)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_2_buff_0 : memref<512xbf16>) loc(#loc358)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":602:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_2, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc359)
      aie.use_lock(%direct_y_worker_2_2_cons_lock_0, Release, %c1_i32) loc(#loc360)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc360)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc360)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc360)
      %20 = arith.addi %0, %c1 : index loc(#loc346)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc346)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc361)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc345)
    %core_2_5 = aie.core(%tile_2_5) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc363)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":613:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":609:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":609:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc363)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc363)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_2_3) : (memref<512xf32>) -> () loc(#loc365)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc366)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":622:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":609:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc366)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc366)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc368)
      aie.use_lock(%direct_w_broadcast_2_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc369)
      %7 = arith.index_cast %5 : i32 to index loc(#loc370)
      %8 = arith.index_cast %7 : index to i64 loc(#loc370)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc370)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_3_cons_buff_0 : memref<4352xui8>) loc(#loc370)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_3_cons_buff_1 : memref<4352xui8>) loc(#loc370)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_2_3_cons_buff_0 : memref<4352xui8>) loc(#loc370)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":626:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_3_2_cons_buff_0, %9, %direct_acc0_2_3, %direct_dequant_2_3) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc371)
      aie.use_lock(%direct_a_broadcast_3_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc372)
      aie.use_lock(%direct_w_broadcast_2_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc373)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc373)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc373)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc373)
      %13 = arith.addi %4, %c1 : index loc(#loc366)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc366)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_2_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc374)
      %14 = arith.index_cast %2 : i32 to index loc(#loc375)
      %15 = arith.index_cast %14 : index to i64 loc(#loc375)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc375)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_3_buff_0 : memref<512xbf16>) loc(#loc375)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_3_buff_1 : memref<512xbf16>) loc(#loc375)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_2_3_buff_0 : memref<512xbf16>) loc(#loc375)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":632:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_3, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc376)
      aie.use_lock(%direct_y_worker_2_3_cons_lock_0, Release, %c1_i32) loc(#loc377)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc377)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc377)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc377)
      %20 = arith.addi %0, %c1 : index loc(#loc363)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc363)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc378)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc362)
    %core_3_2 = aie.core(%tile_3_2) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc380)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":643:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":639:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":639:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc380)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc380)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_3_0) : (memref<512xf32>) -> () loc(#loc382)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc383)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":652:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":639:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc383)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc383)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_0_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc385)
      aie.use_lock(%direct_w_broadcast_3_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc386)
      %7 = arith.index_cast %5 : i32 to index loc(#loc387)
      %8 = arith.index_cast %7 : index to i64 loc(#loc387)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc387)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_0_cons_buff_0 : memref<4352xui8>) loc(#loc387)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_0_cons_buff_1 : memref<4352xui8>) loc(#loc387)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_0_cons_buff_0 : memref<4352xui8>) loc(#loc387)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":656:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_0_3_cons_buff_0, %9, %direct_acc0_3_0, %direct_dequant_3_0) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc388)
      aie.use_lock(%direct_a_broadcast_0_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc389)
      aie.use_lock(%direct_w_broadcast_3_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc390)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc390)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc390)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc390)
      %13 = arith.addi %4, %c1 : index loc(#loc383)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc383)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_3_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc391)
      %14 = arith.index_cast %2 : i32 to index loc(#loc392)
      %15 = arith.index_cast %14 : index to i64 loc(#loc392)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc392)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_0_buff_0 : memref<512xbf16>) loc(#loc392)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_0_buff_1 : memref<512xbf16>) loc(#loc392)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_0_buff_0 : memref<512xbf16>) loc(#loc392)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":662:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_0, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc393)
      aie.use_lock(%direct_y_worker_3_0_cons_lock_0, Release, %c1_i32) loc(#loc394)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc394)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc394)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc394)
      %20 = arith.addi %0, %c1 : index loc(#loc380)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc380)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc395)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc379)
    %core_3_3 = aie.core(%tile_3_3) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc397)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":673:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":669:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":669:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc397)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc397)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_3_1) : (memref<512xf32>) -> () loc(#loc399)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc400)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":682:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":669:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc400)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc400)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_1_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc402)
      aie.use_lock(%direct_w_broadcast_3_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc403)
      %7 = arith.index_cast %5 : i32 to index loc(#loc404)
      %8 = arith.index_cast %7 : index to i64 loc(#loc404)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc404)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_1_cons_buff_0 : memref<4352xui8>) loc(#loc404)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_1_cons_buff_1 : memref<4352xui8>) loc(#loc404)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_1_cons_buff_0 : memref<4352xui8>) loc(#loc404)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":686:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_1_3_cons_buff_0, %9, %direct_acc0_3_1, %direct_dequant_3_1) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc405)
      aie.use_lock(%direct_a_broadcast_1_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc406)
      aie.use_lock(%direct_w_broadcast_3_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc407)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc407)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc407)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc407)
      %13 = arith.addi %4, %c1 : index loc(#loc400)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc400)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_3_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc408)
      %14 = arith.index_cast %2 : i32 to index loc(#loc409)
      %15 = arith.index_cast %14 : index to i64 loc(#loc409)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc409)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_1_buff_0 : memref<512xbf16>) loc(#loc409)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_1_buff_1 : memref<512xbf16>) loc(#loc409)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_1_buff_0 : memref<512xbf16>) loc(#loc409)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":692:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_1, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc410)
      aie.use_lock(%direct_y_worker_3_1_cons_lock_0, Release, %c1_i32) loc(#loc411)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc411)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc411)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc411)
      %20 = arith.addi %0, %c1 : index loc(#loc397)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc397)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc412)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc396)
    %core_3_4 = aie.core(%tile_3_4) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc414)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":703:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":699:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":699:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc414)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc414)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_3_2) : (memref<512xf32>) -> () loc(#loc416)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc417)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":712:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":699:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc417)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc417)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_2_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc419)
      aie.use_lock(%direct_w_broadcast_3_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc420)
      %7 = arith.index_cast %5 : i32 to index loc(#loc421)
      %8 = arith.index_cast %7 : index to i64 loc(#loc421)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc421)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_2_cons_buff_0 : memref<4352xui8>) loc(#loc421)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_2_cons_buff_1 : memref<4352xui8>) loc(#loc421)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_2_cons_buff_0 : memref<4352xui8>) loc(#loc421)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":716:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_2_3_cons_buff_0, %9, %direct_acc0_3_2, %direct_dequant_3_2) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc422)
      aie.use_lock(%direct_a_broadcast_2_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc423)
      aie.use_lock(%direct_w_broadcast_3_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc424)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc424)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc424)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc424)
      %13 = arith.addi %4, %c1 : index loc(#loc417)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc417)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_3_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc425)
      %14 = arith.index_cast %2 : i32 to index loc(#loc426)
      %15 = arith.index_cast %14 : index to i64 loc(#loc426)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc426)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_2_buff_0 : memref<512xbf16>) loc(#loc426)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_2_buff_1 : memref<512xbf16>) loc(#loc426)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_2_buff_0 : memref<512xbf16>) loc(#loc426)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":722:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_2, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc427)
      aie.use_lock(%direct_y_worker_3_2_cons_lock_0, Release, %c1_i32) loc(#loc428)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc428)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc428)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc428)
      %20 = arith.addi %0, %c1 : index loc(#loc414)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc414)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc429)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc413)
    %core_3_5 = aie.core(%tile_3_5) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc431)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":733:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":729:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":729:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc431)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc431)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_3_3) : (memref<512xf32>) -> () loc(#loc433)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc434)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":742:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":729:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc434)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc434)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_3_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc436)
      aie.use_lock(%direct_w_broadcast_3_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc437)
      %7 = arith.index_cast %5 : i32 to index loc(#loc438)
      %8 = arith.index_cast %7 : index to i64 loc(#loc438)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc438)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_3_cons_buff_0 : memref<4352xui8>) loc(#loc438)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_3_cons_buff_1 : memref<4352xui8>) loc(#loc438)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_3_3_cons_buff_0 : memref<4352xui8>) loc(#loc438)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":746:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_3_3_cons_buff_0, %9, %direct_acc0_3_3, %direct_dequant_3_3) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc439)
      aie.use_lock(%direct_a_broadcast_3_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc440)
      aie.use_lock(%direct_w_broadcast_3_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc441)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc441)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc441)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc441)
      %13 = arith.addi %4, %c1 : index loc(#loc434)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc434)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_3_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc442)
      %14 = arith.index_cast %2 : i32 to index loc(#loc443)
      %15 = arith.index_cast %14 : index to i64 loc(#loc443)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc443)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_3_buff_0 : memref<512xbf16>) loc(#loc443)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_3_buff_1 : memref<512xbf16>) loc(#loc443)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_3_3_buff_0 : memref<512xbf16>) loc(#loc443)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":752:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_3, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc444)
      aie.use_lock(%direct_y_worker_3_3_cons_lock_0, Release, %c1_i32) loc(#loc445)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc445)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc445)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc445)
      %20 = arith.addi %0, %c1 : index loc(#loc431)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc431)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc446)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc430)
    %core_4_2 = aie.core(%tile_4_2) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc448)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":763:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":759:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":759:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc448)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc448)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_4_0) : (memref<512xf32>) -> () loc(#loc450)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc451)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":772:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":759:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc451)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc451)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_4_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc453)
      aie.use_lock(%direct_w_broadcast_4_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc454)
      %7 = arith.index_cast %5 : i32 to index loc(#loc455)
      %8 = arith.index_cast %7 : index to i64 loc(#loc455)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc455)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_0_cons_buff_0 : memref<4352xui8>) loc(#loc455)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_0_cons_buff_1 : memref<4352xui8>) loc(#loc455)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_0_cons_buff_0 : memref<4352xui8>) loc(#loc455)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":776:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_4_0_cons_buff_0, %9, %direct_acc0_4_0, %direct_dequant_4_0) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc456)
      aie.use_lock(%direct_a_broadcast_4_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc457)
      aie.use_lock(%direct_w_broadcast_4_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc458)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc458)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc458)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc458)
      %13 = arith.addi %4, %c1 : index loc(#loc451)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc451)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_4_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc459)
      %14 = arith.index_cast %2 : i32 to index loc(#loc460)
      %15 = arith.index_cast %14 : index to i64 loc(#loc460)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc460)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_0_buff_0 : memref<512xbf16>) loc(#loc460)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_0_buff_1 : memref<512xbf16>) loc(#loc460)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_0_buff_0 : memref<512xbf16>) loc(#loc460)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":782:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_0, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc461)
      aie.use_lock(%direct_y_worker_4_0_cons_lock_0, Release, %c1_i32) loc(#loc462)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc462)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc462)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc462)
      %20 = arith.addi %0, %c1 : index loc(#loc448)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc448)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc463)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc447)
    %core_4_3 = aie.core(%tile_4_3) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc465)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":793:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":789:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":789:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc465)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc465)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_4_1) : (memref<512xf32>) -> () loc(#loc467)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc468)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":802:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":789:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc468)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc468)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_5_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc470)
      aie.use_lock(%direct_w_broadcast_4_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc471)
      %7 = arith.index_cast %5 : i32 to index loc(#loc472)
      %8 = arith.index_cast %7 : index to i64 loc(#loc472)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc472)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_1_cons_buff_0 : memref<4352xui8>) loc(#loc472)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_1_cons_buff_1 : memref<4352xui8>) loc(#loc472)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_1_cons_buff_0 : memref<4352xui8>) loc(#loc472)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":806:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_5_0_cons_buff_0, %9, %direct_acc0_4_1, %direct_dequant_4_1) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc473)
      aie.use_lock(%direct_a_broadcast_5_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc474)
      aie.use_lock(%direct_w_broadcast_4_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc475)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc475)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc475)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc475)
      %13 = arith.addi %4, %c1 : index loc(#loc468)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc468)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_4_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc476)
      %14 = arith.index_cast %2 : i32 to index loc(#loc477)
      %15 = arith.index_cast %14 : index to i64 loc(#loc477)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc477)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_1_buff_0 : memref<512xbf16>) loc(#loc477)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_1_buff_1 : memref<512xbf16>) loc(#loc477)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_1_buff_0 : memref<512xbf16>) loc(#loc477)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":812:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_1, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc478)
      aie.use_lock(%direct_y_worker_4_1_cons_lock_0, Release, %c1_i32) loc(#loc479)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc479)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc479)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc479)
      %20 = arith.addi %0, %c1 : index loc(#loc465)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc465)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc480)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc464)
    %core_4_4 = aie.core(%tile_4_4) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc482)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":823:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":819:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":819:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc482)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc482)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_4_2) : (memref<512xf32>) -> () loc(#loc484)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc485)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":832:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":819:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc485)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc485)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_6_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc487)
      aie.use_lock(%direct_w_broadcast_4_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc488)
      %7 = arith.index_cast %5 : i32 to index loc(#loc489)
      %8 = arith.index_cast %7 : index to i64 loc(#loc489)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc489)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_2_cons_buff_0 : memref<4352xui8>) loc(#loc489)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_2_cons_buff_1 : memref<4352xui8>) loc(#loc489)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_2_cons_buff_0 : memref<4352xui8>) loc(#loc489)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":836:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_6_0_cons_buff_0, %9, %direct_acc0_4_2, %direct_dequant_4_2) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc490)
      aie.use_lock(%direct_a_broadcast_6_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc491)
      aie.use_lock(%direct_w_broadcast_4_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc492)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc492)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc492)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc492)
      %13 = arith.addi %4, %c1 : index loc(#loc485)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc485)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_4_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc493)
      %14 = arith.index_cast %2 : i32 to index loc(#loc494)
      %15 = arith.index_cast %14 : index to i64 loc(#loc494)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc494)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_2_buff_0 : memref<512xbf16>) loc(#loc494)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_2_buff_1 : memref<512xbf16>) loc(#loc494)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_2_buff_0 : memref<512xbf16>) loc(#loc494)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":842:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_2, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc495)
      aie.use_lock(%direct_y_worker_4_2_cons_lock_0, Release, %c1_i32) loc(#loc496)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc496)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc496)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc496)
      %20 = arith.addi %0, %c1 : index loc(#loc482)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc482)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc497)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc481)
    %core_4_5 = aie.core(%tile_4_5) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc499)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":853:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":849:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":849:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc499)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc499)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_4_3) : (memref<512xf32>) -> () loc(#loc501)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc502)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":862:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":849:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc502)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc502)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_7_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc504)
      aie.use_lock(%direct_w_broadcast_4_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc505)
      %7 = arith.index_cast %5 : i32 to index loc(#loc506)
      %8 = arith.index_cast %7 : index to i64 loc(#loc506)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc506)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_3_cons_buff_0 : memref<4352xui8>) loc(#loc506)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_3_cons_buff_1 : memref<4352xui8>) loc(#loc506)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_4_3_cons_buff_0 : memref<4352xui8>) loc(#loc506)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":866:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_7_0_cons_buff_0, %9, %direct_acc0_4_3, %direct_dequant_4_3) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc507)
      aie.use_lock(%direct_a_broadcast_7_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc508)
      aie.use_lock(%direct_w_broadcast_4_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc509)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc509)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc509)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc509)
      %13 = arith.addi %4, %c1 : index loc(#loc502)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc502)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_4_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc510)
      %14 = arith.index_cast %2 : i32 to index loc(#loc511)
      %15 = arith.index_cast %14 : index to i64 loc(#loc511)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc511)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_3_buff_0 : memref<512xbf16>) loc(#loc511)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_3_buff_1 : memref<512xbf16>) loc(#loc511)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_4_3_buff_0 : memref<512xbf16>) loc(#loc511)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":872:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_3, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc512)
      aie.use_lock(%direct_y_worker_4_3_cons_lock_0, Release, %c1_i32) loc(#loc513)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc513)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc513)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc513)
      %20 = arith.addi %0, %c1 : index loc(#loc499)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc499)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc514)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc498)
    %core_5_2 = aie.core(%tile_5_2) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc516)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":883:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":879:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":879:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc516)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc516)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_5_0) : (memref<512xf32>) -> () loc(#loc518)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc519)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":892:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":879:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc519)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc519)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_4_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc521)
      aie.use_lock(%direct_w_broadcast_5_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc522)
      %7 = arith.index_cast %5 : i32 to index loc(#loc523)
      %8 = arith.index_cast %7 : index to i64 loc(#loc523)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc523)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_0_cons_buff_0 : memref<4352xui8>) loc(#loc523)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_0_cons_buff_1 : memref<4352xui8>) loc(#loc523)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_0_cons_buff_0 : memref<4352xui8>) loc(#loc523)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":896:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_4_1_cons_buff_0, %9, %direct_acc0_5_0, %direct_dequant_5_0) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc524)
      aie.use_lock(%direct_a_broadcast_4_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc525)
      aie.use_lock(%direct_w_broadcast_5_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc526)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc526)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc526)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc526)
      %13 = arith.addi %4, %c1 : index loc(#loc519)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc519)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_5_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc527)
      %14 = arith.index_cast %2 : i32 to index loc(#loc528)
      %15 = arith.index_cast %14 : index to i64 loc(#loc528)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc528)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_0_buff_0 : memref<512xbf16>) loc(#loc528)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_0_buff_1 : memref<512xbf16>) loc(#loc528)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_0_buff_0 : memref<512xbf16>) loc(#loc528)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":902:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_0, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc529)
      aie.use_lock(%direct_y_worker_5_0_cons_lock_0, Release, %c1_i32) loc(#loc530)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc530)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc530)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc530)
      %20 = arith.addi %0, %c1 : index loc(#loc516)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc516)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc531)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc515)
    %core_5_3 = aie.core(%tile_5_3) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc533)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":913:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":909:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":909:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc533)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc533)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_5_1) : (memref<512xf32>) -> () loc(#loc535)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc536)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":922:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":909:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc536)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc536)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_5_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc538)
      aie.use_lock(%direct_w_broadcast_5_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc539)
      %7 = arith.index_cast %5 : i32 to index loc(#loc540)
      %8 = arith.index_cast %7 : index to i64 loc(#loc540)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc540)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_1_cons_buff_0 : memref<4352xui8>) loc(#loc540)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_1_cons_buff_1 : memref<4352xui8>) loc(#loc540)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_1_cons_buff_0 : memref<4352xui8>) loc(#loc540)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":926:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_5_1_cons_buff_0, %9, %direct_acc0_5_1, %direct_dequant_5_1) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc541)
      aie.use_lock(%direct_a_broadcast_5_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc542)
      aie.use_lock(%direct_w_broadcast_5_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc543)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc543)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc543)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc543)
      %13 = arith.addi %4, %c1 : index loc(#loc536)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc536)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_5_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc544)
      %14 = arith.index_cast %2 : i32 to index loc(#loc545)
      %15 = arith.index_cast %14 : index to i64 loc(#loc545)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc545)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_1_buff_0 : memref<512xbf16>) loc(#loc545)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_1_buff_1 : memref<512xbf16>) loc(#loc545)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_1_buff_0 : memref<512xbf16>) loc(#loc545)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":932:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_1, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc546)
      aie.use_lock(%direct_y_worker_5_1_cons_lock_0, Release, %c1_i32) loc(#loc547)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc547)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc547)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc547)
      %20 = arith.addi %0, %c1 : index loc(#loc533)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc533)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc548)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc532)
    %core_5_4 = aie.core(%tile_5_4) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc550)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":943:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":939:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":939:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc550)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc550)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_5_2) : (memref<512xf32>) -> () loc(#loc552)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc553)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":952:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":939:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc553)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc553)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_6_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc555)
      aie.use_lock(%direct_w_broadcast_5_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc556)
      %7 = arith.index_cast %5 : i32 to index loc(#loc557)
      %8 = arith.index_cast %7 : index to i64 loc(#loc557)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc557)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_2_cons_buff_0 : memref<4352xui8>) loc(#loc557)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_2_cons_buff_1 : memref<4352xui8>) loc(#loc557)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_2_cons_buff_0 : memref<4352xui8>) loc(#loc557)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":956:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_6_1_cons_buff_0, %9, %direct_acc0_5_2, %direct_dequant_5_2) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc558)
      aie.use_lock(%direct_a_broadcast_6_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc559)
      aie.use_lock(%direct_w_broadcast_5_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc560)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc560)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc560)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc560)
      %13 = arith.addi %4, %c1 : index loc(#loc553)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc553)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_5_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc561)
      %14 = arith.index_cast %2 : i32 to index loc(#loc562)
      %15 = arith.index_cast %14 : index to i64 loc(#loc562)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc562)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_2_buff_0 : memref<512xbf16>) loc(#loc562)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_2_buff_1 : memref<512xbf16>) loc(#loc562)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_2_buff_0 : memref<512xbf16>) loc(#loc562)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":962:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_2, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc563)
      aie.use_lock(%direct_y_worker_5_2_cons_lock_0, Release, %c1_i32) loc(#loc564)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc564)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc564)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc564)
      %20 = arith.addi %0, %c1 : index loc(#loc550)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc550)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc565)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc549)
    %core_5_5 = aie.core(%tile_5_5) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc567)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":973:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":969:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":969:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc567)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc567)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_5_3) : (memref<512xf32>) -> () loc(#loc569)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc570)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":982:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":969:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc570)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc570)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_7_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc572)
      aie.use_lock(%direct_w_broadcast_5_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc573)
      %7 = arith.index_cast %5 : i32 to index loc(#loc574)
      %8 = arith.index_cast %7 : index to i64 loc(#loc574)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc574)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_3_cons_buff_0 : memref<4352xui8>) loc(#loc574)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_3_cons_buff_1 : memref<4352xui8>) loc(#loc574)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_5_3_cons_buff_0 : memref<4352xui8>) loc(#loc574)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":986:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_7_1_cons_buff_0, %9, %direct_acc0_5_3, %direct_dequant_5_3) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc575)
      aie.use_lock(%direct_a_broadcast_7_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc576)
      aie.use_lock(%direct_w_broadcast_5_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc577)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc577)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc577)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc577)
      %13 = arith.addi %4, %c1 : index loc(#loc570)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc570)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_5_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc578)
      %14 = arith.index_cast %2 : i32 to index loc(#loc579)
      %15 = arith.index_cast %14 : index to i64 loc(#loc579)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc579)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_3_buff_0 : memref<512xbf16>) loc(#loc579)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_3_buff_1 : memref<512xbf16>) loc(#loc579)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_5_3_buff_0 : memref<512xbf16>) loc(#loc579)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":992:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_3, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc580)
      aie.use_lock(%direct_y_worker_5_3_cons_lock_0, Release, %c1_i32) loc(#loc581)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc581)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc581)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc581)
      %20 = arith.addi %0, %c1 : index loc(#loc567)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc567)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc582)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc566)
    %core_6_2 = aie.core(%tile_6_2) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc584)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1003:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":999:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":999:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc584)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc584)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_6_0) : (memref<512xf32>) -> () loc(#loc586)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc587)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1012:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":999:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc587)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc587)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_4_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc589)
      aie.use_lock(%direct_w_broadcast_6_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc590)
      %7 = arith.index_cast %5 : i32 to index loc(#loc591)
      %8 = arith.index_cast %7 : index to i64 loc(#loc591)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc591)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_0_cons_buff_0 : memref<4352xui8>) loc(#loc591)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_0_cons_buff_1 : memref<4352xui8>) loc(#loc591)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_0_cons_buff_0 : memref<4352xui8>) loc(#loc591)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1016:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_4_2_cons_buff_0, %9, %direct_acc0_6_0, %direct_dequant_6_0) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc592)
      aie.use_lock(%direct_a_broadcast_4_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc593)
      aie.use_lock(%direct_w_broadcast_6_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc594)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc594)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc594)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc594)
      %13 = arith.addi %4, %c1 : index loc(#loc587)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc587)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_6_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc595)
      %14 = arith.index_cast %2 : i32 to index loc(#loc596)
      %15 = arith.index_cast %14 : index to i64 loc(#loc596)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc596)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_0_buff_0 : memref<512xbf16>) loc(#loc596)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_0_buff_1 : memref<512xbf16>) loc(#loc596)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_0_buff_0 : memref<512xbf16>) loc(#loc596)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1022:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_0, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc597)
      aie.use_lock(%direct_y_worker_6_0_cons_lock_0, Release, %c1_i32) loc(#loc598)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc598)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc598)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc598)
      %20 = arith.addi %0, %c1 : index loc(#loc584)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc584)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc599)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc583)
    %core_6_3 = aie.core(%tile_6_3) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc601)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1033:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1029:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1029:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc601)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc601)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_6_1) : (memref<512xf32>) -> () loc(#loc603)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc604)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1042:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1029:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc604)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc604)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_5_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc606)
      aie.use_lock(%direct_w_broadcast_6_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc607)
      %7 = arith.index_cast %5 : i32 to index loc(#loc608)
      %8 = arith.index_cast %7 : index to i64 loc(#loc608)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc608)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_1_cons_buff_0 : memref<4352xui8>) loc(#loc608)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_1_cons_buff_1 : memref<4352xui8>) loc(#loc608)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_1_cons_buff_0 : memref<4352xui8>) loc(#loc608)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1046:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_5_2_cons_buff_0, %9, %direct_acc0_6_1, %direct_dequant_6_1) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc609)
      aie.use_lock(%direct_a_broadcast_5_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc610)
      aie.use_lock(%direct_w_broadcast_6_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc611)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc611)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc611)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc611)
      %13 = arith.addi %4, %c1 : index loc(#loc604)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc604)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_6_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc612)
      %14 = arith.index_cast %2 : i32 to index loc(#loc613)
      %15 = arith.index_cast %14 : index to i64 loc(#loc613)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc613)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_1_buff_0 : memref<512xbf16>) loc(#loc613)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_1_buff_1 : memref<512xbf16>) loc(#loc613)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_1_buff_0 : memref<512xbf16>) loc(#loc613)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1052:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_1, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc614)
      aie.use_lock(%direct_y_worker_6_1_cons_lock_0, Release, %c1_i32) loc(#loc615)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc615)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc615)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc615)
      %20 = arith.addi %0, %c1 : index loc(#loc601)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc601)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc616)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc600)
    %core_6_4 = aie.core(%tile_6_4) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc618)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1063:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1059:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1059:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc618)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc618)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_6_2) : (memref<512xf32>) -> () loc(#loc620)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc621)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1072:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1059:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc621)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc621)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_6_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc623)
      aie.use_lock(%direct_w_broadcast_6_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc624)
      %7 = arith.index_cast %5 : i32 to index loc(#loc625)
      %8 = arith.index_cast %7 : index to i64 loc(#loc625)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc625)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_2_cons_buff_0 : memref<4352xui8>) loc(#loc625)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_2_cons_buff_1 : memref<4352xui8>) loc(#loc625)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_2_cons_buff_0 : memref<4352xui8>) loc(#loc625)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1076:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_6_2_cons_buff_0, %9, %direct_acc0_6_2, %direct_dequant_6_2) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc626)
      aie.use_lock(%direct_a_broadcast_6_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc627)
      aie.use_lock(%direct_w_broadcast_6_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc628)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc628)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc628)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc628)
      %13 = arith.addi %4, %c1 : index loc(#loc621)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc621)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_6_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc629)
      %14 = arith.index_cast %2 : i32 to index loc(#loc630)
      %15 = arith.index_cast %14 : index to i64 loc(#loc630)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc630)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_2_buff_0 : memref<512xbf16>) loc(#loc630)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_2_buff_1 : memref<512xbf16>) loc(#loc630)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_2_buff_0 : memref<512xbf16>) loc(#loc630)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1082:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_2, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc631)
      aie.use_lock(%direct_y_worker_6_2_cons_lock_0, Release, %c1_i32) loc(#loc632)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc632)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc632)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc632)
      %20 = arith.addi %0, %c1 : index loc(#loc618)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc618)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc633)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc617)
    %core_6_5 = aie.core(%tile_6_5) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc635)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1093:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1089:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1089:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc635)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc635)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_6_3) : (memref<512xf32>) -> () loc(#loc637)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc638)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1102:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1089:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc638)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc638)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_7_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc640)
      aie.use_lock(%direct_w_broadcast_6_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc641)
      %7 = arith.index_cast %5 : i32 to index loc(#loc642)
      %8 = arith.index_cast %7 : index to i64 loc(#loc642)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc642)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_3_cons_buff_0 : memref<4352xui8>) loc(#loc642)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_3_cons_buff_1 : memref<4352xui8>) loc(#loc642)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_6_3_cons_buff_0 : memref<4352xui8>) loc(#loc642)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1106:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_low(%direct_a_broadcast_7_2_cons_buff_0, %9, %direct_acc0_6_3, %direct_dequant_6_3) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc643)
      aie.use_lock(%direct_a_broadcast_7_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc644)
      aie.use_lock(%direct_w_broadcast_6_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc645)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc645)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc645)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc645)
      %13 = arith.addi %4, %c1 : index loc(#loc638)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc638)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_6_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc646)
      %14 = arith.index_cast %2 : i32 to index loc(#loc647)
      %15 = arith.index_cast %14 : index to i64 loc(#loc647)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc647)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_3_buff_0 : memref<512xbf16>) loc(#loc647)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_3_buff_1 : memref<512xbf16>) loc(#loc647)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_6_3_buff_0 : memref<512xbf16>) loc(#loc647)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1112:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_3, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc648)
      aie.use_lock(%direct_y_worker_6_3_cons_lock_0, Release, %c1_i32) loc(#loc649)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc649)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc649)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc649)
      %20 = arith.addi %0, %c1 : index loc(#loc635)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc635)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc650)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc634)
    %core_7_2 = aie.core(%tile_7_2) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc652)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1123:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1119:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1119:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc652)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc652)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_7_0) : (memref<512xf32>) -> () loc(#loc654)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc655)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1132:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1119:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc655)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc655)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_4_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc657)
      aie.use_lock(%direct_w_broadcast_7_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc658)
      %7 = arith.index_cast %5 : i32 to index loc(#loc659)
      %8 = arith.index_cast %7 : index to i64 loc(#loc659)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc659)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_0_cons_buff_0 : memref<4352xui8>) loc(#loc659)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_0_cons_buff_1 : memref<4352xui8>) loc(#loc659)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_0_cons_buff_0 : memref<4352xui8>) loc(#loc659)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1136:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_4_3_cons_buff_0, %9, %direct_acc0_7_0, %direct_dequant_7_0) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc660)
      aie.use_lock(%direct_a_broadcast_4_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc661)
      aie.use_lock(%direct_w_broadcast_7_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc662)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc662)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc662)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc662)
      %13 = arith.addi %4, %c1 : index loc(#loc655)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc655)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_7_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc663)
      %14 = arith.index_cast %2 : i32 to index loc(#loc664)
      %15 = arith.index_cast %14 : index to i64 loc(#loc664)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc664)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_0_buff_0 : memref<512xbf16>) loc(#loc664)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_0_buff_1 : memref<512xbf16>) loc(#loc664)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_0_buff_0 : memref<512xbf16>) loc(#loc664)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1142:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_0, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc665)
      aie.use_lock(%direct_y_worker_7_0_cons_lock_0, Release, %c1_i32) loc(#loc666)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc666)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc666)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc666)
      %20 = arith.addi %0, %c1 : index loc(#loc652)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc652)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc667)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc651)
    %core_7_3 = aie.core(%tile_7_3) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc669)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1153:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1149:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1149:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc669)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc669)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_7_1) : (memref<512xf32>) -> () loc(#loc671)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc672)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1162:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1149:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc672)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc672)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_5_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc674)
      aie.use_lock(%direct_w_broadcast_7_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc675)
      %7 = arith.index_cast %5 : i32 to index loc(#loc676)
      %8 = arith.index_cast %7 : index to i64 loc(#loc676)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc676)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_1_cons_buff_0 : memref<4352xui8>) loc(#loc676)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_1_cons_buff_1 : memref<4352xui8>) loc(#loc676)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_1_cons_buff_0 : memref<4352xui8>) loc(#loc676)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1166:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_5_3_cons_buff_0, %9, %direct_acc0_7_1, %direct_dequant_7_1) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc677)
      aie.use_lock(%direct_a_broadcast_5_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc678)
      aie.use_lock(%direct_w_broadcast_7_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc679)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc679)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc679)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc679)
      %13 = arith.addi %4, %c1 : index loc(#loc672)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc672)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_7_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc680)
      %14 = arith.index_cast %2 : i32 to index loc(#loc681)
      %15 = arith.index_cast %14 : index to i64 loc(#loc681)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc681)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_1_buff_0 : memref<512xbf16>) loc(#loc681)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_1_buff_1 : memref<512xbf16>) loc(#loc681)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_1_buff_0 : memref<512xbf16>) loc(#loc681)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1172:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_1, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc682)
      aie.use_lock(%direct_y_worker_7_1_cons_lock_0, Release, %c1_i32) loc(#loc683)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc683)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc683)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc683)
      %20 = arith.addi %0, %c1 : index loc(#loc669)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc669)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc684)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc668)
    %core_7_4 = aie.core(%tile_7_4) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc686)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1183:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1179:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1179:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc686)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc686)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_7_2) : (memref<512xf32>) -> () loc(#loc688)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc689)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1192:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1179:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc689)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc689)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_6_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc691)
      aie.use_lock(%direct_w_broadcast_7_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc692)
      %7 = arith.index_cast %5 : i32 to index loc(#loc693)
      %8 = arith.index_cast %7 : index to i64 loc(#loc693)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc693)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_2_cons_buff_0 : memref<4352xui8>) loc(#loc693)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_2_cons_buff_1 : memref<4352xui8>) loc(#loc693)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_2_cons_buff_0 : memref<4352xui8>) loc(#loc693)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1196:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_6_3_cons_buff_0, %9, %direct_acc0_7_2, %direct_dequant_7_2) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc694)
      aie.use_lock(%direct_a_broadcast_6_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc695)
      aie.use_lock(%direct_w_broadcast_7_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc696)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc696)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc696)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc696)
      %13 = arith.addi %4, %c1 : index loc(#loc689)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc689)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_7_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc697)
      %14 = arith.index_cast %2 : i32 to index loc(#loc698)
      %15 = arith.index_cast %14 : index to i64 loc(#loc698)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc698)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_2_buff_0 : memref<512xbf16>) loc(#loc698)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_2_buff_1 : memref<512xbf16>) loc(#loc698)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_2_buff_0 : memref<512xbf16>) loc(#loc698)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1202:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_2, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc699)
      aie.use_lock(%direct_y_worker_7_2_cons_lock_0, Release, %c1_i32) loc(#loc700)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc700)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc700)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc700)
      %20 = arith.addi %0, %c1 : index loc(#loc686)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc686)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc701)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc685)
    %core_7_5 = aie.core(%tile_7_5) {
      %c1 = arith.constant 1 : index loc(#loc175)
      %c9223372036854775807 = arith.constant 9223372036854775807 : index loc(#loc175)
      %c0 = arith.constant 0 : index loc(#loc175)
      %c2 = arith.constant 2 : index loc(#loc175)
      %c0_i32 = arith.constant 0 : i32 loc(#loc175)
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %c2_i32 = arith.constant 2 : i32 loc(#loc175)
      cf.br ^bb1(%c0, %c0_i32, %c0_i32 : index, i32, i32) loc(#loc703)
    ^bb1(%0: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1213:15), %1: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1209:17), %2: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1209:17)):  // 2 preds: ^bb0, ^bb13
      %3 = arith.cmpi slt, %0, %c9223372036854775807 : index loc(#loc703)
      cf.cond_br %3, ^bb2, ^bb14 loc(#loc703)
    ^bb2:  // pred: ^bb1
      func.call @w4a16_prefill_reuse_init(%direct_acc0_7_3) : (memref<512xf32>) -> () loc(#loc705)
      cf.br ^bb3(%c0, %1 : index, i32) loc(#loc706)
    ^bb3(%4: index loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1222:19), %5: i32 loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1209:17)):  // 2 preds: ^bb2, ^bb8
      %6 = arith.cmpi slt, %4, %c2 : index loc(#loc706)
      cf.cond_br %6, ^bb4, ^bb9 loc(#loc706)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_a_broadcast_7_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc708)
      aie.use_lock(%direct_w_broadcast_7_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc709)
      %7 = arith.index_cast %5 : i32 to index loc(#loc710)
      %8 = arith.index_cast %7 : index to i64 loc(#loc710)
      cf.switch %8 : i64, [
        default: ^bb7,
        0: ^bb5,
        1: ^bb6
      ] loc(#loc710)
    ^bb5:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_3_cons_buff_0 : memref<4352xui8>) loc(#loc710)
    ^bb6:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_3_cons_buff_1 : memref<4352xui8>) loc(#loc710)
    ^bb7:  // pred: ^bb4
      cf.br ^bb8(%direct_w_broadcast_7_3_cons_buff_0 : memref<4352xui8>) loc(#loc710)
    ^bb8(%9: memref<4352xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1226:18)):  // 3 preds: ^bb5, ^bb6, ^bb7
      func.call @w4a16_prefill_reuse_accumulate_high(%direct_a_broadcast_7_3_cons_buff_0, %9, %direct_acc0_7_3, %direct_dequant_7_3) : (memref<2048xbf16>, memref<4352xui8>, memref<512xf32>, memref<4096xbf16>) -> () loc(#loc711)
      aie.use_lock(%direct_a_broadcast_7_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc712)
      aie.use_lock(%direct_w_broadcast_7_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc713)
      %10 = arith.addi %5, %c1_i32 : i32 loc(#loc713)
      %11 = arith.cmpi sge, %10, %c2_i32 : i32 loc(#loc713)
      %12 = arith.select %11, %c0_i32, %10 : i32 loc(#loc713)
      %13 = arith.addi %4, %c1 : index loc(#loc706)
      cf.br ^bb3(%13, %12 : index, i32) loc(#loc706)
    ^bb9:  // pred: ^bb3
      aie.use_lock(%direct_y_worker_7_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc714)
      %14 = arith.index_cast %2 : i32 to index loc(#loc715)
      %15 = arith.index_cast %14 : index to i64 loc(#loc715)
      cf.switch %15 : i64, [
        default: ^bb12,
        0: ^bb10,
        1: ^bb11
      ] loc(#loc715)
    ^bb10:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_3_buff_0 : memref<512xbf16>) loc(#loc715)
    ^bb11:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_3_buff_1 : memref<512xbf16>) loc(#loc715)
    ^bb12:  // pred: ^bb9
      cf.br ^bb13(%direct_y_worker_7_3_buff_0 : memref<512xbf16>) loc(#loc715)
    ^bb13(%16: memref<512xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1232:16)):  // 3 preds: ^bb10, ^bb11, ^bb12
      func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_3, %16) : (memref<512xf32>, memref<512xbf16>) -> () loc(#loc716)
      aie.use_lock(%direct_y_worker_7_3_cons_lock_0, Release, %c1_i32) loc(#loc717)
      %17 = arith.addi %2, %c1_i32 : i32 loc(#loc717)
      %18 = arith.cmpi sge, %17, %c2_i32 : i32 loc(#loc717)
      %19 = arith.select %18, %c0_i32, %17 : i32 loc(#loc717)
      %20 = arith.addi %0, %c1 : index loc(#loc703)
      cf.br ^bb1(%20, %5, %19 : index, i32, i32) loc(#loc703)
    ^bb14:  // pred: ^bb1
      aie.end loc(#loc718)
    } {dynamic_objfifo_lowering = true, link_files = ["w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r1_vectorzero1_mmulmreuse1.o"], stack_size = 2048 : i32} loc(#loc702)
    aie.runtime_sequence(%arg0: memref<32768xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1239:26), %arg1: memref<278528xui8> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1239:53), %arg2: memref<16384xbf16> loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1239:80)) {
      %0 = aiex.dma_configure_task_for @direct_y_host_0_shim_alloc {
        aie.dma_bd(%arg2 : memref<16384xbf16> offset = 0 len = 2048 sizes = [1, 1, 4, 512] strides = [0, 0, 2048, 1]) loc(#loc724)
        aie.end loc(#loc725)
      } {issue_token = true} loc(#loc723)
      aiex.dma_start_task(%0) loc(#loc726)
      %1 = aiex.dma_configure_task_for @direct_y_host_1_shim_alloc {
        aie.dma_bd(%arg2 : memref<16384xbf16> offset = 512 len = 2048 sizes = [1, 1, 4, 512] strides = [0, 0, 2048, 1]) loc(#loc728)
        aie.end loc(#loc729)
      } {issue_token = true} loc(#loc727)
      aiex.dma_start_task(%1) loc(#loc730)
      %2 = aiex.dma_configure_task_for @direct_y_host_2_shim_alloc {
        aie.dma_bd(%arg2 : memref<16384xbf16> offset = 1024 len = 2048 sizes = [1, 1, 4, 512] strides = [0, 0, 2048, 1]) loc(#loc732)
        aie.end loc(#loc733)
      } {issue_token = true} loc(#loc731)
      aiex.dma_start_task(%2) loc(#loc734)
      %3 = aiex.dma_configure_task_for @direct_y_host_3_shim_alloc {
        aie.dma_bd(%arg2 : memref<16384xbf16> offset = 1536 len = 2048 sizes = [1, 1, 4, 512] strides = [0, 0, 2048, 1]) loc(#loc736)
        aie.end loc(#loc737)
      } {issue_token = true} loc(#loc735)
      aiex.dma_start_task(%3) loc(#loc738)
      %4 = aiex.dma_configure_task_for @direct_y_host_4_shim_alloc {
        aie.dma_bd(%arg2 : memref<16384xbf16> offset = 8192 len = 2048 sizes = [1, 1, 4, 512] strides = [0, 0, 2048, 1]) loc(#loc740)
        aie.end loc(#loc741)
      } {issue_token = true} loc(#loc739)
      aiex.dma_start_task(%4) loc(#loc742)
      %5 = aiex.dma_configure_task_for @direct_y_host_5_shim_alloc {
        aie.dma_bd(%arg2 : memref<16384xbf16> offset = 8704 len = 2048 sizes = [1, 1, 4, 512] strides = [0, 0, 2048, 1]) loc(#loc744)
        aie.end loc(#loc745)
      } {issue_token = true} loc(#loc743)
      aiex.dma_start_task(%5) loc(#loc746)
      %6 = aiex.dma_configure_task_for @direct_y_host_6_shim_alloc {
        aie.dma_bd(%arg2 : memref<16384xbf16> offset = 9216 len = 2048 sizes = [1, 1, 4, 512] strides = [0, 0, 2048, 1]) loc(#loc748)
        aie.end loc(#loc749)
      } {issue_token = true} loc(#loc747)
      aiex.dma_start_task(%6) loc(#loc750)
      %7 = aiex.dma_configure_task_for @direct_y_host_7_shim_alloc {
        aie.dma_bd(%arg2 : memref<16384xbf16> offset = 9728 len = 2048 sizes = [1, 1, 4, 512] strides = [0, 0, 2048, 1]) loc(#loc752)
        aie.end loc(#loc753)
      } {issue_token = true} loc(#loc751)
      aiex.dma_start_task(%7) loc(#loc754)
      %8 = aiex.dma_configure_task_for @direct_a_host_0_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 0 len = 4096 sizes = [1, 8, 1, 512] strides = [0, 512, 4096, 1]) loc(#loc756)
        aie.end loc(#loc757)
      } loc(#loc755)
      aiex.dma_start_task(%8) loc(#loc758)
      %9 = aiex.dma_configure_task_for @direct_a_host_1_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 4096 len = 4096 sizes = [1, 8, 1, 512] strides = [0, 512, 4096, 1]) loc(#loc760)
        aie.end loc(#loc761)
      } loc(#loc759)
      aiex.dma_start_task(%9) loc(#loc762)
      %10 = aiex.dma_configure_task_for @direct_a_host_2_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 8192 len = 4096 sizes = [1, 8, 1, 512] strides = [0, 512, 4096, 1]) loc(#loc764)
        aie.end loc(#loc765)
      } loc(#loc763)
      aiex.dma_start_task(%10) loc(#loc766)
      %11 = aiex.dma_configure_task_for @direct_a_host_3_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 12288 len = 4096 sizes = [1, 8, 1, 512] strides = [0, 512, 4096, 1]) loc(#loc768)
        aie.end loc(#loc769)
      } loc(#loc767)
      aiex.dma_start_task(%11) loc(#loc770)
      %12 = aiex.dma_configure_task_for @direct_a_host_4_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 16384 len = 4096 sizes = [1, 8, 1, 512] strides = [0, 512, 4096, 1]) loc(#loc772)
        aie.end loc(#loc773)
      } loc(#loc771)
      aiex.dma_start_task(%12) loc(#loc774)
      %13 = aiex.dma_configure_task_for @direct_a_host_5_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 20480 len = 4096 sizes = [1, 8, 1, 512] strides = [0, 512, 4096, 1]) loc(#loc776)
        aie.end loc(#loc777)
      } loc(#loc775)
      aiex.dma_start_task(%13) loc(#loc778)
      %14 = aiex.dma_configure_task_for @direct_a_host_6_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 24576 len = 4096 sizes = [1, 8, 1, 512] strides = [0, 512, 4096, 1]) loc(#loc780)
        aie.end loc(#loc781)
      } loc(#loc779)
      aiex.dma_start_task(%14) loc(#loc782)
      %15 = aiex.dma_configure_task_for @direct_a_host_7_shim_alloc {
        aie.dma_bd(%arg0 : memref<32768xbf16> offset = 28672 len = 4096 sizes = [1, 8, 1, 512] strides = [0, 512, 4096, 1]) loc(#loc784)
        aie.end loc(#loc785)
      } loc(#loc783)
      aiex.dma_start_task(%15) loc(#loc786)
      %16 = aiex.dma_configure_task_for @direct_w_host_0_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 39168 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc788)
        aie.end loc(#loc789)
      } loc(#loc787)
      aiex.dma_start_task(%16) loc(#loc790)
      %17 = aiex.dma_configure_task_for @direct_w_host_1_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 39168 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc792)
        aie.end loc(#loc793)
      } loc(#loc791)
      aiex.dma_start_task(%17) loc(#loc794)
      %18 = aiex.dma_configure_task_for @direct_w_host_2_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 73984 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc796)
        aie.end loc(#loc797)
      } loc(#loc795)
      aiex.dma_start_task(%18) loc(#loc798)
      %19 = aiex.dma_configure_task_for @direct_w_host_3_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 73984 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc800)
        aie.end loc(#loc801)
      } loc(#loc799)
      aiex.dma_start_task(%19) loc(#loc802)
      %20 = aiex.dma_configure_task_for @direct_w_host_4_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 39168 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc804)
        aie.end loc(#loc805)
      } loc(#loc803)
      aiex.dma_start_task(%20) loc(#loc806)
      %21 = aiex.dma_configure_task_for @direct_w_host_5_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 39168 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc808)
        aie.end loc(#loc809)
      } loc(#loc807)
      aiex.dma_start_task(%21) loc(#loc810)
      %22 = aiex.dma_configure_task_for @direct_w_host_6_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 73984 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc812)
        aie.end loc(#loc813)
      } loc(#loc811)
      aiex.dma_start_task(%22) loc(#loc814)
      %23 = aiex.dma_configure_task_for @direct_w_host_7_shim_alloc {
        aie.dma_bd(%arg1 : memref<278528xui8> offset = 73984 len = 8704 sizes = [1, 1, 1, 8704] strides = [0, 0, 0, 1]) loc(#loc816)
        aie.end loc(#loc817)
      } loc(#loc815)
      aiex.dma_start_task(%23) loc(#loc818)
      aiex.dma_await_task(%0) loc(#loc819)
      aiex.dma_await_task(%1) loc(#loc820)
      aiex.dma_await_task(%2) loc(#loc821)
      aiex.dma_await_task(%3) loc(#loc822)
      aiex.dma_await_task(%4) loc(#loc823)
      aiex.dma_await_task(%5) loc(#loc824)
      aiex.dma_await_task(%6) loc(#loc825)
      aiex.dma_await_task(%7) loc(#loc826)
      aiex.dma_free_task(%0) loc(#loc827)
      aiex.dma_free_task(%1) loc(#loc828)
      aiex.dma_free_task(%2) loc(#loc829)
      aiex.dma_free_task(%3) loc(#loc830)
      aiex.dma_free_task(%4) loc(#loc831)
      aiex.dma_free_task(%5) loc(#loc832)
      aiex.dma_free_task(%6) loc(#loc833)
      aiex.dma_free_task(%7) loc(#loc834)
      aiex.dma_free_task(%8) loc(#loc835)
      aiex.dma_free_task(%9) loc(#loc836)
      aiex.dma_free_task(%10) loc(#loc837)
      aiex.dma_free_task(%11) loc(#loc838)
      aiex.dma_free_task(%12) loc(#loc839)
      aiex.dma_free_task(%13) loc(#loc840)
      aiex.dma_free_task(%14) loc(#loc841)
      aiex.dma_free_task(%15) loc(#loc842)
      aiex.dma_free_task(%16) loc(#loc843)
      aiex.dma_free_task(%17) loc(#loc844)
      aiex.dma_free_task(%18) loc(#loc845)
      aiex.dma_free_task(%19) loc(#loc846)
      aiex.dma_free_task(%20) loc(#loc847)
      aiex.dma_free_task(%21) loc(#loc848)
      aiex.dma_free_task(%22) loc(#loc849)
      aiex.dma_free_task(%23) loc(#loc850)
    } loc(#loc719)
    %memtile_dma_0_1 = aie.memtile_dma(%mem_tile_0_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc73)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_host_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc63)
      aie.use_lock(%direct_a_host_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb2 loc(#loc63)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_host_0_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc63)
      aie.use_lock(%direct_a_host_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb1 loc(#loc63)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc63)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_host_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc63)
      aie.use_lock(%direct_a_host_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb5 loc(#loc63)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc63)
      aie.dma_bd(%direct_a_host_0_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc63)
      aie.use_lock(%direct_a_host_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc63)
      aie.next_bd ^bb4 loc(#loc63)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc65)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc64)
      aie.dma_bd(%direct_w_host_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc64)
      aie.use_lock(%direct_w_host_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc64)
      aie.next_bd ^bb8 loc(#loc64)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_0_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc64)
      aie.dma_bd(%direct_w_host_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc64)
      aie.use_lock(%direct_w_host_0_cons_prod_lock_0, Release, %c1_i32) loc(#loc64)
      aie.next_bd ^bb7 loc(#loc64)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc64)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc64)
      aie.dma_bd(%direct_w_host_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc64)
      aie.use_lock(%direct_w_host_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc64)
      aie.next_bd ^bb11 loc(#loc64)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc64)
      aie.dma_bd(%direct_w_host_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc64)
      aie.use_lock(%direct_w_host_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc64)
      aie.next_bd ^bb10 loc(#loc64)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc41)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_prod_lock_0, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb14 loc(#loc41)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_0_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_prod_lock_1, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb15 loc(#loc41)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_0_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_prod_lock_2, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb16 loc(#loc41)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_0_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_prod_lock_3, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb17 loc(#loc41)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_prod_lock_0, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb18 loc(#loc41)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_0_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_prod_lock_1, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb19 loc(#loc41)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_0_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_prod_lock_2, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb20 loc(#loc41)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_0_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_prod_lock_3, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb13 loc(#loc41)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc40)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_cons_lock_0, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb23 loc(#loc41)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_0_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_cons_lock_0, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb22 loc(#loc41)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc39)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_0_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_cons_lock_1, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb26 loc(#loc41)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_0_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_cons_lock_1, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb25 loc(#loc41)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc38)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_0_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_cons_lock_2, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb29 loc(#loc41)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_0_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_cons_lock_2, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb28 loc(#loc41)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc37)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_0_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_cons_lock_3, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb32 loc(#loc41)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_0_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc41)
      aie.dma_bd(%direct_y_host_0_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc41)
      aie.use_lock(%direct_y_host_0_cons_lock_3, Release, %c1_i32) loc(#loc41)
      aie.next_bd ^bb31 loc(#loc41)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc73)
    } loc(#loc73)
    %mem_0_2 = aie.mem(%tile_0_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc73)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc73)
      aie.dma_bd(%direct_a_broadcast_0_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc73)
      aie.use_lock(%direct_a_broadcast_0_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc73)
      aie.next_bd ^bb1 loc(#loc73)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc65)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_0_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_w_broadcast_0_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc65)
      aie.use_lock(%direct_w_broadcast_0_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb4 loc(#loc65)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_0_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_w_broadcast_0_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc65)
      aie.use_lock(%direct_w_broadcast_0_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb3 loc(#loc65)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc40)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_0_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc40)
      aie.dma_bd(%direct_y_worker_0_0_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc40)
      aie.use_lock(%direct_y_worker_0_0_prod_lock_0, Release, %c1_i32) loc(#loc40)
      aie.next_bd ^bb7 loc(#loc40)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_0_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc40)
      aie.dma_bd(%direct_y_worker_0_0_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc40)
      aie.use_lock(%direct_y_worker_0_0_prod_lock_0, Release, %c1_i32) loc(#loc40)
      aie.next_bd ^bb6 loc(#loc40)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc73)
    } loc(#loc73)
    %mem_1_2 = aie.mem(%tile_1_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc73)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc73)
      aie.dma_bd(%direct_a_broadcast_0_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc73)
      aie.use_lock(%direct_a_broadcast_0_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc73)
      aie.next_bd ^bb1 loc(#loc73)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc62)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_1_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_w_broadcast_1_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc62)
      aie.use_lock(%direct_w_broadcast_1_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb4 loc(#loc62)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_1_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_w_broadcast_1_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc62)
      aie.use_lock(%direct_w_broadcast_1_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb3 loc(#loc62)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc35)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_1_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc35)
      aie.dma_bd(%direct_y_worker_1_0_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc35)
      aie.use_lock(%direct_y_worker_1_0_prod_lock_0, Release, %c1_i32) loc(#loc35)
      aie.next_bd ^bb7 loc(#loc35)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_1_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc35)
      aie.dma_bd(%direct_y_worker_1_0_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc35)
      aie.use_lock(%direct_y_worker_1_0_prod_lock_0, Release, %c1_i32) loc(#loc35)
      aie.next_bd ^bb6 loc(#loc35)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc73)
    } loc(#loc73)
    %mem_2_2 = aie.mem(%tile_2_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc73)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc73)
      aie.dma_bd(%direct_a_broadcast_0_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc73)
      aie.use_lock(%direct_a_broadcast_0_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc73)
      aie.next_bd ^bb1 loc(#loc73)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc59)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_2_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_w_broadcast_2_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc59)
      aie.use_lock(%direct_w_broadcast_2_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb4 loc(#loc59)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_2_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_w_broadcast_2_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc59)
      aie.use_lock(%direct_w_broadcast_2_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb3 loc(#loc59)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc30)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_2_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc30)
      aie.dma_bd(%direct_y_worker_2_0_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc30)
      aie.use_lock(%direct_y_worker_2_0_prod_lock_0, Release, %c1_i32) loc(#loc30)
      aie.next_bd ^bb7 loc(#loc30)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_2_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc30)
      aie.dma_bd(%direct_y_worker_2_0_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc30)
      aie.use_lock(%direct_y_worker_2_0_prod_lock_0, Release, %c1_i32) loc(#loc30)
      aie.next_bd ^bb6 loc(#loc30)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc73)
    } loc(#loc73)
    %mem_3_2 = aie.mem(%tile_3_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc73)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_0_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc73)
      aie.dma_bd(%direct_a_broadcast_0_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc73)
      aie.use_lock(%direct_a_broadcast_0_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc73)
      aie.next_bd ^bb1 loc(#loc73)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc56)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_3_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_3_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_3_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb4 loc(#loc56)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_3_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_3_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_3_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb3 loc(#loc56)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc25)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_3_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc25)
      aie.dma_bd(%direct_y_worker_3_0_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc25)
      aie.use_lock(%direct_y_worker_3_0_prod_lock_0, Release, %c1_i32) loc(#loc25)
      aie.next_bd ^bb7 loc(#loc25)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_3_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc25)
      aie.dma_bd(%direct_y_worker_3_0_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc25)
      aie.use_lock(%direct_y_worker_3_0_prod_lock_0, Release, %c1_i32) loc(#loc25)
      aie.next_bd ^bb6 loc(#loc25)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc73)
    } loc(#loc73)
    aie.shim_dma_allocation @direct_a_host_0_shim_alloc(%shim_noc_tile_0_0, MM2S, 0) loc(#loc63)
    %memtile_dma_1_1 = aie.memtile_dma(%mem_tile_1_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc72)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      aie.dma_bd(%direct_a_host_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc60)
      aie.use_lock(%direct_a_host_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc60)
      aie.next_bd ^bb2 loc(#loc60)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      aie.dma_bd(%direct_a_host_1_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc60)
      aie.use_lock(%direct_a_host_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc60)
      aie.next_bd ^bb1 loc(#loc60)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc60)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      aie.dma_bd(%direct_a_host_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc60)
      aie.use_lock(%direct_a_host_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc60)
      aie.next_bd ^bb5 loc(#loc60)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc60)
      aie.dma_bd(%direct_a_host_1_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc60)
      aie.use_lock(%direct_a_host_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc60)
      aie.next_bd ^bb4 loc(#loc60)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc62)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_w_host_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc61)
      aie.use_lock(%direct_w_host_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb8 loc(#loc61)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_1_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_w_host_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc61)
      aie.use_lock(%direct_w_host_1_cons_prod_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb7 loc(#loc61)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc61)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_w_host_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc61)
      aie.use_lock(%direct_w_host_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb11 loc(#loc61)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc61)
      aie.dma_bd(%direct_w_host_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc61)
      aie.use_lock(%direct_w_host_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc61)
      aie.next_bd ^bb10 loc(#loc61)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc36)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_prod_lock_0, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb14 loc(#loc36)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_1_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_prod_lock_1, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb15 loc(#loc36)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_1_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_prod_lock_2, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb16 loc(#loc36)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_1_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_prod_lock_3, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb17 loc(#loc36)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_prod_lock_0, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb18 loc(#loc36)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_1_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_prod_lock_1, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb19 loc(#loc36)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_1_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_prod_lock_2, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb20 loc(#loc36)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_1_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_prod_lock_3, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb13 loc(#loc36)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc35)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_cons_lock_0, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb23 loc(#loc36)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_1_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_cons_lock_0, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb22 loc(#loc36)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc34)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_1_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_cons_lock_1, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb26 loc(#loc36)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_1_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_cons_lock_1, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb25 loc(#loc36)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc33)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_1_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_cons_lock_2, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb29 loc(#loc36)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_1_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_cons_lock_2, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb28 loc(#loc36)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc32)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_1_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_cons_lock_3, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb32 loc(#loc36)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_1_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc36)
      aie.dma_bd(%direct_y_host_1_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc36)
      aie.use_lock(%direct_y_host_1_cons_lock_3, Release, %c1_i32) loc(#loc36)
      aie.next_bd ^bb31 loc(#loc36)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc72)
    } loc(#loc72)
    %mem_0_3 = aie.mem(%tile_0_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc72)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc72)
      aie.dma_bd(%direct_a_broadcast_1_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc72)
      aie.use_lock(%direct_a_broadcast_1_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc72)
      aie.next_bd ^bb1 loc(#loc72)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc65)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_0_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_w_broadcast_0_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc65)
      aie.use_lock(%direct_w_broadcast_0_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb4 loc(#loc65)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_0_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_w_broadcast_0_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc65)
      aie.use_lock(%direct_w_broadcast_0_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb3 loc(#loc65)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc39)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_0_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc39)
      aie.dma_bd(%direct_y_worker_0_1_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc39)
      aie.use_lock(%direct_y_worker_0_1_prod_lock_0, Release, %c1_i32) loc(#loc39)
      aie.next_bd ^bb7 loc(#loc39)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_0_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc39)
      aie.dma_bd(%direct_y_worker_0_1_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc39)
      aie.use_lock(%direct_y_worker_0_1_prod_lock_0, Release, %c1_i32) loc(#loc39)
      aie.next_bd ^bb6 loc(#loc39)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc72)
    } loc(#loc72)
    %mem_1_3 = aie.mem(%tile_1_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc72)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc72)
      aie.dma_bd(%direct_a_broadcast_1_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc72)
      aie.use_lock(%direct_a_broadcast_1_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc72)
      aie.next_bd ^bb1 loc(#loc72)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc62)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_1_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_w_broadcast_1_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc62)
      aie.use_lock(%direct_w_broadcast_1_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb4 loc(#loc62)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_1_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_w_broadcast_1_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc62)
      aie.use_lock(%direct_w_broadcast_1_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb3 loc(#loc62)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc34)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_1_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc34)
      aie.dma_bd(%direct_y_worker_1_1_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc34)
      aie.use_lock(%direct_y_worker_1_1_prod_lock_0, Release, %c1_i32) loc(#loc34)
      aie.next_bd ^bb7 loc(#loc34)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_1_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc34)
      aie.dma_bd(%direct_y_worker_1_1_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc34)
      aie.use_lock(%direct_y_worker_1_1_prod_lock_0, Release, %c1_i32) loc(#loc34)
      aie.next_bd ^bb6 loc(#loc34)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc72)
    } loc(#loc72)
    %mem_2_3 = aie.mem(%tile_2_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc72)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc72)
      aie.dma_bd(%direct_a_broadcast_1_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc72)
      aie.use_lock(%direct_a_broadcast_1_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc72)
      aie.next_bd ^bb1 loc(#loc72)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc59)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_2_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_w_broadcast_2_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc59)
      aie.use_lock(%direct_w_broadcast_2_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb4 loc(#loc59)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_2_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_w_broadcast_2_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc59)
      aie.use_lock(%direct_w_broadcast_2_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb3 loc(#loc59)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc29)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_2_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc29)
      aie.dma_bd(%direct_y_worker_2_1_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc29)
      aie.use_lock(%direct_y_worker_2_1_prod_lock_0, Release, %c1_i32) loc(#loc29)
      aie.next_bd ^bb7 loc(#loc29)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_2_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc29)
      aie.dma_bd(%direct_y_worker_2_1_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc29)
      aie.use_lock(%direct_y_worker_2_1_prod_lock_0, Release, %c1_i32) loc(#loc29)
      aie.next_bd ^bb6 loc(#loc29)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc72)
    } loc(#loc72)
    %mem_3_3 = aie.mem(%tile_3_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc72)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_1_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc72)
      aie.dma_bd(%direct_a_broadcast_1_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc72)
      aie.use_lock(%direct_a_broadcast_1_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc72)
      aie.next_bd ^bb1 loc(#loc72)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc56)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_3_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_3_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_3_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb4 loc(#loc56)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_3_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_3_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_3_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb3 loc(#loc56)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc24)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_3_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc24)
      aie.dma_bd(%direct_y_worker_3_1_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc24)
      aie.use_lock(%direct_y_worker_3_1_prod_lock_0, Release, %c1_i32) loc(#loc24)
      aie.next_bd ^bb7 loc(#loc24)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_3_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc24)
      aie.dma_bd(%direct_y_worker_3_1_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc24)
      aie.use_lock(%direct_y_worker_3_1_prod_lock_0, Release, %c1_i32) loc(#loc24)
      aie.next_bd ^bb6 loc(#loc24)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc72)
    } loc(#loc72)
    aie.shim_dma_allocation @direct_a_host_1_shim_alloc(%shim_noc_tile_1_0, MM2S, 0) loc(#loc60)
    %memtile_dma_2_1 = aie.memtile_dma(%mem_tile_2_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc71)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_a_host_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc57)
      aie.use_lock(%direct_a_host_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb2 loc(#loc57)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_a_host_2_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc57)
      aie.use_lock(%direct_a_host_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb1 loc(#loc57)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc57)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_a_host_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc57)
      aie.use_lock(%direct_a_host_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb5 loc(#loc57)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc57)
      aie.dma_bd(%direct_a_host_2_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc57)
      aie.use_lock(%direct_a_host_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc57)
      aie.next_bd ^bb4 loc(#loc57)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc59)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc58)
      aie.dma_bd(%direct_w_host_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc58)
      aie.use_lock(%direct_w_host_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc58)
      aie.next_bd ^bb8 loc(#loc58)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_2_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc58)
      aie.dma_bd(%direct_w_host_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc58)
      aie.use_lock(%direct_w_host_2_cons_prod_lock_0, Release, %c1_i32) loc(#loc58)
      aie.next_bd ^bb7 loc(#loc58)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc58)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc58)
      aie.dma_bd(%direct_w_host_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc58)
      aie.use_lock(%direct_w_host_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc58)
      aie.next_bd ^bb11 loc(#loc58)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc58)
      aie.dma_bd(%direct_w_host_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc58)
      aie.use_lock(%direct_w_host_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc58)
      aie.next_bd ^bb10 loc(#loc58)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc31)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_0, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb14 loc(#loc31)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_2_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_1, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb15 loc(#loc31)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_2_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_2, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb16 loc(#loc31)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_2_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_3, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb17 loc(#loc31)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_0, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb18 loc(#loc31)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_2_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_1, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb19 loc(#loc31)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_2_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_2, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb20 loc(#loc31)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_2_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_prod_lock_3, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb13 loc(#loc31)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc30)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_0, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb23 loc(#loc31)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_2_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_0, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb22 loc(#loc31)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc29)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_2_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_1, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb26 loc(#loc31)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_2_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_1, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb25 loc(#loc31)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc28)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_2_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_2, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb29 loc(#loc31)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_2_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_2, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb28 loc(#loc31)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc27)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_2_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_3, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb32 loc(#loc31)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_2_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc31)
      aie.dma_bd(%direct_y_host_2_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc31)
      aie.use_lock(%direct_y_host_2_cons_lock_3, Release, %c1_i32) loc(#loc31)
      aie.next_bd ^bb31 loc(#loc31)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc71)
    } loc(#loc71)
    %mem_0_4 = aie.mem(%tile_0_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc71)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc71)
      aie.dma_bd(%direct_a_broadcast_2_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc71)
      aie.use_lock(%direct_a_broadcast_2_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc71)
      aie.next_bd ^bb1 loc(#loc71)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc65)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_0_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_w_broadcast_0_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc65)
      aie.use_lock(%direct_w_broadcast_0_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb4 loc(#loc65)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_0_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_w_broadcast_0_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc65)
      aie.use_lock(%direct_w_broadcast_0_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb3 loc(#loc65)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc38)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_0_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc38)
      aie.dma_bd(%direct_y_worker_0_2_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc38)
      aie.use_lock(%direct_y_worker_0_2_prod_lock_0, Release, %c1_i32) loc(#loc38)
      aie.next_bd ^bb7 loc(#loc38)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_0_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc38)
      aie.dma_bd(%direct_y_worker_0_2_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc38)
      aie.use_lock(%direct_y_worker_0_2_prod_lock_0, Release, %c1_i32) loc(#loc38)
      aie.next_bd ^bb6 loc(#loc38)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc71)
    } loc(#loc71)
    %mem_1_4 = aie.mem(%tile_1_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc71)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc71)
      aie.dma_bd(%direct_a_broadcast_2_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc71)
      aie.use_lock(%direct_a_broadcast_2_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc71)
      aie.next_bd ^bb1 loc(#loc71)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc62)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_1_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_w_broadcast_1_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc62)
      aie.use_lock(%direct_w_broadcast_1_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb4 loc(#loc62)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_1_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_w_broadcast_1_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc62)
      aie.use_lock(%direct_w_broadcast_1_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb3 loc(#loc62)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc33)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_1_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc33)
      aie.dma_bd(%direct_y_worker_1_2_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc33)
      aie.use_lock(%direct_y_worker_1_2_prod_lock_0, Release, %c1_i32) loc(#loc33)
      aie.next_bd ^bb7 loc(#loc33)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_1_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc33)
      aie.dma_bd(%direct_y_worker_1_2_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc33)
      aie.use_lock(%direct_y_worker_1_2_prod_lock_0, Release, %c1_i32) loc(#loc33)
      aie.next_bd ^bb6 loc(#loc33)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc71)
    } loc(#loc71)
    %mem_2_4 = aie.mem(%tile_2_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc71)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc71)
      aie.dma_bd(%direct_a_broadcast_2_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc71)
      aie.use_lock(%direct_a_broadcast_2_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc71)
      aie.next_bd ^bb1 loc(#loc71)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc59)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_2_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_w_broadcast_2_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc59)
      aie.use_lock(%direct_w_broadcast_2_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb4 loc(#loc59)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_2_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_w_broadcast_2_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc59)
      aie.use_lock(%direct_w_broadcast_2_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb3 loc(#loc59)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc28)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_2_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc28)
      aie.dma_bd(%direct_y_worker_2_2_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc28)
      aie.use_lock(%direct_y_worker_2_2_prod_lock_0, Release, %c1_i32) loc(#loc28)
      aie.next_bd ^bb7 loc(#loc28)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_2_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc28)
      aie.dma_bd(%direct_y_worker_2_2_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc28)
      aie.use_lock(%direct_y_worker_2_2_prod_lock_0, Release, %c1_i32) loc(#loc28)
      aie.next_bd ^bb6 loc(#loc28)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc71)
    } loc(#loc71)
    %mem_3_4 = aie.mem(%tile_3_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc71)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_2_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc71)
      aie.dma_bd(%direct_a_broadcast_2_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc71)
      aie.use_lock(%direct_a_broadcast_2_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc71)
      aie.next_bd ^bb1 loc(#loc71)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc56)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_3_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_3_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_3_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb4 loc(#loc56)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_3_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_3_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_3_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb3 loc(#loc56)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc23)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_3_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc23)
      aie.dma_bd(%direct_y_worker_3_2_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc23)
      aie.use_lock(%direct_y_worker_3_2_prod_lock_0, Release, %c1_i32) loc(#loc23)
      aie.next_bd ^bb7 loc(#loc23)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_3_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc23)
      aie.dma_bd(%direct_y_worker_3_2_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc23)
      aie.use_lock(%direct_y_worker_3_2_prod_lock_0, Release, %c1_i32) loc(#loc23)
      aie.next_bd ^bb6 loc(#loc23)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc71)
    } loc(#loc71)
    aie.shim_dma_allocation @direct_a_host_2_shim_alloc(%shim_noc_tile_2_0, MM2S, 0) loc(#loc57)
    %memtile_dma_3_1 = aie.memtile_dma(%mem_tile_3_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc70)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_a_host_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc54)
      aie.use_lock(%direct_a_host_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb2 loc(#loc54)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_a_host_3_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc54)
      aie.use_lock(%direct_a_host_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb1 loc(#loc54)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc54)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_a_host_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc54)
      aie.use_lock(%direct_a_host_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb5 loc(#loc54)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc54)
      aie.dma_bd(%direct_a_host_3_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc54)
      aie.use_lock(%direct_a_host_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc54)
      aie.next_bd ^bb4 loc(#loc54)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc56)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_host_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc55)
      aie.use_lock(%direct_w_host_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb8 loc(#loc55)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_3_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_host_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc55)
      aie.use_lock(%direct_w_host_3_cons_prod_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb7 loc(#loc55)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc55)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_host_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc55)
      aie.use_lock(%direct_w_host_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb11 loc(#loc55)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc55)
      aie.dma_bd(%direct_w_host_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc55)
      aie.use_lock(%direct_w_host_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc55)
      aie.next_bd ^bb10 loc(#loc55)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc26)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_0, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb14 loc(#loc26)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_3_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_1, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb15 loc(#loc26)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_3_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_2, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb16 loc(#loc26)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_3_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_3, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb17 loc(#loc26)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_0, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb18 loc(#loc26)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_3_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_1, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb19 loc(#loc26)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_3_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_2, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb20 loc(#loc26)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_3_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_prod_lock_3, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb13 loc(#loc26)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc25)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_0, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb23 loc(#loc26)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_3_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_0, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb22 loc(#loc26)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc24)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_3_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_1, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb26 loc(#loc26)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_3_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_1, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb25 loc(#loc26)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc23)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_3_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_2, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb29 loc(#loc26)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_3_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_2, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb28 loc(#loc26)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc22)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_3_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_3, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb32 loc(#loc26)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_3_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc26)
      aie.dma_bd(%direct_y_host_3_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc26)
      aie.use_lock(%direct_y_host_3_cons_lock_3, Release, %c1_i32) loc(#loc26)
      aie.next_bd ^bb31 loc(#loc26)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc70)
    } loc(#loc70)
    %mem_0_5 = aie.mem(%tile_0_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc70)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc70)
      aie.dma_bd(%direct_a_broadcast_3_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc70)
      aie.use_lock(%direct_a_broadcast_3_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc70)
      aie.next_bd ^bb1 loc(#loc70)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc65)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_0_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_w_broadcast_0_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc65)
      aie.use_lock(%direct_w_broadcast_0_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb4 loc(#loc65)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_0_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc65)
      aie.dma_bd(%direct_w_broadcast_0_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc65)
      aie.use_lock(%direct_w_broadcast_0_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc65)
      aie.next_bd ^bb3 loc(#loc65)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc37)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_0_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_worker_0_3_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc37)
      aie.use_lock(%direct_y_worker_0_3_prod_lock_0, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb7 loc(#loc37)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_0_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc37)
      aie.dma_bd(%direct_y_worker_0_3_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc37)
      aie.use_lock(%direct_y_worker_0_3_prod_lock_0, Release, %c1_i32) loc(#loc37)
      aie.next_bd ^bb6 loc(#loc37)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc70)
    } loc(#loc70)
    %mem_1_5 = aie.mem(%tile_1_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc70)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc70)
      aie.dma_bd(%direct_a_broadcast_3_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc70)
      aie.use_lock(%direct_a_broadcast_3_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc70)
      aie.next_bd ^bb1 loc(#loc70)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc62)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_1_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_w_broadcast_1_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc62)
      aie.use_lock(%direct_w_broadcast_1_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb4 loc(#loc62)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_1_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc62)
      aie.dma_bd(%direct_w_broadcast_1_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc62)
      aie.use_lock(%direct_w_broadcast_1_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc62)
      aie.next_bd ^bb3 loc(#loc62)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc32)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_1_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc32)
      aie.dma_bd(%direct_y_worker_1_3_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc32)
      aie.use_lock(%direct_y_worker_1_3_prod_lock_0, Release, %c1_i32) loc(#loc32)
      aie.next_bd ^bb7 loc(#loc32)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_1_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc32)
      aie.dma_bd(%direct_y_worker_1_3_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc32)
      aie.use_lock(%direct_y_worker_1_3_prod_lock_0, Release, %c1_i32) loc(#loc32)
      aie.next_bd ^bb6 loc(#loc32)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc70)
    } loc(#loc70)
    %mem_2_5 = aie.mem(%tile_2_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc70)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc70)
      aie.dma_bd(%direct_a_broadcast_3_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc70)
      aie.use_lock(%direct_a_broadcast_3_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc70)
      aie.next_bd ^bb1 loc(#loc70)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc59)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_2_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_w_broadcast_2_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc59)
      aie.use_lock(%direct_w_broadcast_2_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb4 loc(#loc59)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_2_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc59)
      aie.dma_bd(%direct_w_broadcast_2_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc59)
      aie.use_lock(%direct_w_broadcast_2_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc59)
      aie.next_bd ^bb3 loc(#loc59)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc27)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_2_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc27)
      aie.dma_bd(%direct_y_worker_2_3_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc27)
      aie.use_lock(%direct_y_worker_2_3_prod_lock_0, Release, %c1_i32) loc(#loc27)
      aie.next_bd ^bb7 loc(#loc27)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_2_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc27)
      aie.dma_bd(%direct_y_worker_2_3_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc27)
      aie.use_lock(%direct_y_worker_2_3_prod_lock_0, Release, %c1_i32) loc(#loc27)
      aie.next_bd ^bb6 loc(#loc27)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc70)
    } loc(#loc70)
    %mem_3_5 = aie.mem(%tile_3_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc70)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_3_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc70)
      aie.dma_bd(%direct_a_broadcast_3_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc70)
      aie.use_lock(%direct_a_broadcast_3_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc70)
      aie.next_bd ^bb1 loc(#loc70)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc56)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_3_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_3_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_3_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb4 loc(#loc56)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_3_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc56)
      aie.dma_bd(%direct_w_broadcast_3_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc56)
      aie.use_lock(%direct_w_broadcast_3_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc56)
      aie.next_bd ^bb3 loc(#loc56)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc22)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_3_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc22)
      aie.dma_bd(%direct_y_worker_3_3_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc22)
      aie.use_lock(%direct_y_worker_3_3_prod_lock_0, Release, %c1_i32) loc(#loc22)
      aie.next_bd ^bb7 loc(#loc22)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_3_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc22)
      aie.dma_bd(%direct_y_worker_3_3_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc22)
      aie.use_lock(%direct_y_worker_3_3_prod_lock_0, Release, %c1_i32) loc(#loc22)
      aie.next_bd ^bb6 loc(#loc22)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc70)
    } loc(#loc70)
    aie.shim_dma_allocation @direct_a_host_3_shim_alloc(%shim_noc_tile_3_0, MM2S, 0) loc(#loc54)
    %memtile_dma_4_1 = aie.memtile_dma(%mem_tile_4_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc69)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_a_host_4_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc51)
      aie.use_lock(%direct_a_host_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb2 loc(#loc51)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_a_host_4_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc51)
      aie.use_lock(%direct_a_host_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb1 loc(#loc51)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc51)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_a_host_4_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc51)
      aie.use_lock(%direct_a_host_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb5 loc(#loc51)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc51)
      aie.dma_bd(%direct_a_host_4_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc51)
      aie.use_lock(%direct_a_host_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc51)
      aie.next_bd ^bb4 loc(#loc51)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc53)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      aie.dma_bd(%direct_w_host_4_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc52)
      aie.use_lock(%direct_w_host_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc52)
      aie.next_bd ^bb8 loc(#loc52)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_4_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      aie.dma_bd(%direct_w_host_4_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc52)
      aie.use_lock(%direct_w_host_4_cons_prod_lock_0, Release, %c1_i32) loc(#loc52)
      aie.next_bd ^bb7 loc(#loc52)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc52)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      aie.dma_bd(%direct_w_host_4_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc52)
      aie.use_lock(%direct_w_host_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc52)
      aie.next_bd ^bb11 loc(#loc52)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_4_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc52)
      aie.dma_bd(%direct_w_host_4_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc52)
      aie.use_lock(%direct_w_host_4_cons_cons_lock_0, Release, %c1_i32) loc(#loc52)
      aie.next_bd ^bb10 loc(#loc52)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc21)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_4_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_0, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb14 loc(#loc21)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_4_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_1, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb15 loc(#loc21)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_4_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_2, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb16 loc(#loc21)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_4_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_3, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb17 loc(#loc21)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_4_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_0, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb18 loc(#loc21)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_4_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_1, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb19 loc(#loc21)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_4_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_2, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb20 loc(#loc21)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_4_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_prod_lock_3, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb13 loc(#loc21)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc20)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_4_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_0, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb23 loc(#loc21)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_4_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_0, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb22 loc(#loc21)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc19)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_4_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_1, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb26 loc(#loc21)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_4_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_1, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb25 loc(#loc21)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc18)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_4_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_2, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb29 loc(#loc21)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_4_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_2, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb28 loc(#loc21)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc17)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_4_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_3, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb32 loc(#loc21)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_4_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc21)
      aie.dma_bd(%direct_y_host_4_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc21)
      aie.use_lock(%direct_y_host_4_cons_lock_3, Release, %c1_i32) loc(#loc21)
      aie.next_bd ^bb31 loc(#loc21)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc69)
    } loc(#loc69)
    %mem_4_2 = aie.mem(%tile_4_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc69)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_4_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc69)
      aie.dma_bd(%direct_a_broadcast_4_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc69)
      aie.use_lock(%direct_a_broadcast_4_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc69)
      aie.next_bd ^bb1 loc(#loc69)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc53)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_4_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb4 loc(#loc53)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_4_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb3 loc(#loc53)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc20)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_4_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc20)
      aie.dma_bd(%direct_y_worker_4_0_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc20)
      aie.use_lock(%direct_y_worker_4_0_prod_lock_0, Release, %c1_i32) loc(#loc20)
      aie.next_bd ^bb7 loc(#loc20)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_4_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc20)
      aie.dma_bd(%direct_y_worker_4_0_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc20)
      aie.use_lock(%direct_y_worker_4_0_prod_lock_0, Release, %c1_i32) loc(#loc20)
      aie.next_bd ^bb6 loc(#loc20)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc69)
    } loc(#loc69)
    %mem_5_2 = aie.mem(%tile_5_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc69)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_4_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc69)
      aie.dma_bd(%direct_a_broadcast_4_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc69)
      aie.use_lock(%direct_a_broadcast_4_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc69)
      aie.next_bd ^bb1 loc(#loc69)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc50)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_5_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_broadcast_5_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc50)
      aie.use_lock(%direct_w_broadcast_5_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb4 loc(#loc50)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_5_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_broadcast_5_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc50)
      aie.use_lock(%direct_w_broadcast_5_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb3 loc(#loc50)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc15)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_5_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc15)
      aie.dma_bd(%direct_y_worker_5_0_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc15)
      aie.use_lock(%direct_y_worker_5_0_prod_lock_0, Release, %c1_i32) loc(#loc15)
      aie.next_bd ^bb7 loc(#loc15)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_5_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc15)
      aie.dma_bd(%direct_y_worker_5_0_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc15)
      aie.use_lock(%direct_y_worker_5_0_prod_lock_0, Release, %c1_i32) loc(#loc15)
      aie.next_bd ^bb6 loc(#loc15)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc69)
    } loc(#loc69)
    %mem_6_2 = aie.mem(%tile_6_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc69)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_4_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc69)
      aie.dma_bd(%direct_a_broadcast_4_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc69)
      aie.use_lock(%direct_a_broadcast_4_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc69)
      aie.next_bd ^bb1 loc(#loc69)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc47)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_6_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_6_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_6_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb4 loc(#loc47)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_6_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_6_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_6_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb3 loc(#loc47)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc10)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_6_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%direct_y_worker_6_0_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc10)
      aie.use_lock(%direct_y_worker_6_0_prod_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb7 loc(#loc10)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_6_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc10)
      aie.dma_bd(%direct_y_worker_6_0_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc10)
      aie.use_lock(%direct_y_worker_6_0_prod_lock_0, Release, %c1_i32) loc(#loc10)
      aie.next_bd ^bb6 loc(#loc10)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc69)
    } loc(#loc69)
    %mem_7_2 = aie.mem(%tile_7_2) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc69)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_4_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc69)
      aie.dma_bd(%direct_a_broadcast_4_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc69)
      aie.use_lock(%direct_a_broadcast_4_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc69)
      aie.next_bd ^bb1 loc(#loc69)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc44)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_7_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_w_broadcast_7_0_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc44)
      aie.use_lock(%direct_w_broadcast_7_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb4 loc(#loc44)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_7_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_w_broadcast_7_0_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc44)
      aie.use_lock(%direct_w_broadcast_7_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb3 loc(#loc44)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc5)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_7_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc5)
      aie.dma_bd(%direct_y_worker_7_0_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc5)
      aie.use_lock(%direct_y_worker_7_0_prod_lock_0, Release, %c1_i32) loc(#loc5)
      aie.next_bd ^bb7 loc(#loc5)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_7_0_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc5)
      aie.dma_bd(%direct_y_worker_7_0_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc5)
      aie.use_lock(%direct_y_worker_7_0_prod_lock_0, Release, %c1_i32) loc(#loc5)
      aie.next_bd ^bb6 loc(#loc5)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc69)
    } loc(#loc69)
    aie.shim_dma_allocation @direct_a_host_4_shim_alloc(%shim_noc_tile_4_0, MM2S, 0) loc(#loc51)
    %memtile_dma_5_1 = aie.memtile_dma(%mem_tile_5_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc68)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc48)
      aie.dma_bd(%direct_a_host_5_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc48)
      aie.use_lock(%direct_a_host_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc48)
      aie.next_bd ^bb2 loc(#loc48)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc48)
      aie.dma_bd(%direct_a_host_5_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc48)
      aie.use_lock(%direct_a_host_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc48)
      aie.next_bd ^bb1 loc(#loc48)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc48)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc48)
      aie.dma_bd(%direct_a_host_5_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc48)
      aie.use_lock(%direct_a_host_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc48)
      aie.next_bd ^bb5 loc(#loc48)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc48)
      aie.dma_bd(%direct_a_host_5_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc48)
      aie.use_lock(%direct_a_host_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc48)
      aie.next_bd ^bb4 loc(#loc48)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc50)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_host_5_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc49)
      aie.use_lock(%direct_w_host_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb8 loc(#loc49)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_5_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_host_5_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc49)
      aie.use_lock(%direct_w_host_5_cons_prod_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb7 loc(#loc49)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc49)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_host_5_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc49)
      aie.use_lock(%direct_w_host_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb11 loc(#loc49)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_5_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc49)
      aie.dma_bd(%direct_w_host_5_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc49)
      aie.use_lock(%direct_w_host_5_cons_cons_lock_0, Release, %c1_i32) loc(#loc49)
      aie.next_bd ^bb10 loc(#loc49)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc16)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_5_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb14 loc(#loc16)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_5_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_1, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb15 loc(#loc16)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_5_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_2, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb16 loc(#loc16)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_5_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_3, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb17 loc(#loc16)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_5_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb18 loc(#loc16)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_5_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_1, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb19 loc(#loc16)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_5_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_2, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb20 loc(#loc16)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_5_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_prod_lock_3, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb13 loc(#loc16)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc15)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_5_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb23 loc(#loc16)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_5_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_0, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb22 loc(#loc16)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc14)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_5_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_1, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb26 loc(#loc16)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_5_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_1, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb25 loc(#loc16)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc13)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_5_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_2, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb29 loc(#loc16)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_5_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_2, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb28 loc(#loc16)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc12)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_5_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_3, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb32 loc(#loc16)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_5_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc16)
      aie.dma_bd(%direct_y_host_5_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc16)
      aie.use_lock(%direct_y_host_5_cons_lock_3, Release, %c1_i32) loc(#loc16)
      aie.next_bd ^bb31 loc(#loc16)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc68)
    } loc(#loc68)
    %mem_4_3 = aie.mem(%tile_4_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc68)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_5_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc68)
      aie.dma_bd(%direct_a_broadcast_5_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc68)
      aie.use_lock(%direct_a_broadcast_5_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc68)
      aie.next_bd ^bb1 loc(#loc68)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc53)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_4_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb4 loc(#loc53)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_4_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb3 loc(#loc53)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc19)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_4_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc19)
      aie.dma_bd(%direct_y_worker_4_1_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc19)
      aie.use_lock(%direct_y_worker_4_1_prod_lock_0, Release, %c1_i32) loc(#loc19)
      aie.next_bd ^bb7 loc(#loc19)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_4_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc19)
      aie.dma_bd(%direct_y_worker_4_1_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc19)
      aie.use_lock(%direct_y_worker_4_1_prod_lock_0, Release, %c1_i32) loc(#loc19)
      aie.next_bd ^bb6 loc(#loc19)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc68)
    } loc(#loc68)
    %mem_5_3 = aie.mem(%tile_5_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc68)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_5_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc68)
      aie.dma_bd(%direct_a_broadcast_5_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc68)
      aie.use_lock(%direct_a_broadcast_5_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc68)
      aie.next_bd ^bb1 loc(#loc68)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc50)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_5_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_broadcast_5_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc50)
      aie.use_lock(%direct_w_broadcast_5_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb4 loc(#loc50)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_5_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_broadcast_5_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc50)
      aie.use_lock(%direct_w_broadcast_5_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb3 loc(#loc50)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc14)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_5_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc14)
      aie.dma_bd(%direct_y_worker_5_1_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc14)
      aie.use_lock(%direct_y_worker_5_1_prod_lock_0, Release, %c1_i32) loc(#loc14)
      aie.next_bd ^bb7 loc(#loc14)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_5_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc14)
      aie.dma_bd(%direct_y_worker_5_1_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc14)
      aie.use_lock(%direct_y_worker_5_1_prod_lock_0, Release, %c1_i32) loc(#loc14)
      aie.next_bd ^bb6 loc(#loc14)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc68)
    } loc(#loc68)
    %mem_6_3 = aie.mem(%tile_6_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc68)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_5_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc68)
      aie.dma_bd(%direct_a_broadcast_5_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc68)
      aie.use_lock(%direct_a_broadcast_5_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc68)
      aie.next_bd ^bb1 loc(#loc68)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc47)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_6_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_6_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_6_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb4 loc(#loc47)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_6_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_6_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_6_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb3 loc(#loc47)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc9)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_6_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc9)
      aie.dma_bd(%direct_y_worker_6_1_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc9)
      aie.use_lock(%direct_y_worker_6_1_prod_lock_0, Release, %c1_i32) loc(#loc9)
      aie.next_bd ^bb7 loc(#loc9)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_6_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc9)
      aie.dma_bd(%direct_y_worker_6_1_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc9)
      aie.use_lock(%direct_y_worker_6_1_prod_lock_0, Release, %c1_i32) loc(#loc9)
      aie.next_bd ^bb6 loc(#loc9)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc68)
    } loc(#loc68)
    %mem_7_3 = aie.mem(%tile_7_3) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc68)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_5_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc68)
      aie.dma_bd(%direct_a_broadcast_5_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc68)
      aie.use_lock(%direct_a_broadcast_5_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc68)
      aie.next_bd ^bb1 loc(#loc68)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc44)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_7_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_w_broadcast_7_1_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc44)
      aie.use_lock(%direct_w_broadcast_7_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb4 loc(#loc44)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_7_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_w_broadcast_7_1_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc44)
      aie.use_lock(%direct_w_broadcast_7_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb3 loc(#loc44)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc4)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_7_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc4)
      aie.dma_bd(%direct_y_worker_7_1_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc4)
      aie.use_lock(%direct_y_worker_7_1_prod_lock_0, Release, %c1_i32) loc(#loc4)
      aie.next_bd ^bb7 loc(#loc4)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_7_1_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc4)
      aie.dma_bd(%direct_y_worker_7_1_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc4)
      aie.use_lock(%direct_y_worker_7_1_prod_lock_0, Release, %c1_i32) loc(#loc4)
      aie.next_bd ^bb6 loc(#loc4)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc68)
    } loc(#loc68)
    aie.shim_dma_allocation @direct_a_host_5_shim_alloc(%shim_noc_tile_5_0, MM2S, 0) loc(#loc48)
    %memtile_dma_6_1 = aie.memtile_dma(%mem_tile_6_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc67)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_a_host_6_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc45)
      aie.use_lock(%direct_a_host_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb2 loc(#loc45)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_a_host_6_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc45)
      aie.use_lock(%direct_a_host_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb1 loc(#loc45)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc45)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_a_host_6_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc45)
      aie.use_lock(%direct_a_host_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb5 loc(#loc45)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc45)
      aie.dma_bd(%direct_a_host_6_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc45)
      aie.use_lock(%direct_a_host_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc45)
      aie.next_bd ^bb4 loc(#loc45)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc47)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc46)
      aie.dma_bd(%direct_w_host_6_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc46)
      aie.use_lock(%direct_w_host_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc46)
      aie.next_bd ^bb8 loc(#loc46)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_6_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc46)
      aie.dma_bd(%direct_w_host_6_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc46)
      aie.use_lock(%direct_w_host_6_cons_prod_lock_0, Release, %c1_i32) loc(#loc46)
      aie.next_bd ^bb7 loc(#loc46)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc46)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc46)
      aie.dma_bd(%direct_w_host_6_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc46)
      aie.use_lock(%direct_w_host_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc46)
      aie.next_bd ^bb11 loc(#loc46)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_6_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc46)
      aie.dma_bd(%direct_w_host_6_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc46)
      aie.use_lock(%direct_w_host_6_cons_cons_lock_0, Release, %c1_i32) loc(#loc46)
      aie.next_bd ^bb10 loc(#loc46)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc11)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_6_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb14 loc(#loc11)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_6_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_1, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb15 loc(#loc11)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_6_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_2, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb16 loc(#loc11)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_6_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_3, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb17 loc(#loc11)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_6_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb18 loc(#loc11)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_6_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_1, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb19 loc(#loc11)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_6_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_2, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb20 loc(#loc11)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_6_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_prod_lock_3, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb13 loc(#loc11)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc10)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_6_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb23 loc(#loc11)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_6_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_0, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb22 loc(#loc11)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc9)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_6_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_1, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb26 loc(#loc11)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_6_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_1, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb25 loc(#loc11)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc8)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_6_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_2, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb29 loc(#loc11)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_6_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_2, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb28 loc(#loc11)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc7)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_6_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_3, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb32 loc(#loc11)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_6_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc11)
      aie.dma_bd(%direct_y_host_6_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc11)
      aie.use_lock(%direct_y_host_6_cons_lock_3, Release, %c1_i32) loc(#loc11)
      aie.next_bd ^bb31 loc(#loc11)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc67)
    } loc(#loc67)
    %mem_4_4 = aie.mem(%tile_4_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc67)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_6_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc67)
      aie.dma_bd(%direct_a_broadcast_6_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc67)
      aie.use_lock(%direct_a_broadcast_6_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc67)
      aie.next_bd ^bb1 loc(#loc67)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc53)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_4_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb4 loc(#loc53)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_4_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb3 loc(#loc53)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc18)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_4_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc18)
      aie.dma_bd(%direct_y_worker_4_2_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc18)
      aie.use_lock(%direct_y_worker_4_2_prod_lock_0, Release, %c1_i32) loc(#loc18)
      aie.next_bd ^bb7 loc(#loc18)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_4_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc18)
      aie.dma_bd(%direct_y_worker_4_2_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc18)
      aie.use_lock(%direct_y_worker_4_2_prod_lock_0, Release, %c1_i32) loc(#loc18)
      aie.next_bd ^bb6 loc(#loc18)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc67)
    } loc(#loc67)
    %mem_5_4 = aie.mem(%tile_5_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc67)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_6_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc67)
      aie.dma_bd(%direct_a_broadcast_6_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc67)
      aie.use_lock(%direct_a_broadcast_6_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc67)
      aie.next_bd ^bb1 loc(#loc67)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc50)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_5_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_broadcast_5_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc50)
      aie.use_lock(%direct_w_broadcast_5_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb4 loc(#loc50)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_5_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_broadcast_5_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc50)
      aie.use_lock(%direct_w_broadcast_5_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb3 loc(#loc50)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc13)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_5_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc13)
      aie.dma_bd(%direct_y_worker_5_2_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc13)
      aie.use_lock(%direct_y_worker_5_2_prod_lock_0, Release, %c1_i32) loc(#loc13)
      aie.next_bd ^bb7 loc(#loc13)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_5_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc13)
      aie.dma_bd(%direct_y_worker_5_2_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc13)
      aie.use_lock(%direct_y_worker_5_2_prod_lock_0, Release, %c1_i32) loc(#loc13)
      aie.next_bd ^bb6 loc(#loc13)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc67)
    } loc(#loc67)
    %mem_6_4 = aie.mem(%tile_6_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc67)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_6_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc67)
      aie.dma_bd(%direct_a_broadcast_6_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc67)
      aie.use_lock(%direct_a_broadcast_6_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc67)
      aie.next_bd ^bb1 loc(#loc67)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc47)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_6_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_6_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_6_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb4 loc(#loc47)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_6_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_6_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_6_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb3 loc(#loc47)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc8)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_6_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc8)
      aie.dma_bd(%direct_y_worker_6_2_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc8)
      aie.use_lock(%direct_y_worker_6_2_prod_lock_0, Release, %c1_i32) loc(#loc8)
      aie.next_bd ^bb7 loc(#loc8)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_6_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc8)
      aie.dma_bd(%direct_y_worker_6_2_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc8)
      aie.use_lock(%direct_y_worker_6_2_prod_lock_0, Release, %c1_i32) loc(#loc8)
      aie.next_bd ^bb6 loc(#loc8)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc67)
    } loc(#loc67)
    %mem_7_4 = aie.mem(%tile_7_4) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc67)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_6_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc67)
      aie.dma_bd(%direct_a_broadcast_6_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc67)
      aie.use_lock(%direct_a_broadcast_6_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc67)
      aie.next_bd ^bb1 loc(#loc67)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc44)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_7_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_w_broadcast_7_2_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc44)
      aie.use_lock(%direct_w_broadcast_7_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb4 loc(#loc44)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_7_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_w_broadcast_7_2_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc44)
      aie.use_lock(%direct_w_broadcast_7_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb3 loc(#loc44)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc3)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_7_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%direct_y_worker_7_2_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc3)
      aie.use_lock(%direct_y_worker_7_2_prod_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb7 loc(#loc3)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_7_2_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc3)
      aie.dma_bd(%direct_y_worker_7_2_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc3)
      aie.use_lock(%direct_y_worker_7_2_prod_lock_0, Release, %c1_i32) loc(#loc3)
      aie.next_bd ^bb6 loc(#loc3)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc67)
    } loc(#loc67)
    aie.shim_dma_allocation @direct_a_host_6_shim_alloc(%shim_noc_tile_6_0, MM2S, 0) loc(#loc45)
    %memtile_dma_7_1 = aie.memtile_dma(%mem_tile_7_1) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(MM2S, 0, ^bb1, ^bb3) loc(#loc66)
    ^bb1:  // 2 preds: ^bb0, ^bb2
      aie.use_lock(%direct_a_host_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc42)
      aie.dma_bd(%direct_a_host_7_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 0 : i32, next_bd_id = 1 : i32} loc(#loc42)
      aie.use_lock(%direct_a_host_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc42)
      aie.next_bd ^bb2 loc(#loc42)
    ^bb2:  // pred: ^bb1
      aie.use_lock(%direct_a_host_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc42)
      aie.dma_bd(%direct_a_host_7_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048 sizes = [1, 4, 512] strides = [512, 512, 1]) {bd_id = 1 : i32, next_bd_id = 0 : i32} loc(#loc42)
      aie.use_lock(%direct_a_host_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc42)
      aie.next_bd ^bb1 loc(#loc42)
    ^bb3:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 0, ^bb4, ^bb6) loc(#loc42)
    ^bb4:  // 2 preds: ^bb3, ^bb5
      aie.use_lock(%direct_a_host_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc42)
      aie.dma_bd(%direct_a_host_7_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 2 : i32, next_bd_id = 3 : i32} loc(#loc42)
      aie.use_lock(%direct_a_host_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc42)
      aie.next_bd ^bb5 loc(#loc42)
    ^bb5:  // pred: ^bb4
      aie.use_lock(%direct_a_host_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc42)
      aie.dma_bd(%direct_a_host_7_cons_buff_1 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 3 : i32, next_bd_id = 2 : i32} loc(#loc42)
      aie.use_lock(%direct_a_host_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc42)
      aie.next_bd ^bb4 loc(#loc42)
    ^bb6:  // pred: ^bb3
      %2 = aie.dma_start(MM2S, 1, ^bb7, ^bb9) loc(#loc44)
    ^bb7:  // 2 preds: ^bb6, ^bb8
      aie.use_lock(%direct_w_host_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc43)
      aie.dma_bd(%direct_w_host_7_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 24 : i32, next_bd_id = 25 : i32} loc(#loc43)
      aie.use_lock(%direct_w_host_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc43)
      aie.next_bd ^bb8 loc(#loc43)
    ^bb8:  // pred: ^bb7
      aie.use_lock(%direct_w_host_7_cons_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc43)
      aie.dma_bd(%direct_w_host_7_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 25 : i32, next_bd_id = 24 : i32} loc(#loc43)
      aie.use_lock(%direct_w_host_7_cons_prod_lock_0, Release, %c1_i32) loc(#loc43)
      aie.next_bd ^bb7 loc(#loc43)
    ^bb9:  // pred: ^bb6
      %3 = aie.dma_start(S2MM, 1, ^bb10, ^bb12) loc(#loc43)
    ^bb10:  // 2 preds: ^bb9, ^bb11
      aie.use_lock(%direct_w_host_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc43)
      aie.dma_bd(%direct_w_host_7_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 26 : i32, next_bd_id = 27 : i32} loc(#loc43)
      aie.use_lock(%direct_w_host_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc43)
      aie.next_bd ^bb11 loc(#loc43)
    ^bb11:  // pred: ^bb10
      aie.use_lock(%direct_w_host_7_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc43)
      aie.dma_bd(%direct_w_host_7_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 27 : i32, next_bd_id = 26 : i32} loc(#loc43)
      aie.use_lock(%direct_w_host_7_cons_cons_lock_0, Release, %c1_i32) loc(#loc43)
      aie.next_bd ^bb10 loc(#loc43)
    ^bb12:  // pred: ^bb9
      %4 = aie.dma_start(MM2S, 2, ^bb13, ^bb21) loc(#loc6)
    ^bb13:  // 2 preds: ^bb12, ^bb20
      aie.use_lock(%direct_y_host_7_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 5 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb14 loc(#loc6)
    ^bb14:  // pred: ^bb13
      aie.use_lock(%direct_y_host_7_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 5 : i32, next_bd_id = 6 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_1, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb15 loc(#loc6)
    ^bb15:  // pred: ^bb14
      aie.use_lock(%direct_y_host_7_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 6 : i32, next_bd_id = 7 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_2, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb16 loc(#loc6)
    ^bb16:  // pred: ^bb15
      aie.use_lock(%direct_y_host_7_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 7 : i32, next_bd_id = 8 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_3, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb17 loc(#loc6)
    ^bb17:  // pred: ^bb16
      aie.use_lock(%direct_y_host_7_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 8 : i32, next_bd_id = 9 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb18 loc(#loc6)
    ^bb18:  // pred: ^bb17
      aie.use_lock(%direct_y_host_7_cons_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 9 : i32, next_bd_id = 10 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_1, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb19 loc(#loc6)
    ^bb19:  // pred: ^bb18
      aie.use_lock(%direct_y_host_7_cons_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 10 : i32, next_bd_id = 11 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_2, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb20 loc(#loc6)
    ^bb20:  // pred: ^bb19
      aie.use_lock(%direct_y_host_7_cons_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 11 : i32, next_bd_id = 4 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_prod_lock_3, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb13 loc(#loc6)
    ^bb21:  // pred: ^bb12
      %5 = aie.dma_start(S2MM, 2, ^bb22, ^bb24) loc(#loc5)
    ^bb22:  // 2 preds: ^bb21, ^bb23
      aie.use_lock(%direct_y_host_7_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 12 : i32, next_bd_id = 13 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb23 loc(#loc6)
    ^bb23:  // pred: ^bb22
      aie.use_lock(%direct_y_host_7_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<2048xbf16> offset = 0 len = 512) {bd_id = 13 : i32, next_bd_id = 12 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_0, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb22 loc(#loc6)
    ^bb24:  // pred: ^bb21
      %6 = aie.dma_start(S2MM, 3, ^bb25, ^bb27) loc(#loc4)
    ^bb25:  // 2 preds: ^bb24, ^bb26
      aie.use_lock(%direct_y_host_7_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 28 : i32, next_bd_id = 29 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_1, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb26 loc(#loc6)
    ^bb26:  // pred: ^bb25
      aie.use_lock(%direct_y_host_7_prod_lock_1, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<2048xbf16> offset = 512 len = 512) {bd_id = 29 : i32, next_bd_id = 28 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_1, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb25 loc(#loc6)
    ^bb27:  // pred: ^bb24
      %7 = aie.dma_start(S2MM, 4, ^bb28, ^bb30) loc(#loc3)
    ^bb28:  // 2 preds: ^bb27, ^bb29
      aie.use_lock(%direct_y_host_7_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 14 : i32, next_bd_id = 15 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_2, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb29 loc(#loc6)
    ^bb29:  // pred: ^bb28
      aie.use_lock(%direct_y_host_7_prod_lock_2, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<2048xbf16> offset = 1024 len = 512) {bd_id = 15 : i32, next_bd_id = 14 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_2, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb28 loc(#loc6)
    ^bb30:  // pred: ^bb27
      %8 = aie.dma_start(S2MM, 5, ^bb31, ^bb33) loc(#loc2)
    ^bb31:  // 2 preds: ^bb30, ^bb32
      aie.use_lock(%direct_y_host_7_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_0 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 30 : i32, next_bd_id = 31 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_3, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb32 loc(#loc6)
    ^bb32:  // pred: ^bb31
      aie.use_lock(%direct_y_host_7_prod_lock_3, AcquireGreaterEqual, %c1_i32) loc(#loc6)
      aie.dma_bd(%direct_y_host_7_buff_1 : memref<2048xbf16> offset = 1536 len = 512) {bd_id = 31 : i32, next_bd_id = 30 : i32} loc(#loc6)
      aie.use_lock(%direct_y_host_7_cons_lock_3, Release, %c1_i32) loc(#loc6)
      aie.next_bd ^bb31 loc(#loc6)
    ^bb33:  // pred: ^bb30
      aie.end loc(#loc66)
    } loc(#loc66)
    %mem_4_5 = aie.mem(%tile_4_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc66)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_7_0_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc66)
      aie.dma_bd(%direct_a_broadcast_7_0_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc66)
      aie.use_lock(%direct_a_broadcast_7_0_cons_cons_lock_0, Release, %c1_i32) loc(#loc66)
      aie.next_bd ^bb1 loc(#loc66)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc53)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_4_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb4 loc(#loc53)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_4_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc53)
      aie.dma_bd(%direct_w_broadcast_4_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc53)
      aie.use_lock(%direct_w_broadcast_4_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc53)
      aie.next_bd ^bb3 loc(#loc53)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc17)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_4_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc17)
      aie.dma_bd(%direct_y_worker_4_3_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc17)
      aie.use_lock(%direct_y_worker_4_3_prod_lock_0, Release, %c1_i32) loc(#loc17)
      aie.next_bd ^bb7 loc(#loc17)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_4_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc17)
      aie.dma_bd(%direct_y_worker_4_3_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc17)
      aie.use_lock(%direct_y_worker_4_3_prod_lock_0, Release, %c1_i32) loc(#loc17)
      aie.next_bd ^bb6 loc(#loc17)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc66)
    } loc(#loc66)
    %mem_5_5 = aie.mem(%tile_5_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc66)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_7_1_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc66)
      aie.dma_bd(%direct_a_broadcast_7_1_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc66)
      aie.use_lock(%direct_a_broadcast_7_1_cons_cons_lock_0, Release, %c1_i32) loc(#loc66)
      aie.next_bd ^bb1 loc(#loc66)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc50)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_5_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_broadcast_5_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc50)
      aie.use_lock(%direct_w_broadcast_5_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb4 loc(#loc50)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_5_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc50)
      aie.dma_bd(%direct_w_broadcast_5_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc50)
      aie.use_lock(%direct_w_broadcast_5_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc50)
      aie.next_bd ^bb3 loc(#loc50)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc12)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_5_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc12)
      aie.dma_bd(%direct_y_worker_5_3_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc12)
      aie.use_lock(%direct_y_worker_5_3_prod_lock_0, Release, %c1_i32) loc(#loc12)
      aie.next_bd ^bb7 loc(#loc12)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_5_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc12)
      aie.dma_bd(%direct_y_worker_5_3_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc12)
      aie.use_lock(%direct_y_worker_5_3_prod_lock_0, Release, %c1_i32) loc(#loc12)
      aie.next_bd ^bb6 loc(#loc12)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc66)
    } loc(#loc66)
    %mem_6_5 = aie.mem(%tile_6_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc66)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_7_2_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc66)
      aie.dma_bd(%direct_a_broadcast_7_2_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc66)
      aie.use_lock(%direct_a_broadcast_7_2_cons_cons_lock_0, Release, %c1_i32) loc(#loc66)
      aie.next_bd ^bb1 loc(#loc66)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc47)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_6_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_6_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_6_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb4 loc(#loc47)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_6_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc47)
      aie.dma_bd(%direct_w_broadcast_6_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc47)
      aie.use_lock(%direct_w_broadcast_6_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc47)
      aie.next_bd ^bb3 loc(#loc47)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc7)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_6_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc7)
      aie.dma_bd(%direct_y_worker_6_3_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc7)
      aie.use_lock(%direct_y_worker_6_3_prod_lock_0, Release, %c1_i32) loc(#loc7)
      aie.next_bd ^bb7 loc(#loc7)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_6_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc7)
      aie.dma_bd(%direct_y_worker_6_3_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc7)
      aie.use_lock(%direct_y_worker_6_3_prod_lock_0, Release, %c1_i32) loc(#loc7)
      aie.next_bd ^bb6 loc(#loc7)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc66)
    } loc(#loc66)
    %mem_7_5 = aie.mem(%tile_7_5) {
      %c1_i32 = arith.constant 1 : i32 loc(#loc175)
      %0 = aie.dma_start(S2MM, 0, ^bb1, ^bb2) loc(#loc66)
    ^bb1:  // 2 preds: ^bb0, ^bb1
      aie.use_lock(%direct_a_broadcast_7_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc66)
      aie.dma_bd(%direct_a_broadcast_7_3_cons_buff_0 : memref<2048xbf16> offset = 0 len = 2048) {bd_id = 0 : i32, next_bd_id = 0 : i32} loc(#loc66)
      aie.use_lock(%direct_a_broadcast_7_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc66)
      aie.next_bd ^bb1 loc(#loc66)
    ^bb2:  // pred: ^bb0
      %1 = aie.dma_start(S2MM, 1, ^bb3, ^bb5) loc(#loc44)
    ^bb3:  // 2 preds: ^bb2, ^bb4
      aie.use_lock(%direct_w_broadcast_7_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_w_broadcast_7_3_cons_buff_0 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 1 : i32, next_bd_id = 2 : i32} loc(#loc44)
      aie.use_lock(%direct_w_broadcast_7_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb4 loc(#loc44)
    ^bb4:  // pred: ^bb3
      aie.use_lock(%direct_w_broadcast_7_3_cons_prod_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc44)
      aie.dma_bd(%direct_w_broadcast_7_3_cons_buff_1 : memref<4352xui8> offset = 0 len = 4352) {bd_id = 2 : i32, next_bd_id = 1 : i32} loc(#loc44)
      aie.use_lock(%direct_w_broadcast_7_3_cons_cons_lock_0, Release, %c1_i32) loc(#loc44)
      aie.next_bd ^bb3 loc(#loc44)
    ^bb5:  // pred: ^bb2
      %2 = aie.dma_start(MM2S, 0, ^bb6, ^bb8) loc(#loc2)
    ^bb6:  // 2 preds: ^bb5, ^bb7
      aie.use_lock(%direct_y_worker_7_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%direct_y_worker_7_3_buff_0 : memref<512xbf16> offset = 0 len = 512) {bd_id = 3 : i32, next_bd_id = 4 : i32} loc(#loc2)
      aie.use_lock(%direct_y_worker_7_3_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb7 loc(#loc2)
    ^bb7:  // pred: ^bb6
      aie.use_lock(%direct_y_worker_7_3_cons_lock_0, AcquireGreaterEqual, %c1_i32) loc(#loc2)
      aie.dma_bd(%direct_y_worker_7_3_buff_1 : memref<512xbf16> offset = 0 len = 512) {bd_id = 4 : i32, next_bd_id = 3 : i32} loc(#loc2)
      aie.use_lock(%direct_y_worker_7_3_prod_lock_0, Release, %c1_i32) loc(#loc2)
      aie.next_bd ^bb6 loc(#loc2)
    ^bb8:  // pred: ^bb5
      aie.end loc(#loc66)
    } loc(#loc66)
    aie.shim_dma_allocation @direct_a_host_7_shim_alloc(%shim_noc_tile_7_0, MM2S, 0) loc(#loc42)
    aie.shim_dma_allocation @direct_w_host_0_shim_alloc(%shim_noc_tile_0_0, MM2S, 1) loc(#loc64)
    aie.shim_dma_allocation @direct_w_host_1_shim_alloc(%shim_noc_tile_1_0, MM2S, 1) loc(#loc61)
    aie.shim_dma_allocation @direct_w_host_2_shim_alloc(%shim_noc_tile_2_0, MM2S, 1) loc(#loc58)
    aie.shim_dma_allocation @direct_w_host_3_shim_alloc(%shim_noc_tile_3_0, MM2S, 1) loc(#loc55)
    aie.shim_dma_allocation @direct_w_host_4_shim_alloc(%shim_noc_tile_4_0, MM2S, 1) loc(#loc52)
    aie.shim_dma_allocation @direct_w_host_5_shim_alloc(%shim_noc_tile_5_0, MM2S, 1) loc(#loc49)
    aie.shim_dma_allocation @direct_w_host_6_shim_alloc(%shim_noc_tile_6_0, MM2S, 1) loc(#loc46)
    aie.shim_dma_allocation @direct_w_host_7_shim_alloc(%shim_noc_tile_7_0, MM2S, 1) loc(#loc43)
    aie.shim_dma_allocation @direct_y_host_0_shim_alloc(%shim_noc_tile_0_0, S2MM, 0) loc(#loc41)
    aie.shim_dma_allocation @direct_y_host_1_shim_alloc(%shim_noc_tile_1_0, S2MM, 0) loc(#loc36)
    aie.shim_dma_allocation @direct_y_host_2_shim_alloc(%shim_noc_tile_2_0, S2MM, 0) loc(#loc31)
    aie.shim_dma_allocation @direct_y_host_3_shim_alloc(%shim_noc_tile_3_0, S2MM, 0) loc(#loc26)
    aie.shim_dma_allocation @direct_y_host_4_shim_alloc(%shim_noc_tile_4_0, S2MM, 0) loc(#loc21)
    aie.shim_dma_allocation @direct_y_host_5_shim_alloc(%shim_noc_tile_5_0, S2MM, 0) loc(#loc16)
    aie.shim_dma_allocation @direct_y_host_6_shim_alloc(%shim_noc_tile_6_0, S2MM, 0) loc(#loc11)
    aie.shim_dma_allocation @direct_y_host_7_shim_alloc(%shim_noc_tile_7_0, S2MM, 0) loc(#loc6)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_7_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_7_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_6_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_6_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_5_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_5_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_4_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_4_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_3_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_3_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_2_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_2_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_1_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_1_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
    aie.packet_flow(15) {
      aie.packet_source<%shim_noc_tile_0_0, TileControl : 0> loc(#loc1)
      aie.packet_dest<%shim_noc_tile_0_0, South : 0> loc(#loc1)
    } {keep_pkt_header = true, priority_route = true} loc(#loc1)
  } loc(#loc1)
} loc(#loc)
#loc = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1:1)
#loc1 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":2:3)
#loc2 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":177:5)
#loc3 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":176:5)
#loc4 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":175:5)
#loc5 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":174:5)
#loc6 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":173:5)
#loc7 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":171:5)
#loc8 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":170:5)
#loc9 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":169:5)
#loc10 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":168:5)
#loc11 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":167:5)
#loc12 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":165:5)
#loc13 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":164:5)
#loc14 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":163:5)
#loc15 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":162:5)
#loc16 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":161:5)
#loc17 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":159:5)
#loc18 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":158:5)
#loc19 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":157:5)
#loc20 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":156:5)
#loc21 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":155:5)
#loc22 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":153:5)
#loc23 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":152:5)
#loc24 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":151:5)
#loc25 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":150:5)
#loc26 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":149:5)
#loc27 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":147:5)
#loc28 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":146:5)
#loc29 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":145:5)
#loc30 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":144:5)
#loc31 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":143:5)
#loc32 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":141:5)
#loc33 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":140:5)
#loc34 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":139:5)
#loc35 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":138:5)
#loc36 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":137:5)
#loc37 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":135:5)
#loc38 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":134:5)
#loc39 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":133:5)
#loc40 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":132:5)
#loc41 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":131:5)
#loc42 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":105:5)
#loc43 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":129:5)
#loc44 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":128:5)
#loc45 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":102:5)
#loc46 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":126:5)
#loc47 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":125:5)
#loc48 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":99:5)
#loc49 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":123:5)
#loc50 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":122:5)
#loc51 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":96:5)
#loc52 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":120:5)
#loc53 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":119:5)
#loc54 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":93:5)
#loc55 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":117:5)
#loc56 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":116:5)
#loc57 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":90:5)
#loc58 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":114:5)
#loc59 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":113:5)
#loc60 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":87:5)
#loc61 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":111:5)
#loc62 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":110:5)
#loc63 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":84:5)
#loc64 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":108:5)
#loc65 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":107:5)
#loc66 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":104:5)
#loc67 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":101:5)
#loc68 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":98:5)
#loc69 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":95:5)
#loc70 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":92:5)
#loc71 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":89:5)
#loc72 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":86:5)
#loc73 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":83:5)
#loc74 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":179:24)
#loc75 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":180:24)
#loc76 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":181:27)
#loc77 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":182:5)
#loc78 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":183:5)
#loc79 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":184:5)
#loc80 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":185:5)
#loc81 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":186:24)
#loc82 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":187:24)
#loc83 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":188:27)
#loc84 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":189:24)
#loc85 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":190:24)
#loc86 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":191:27)
#loc87 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":192:24)
#loc88 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":193:24)
#loc89 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":194:27)
#loc90 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":195:24)
#loc91 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":196:24)
#loc92 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":197:27)
#loc93 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":198:24)
#loc94 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":199:24)
#loc95 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":200:27)
#loc96 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":201:24)
#loc97 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":202:24)
#loc98 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":203:27)
#loc99 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":204:24)
#loc100 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":205:24)
#loc101 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":206:27)
#loc102 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":207:24)
#loc103 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":208:24)
#loc104 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":209:27)
#loc105 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":210:24)
#loc106 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":211:24)
#loc107 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":212:27)
#loc108 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":213:24)
#loc109 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":214:24)
#loc110 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":215:27)
#loc111 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":216:24)
#loc112 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":217:24)
#loc113 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":218:27)
#loc114 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":219:24)
#loc115 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":220:24)
#loc116 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":221:27)
#loc117 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":222:24)
#loc118 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":223:24)
#loc119 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":224:27)
#loc120 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":225:24)
#loc121 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":226:24)
#loc122 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":227:27)
#loc123 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":228:24)
#loc124 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":229:24)
#loc125 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":230:27)
#loc126 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":231:24)
#loc127 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":232:24)
#loc128 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":233:27)
#loc129 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":234:24)
#loc130 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":235:24)
#loc131 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":236:27)
#loc132 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":237:24)
#loc133 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":238:24)
#loc134 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":239:27)
#loc135 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":240:24)
#loc136 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":241:24)
#loc137 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":242:27)
#loc138 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":243:24)
#loc139 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":244:24)
#loc140 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":245:27)
#loc141 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":246:24)
#loc142 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":247:24)
#loc143 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":248:27)
#loc144 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":249:24)
#loc145 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":250:24)
#loc146 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":251:27)
#loc147 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":252:24)
#loc148 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":253:24)
#loc149 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":254:27)
#loc150 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":255:24)
#loc151 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":256:24)
#loc152 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":257:27)
#loc153 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":258:24)
#loc154 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":259:24)
#loc155 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":260:27)
#loc156 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":261:24)
#loc157 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":262:24)
#loc158 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":263:27)
#loc159 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":264:24)
#loc160 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":265:24)
#loc161 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":266:27)
#loc162 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":267:24)
#loc163 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":268:24)
#loc164 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":269:27)
#loc165 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":270:24)
#loc166 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":271:24)
#loc167 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":272:27)
#loc168 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":273:24)
#loc169 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":274:24)
#loc170 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":275:27)
#loc171 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":276:24)
#loc172 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":277:24)
#loc173 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":278:27)
#loc175 = loc(unknown)
#loc176 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":283:7)
#loc178 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":288:11)
#loc179 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":292:11)
#loc181 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":293:18)
#loc182 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":295:18)
#loc184 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":297:13)
#loc185 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":298:13)
#loc186 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":299:13)
#loc187 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":301:16)
#loc189 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":303:11)
#loc190 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":304:11)
#loc191 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":307:7)
#loc193 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":313:7)
#loc195 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":318:11)
#loc196 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":322:11)
#loc198 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":323:18)
#loc199 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":325:18)
#loc201 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":327:13)
#loc202 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":328:13)
#loc203 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":329:13)
#loc204 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":331:16)
#loc206 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":333:11)
#loc207 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":334:11)
#loc208 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":337:7)
#loc210 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":343:7)
#loc212 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":348:11)
#loc213 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":352:11)
#loc215 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":353:18)
#loc216 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":355:18)
#loc218 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":357:13)
#loc219 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":358:13)
#loc220 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":359:13)
#loc221 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":361:16)
#loc223 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":363:11)
#loc224 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":364:11)
#loc225 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":367:7)
#loc227 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":373:7)
#loc229 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":378:11)
#loc230 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":382:11)
#loc232 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":383:18)
#loc233 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":385:18)
#loc235 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":387:13)
#loc236 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":388:13)
#loc237 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":389:13)
#loc238 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":391:16)
#loc240 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":393:11)
#loc241 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":394:11)
#loc242 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":397:7)
#loc244 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":403:7)
#loc246 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":408:11)
#loc247 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":412:11)
#loc249 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":413:18)
#loc250 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":415:18)
#loc252 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":417:13)
#loc253 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":418:13)
#loc254 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":419:13)
#loc255 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":421:16)
#loc257 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":423:11)
#loc258 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":424:11)
#loc259 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":427:7)
#loc261 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":433:7)
#loc263 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":438:11)
#loc264 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":442:11)
#loc266 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":443:18)
#loc267 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":445:18)
#loc269 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":447:13)
#loc270 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":448:13)
#loc271 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":449:13)
#loc272 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":451:16)
#loc274 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":453:11)
#loc275 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":454:11)
#loc276 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":457:7)
#loc278 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":463:7)
#loc280 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":468:11)
#loc281 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":472:11)
#loc283 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":473:18)
#loc284 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":475:18)
#loc286 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":477:13)
#loc287 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":478:13)
#loc288 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":479:13)
#loc289 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":481:16)
#loc291 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":483:11)
#loc292 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":484:11)
#loc293 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":487:7)
#loc295 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":493:7)
#loc297 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":498:11)
#loc298 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":502:11)
#loc300 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":503:18)
#loc301 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":505:18)
#loc303 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":507:13)
#loc304 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":508:13)
#loc305 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":509:13)
#loc306 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":511:16)
#loc308 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":513:11)
#loc309 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":514:11)
#loc310 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":517:7)
#loc312 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":523:7)
#loc314 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":528:11)
#loc315 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":532:11)
#loc317 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":533:18)
#loc318 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":535:18)
#loc320 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":537:13)
#loc321 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":538:13)
#loc322 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":539:13)
#loc323 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":541:16)
#loc325 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":543:11)
#loc326 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":544:11)
#loc327 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":547:7)
#loc329 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":553:7)
#loc331 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":558:11)
#loc332 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":562:11)
#loc334 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":563:18)
#loc335 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":565:18)
#loc337 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":567:13)
#loc338 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":568:13)
#loc339 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":569:13)
#loc340 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":571:16)
#loc342 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":573:11)
#loc343 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":574:11)
#loc344 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":577:7)
#loc346 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":583:7)
#loc348 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":588:11)
#loc349 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":592:11)
#loc351 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":593:18)
#loc352 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":595:18)
#loc354 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":597:13)
#loc355 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":598:13)
#loc356 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":599:13)
#loc357 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":601:16)
#loc359 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":603:11)
#loc360 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":604:11)
#loc361 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":607:7)
#loc363 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":613:7)
#loc365 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":618:11)
#loc366 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":622:11)
#loc368 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":623:18)
#loc369 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":625:18)
#loc371 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":627:13)
#loc372 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":628:13)
#loc373 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":629:13)
#loc374 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":631:16)
#loc376 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":633:11)
#loc377 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":634:11)
#loc378 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":637:7)
#loc380 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":643:7)
#loc382 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":648:11)
#loc383 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":652:11)
#loc385 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":653:18)
#loc386 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":655:18)
#loc388 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":657:13)
#loc389 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":658:13)
#loc390 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":659:13)
#loc391 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":661:16)
#loc393 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":663:11)
#loc394 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":664:11)
#loc395 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":667:7)
#loc397 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":673:7)
#loc399 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":678:11)
#loc400 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":682:11)
#loc402 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":683:18)
#loc403 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":685:18)
#loc405 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":687:13)
#loc406 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":688:13)
#loc407 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":689:13)
#loc408 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":691:16)
#loc410 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":693:11)
#loc411 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":694:11)
#loc412 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":697:7)
#loc414 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":703:7)
#loc416 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":708:11)
#loc417 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":712:11)
#loc419 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":713:18)
#loc420 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":715:18)
#loc422 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":717:13)
#loc423 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":718:13)
#loc424 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":719:13)
#loc425 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":721:16)
#loc427 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":723:11)
#loc428 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":724:11)
#loc429 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":727:7)
#loc431 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":733:7)
#loc433 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":738:11)
#loc434 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":742:11)
#loc436 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":743:18)
#loc437 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":745:18)
#loc439 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":747:13)
#loc440 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":748:13)
#loc441 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":749:13)
#loc442 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":751:16)
#loc444 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":753:11)
#loc445 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":754:11)
#loc446 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":757:7)
#loc448 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":763:7)
#loc450 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":768:11)
#loc451 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":772:11)
#loc453 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":773:18)
#loc454 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":775:18)
#loc456 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":777:13)
#loc457 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":778:13)
#loc458 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":779:13)
#loc459 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":781:16)
#loc461 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":783:11)
#loc462 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":784:11)
#loc463 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":787:7)
#loc465 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":793:7)
#loc467 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":798:11)
#loc468 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":802:11)
#loc470 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":803:18)
#loc471 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":805:18)
#loc473 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":807:13)
#loc474 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":808:13)
#loc475 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":809:13)
#loc476 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":811:16)
#loc478 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":813:11)
#loc479 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":814:11)
#loc480 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":817:7)
#loc482 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":823:7)
#loc484 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":828:11)
#loc485 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":832:11)
#loc487 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":833:18)
#loc488 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":835:18)
#loc490 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":837:13)
#loc491 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":838:13)
#loc492 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":839:13)
#loc493 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":841:16)
#loc495 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":843:11)
#loc496 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":844:11)
#loc497 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":847:7)
#loc499 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":853:7)
#loc501 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":858:11)
#loc502 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":862:11)
#loc504 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":863:18)
#loc505 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":865:18)
#loc507 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":867:13)
#loc508 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":868:13)
#loc509 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":869:13)
#loc510 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":871:16)
#loc512 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":873:11)
#loc513 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":874:11)
#loc514 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":877:7)
#loc516 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":883:7)
#loc518 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":888:11)
#loc519 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":892:11)
#loc521 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":893:18)
#loc522 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":895:18)
#loc524 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":897:13)
#loc525 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":898:13)
#loc526 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":899:13)
#loc527 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":901:16)
#loc529 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":903:11)
#loc530 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":904:11)
#loc531 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":907:7)
#loc533 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":913:7)
#loc535 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":918:11)
#loc536 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":922:11)
#loc538 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":923:18)
#loc539 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":925:18)
#loc541 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":927:13)
#loc542 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":928:13)
#loc543 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":929:13)
#loc544 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":931:16)
#loc546 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":933:11)
#loc547 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":934:11)
#loc548 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":937:7)
#loc550 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":943:7)
#loc552 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":948:11)
#loc553 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":952:11)
#loc555 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":953:18)
#loc556 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":955:18)
#loc558 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":957:13)
#loc559 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":958:13)
#loc560 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":959:13)
#loc561 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":961:16)
#loc563 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":963:11)
#loc564 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":964:11)
#loc565 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":967:7)
#loc567 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":973:7)
#loc569 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":978:11)
#loc570 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":982:11)
#loc572 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":983:18)
#loc573 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":985:18)
#loc575 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":987:13)
#loc576 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":988:13)
#loc577 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":989:13)
#loc578 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":991:16)
#loc580 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":993:11)
#loc581 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":994:11)
#loc582 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":997:7)
#loc584 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1003:7)
#loc586 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1008:11)
#loc587 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1012:11)
#loc589 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1013:18)
#loc590 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1015:18)
#loc592 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1017:13)
#loc593 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1018:13)
#loc594 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1019:13)
#loc595 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1021:16)
#loc597 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1023:11)
#loc598 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1024:11)
#loc599 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1027:7)
#loc601 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1033:7)
#loc603 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1038:11)
#loc604 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1042:11)
#loc606 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1043:18)
#loc607 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1045:18)
#loc609 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1047:13)
#loc610 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1048:13)
#loc611 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1049:13)
#loc612 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1051:16)
#loc614 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1053:11)
#loc615 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1054:11)
#loc616 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1057:7)
#loc618 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1063:7)
#loc620 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1068:11)
#loc621 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1072:11)
#loc623 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1073:18)
#loc624 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1075:18)
#loc626 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1077:13)
#loc627 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1078:13)
#loc628 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1079:13)
#loc629 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1081:16)
#loc631 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1083:11)
#loc632 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1084:11)
#loc633 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1087:7)
#loc635 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1093:7)
#loc637 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1098:11)
#loc638 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1102:11)
#loc640 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1103:18)
#loc641 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1105:18)
#loc643 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1107:13)
#loc644 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1108:13)
#loc645 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1109:13)
#loc646 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1111:16)
#loc648 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1113:11)
#loc649 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1114:11)
#loc650 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1117:7)
#loc652 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1123:7)
#loc654 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1128:11)
#loc655 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1132:11)
#loc657 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1133:18)
#loc658 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1135:18)
#loc660 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1137:13)
#loc661 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1138:13)
#loc662 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1139:13)
#loc663 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1141:16)
#loc665 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1143:11)
#loc666 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1144:11)
#loc667 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1147:7)
#loc669 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1153:7)
#loc671 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1158:11)
#loc672 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1162:11)
#loc674 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1163:18)
#loc675 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1165:18)
#loc677 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1167:13)
#loc678 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1168:13)
#loc679 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1169:13)
#loc680 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1171:16)
#loc682 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1173:11)
#loc683 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1174:11)
#loc684 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1177:7)
#loc686 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1183:7)
#loc688 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1188:11)
#loc689 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1192:11)
#loc691 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1193:18)
#loc692 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1195:18)
#loc694 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1197:13)
#loc695 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1198:13)
#loc696 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1199:13)
#loc697 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1201:16)
#loc699 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1203:11)
#loc700 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1204:11)
#loc701 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1207:7)
#loc703 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1213:7)
#loc705 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1218:11)
#loc706 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1222:11)
#loc708 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1223:18)
#loc709 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1225:18)
#loc711 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1227:13)
#loc712 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1228:13)
#loc713 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1229:13)
#loc714 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1231:16)
#loc716 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1233:11)
#loc717 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1234:11)
#loc718 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1237:7)
#loc719 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1239:5)
#loc723 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1240:12)
#loc724 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1241:9)
#loc725 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1242:9)
#loc726 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1244:7)
#loc727 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1245:12)
#loc728 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1246:9)
#loc729 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1247:9)
#loc730 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1249:7)
#loc731 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1250:12)
#loc732 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1251:9)
#loc733 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1252:9)
#loc734 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1254:7)
#loc735 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1255:12)
#loc736 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1256:9)
#loc737 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1257:9)
#loc738 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1259:7)
#loc739 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1260:12)
#loc740 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1261:9)
#loc741 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1262:9)
#loc742 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1264:7)
#loc743 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1265:12)
#loc744 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1266:9)
#loc745 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1267:9)
#loc746 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1269:7)
#loc747 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1270:12)
#loc748 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1271:9)
#loc749 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1272:9)
#loc750 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1274:7)
#loc751 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1275:12)
#loc752 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1276:9)
#loc753 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1277:9)
#loc754 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1279:7)
#loc755 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1280:12)
#loc756 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1281:9)
#loc757 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1282:9)
#loc758 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1284:7)
#loc759 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1285:12)
#loc760 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1286:9)
#loc761 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1287:9)
#loc762 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1289:7)
#loc763 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1290:13)
#loc764 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1291:9)
#loc765 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1292:9)
#loc766 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1294:7)
#loc767 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1295:13)
#loc768 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1296:9)
#loc769 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1297:9)
#loc770 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1299:7)
#loc771 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1300:13)
#loc772 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1301:9)
#loc773 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1302:9)
#loc774 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1304:7)
#loc775 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1305:13)
#loc776 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1306:9)
#loc777 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1307:9)
#loc778 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1309:7)
#loc779 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1310:13)
#loc780 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1311:9)
#loc781 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1312:9)
#loc782 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1314:7)
#loc783 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1315:13)
#loc784 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1316:9)
#loc785 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1317:9)
#loc786 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1319:7)
#loc787 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1320:13)
#loc788 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1321:9)
#loc789 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1322:9)
#loc790 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1324:7)
#loc791 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1325:13)
#loc792 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1326:9)
#loc793 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1327:9)
#loc794 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1329:7)
#loc795 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1330:13)
#loc796 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1331:9)
#loc797 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1332:9)
#loc798 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1334:7)
#loc799 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1335:13)
#loc800 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1336:9)
#loc801 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1337:9)
#loc802 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1339:7)
#loc803 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1340:13)
#loc804 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1341:9)
#loc805 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1342:9)
#loc806 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1344:7)
#loc807 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1345:13)
#loc808 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1346:9)
#loc809 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1347:9)
#loc810 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1349:7)
#loc811 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1350:13)
#loc812 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1351:9)
#loc813 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1352:9)
#loc814 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1354:7)
#loc815 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1355:13)
#loc816 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1356:9)
#loc817 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1357:9)
#loc818 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1359:7)
#loc819 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1360:7)
#loc820 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1361:7)
#loc821 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1362:7)
#loc822 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1363:7)
#loc823 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1364:7)
#loc824 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1365:7)
#loc825 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1366:7)
#loc826 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1367:7)
#loc827 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1368:7)
#loc828 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1369:7)
#loc829 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1370:7)
#loc830 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1371:7)
#loc831 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1372:7)
#loc832 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1373:7)
#loc833 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1374:7)
#loc834 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1375:7)
#loc835 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1376:7)
#loc836 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1377:7)
#loc837 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1378:7)
#loc838 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1379:7)
#loc839 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1380:7)
#loc840 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1381:7)
#loc841 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1382:7)
#loc842 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1383:7)
#loc843 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1384:7)
#loc844 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1385:7)
#loc845 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1386:7)
#loc846 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1387:7)
#loc847 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1388:7)
#loc848 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1389:7)
#loc849 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1390:7)
#loc850 = loc("/notebooks/HeteroMega-kernel-opt-bf16-20261025/artifacts_v3/upstream_bf16_projection_m128_k256_n128_0914010889a7ad6d/final.prj/aie.mlir":1391:7)
