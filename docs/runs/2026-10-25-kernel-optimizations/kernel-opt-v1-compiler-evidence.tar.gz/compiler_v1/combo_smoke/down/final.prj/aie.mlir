module {
  aie.device(npu2) {
    %logical_core = aie.logical_tile<CoreTile>(0, 2)
    %logical_core_0 = aie.logical_tile<CoreTile>(0, 3)
    %logical_core_1 = aie.logical_tile<CoreTile>(0, 4)
    %logical_core_2 = aie.logical_tile<CoreTile>(0, 5)
    %logical_core_3 = aie.logical_tile<CoreTile>(1, 2)
    %logical_core_4 = aie.logical_tile<CoreTile>(1, 3)
    %logical_core_5 = aie.logical_tile<CoreTile>(1, 4)
    %logical_core_6 = aie.logical_tile<CoreTile>(1, 5)
    %logical_core_7 = aie.logical_tile<CoreTile>(2, 2)
    %logical_core_8 = aie.logical_tile<CoreTile>(2, 3)
    %logical_core_9 = aie.logical_tile<CoreTile>(2, 4)
    %logical_core_10 = aie.logical_tile<CoreTile>(2, 5)
    %logical_core_11 = aie.logical_tile<CoreTile>(3, 2)
    %logical_core_12 = aie.logical_tile<CoreTile>(3, 3)
    %logical_core_13 = aie.logical_tile<CoreTile>(3, 4)
    %logical_core_14 = aie.logical_tile<CoreTile>(3, 5)
    %logical_core_15 = aie.logical_tile<CoreTile>(4, 2)
    %logical_core_16 = aie.logical_tile<CoreTile>(4, 3)
    %logical_core_17 = aie.logical_tile<CoreTile>(4, 4)
    %logical_core_18 = aie.logical_tile<CoreTile>(4, 5)
    %logical_core_19 = aie.logical_tile<CoreTile>(5, 2)
    %logical_core_20 = aie.logical_tile<CoreTile>(5, 3)
    %logical_core_21 = aie.logical_tile<CoreTile>(5, 4)
    %logical_core_22 = aie.logical_tile<CoreTile>(5, 5)
    %logical_core_23 = aie.logical_tile<CoreTile>(6, 2)
    %logical_core_24 = aie.logical_tile<CoreTile>(6, 3)
    %logical_core_25 = aie.logical_tile<CoreTile>(6, 4)
    %logical_core_26 = aie.logical_tile<CoreTile>(6, 5)
    %logical_core_27 = aie.logical_tile<CoreTile>(7, 2)
    %logical_core_28 = aie.logical_tile<CoreTile>(7, 3)
    %logical_core_29 = aie.logical_tile<CoreTile>(7, 4)
    %logical_core_30 = aie.logical_tile<CoreTile>(7, 5)
    %logical_mem = aie.logical_tile<MemTile>(0, 1)
    %logical_mem_31 = aie.logical_tile<MemTile>(1, 1)
    %logical_mem_32 = aie.logical_tile<MemTile>(2, 1)
    %logical_mem_33 = aie.logical_tile<MemTile>(3, 1)
    %logical_shim_noc = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_shim_noc_34 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_shim_noc_35 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_shim_noc_36 = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_mem_37 = aie.logical_tile<MemTile>(0, 1)
    %logical_mem_38 = aie.logical_tile<MemTile>(1, 1)
    %logical_mem_39 = aie.logical_tile<MemTile>(2, 1)
    %logical_mem_40 = aie.logical_tile<MemTile>(3, 1)
    %logical_mem_41 = aie.logical_tile<MemTile>(4, 1)
    %logical_mem_42 = aie.logical_tile<MemTile>(5, 1)
    %logical_mem_43 = aie.logical_tile<MemTile>(6, 1)
    %logical_mem_44 = aie.logical_tile<MemTile>(7, 1)
    %logical_shim_noc_45 = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_shim_noc_46 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_shim_noc_47 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_shim_noc_48 = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_shim_noc_49 = aie.logical_tile<ShimNOCTile>(4, 0)
    %logical_shim_noc_50 = aie.logical_tile<ShimNOCTile>(5, 0)
    %logical_shim_noc_51 = aie.logical_tile<ShimNOCTile>(6, 0)
    %logical_shim_noc_52 = aie.logical_tile<ShimNOCTile>(7, 0)
    %logical_mem_53 = aie.logical_tile<MemTile>(0, 1)
    %logical_shim_noc_54 = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_mem_55 = aie.logical_tile<MemTile>(1, 1)
    %logical_shim_noc_56 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_mem_57 = aie.logical_tile<MemTile>(2, 1)
    %logical_shim_noc_58 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_mem_59 = aie.logical_tile<MemTile>(3, 1)
    %logical_shim_noc_60 = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_mem_61 = aie.logical_tile<MemTile>(4, 1)
    %logical_shim_noc_62 = aie.logical_tile<ShimNOCTile>(4, 0)
    %logical_mem_63 = aie.logical_tile<MemTile>(5, 1)
    %logical_shim_noc_64 = aie.logical_tile<ShimNOCTile>(5, 0)
    %logical_mem_65 = aie.logical_tile<MemTile>(6, 1)
    %logical_shim_noc_66 = aie.logical_tile<ShimNOCTile>(6, 0)
    %logical_mem_67 = aie.logical_tile<MemTile>(7, 1)
    %logical_shim_noc_68 = aie.logical_tile<ShimNOCTile>(7, 0)
    aie.objectfifo @direct_a_broadcast_0(%logical_mem dimensionsToStream [<size = 4, stride = 512>, <size = 4, stride = 2048>, <size = 512, stride = 1>], {%logical_core, %logical_core_3, %logical_core_7, %logical_core_11, %logical_core_15, %logical_core_19, %logical_core_23, %logical_core_27}, [2 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32]) : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_a_host_0(%logical_shim_noc, {%logical_mem}, 2 : i32) {prod_dma_channel = 0 : i32} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo.link [@direct_a_host_0] -> [@direct_a_broadcast_0]([] [0])
    aie.objectfifo @direct_a_broadcast_1(%logical_mem_31 dimensionsToStream [<size = 4, stride = 512>, <size = 4, stride = 2048>, <size = 512, stride = 1>], {%logical_core_0, %logical_core_4, %logical_core_8, %logical_core_12, %logical_core_16, %logical_core_20, %logical_core_24, %logical_core_28}, [2 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32]) : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_a_host_1(%logical_shim_noc_34, {%logical_mem_31}, 2 : i32) {prod_dma_channel = 0 : i32} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo.link [@direct_a_host_1] -> [@direct_a_broadcast_1]([] [0])
    aie.objectfifo @direct_a_broadcast_2(%logical_mem_32 dimensionsToStream [<size = 4, stride = 512>, <size = 4, stride = 2048>, <size = 512, stride = 1>], {%logical_core_1, %logical_core_5, %logical_core_9, %logical_core_13, %logical_core_17, %logical_core_21, %logical_core_25, %logical_core_29}, [2 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32]) : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_a_host_2(%logical_shim_noc_35, {%logical_mem_32}, 2 : i32) {prod_dma_channel = 0 : i32} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo.link [@direct_a_host_2] -> [@direct_a_broadcast_2]([] [0])
    aie.objectfifo @direct_a_broadcast_3(%logical_mem_33 dimensionsToStream [<size = 4, stride = 512>, <size = 4, stride = 2048>, <size = 512, stride = 1>], {%logical_core_2, %logical_core_6, %logical_core_10, %logical_core_14, %logical_core_18, %logical_core_22, %logical_core_26, %logical_core_30}, [2 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32, 1 : i32]) : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_a_host_3(%logical_shim_noc_36, {%logical_mem_33}, 2 : i32) {prod_dma_channel = 0 : i32} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo.link [@direct_a_host_3] -> [@direct_a_broadcast_3]([] [0])
    aie.objectfifo @direct_w_broadcast_0(%logical_mem_37, {%logical_core, %logical_core_0, %logical_core_1, %logical_core_2}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_0(%logical_shim_noc_45, {%logical_mem_37}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_0] -> [@direct_w_broadcast_0]([] [0])
    aie.objectfifo @direct_w_broadcast_1(%logical_mem_38, {%logical_core_3, %logical_core_4, %logical_core_5, %logical_core_6}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_1(%logical_shim_noc_46, {%logical_mem_38}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_1] -> [@direct_w_broadcast_1]([] [0])
    aie.objectfifo @direct_w_broadcast_2(%logical_mem_39, {%logical_core_7, %logical_core_8, %logical_core_9, %logical_core_10}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_2(%logical_shim_noc_47, {%logical_mem_39}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_2] -> [@direct_w_broadcast_2]([] [0])
    aie.objectfifo @direct_w_broadcast_3(%logical_mem_40, {%logical_core_11, %logical_core_12, %logical_core_13, %logical_core_14}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_3(%logical_shim_noc_48, {%logical_mem_40}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_3] -> [@direct_w_broadcast_3]([] [0])
    aie.objectfifo @direct_w_broadcast_4(%logical_mem_41, {%logical_core_15, %logical_core_16, %logical_core_17, %logical_core_18}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_4(%logical_shim_noc_49, {%logical_mem_41}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_4] -> [@direct_w_broadcast_4]([] [0])
    aie.objectfifo @direct_w_broadcast_5(%logical_mem_42, {%logical_core_19, %logical_core_20, %logical_core_21, %logical_core_22}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_5(%logical_shim_noc_50, {%logical_mem_42}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_5] -> [@direct_w_broadcast_5]([] [0])
    aie.objectfifo @direct_w_broadcast_6(%logical_mem_43, {%logical_core_23, %logical_core_24, %logical_core_25, %logical_core_26}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_6(%logical_shim_noc_51, {%logical_mem_43}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_6] -> [@direct_w_broadcast_6]([] [0])
    aie.objectfifo @direct_w_broadcast_7(%logical_mem_44, {%logical_core_27, %logical_core_28, %logical_core_29, %logical_core_30}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_7(%logical_shim_noc_52, {%logical_mem_44}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_7] -> [@direct_w_broadcast_7]([] [0])
    aie.objectfifo @direct_y_host_0(%logical_mem_53, {%logical_shim_noc_54}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_y_worker_0_0(%logical_core, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_0_1(%logical_core_0, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_0_2(%logical_core_1, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_0_3(%logical_core_2, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@direct_y_worker_0_0, @direct_y_worker_0_1, @direct_y_worker_0_2, @direct_y_worker_0_3] -> [@direct_y_host_0]([0, 2048, 4096, 6144] [])
    aie.objectfifo @direct_y_host_1(%logical_mem_55, {%logical_shim_noc_56}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_y_worker_1_0(%logical_core_3, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_1_1(%logical_core_4, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_1_2(%logical_core_5, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_1_3(%logical_core_6, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@direct_y_worker_1_0, @direct_y_worker_1_1, @direct_y_worker_1_2, @direct_y_worker_1_3] -> [@direct_y_host_1]([0, 2048, 4096, 6144] [])
    aie.objectfifo @direct_y_host_2(%logical_mem_57, {%logical_shim_noc_58}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_y_worker_2_0(%logical_core_7, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_2_1(%logical_core_8, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_2_2(%logical_core_9, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_2_3(%logical_core_10, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@direct_y_worker_2_0, @direct_y_worker_2_1, @direct_y_worker_2_2, @direct_y_worker_2_3] -> [@direct_y_host_2]([0, 2048, 4096, 6144] [])
    aie.objectfifo @direct_y_host_3(%logical_mem_59, {%logical_shim_noc_60}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_y_worker_3_0(%logical_core_11, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_3_1(%logical_core_12, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_3_2(%logical_core_13, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_3_3(%logical_core_14, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@direct_y_worker_3_0, @direct_y_worker_3_1, @direct_y_worker_3_2, @direct_y_worker_3_3] -> [@direct_y_host_3]([0, 2048, 4096, 6144] [])
    aie.objectfifo @direct_y_host_4(%logical_mem_61, {%logical_shim_noc_62}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_y_worker_4_0(%logical_core_15, {%logical_mem_61}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_4_1(%logical_core_16, {%logical_mem_61}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_4_2(%logical_core_17, {%logical_mem_61}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_4_3(%logical_core_18, {%logical_mem_61}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@direct_y_worker_4_0, @direct_y_worker_4_1, @direct_y_worker_4_2, @direct_y_worker_4_3] -> [@direct_y_host_4]([0, 2048, 4096, 6144] [])
    aie.objectfifo @direct_y_host_5(%logical_mem_63, {%logical_shim_noc_64}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_y_worker_5_0(%logical_core_19, {%logical_mem_63}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_5_1(%logical_core_20, {%logical_mem_63}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_5_2(%logical_core_21, {%logical_mem_63}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_5_3(%logical_core_22, {%logical_mem_63}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@direct_y_worker_5_0, @direct_y_worker_5_1, @direct_y_worker_5_2, @direct_y_worker_5_3] -> [@direct_y_host_5]([0, 2048, 4096, 6144] [])
    aie.objectfifo @direct_y_host_6(%logical_mem_65, {%logical_shim_noc_66}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_y_worker_6_0(%logical_core_23, {%logical_mem_65}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_6_1(%logical_core_24, {%logical_mem_65}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_6_2(%logical_core_25, {%logical_mem_65}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_6_3(%logical_core_26, {%logical_mem_65}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@direct_y_worker_6_0, @direct_y_worker_6_1, @direct_y_worker_6_2, @direct_y_worker_6_3] -> [@direct_y_host_6]([0, 2048, 4096, 6144] [])
    aie.objectfifo @direct_y_host_7(%logical_mem_67, {%logical_shim_noc_68}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<8192xbf16>>  
    aie.objectfifo @direct_y_worker_7_0(%logical_core_27, {%logical_mem_67}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_7_1(%logical_core_28, {%logical_mem_67}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_7_2(%logical_core_29, {%logical_mem_67}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo @direct_y_worker_7_3(%logical_core_30, {%logical_mem_67}, 2 : i32) : !aie.objectfifo<memref<2048xbf16>>  
    aie.objectfifo.link [@direct_y_worker_7_0, @direct_y_worker_7_1, @direct_y_worker_7_2, @direct_y_worker_7_3] -> [@direct_y_host_7]([0, 2048, 4096, 6144] [])
    %direct_acc0_0_0 = aie.buffer(%logical_core) {sym_name = "direct_acc0_0_0"} : memref<2048xf32> 
    %direct_acc1_0_0 = aie.buffer(%logical_core) {sym_name = "direct_acc1_0_0"} : memref<2048xf32> 
    %direct_dequant_0_0 = aie.buffer(%logical_core) {sym_name = "direct_dequant_0_0"} : memref<4096xbf16> 
    func.func private @w4a16_prefill_reuse_init(memref<2048xf32>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r4_vectorzero1_mmulmreuse2.o"}
    func.func private @w4a16_prefill_reuse_accumulate_low(memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r4_vectorzero1_mmulmreuse2.o"}
    func.func private @w4a16_prefill_reuse_accumulate_high(memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r4_vectorzero1_mmulmreuse2.o"}
    func.func private @w4a16_prefill_reuse_finish(memref<2048xf32>, memref<2048xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r4_vectorzero1_mmulmreuse2.o"}
    %direct_acc0_0_1 = aie.buffer(%logical_core_0) {sym_name = "direct_acc0_0_1"} : memref<2048xf32> 
    %direct_acc1_0_1 = aie.buffer(%logical_core_0) {sym_name = "direct_acc1_0_1"} : memref<2048xf32> 
    %direct_dequant_0_1 = aie.buffer(%logical_core_0) {sym_name = "direct_dequant_0_1"} : memref<4096xbf16> 
    %direct_acc0_0_2 = aie.buffer(%logical_core_1) {sym_name = "direct_acc0_0_2"} : memref<2048xf32> 
    %direct_acc1_0_2 = aie.buffer(%logical_core_1) {sym_name = "direct_acc1_0_2"} : memref<2048xf32> 
    %direct_dequant_0_2 = aie.buffer(%logical_core_1) {sym_name = "direct_dequant_0_2"} : memref<4096xbf16> 
    %direct_acc0_0_3 = aie.buffer(%logical_core_2) {sym_name = "direct_acc0_0_3"} : memref<2048xf32> 
    %direct_acc1_0_3 = aie.buffer(%logical_core_2) {sym_name = "direct_acc1_0_3"} : memref<2048xf32> 
    %direct_dequant_0_3 = aie.buffer(%logical_core_2) {sym_name = "direct_dequant_0_3"} : memref<4096xbf16> 
    %direct_acc0_1_0 = aie.buffer(%logical_core_3) {sym_name = "direct_acc0_1_0"} : memref<2048xf32> 
    %direct_acc1_1_0 = aie.buffer(%logical_core_3) {sym_name = "direct_acc1_1_0"} : memref<2048xf32> 
    %direct_dequant_1_0 = aie.buffer(%logical_core_3) {sym_name = "direct_dequant_1_0"} : memref<4096xbf16> 
    %direct_acc0_1_1 = aie.buffer(%logical_core_4) {sym_name = "direct_acc0_1_1"} : memref<2048xf32> 
    %direct_acc1_1_1 = aie.buffer(%logical_core_4) {sym_name = "direct_acc1_1_1"} : memref<2048xf32> 
    %direct_dequant_1_1 = aie.buffer(%logical_core_4) {sym_name = "direct_dequant_1_1"} : memref<4096xbf16> 
    %direct_acc0_1_2 = aie.buffer(%logical_core_5) {sym_name = "direct_acc0_1_2"} : memref<2048xf32> 
    %direct_acc1_1_2 = aie.buffer(%logical_core_5) {sym_name = "direct_acc1_1_2"} : memref<2048xf32> 
    %direct_dequant_1_2 = aie.buffer(%logical_core_5) {sym_name = "direct_dequant_1_2"} : memref<4096xbf16> 
    %direct_acc0_1_3 = aie.buffer(%logical_core_6) {sym_name = "direct_acc0_1_3"} : memref<2048xf32> 
    %direct_acc1_1_3 = aie.buffer(%logical_core_6) {sym_name = "direct_acc1_1_3"} : memref<2048xf32> 
    %direct_dequant_1_3 = aie.buffer(%logical_core_6) {sym_name = "direct_dequant_1_3"} : memref<4096xbf16> 
    %direct_acc0_2_0 = aie.buffer(%logical_core_7) {sym_name = "direct_acc0_2_0"} : memref<2048xf32> 
    %direct_acc1_2_0 = aie.buffer(%logical_core_7) {sym_name = "direct_acc1_2_0"} : memref<2048xf32> 
    %direct_dequant_2_0 = aie.buffer(%logical_core_7) {sym_name = "direct_dequant_2_0"} : memref<4096xbf16> 
    %direct_acc0_2_1 = aie.buffer(%logical_core_8) {sym_name = "direct_acc0_2_1"} : memref<2048xf32> 
    %direct_acc1_2_1 = aie.buffer(%logical_core_8) {sym_name = "direct_acc1_2_1"} : memref<2048xf32> 
    %direct_dequant_2_1 = aie.buffer(%logical_core_8) {sym_name = "direct_dequant_2_1"} : memref<4096xbf16> 
    %direct_acc0_2_2 = aie.buffer(%logical_core_9) {sym_name = "direct_acc0_2_2"} : memref<2048xf32> 
    %direct_acc1_2_2 = aie.buffer(%logical_core_9) {sym_name = "direct_acc1_2_2"} : memref<2048xf32> 
    %direct_dequant_2_2 = aie.buffer(%logical_core_9) {sym_name = "direct_dequant_2_2"} : memref<4096xbf16> 
    %direct_acc0_2_3 = aie.buffer(%logical_core_10) {sym_name = "direct_acc0_2_3"} : memref<2048xf32> 
    %direct_acc1_2_3 = aie.buffer(%logical_core_10) {sym_name = "direct_acc1_2_3"} : memref<2048xf32> 
    %direct_dequant_2_3 = aie.buffer(%logical_core_10) {sym_name = "direct_dequant_2_3"} : memref<4096xbf16> 
    %direct_acc0_3_0 = aie.buffer(%logical_core_11) {sym_name = "direct_acc0_3_0"} : memref<2048xf32> 
    %direct_acc1_3_0 = aie.buffer(%logical_core_11) {sym_name = "direct_acc1_3_0"} : memref<2048xf32> 
    %direct_dequant_3_0 = aie.buffer(%logical_core_11) {sym_name = "direct_dequant_3_0"} : memref<4096xbf16> 
    %direct_acc0_3_1 = aie.buffer(%logical_core_12) {sym_name = "direct_acc0_3_1"} : memref<2048xf32> 
    %direct_acc1_3_1 = aie.buffer(%logical_core_12) {sym_name = "direct_acc1_3_1"} : memref<2048xf32> 
    %direct_dequant_3_1 = aie.buffer(%logical_core_12) {sym_name = "direct_dequant_3_1"} : memref<4096xbf16> 
    %direct_acc0_3_2 = aie.buffer(%logical_core_13) {sym_name = "direct_acc0_3_2"} : memref<2048xf32> 
    %direct_acc1_3_2 = aie.buffer(%logical_core_13) {sym_name = "direct_acc1_3_2"} : memref<2048xf32> 
    %direct_dequant_3_2 = aie.buffer(%logical_core_13) {sym_name = "direct_dequant_3_2"} : memref<4096xbf16> 
    %direct_acc0_3_3 = aie.buffer(%logical_core_14) {sym_name = "direct_acc0_3_3"} : memref<2048xf32> 
    %direct_acc1_3_3 = aie.buffer(%logical_core_14) {sym_name = "direct_acc1_3_3"} : memref<2048xf32> 
    %direct_dequant_3_3 = aie.buffer(%logical_core_14) {sym_name = "direct_dequant_3_3"} : memref<4096xbf16> 
    %direct_acc0_4_0 = aie.buffer(%logical_core_15) {sym_name = "direct_acc0_4_0"} : memref<2048xf32> 
    %direct_acc1_4_0 = aie.buffer(%logical_core_15) {sym_name = "direct_acc1_4_0"} : memref<2048xf32> 
    %direct_dequant_4_0 = aie.buffer(%logical_core_15) {sym_name = "direct_dequant_4_0"} : memref<4096xbf16> 
    %direct_acc0_4_1 = aie.buffer(%logical_core_16) {sym_name = "direct_acc0_4_1"} : memref<2048xf32> 
    %direct_acc1_4_1 = aie.buffer(%logical_core_16) {sym_name = "direct_acc1_4_1"} : memref<2048xf32> 
    %direct_dequant_4_1 = aie.buffer(%logical_core_16) {sym_name = "direct_dequant_4_1"} : memref<4096xbf16> 
    %direct_acc0_4_2 = aie.buffer(%logical_core_17) {sym_name = "direct_acc0_4_2"} : memref<2048xf32> 
    %direct_acc1_4_2 = aie.buffer(%logical_core_17) {sym_name = "direct_acc1_4_2"} : memref<2048xf32> 
    %direct_dequant_4_2 = aie.buffer(%logical_core_17) {sym_name = "direct_dequant_4_2"} : memref<4096xbf16> 
    %direct_acc0_4_3 = aie.buffer(%logical_core_18) {sym_name = "direct_acc0_4_3"} : memref<2048xf32> 
    %direct_acc1_4_3 = aie.buffer(%logical_core_18) {sym_name = "direct_acc1_4_3"} : memref<2048xf32> 
    %direct_dequant_4_3 = aie.buffer(%logical_core_18) {sym_name = "direct_dequant_4_3"} : memref<4096xbf16> 
    %direct_acc0_5_0 = aie.buffer(%logical_core_19) {sym_name = "direct_acc0_5_0"} : memref<2048xf32> 
    %direct_acc1_5_0 = aie.buffer(%logical_core_19) {sym_name = "direct_acc1_5_0"} : memref<2048xf32> 
    %direct_dequant_5_0 = aie.buffer(%logical_core_19) {sym_name = "direct_dequant_5_0"} : memref<4096xbf16> 
    %direct_acc0_5_1 = aie.buffer(%logical_core_20) {sym_name = "direct_acc0_5_1"} : memref<2048xf32> 
    %direct_acc1_5_1 = aie.buffer(%logical_core_20) {sym_name = "direct_acc1_5_1"} : memref<2048xf32> 
    %direct_dequant_5_1 = aie.buffer(%logical_core_20) {sym_name = "direct_dequant_5_1"} : memref<4096xbf16> 
    %direct_acc0_5_2 = aie.buffer(%logical_core_21) {sym_name = "direct_acc0_5_2"} : memref<2048xf32> 
    %direct_acc1_5_2 = aie.buffer(%logical_core_21) {sym_name = "direct_acc1_5_2"} : memref<2048xf32> 
    %direct_dequant_5_2 = aie.buffer(%logical_core_21) {sym_name = "direct_dequant_5_2"} : memref<4096xbf16> 
    %direct_acc0_5_3 = aie.buffer(%logical_core_22) {sym_name = "direct_acc0_5_3"} : memref<2048xf32> 
    %direct_acc1_5_3 = aie.buffer(%logical_core_22) {sym_name = "direct_acc1_5_3"} : memref<2048xf32> 
    %direct_dequant_5_3 = aie.buffer(%logical_core_22) {sym_name = "direct_dequant_5_3"} : memref<4096xbf16> 
    %direct_acc0_6_0 = aie.buffer(%logical_core_23) {sym_name = "direct_acc0_6_0"} : memref<2048xf32> 
    %direct_acc1_6_0 = aie.buffer(%logical_core_23) {sym_name = "direct_acc1_6_0"} : memref<2048xf32> 
    %direct_dequant_6_0 = aie.buffer(%logical_core_23) {sym_name = "direct_dequant_6_0"} : memref<4096xbf16> 
    %direct_acc0_6_1 = aie.buffer(%logical_core_24) {sym_name = "direct_acc0_6_1"} : memref<2048xf32> 
    %direct_acc1_6_1 = aie.buffer(%logical_core_24) {sym_name = "direct_acc1_6_1"} : memref<2048xf32> 
    %direct_dequant_6_1 = aie.buffer(%logical_core_24) {sym_name = "direct_dequant_6_1"} : memref<4096xbf16> 
    %direct_acc0_6_2 = aie.buffer(%logical_core_25) {sym_name = "direct_acc0_6_2"} : memref<2048xf32> 
    %direct_acc1_6_2 = aie.buffer(%logical_core_25) {sym_name = "direct_acc1_6_2"} : memref<2048xf32> 
    %direct_dequant_6_2 = aie.buffer(%logical_core_25) {sym_name = "direct_dequant_6_2"} : memref<4096xbf16> 
    %direct_acc0_6_3 = aie.buffer(%logical_core_26) {sym_name = "direct_acc0_6_3"} : memref<2048xf32> 
    %direct_acc1_6_3 = aie.buffer(%logical_core_26) {sym_name = "direct_acc1_6_3"} : memref<2048xf32> 
    %direct_dequant_6_3 = aie.buffer(%logical_core_26) {sym_name = "direct_dequant_6_3"} : memref<4096xbf16> 
    %direct_acc0_7_0 = aie.buffer(%logical_core_27) {sym_name = "direct_acc0_7_0"} : memref<2048xf32> 
    %direct_acc1_7_0 = aie.buffer(%logical_core_27) {sym_name = "direct_acc1_7_0"} : memref<2048xf32> 
    %direct_dequant_7_0 = aie.buffer(%logical_core_27) {sym_name = "direct_dequant_7_0"} : memref<4096xbf16> 
    %direct_acc0_7_1 = aie.buffer(%logical_core_28) {sym_name = "direct_acc0_7_1"} : memref<2048xf32> 
    %direct_acc1_7_1 = aie.buffer(%logical_core_28) {sym_name = "direct_acc1_7_1"} : memref<2048xf32> 
    %direct_dequant_7_1 = aie.buffer(%logical_core_28) {sym_name = "direct_dequant_7_1"} : memref<4096xbf16> 
    %direct_acc0_7_2 = aie.buffer(%logical_core_29) {sym_name = "direct_acc0_7_2"} : memref<2048xf32> 
    %direct_acc1_7_2 = aie.buffer(%logical_core_29) {sym_name = "direct_acc1_7_2"} : memref<2048xf32> 
    %direct_dequant_7_2 = aie.buffer(%logical_core_29) {sym_name = "direct_dequant_7_2"} : memref<4096xbf16> 
    %direct_acc0_7_3 = aie.buffer(%logical_core_30) {sym_name = "direct_acc0_7_3"} : memref<2048xf32> 
    %direct_acc1_7_3 = aie.buffer(%logical_core_30) {sym_name = "direct_acc1_7_3"} : memref<2048xf32> 
    %direct_dequant_7_3 = aie.buffer(%logical_core_30) {sym_name = "direct_dequant_7_3"} : memref<4096xbf16> 
    %core_0_2 = aie.core(%logical_core) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_0) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_0) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_0_0, %direct_dequant_0_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_0_0, %direct_dequant_0_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_0_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_0, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_0_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_0_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_0, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_0_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_0_3 = aie.core(%logical_core_0) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_1) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_1) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_0_1, %direct_dequant_0_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_0_1, %direct_dequant_0_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_0_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_1, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_0_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_0_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_1, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_0_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_0_4 = aie.core(%logical_core_1) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_2) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_2) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_0_2, %direct_dequant_0_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_0_2, %direct_dequant_0_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_0_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_2, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_0_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_0_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_2, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_0_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_0_5 = aie.core(%logical_core_2) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_3) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_3) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_0_3, %direct_dequant_0_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_0_3, %direct_dequant_0_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_0_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_3, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_0_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_0_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_3, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_0_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_1_2 = aie.core(%logical_core_3) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_0) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_0) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_1_0, %direct_dequant_1_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_1_0, %direct_dequant_1_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_0, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_0, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_1_3 = aie.core(%logical_core_4) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_1) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_1) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_1_1, %direct_dequant_1_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_1_1, %direct_dequant_1_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_1, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_1, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_1_4 = aie.core(%logical_core_5) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_2) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_2) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_1_2, %direct_dequant_1_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_1_2, %direct_dequant_1_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_2, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_2, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_1_5 = aie.core(%logical_core_6) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_3) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_3) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_1_3, %direct_dequant_1_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_1_3, %direct_dequant_1_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_3, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_3, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_2_2 = aie.core(%logical_core_7) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_0) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_0) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_2_0, %direct_dequant_2_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_2_0, %direct_dequant_2_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_2_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_0, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_2_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_2_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_0, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_2_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_2_3 = aie.core(%logical_core_8) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_1) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_1) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_2_1, %direct_dequant_2_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_2_1, %direct_dequant_2_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_2_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_1, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_2_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_2_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_1, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_2_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_2_4 = aie.core(%logical_core_9) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_2) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_2) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_2_2, %direct_dequant_2_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_2_2, %direct_dequant_2_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_2_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_2, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_2_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_2_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_2, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_2_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_2_5 = aie.core(%logical_core_10) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_3) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_3) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_2_3, %direct_dequant_2_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_2_3, %direct_dequant_2_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_2_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_3, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_2_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_2_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_3, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_2_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_3_2 = aie.core(%logical_core_11) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_0) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_0) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_3_0, %direct_dequant_3_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_3_0, %direct_dequant_3_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_0, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_0, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_3_3 = aie.core(%logical_core_12) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_1) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_1) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_3_1, %direct_dequant_3_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_3_1, %direct_dequant_3_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_1, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_1, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_3_4 = aie.core(%logical_core_13) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_2) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_2) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_3_2, %direct_dequant_3_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_3_2, %direct_dequant_3_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_2, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_2, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_3_5 = aie.core(%logical_core_14) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_3) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_3) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_3_3, %direct_dequant_3_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_3_3, %direct_dequant_3_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_3, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_3, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_4_2 = aie.core(%logical_core_15) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_0) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_0) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_4_0, %direct_dequant_4_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_4_0, %direct_dequant_4_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_4_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_0, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_4_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_4_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_0, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_4_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_4_3 = aie.core(%logical_core_16) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_1) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_1) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_4_1, %direct_dequant_4_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_4_1, %direct_dequant_4_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_4_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_1, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_4_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_4_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_1, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_4_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_4_4 = aie.core(%logical_core_17) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_2) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_2) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_4_2, %direct_dequant_4_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_4_2, %direct_dequant_4_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_4_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_2, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_4_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_4_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_2, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_4_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_4_5 = aie.core(%logical_core_18) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_3) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_3) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_4_3, %direct_dequant_4_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_4_3, %direct_dequant_4_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_4_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_3, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_4_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_4_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_3, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_4_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_5_2 = aie.core(%logical_core_19) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_0) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_0) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_5_0, %direct_dequant_5_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_5_0, %direct_dequant_5_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_0, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_0, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_5_3 = aie.core(%logical_core_20) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_1) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_1) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_5_1, %direct_dequant_5_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_5_1, %direct_dequant_5_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_1, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_1, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_5_4 = aie.core(%logical_core_21) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_2) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_2) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_5_2, %direct_dequant_5_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_5_2, %direct_dequant_5_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_2, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_2, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_5_5 = aie.core(%logical_core_22) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_3) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_3) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_5_3, %direct_dequant_5_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_5_3, %direct_dequant_5_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_3, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_3, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_6_2 = aie.core(%logical_core_23) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_0) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_0) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_6_0, %direct_dequant_6_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_6_0, %direct_dequant_6_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_6_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_0, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_6_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_6_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_0, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_6_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_6_3 = aie.core(%logical_core_24) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_1) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_1) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_6_1, %direct_dequant_6_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_6_1, %direct_dequant_6_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_6_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_1, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_6_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_6_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_1, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_6_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_6_4 = aie.core(%logical_core_25) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_2) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_2) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_6_2, %direct_dequant_6_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_6_2, %direct_dequant_6_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_6_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_2, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_6_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_6_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_2, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_6_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_6_5 = aie.core(%logical_core_26) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_3) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_3) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_6_3, %direct_dequant_6_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_6_3, %direct_dequant_6_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_6_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_3, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_6_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_6_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_3, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_6_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_7_2 = aie.core(%logical_core_27) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_0) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_0) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_7_0, %direct_dequant_7_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_7_0, %direct_dequant_7_0) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_0, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_0, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_7_3 = aie.core(%logical_core_28) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_1) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_1) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_7_1, %direct_dequant_7_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_7_1, %direct_dequant_7_1) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_1, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_1, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_7_4 = aie.core(%logical_core_29) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_2) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_2) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_7_2, %direct_dequant_7_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_7_2, %direct_dequant_7_2) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_2, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_2, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_7_5 = aie.core(%logical_core_30) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_69 = arith.constant 0 : index
        %c1_70 = arith.constant 1 : index
        %c1_71 = arith.constant 1 : index
        scf.for %arg1 = %c0_69 to %c1_70 step %c1_71 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_3) : (memref<2048xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_3) : (memref<2048xf32>) -> ()
          %c0_72 = arith.constant 0 : index
          %c9 = arith.constant 9 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_72 to %c9 step %c1_73 {
            %4 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<8192xbf16>>
            %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<8192xbf16>> -> memref<8192xbf16>
            %6 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%5, %7, %direct_acc0_7_3, %direct_dequant_7_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%5, %7, %direct_acc1_7_3, %direct_dequant_7_3) : (memref<8192xbf16>, memref<4352xui8>, memref<2048xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_3, %1) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<2048xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<2048xbf16>> -> memref<2048xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_3, %3) : (memref<2048xf32>, memref<2048xbf16>) -> ()
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    aie.runtime_sequence(%arg0: memref<294912xbf16>, %arg1: memref<557056xui8>, %arg2: memref<131072xbf16>) {
      %0 = aiex.dma_configure_task_for @direct_y_host_0 {
        aie.dma_bd(%arg2 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 2, 16, 512] strides = [0, 512, 8192, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%0)
      %1 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg2 : memref<131072xbf16> offset = 1024 len = 16384 sizes = [1, 2, 16, 512] strides = [0, 512, 8192, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%1)
      %2 = aiex.dma_configure_task_for @direct_y_host_2 {
        aie.dma_bd(%arg2 : memref<131072xbf16> offset = 2048 len = 16384 sizes = [1, 2, 16, 512] strides = [0, 512, 8192, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%2)
      %3 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg2 : memref<131072xbf16> offset = 3072 len = 16384 sizes = [1, 2, 16, 512] strides = [0, 512, 8192, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%3)
      %4 = aiex.dma_configure_task_for @direct_y_host_4 {
        aie.dma_bd(%arg2 : memref<131072xbf16> offset = 4096 len = 16384 sizes = [1, 2, 16, 512] strides = [0, 512, 8192, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%4)
      %5 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg2 : memref<131072xbf16> offset = 5120 len = 16384 sizes = [1, 2, 16, 512] strides = [0, 512, 8192, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%5)
      %6 = aiex.dma_configure_task_for @direct_y_host_6 {
        aie.dma_bd(%arg2 : memref<131072xbf16> offset = 6144 len = 16384 sizes = [1, 2, 16, 512] strides = [0, 512, 8192, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%6)
      %7 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg2 : memref<131072xbf16> offset = 7168 len = 16384 sizes = [1, 2, 16, 512] strides = [0, 512, 8192, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%7)
      %8 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<294912xbf16> offset = 0 len = 73728 sizes = [1, 36, 4, 512] strides = [0, 512, 18432, 1])
        aie.end
      }
      aiex.dma_start_task(%8)
      %9 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<294912xbf16> offset = 73728 len = 73728 sizes = [1, 36, 4, 512] strides = [0, 512, 18432, 1])
        aie.end
      }
      aiex.dma_start_task(%9)
      %10 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<294912xbf16> offset = 147456 len = 73728 sizes = [1, 36, 4, 512] strides = [0, 512, 18432, 1])
        aie.end
      }
      aiex.dma_start_task(%10)
      %11 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<294912xbf16> offset = 221184 len = 73728 sizes = [1, 36, 4, 512] strides = [0, 512, 18432, 1])
        aie.end
      }
      aiex.dma_start_task(%11)
      %12 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 4352 len = 39168 sizes = [1, 1, 1, 39168] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%12)
      %13 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 73984 len = 39168 sizes = [1, 1, 1, 39168] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%13)
      %14 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 143616 len = 39168 sizes = [1, 1, 1, 39168] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%14)
      %15 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 213248 len = 39168 sizes = [1, 1, 1, 39168] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%15)
      %16 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 282880 len = 39168 sizes = [1, 1, 1, 39168] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%16)
      %17 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 352512 len = 39168 sizes = [1, 1, 1, 39168] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%17)
      %18 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 422144 len = 39168 sizes = [1, 1, 1, 39168] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%18)
      %19 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 491776 len = 39168 sizes = [1, 1, 1, 39168] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%19)
      aiex.dma_await_task(%0)
      aiex.dma_await_task(%1)
      aiex.dma_await_task(%2)
      aiex.dma_await_task(%3)
      aiex.dma_await_task(%4)
      aiex.dma_await_task(%5)
      aiex.dma_await_task(%6)
      aiex.dma_await_task(%7)
      aiex.dma_free_task(%0)
      aiex.dma_free_task(%1)
      aiex.dma_free_task(%2)
      aiex.dma_free_task(%3)
      aiex.dma_free_task(%4)
      aiex.dma_free_task(%5)
      aiex.dma_free_task(%6)
      aiex.dma_free_task(%7)
      aiex.dma_free_task(%8)
      aiex.dma_free_task(%9)
      aiex.dma_free_task(%10)
      aiex.dma_free_task(%11)
      aiex.dma_free_task(%12)
      aiex.dma_free_task(%13)
      aiex.dma_free_task(%14)
      aiex.dma_free_task(%15)
      aiex.dma_free_task(%16)
      aiex.dma_free_task(%17)
      aiex.dma_free_task(%18)
      aiex.dma_free_task(%19)
    }
  }
}
