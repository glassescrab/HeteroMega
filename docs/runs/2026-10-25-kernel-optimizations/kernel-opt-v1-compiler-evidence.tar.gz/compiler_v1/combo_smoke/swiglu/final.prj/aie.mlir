module {
  aie.device(npu2) {
    %logical_core = aie.logical_tile<CoreTile>(0, 2)
    %logical_core_0 = aie.logical_tile<CoreTile>(0, 3)
    %logical_core_1 = aie.logical_tile<CoreTile>(0, 4)
    %logical_core_2 = aie.logical_tile<CoreTile>(0, 5)
    %logical_core_3 = aie.logical_tile<CoreTile>(1, 2)
    %logical_core_4 = aie.logical_tile<CoreTile>(1, 3)
    %logical_core_5 = aie.logical_tile<CoreTile>(1, 4)
    %logical_core_6 = aie.logical_tile<CoreTile>(1, 5)
    %logical_core_7 = aie.logical_tile<CoreTile>(2, 2)
    %logical_core_8 = aie.logical_tile<CoreTile>(2, 3)
    %logical_core_9 = aie.logical_tile<CoreTile>(2, 4)
    %logical_core_10 = aie.logical_tile<CoreTile>(2, 5)
    %logical_core_11 = aie.logical_tile<CoreTile>(3, 2)
    %logical_core_12 = aie.logical_tile<CoreTile>(3, 3)
    %logical_core_13 = aie.logical_tile<CoreTile>(3, 4)
    %logical_core_14 = aie.logical_tile<CoreTile>(3, 5)
    %logical_core_15 = aie.logical_tile<CoreTile>(4, 2)
    %logical_core_16 = aie.logical_tile<CoreTile>(4, 3)
    %logical_core_17 = aie.logical_tile<CoreTile>(4, 4)
    %logical_core_18 = aie.logical_tile<CoreTile>(4, 5)
    %logical_core_19 = aie.logical_tile<CoreTile>(5, 2)
    %logical_core_20 = aie.logical_tile<CoreTile>(5, 3)
    %logical_core_21 = aie.logical_tile<CoreTile>(5, 4)
    %logical_core_22 = aie.logical_tile<CoreTile>(5, 5)
    %logical_core_23 = aie.logical_tile<CoreTile>(6, 2)
    %logical_core_24 = aie.logical_tile<CoreTile>(6, 3)
    %logical_core_25 = aie.logical_tile<CoreTile>(6, 4)
    %logical_core_26 = aie.logical_tile<CoreTile>(6, 5)
    %logical_core_27 = aie.logical_tile<CoreTile>(7, 2)
    %logical_core_28 = aie.logical_tile<CoreTile>(7, 3)
    %logical_core_29 = aie.logical_tile<CoreTile>(7, 4)
    %logical_core_30 = aie.logical_tile<CoreTile>(7, 5)
    %logical_mem = aie.logical_tile<MemTile>(0, 1)
    %logical_mem_31 = aie.logical_tile<MemTile>(1, 1)
    %logical_mem_32 = aie.logical_tile<MemTile>(2, 1)
    %logical_mem_33 = aie.logical_tile<MemTile>(3, 1)
    %logical_shim_noc = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_shim_noc_34 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_shim_noc_35 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_shim_noc_36 = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_mem_37 = aie.logical_tile<MemTile>(0, 1)
    %logical_mem_38 = aie.logical_tile<MemTile>(1, 1)
    %logical_mem_39 = aie.logical_tile<MemTile>(2, 1)
    %logical_mem_40 = aie.logical_tile<MemTile>(3, 1)
    %logical_mem_41 = aie.logical_tile<MemTile>(4, 1)
    %logical_mem_42 = aie.logical_tile<MemTile>(5, 1)
    %logical_mem_43 = aie.logical_tile<MemTile>(6, 1)
    %logical_mem_44 = aie.logical_tile<MemTile>(7, 1)
    %logical_shim_noc_45 = aie.logical_tile<ShimNOCTile>(0, 0)
    %logical_shim_noc_46 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_shim_noc_47 = aie.logical_tile<ShimNOCTile>(2, 0)
    %logical_shim_noc_48 = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_shim_noc_49 = aie.logical_tile<ShimNOCTile>(4, 0)
    %logical_shim_noc_50 = aie.logical_tile<ShimNOCTile>(5, 0)
    %logical_shim_noc_51 = aie.logical_tile<ShimNOCTile>(6, 0)
    %logical_shim_noc_52 = aie.logical_tile<ShimNOCTile>(7, 0)
    %logical_mem_53 = aie.logical_tile<MemTile>(1, 1)
    %logical_shim_noc_54 = aie.logical_tile<ShimNOCTile>(1, 0)
    %logical_mem_55 = aie.logical_tile<MemTile>(3, 1)
    %logical_shim_noc_56 = aie.logical_tile<ShimNOCTile>(3, 0)
    %logical_mem_57 = aie.logical_tile<MemTile>(5, 1)
    %logical_shim_noc_58 = aie.logical_tile<ShimNOCTile>(5, 0)
    %logical_mem_59 = aie.logical_tile<MemTile>(7, 1)
    %logical_shim_noc_60 = aie.logical_tile<ShimNOCTile>(7, 0)
    aie.objectfifo @direct_a_broadcast_0(%logical_mem dimensionsToStream [<size = 2, stride = 512>, <size = 4, stride = 1024>, <size = 512, stride = 1>], {%logical_core, %logical_core_3, %logical_core_7, %logical_core_11, %logical_core_15, %logical_core_19, %logical_core_23, %logical_core_27}, 2 : i32) : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo @direct_a_host_0(%logical_shim_noc, {%logical_mem}, 2 : i32) {prod_dma_channel = 0 : i32} : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo.link [@direct_a_host_0] -> [@direct_a_broadcast_0]([] [0])
    aie.objectfifo @direct_a_broadcast_1(%logical_mem_31 dimensionsToStream [<size = 2, stride = 512>, <size = 4, stride = 1024>, <size = 512, stride = 1>], {%logical_core_0, %logical_core_4, %logical_core_8, %logical_core_12, %logical_core_16, %logical_core_20, %logical_core_24, %logical_core_28}, 2 : i32) : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo @direct_a_host_1(%logical_shim_noc_34, {%logical_mem_31}, 2 : i32) {prod_dma_channel = 0 : i32} : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo.link [@direct_a_host_1] -> [@direct_a_broadcast_1]([] [0])
    aie.objectfifo @direct_a_broadcast_2(%logical_mem_32 dimensionsToStream [<size = 2, stride = 512>, <size = 4, stride = 1024>, <size = 512, stride = 1>], {%logical_core_1, %logical_core_5, %logical_core_9, %logical_core_13, %logical_core_17, %logical_core_21, %logical_core_25, %logical_core_29}, 2 : i32) : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo @direct_a_host_2(%logical_shim_noc_35, {%logical_mem_32}, 2 : i32) {prod_dma_channel = 0 : i32} : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo.link [@direct_a_host_2] -> [@direct_a_broadcast_2]([] [0])
    aie.objectfifo @direct_a_broadcast_3(%logical_mem_33 dimensionsToStream [<size = 2, stride = 512>, <size = 4, stride = 1024>, <size = 512, stride = 1>], {%logical_core_2, %logical_core_6, %logical_core_10, %logical_core_14, %logical_core_18, %logical_core_22, %logical_core_26, %logical_core_30}, 2 : i32) : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo @direct_a_host_3(%logical_shim_noc_36, {%logical_mem_33}, 2 : i32) {prod_dma_channel = 0 : i32} : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo.link [@direct_a_host_3] -> [@direct_a_broadcast_3]([] [0])
    aie.objectfifo @direct_gate_0_0(%logical_core, {%logical_core_3}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_0_1(%logical_core_0, {%logical_core_4}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_0_2(%logical_core_1, {%logical_core_5}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_0_3(%logical_core_2, {%logical_core_6}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_2_0(%logical_core_7, {%logical_core_11}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_2_1(%logical_core_8, {%logical_core_12}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_2_2(%logical_core_9, {%logical_core_13}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_2_3(%logical_core_10, {%logical_core_14}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_4_0(%logical_core_15, {%logical_core_19}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_4_1(%logical_core_16, {%logical_core_20}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_4_2(%logical_core_17, {%logical_core_21}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_4_3(%logical_core_18, {%logical_core_22}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_6_0(%logical_core_23, {%logical_core_27}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_6_1(%logical_core_24, {%logical_core_28}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_6_2(%logical_core_25, {%logical_core_29}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_gate_6_3(%logical_core_26, {%logical_core_30}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_w_broadcast_0(%logical_mem_37, {%logical_core, %logical_core_0, %logical_core_1, %logical_core_2}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_0(%logical_shim_noc_45, {%logical_mem_37}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_0] -> [@direct_w_broadcast_0]([] [0])
    aie.objectfifo @direct_w_broadcast_1(%logical_mem_38, {%logical_core_3, %logical_core_4, %logical_core_5, %logical_core_6}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_1(%logical_shim_noc_46, {%logical_mem_38}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_1] -> [@direct_w_broadcast_1]([] [0])
    aie.objectfifo @direct_w_broadcast_2(%logical_mem_39, {%logical_core_7, %logical_core_8, %logical_core_9, %logical_core_10}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_2(%logical_shim_noc_47, {%logical_mem_39}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_2] -> [@direct_w_broadcast_2]([] [0])
    aie.objectfifo @direct_w_broadcast_3(%logical_mem_40, {%logical_core_11, %logical_core_12, %logical_core_13, %logical_core_14}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_3(%logical_shim_noc_48, {%logical_mem_40}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_3] -> [@direct_w_broadcast_3]([] [0])
    aie.objectfifo @direct_w_broadcast_4(%logical_mem_41, {%logical_core_15, %logical_core_16, %logical_core_17, %logical_core_18}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_4(%logical_shim_noc_49, {%logical_mem_41}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_4] -> [@direct_w_broadcast_4]([] [0])
    aie.objectfifo @direct_w_broadcast_5(%logical_mem_42, {%logical_core_19, %logical_core_20, %logical_core_21, %logical_core_22}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_5(%logical_shim_noc_50, {%logical_mem_42}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_5] -> [@direct_w_broadcast_5]([] [0])
    aie.objectfifo @direct_w_broadcast_6(%logical_mem_43, {%logical_core_23, %logical_core_24, %logical_core_25, %logical_core_26}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_6(%logical_shim_noc_51, {%logical_mem_43}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_6] -> [@direct_w_broadcast_6]([] [0])
    aie.objectfifo @direct_w_broadcast_7(%logical_mem_44, {%logical_core_27, %logical_core_28, %logical_core_29, %logical_core_30}, 2 : i32) : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo @direct_w_host_7(%logical_shim_noc_52, {%logical_mem_44}, 2 : i32) {prod_dma_channel = 1 : i32} : !aie.objectfifo<memref<4352xui8>>  
    aie.objectfifo.link [@direct_w_host_7] -> [@direct_w_broadcast_7]([] [0])
    aie.objectfifo @direct_y_host_1(%logical_mem_53, {%logical_shim_noc_54}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo @direct_y_worker_1_0(%logical_core_3, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_1_1(%logical_core_4, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_1_2(%logical_core_5, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_1_3(%logical_core_6, {%logical_mem_53}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo.link [@direct_y_worker_1_0, @direct_y_worker_1_1, @direct_y_worker_1_2, @direct_y_worker_1_3] -> [@direct_y_host_1]([0, 1024, 2048, 3072] [])
    aie.objectfifo @direct_y_host_3(%logical_mem_55, {%logical_shim_noc_56}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo @direct_y_worker_3_0(%logical_core_11, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_3_1(%logical_core_12, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_3_2(%logical_core_13, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_3_3(%logical_core_14, {%logical_mem_55}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo.link [@direct_y_worker_3_0, @direct_y_worker_3_1, @direct_y_worker_3_2, @direct_y_worker_3_3] -> [@direct_y_host_3]([0, 1024, 2048, 3072] [])
    aie.objectfifo @direct_y_host_5(%logical_mem_57, {%logical_shim_noc_58}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo @direct_y_worker_5_0(%logical_core_19, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_5_1(%logical_core_20, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_5_2(%logical_core_21, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_5_3(%logical_core_22, {%logical_mem_57}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo.link [@direct_y_worker_5_0, @direct_y_worker_5_1, @direct_y_worker_5_2, @direct_y_worker_5_3] -> [@direct_y_host_5]([0, 1024, 2048, 3072] [])
    aie.objectfifo @direct_y_host_7(%logical_mem_59, {%logical_shim_noc_60}, 2 : i32) {cons_dma_channels = array<i32: 0>} : !aie.objectfifo<memref<4096xbf16>>  
    aie.objectfifo @direct_y_worker_7_0(%logical_core_27, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_7_1(%logical_core_28, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_7_2(%logical_core_29, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo @direct_y_worker_7_3(%logical_core_30, {%logical_mem_59}, 2 : i32) : !aie.objectfifo<memref<1024xbf16>>  
    aie.objectfifo.link [@direct_y_worker_7_0, @direct_y_worker_7_1, @direct_y_worker_7_2, @direct_y_worker_7_3] -> [@direct_y_host_7]([0, 1024, 2048, 3072] [])
    %direct_acc0_0_0 = aie.buffer(%logical_core) {sym_name = "direct_acc0_0_0"} : memref<1024xf32> 
    %direct_acc1_0_0 = aie.buffer(%logical_core) {sym_name = "direct_acc1_0_0"} : memref<1024xf32> 
    %direct_dequant_0_0 = aie.buffer(%logical_core) {sym_name = "direct_dequant_0_0"} : memref<4096xbf16> 
    func.func private @w4a16_prefill_reuse_init(memref<1024xf32>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse2.o"}
    func.func private @w4a16_prefill_reuse_accumulate_low(memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse2.o"}
    func.func private @w4a16_prefill_reuse_accumulate_high(memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse2.o"}
    func.func private @w4a16_prefill_reuse_finish(memref<1024xf32>, memref<1024xbf16>) attributes {link_with = "w4a16_prefill_reuse_bf16_ae5f247810852e3383db19e4c483279db195c480c498c002eaa0d0e4053609d7_8768ada43abd02bde39395e8d826206ab8ad6324d0ee0b067733fbe76a2f290e_r2_vectorzero1_mmulmreuse2.o"}
    %direct_acc0_0_1 = aie.buffer(%logical_core_0) {sym_name = "direct_acc0_0_1"} : memref<1024xf32> 
    %direct_acc1_0_1 = aie.buffer(%logical_core_0) {sym_name = "direct_acc1_0_1"} : memref<1024xf32> 
    %direct_dequant_0_1 = aie.buffer(%logical_core_0) {sym_name = "direct_dequant_0_1"} : memref<4096xbf16> 
    %direct_acc0_0_2 = aie.buffer(%logical_core_1) {sym_name = "direct_acc0_0_2"} : memref<1024xf32> 
    %direct_acc1_0_2 = aie.buffer(%logical_core_1) {sym_name = "direct_acc1_0_2"} : memref<1024xf32> 
    %direct_dequant_0_2 = aie.buffer(%logical_core_1) {sym_name = "direct_dequant_0_2"} : memref<4096xbf16> 
    %direct_acc0_0_3 = aie.buffer(%logical_core_2) {sym_name = "direct_acc0_0_3"} : memref<1024xf32> 
    %direct_acc1_0_3 = aie.buffer(%logical_core_2) {sym_name = "direct_acc1_0_3"} : memref<1024xf32> 
    %direct_dequant_0_3 = aie.buffer(%logical_core_2) {sym_name = "direct_dequant_0_3"} : memref<4096xbf16> 
    %direct_acc0_1_0 = aie.buffer(%logical_core_3) {sym_name = "direct_acc0_1_0"} : memref<1024xf32> 
    %direct_acc1_1_0 = aie.buffer(%logical_core_3) {sym_name = "direct_acc1_1_0"} : memref<1024xf32> 
    %direct_dequant_1_0 = aie.buffer(%logical_core_3) {sym_name = "direct_dequant_1_0"} : memref<4096xbf16> 
    %direct_up_1_0 = aie.buffer(%logical_core_3) {sym_name = "direct_up_1_0"} : memref<1024xbf16> 
    func.func private @silu_mul_bf16(memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) attributes {link_with = "silu_mul_1863c3ab0cb4be00c0ced57223d172da2706969d1329d7785e9a78c4dea167fc_1024.o"}
    %direct_acc0_1_1 = aie.buffer(%logical_core_4) {sym_name = "direct_acc0_1_1"} : memref<1024xf32> 
    %direct_acc1_1_1 = aie.buffer(%logical_core_4) {sym_name = "direct_acc1_1_1"} : memref<1024xf32> 
    %direct_dequant_1_1 = aie.buffer(%logical_core_4) {sym_name = "direct_dequant_1_1"} : memref<4096xbf16> 
    %direct_up_1_1 = aie.buffer(%logical_core_4) {sym_name = "direct_up_1_1"} : memref<1024xbf16> 
    %direct_acc0_1_2 = aie.buffer(%logical_core_5) {sym_name = "direct_acc0_1_2"} : memref<1024xf32> 
    %direct_acc1_1_2 = aie.buffer(%logical_core_5) {sym_name = "direct_acc1_1_2"} : memref<1024xf32> 
    %direct_dequant_1_2 = aie.buffer(%logical_core_5) {sym_name = "direct_dequant_1_2"} : memref<4096xbf16> 
    %direct_up_1_2 = aie.buffer(%logical_core_5) {sym_name = "direct_up_1_2"} : memref<1024xbf16> 
    %direct_acc0_1_3 = aie.buffer(%logical_core_6) {sym_name = "direct_acc0_1_3"} : memref<1024xf32> 
    %direct_acc1_1_3 = aie.buffer(%logical_core_6) {sym_name = "direct_acc1_1_3"} : memref<1024xf32> 
    %direct_dequant_1_3 = aie.buffer(%logical_core_6) {sym_name = "direct_dequant_1_3"} : memref<4096xbf16> 
    %direct_up_1_3 = aie.buffer(%logical_core_6) {sym_name = "direct_up_1_3"} : memref<1024xbf16> 
    %direct_acc0_2_0 = aie.buffer(%logical_core_7) {sym_name = "direct_acc0_2_0"} : memref<1024xf32> 
    %direct_acc1_2_0 = aie.buffer(%logical_core_7) {sym_name = "direct_acc1_2_0"} : memref<1024xf32> 
    %direct_dequant_2_0 = aie.buffer(%logical_core_7) {sym_name = "direct_dequant_2_0"} : memref<4096xbf16> 
    %direct_acc0_2_1 = aie.buffer(%logical_core_8) {sym_name = "direct_acc0_2_1"} : memref<1024xf32> 
    %direct_acc1_2_1 = aie.buffer(%logical_core_8) {sym_name = "direct_acc1_2_1"} : memref<1024xf32> 
    %direct_dequant_2_1 = aie.buffer(%logical_core_8) {sym_name = "direct_dequant_2_1"} : memref<4096xbf16> 
    %direct_acc0_2_2 = aie.buffer(%logical_core_9) {sym_name = "direct_acc0_2_2"} : memref<1024xf32> 
    %direct_acc1_2_2 = aie.buffer(%logical_core_9) {sym_name = "direct_acc1_2_2"} : memref<1024xf32> 
    %direct_dequant_2_2 = aie.buffer(%logical_core_9) {sym_name = "direct_dequant_2_2"} : memref<4096xbf16> 
    %direct_acc0_2_3 = aie.buffer(%logical_core_10) {sym_name = "direct_acc0_2_3"} : memref<1024xf32> 
    %direct_acc1_2_3 = aie.buffer(%logical_core_10) {sym_name = "direct_acc1_2_3"} : memref<1024xf32> 
    %direct_dequant_2_3 = aie.buffer(%logical_core_10) {sym_name = "direct_dequant_2_3"} : memref<4096xbf16> 
    %direct_acc0_3_0 = aie.buffer(%logical_core_11) {sym_name = "direct_acc0_3_0"} : memref<1024xf32> 
    %direct_acc1_3_0 = aie.buffer(%logical_core_11) {sym_name = "direct_acc1_3_0"} : memref<1024xf32> 
    %direct_dequant_3_0 = aie.buffer(%logical_core_11) {sym_name = "direct_dequant_3_0"} : memref<4096xbf16> 
    %direct_up_3_0 = aie.buffer(%logical_core_11) {sym_name = "direct_up_3_0"} : memref<1024xbf16> 
    %direct_acc0_3_1 = aie.buffer(%logical_core_12) {sym_name = "direct_acc0_3_1"} : memref<1024xf32> 
    %direct_acc1_3_1 = aie.buffer(%logical_core_12) {sym_name = "direct_acc1_3_1"} : memref<1024xf32> 
    %direct_dequant_3_1 = aie.buffer(%logical_core_12) {sym_name = "direct_dequant_3_1"} : memref<4096xbf16> 
    %direct_up_3_1 = aie.buffer(%logical_core_12) {sym_name = "direct_up_3_1"} : memref<1024xbf16> 
    %direct_acc0_3_2 = aie.buffer(%logical_core_13) {sym_name = "direct_acc0_3_2"} : memref<1024xf32> 
    %direct_acc1_3_2 = aie.buffer(%logical_core_13) {sym_name = "direct_acc1_3_2"} : memref<1024xf32> 
    %direct_dequant_3_2 = aie.buffer(%logical_core_13) {sym_name = "direct_dequant_3_2"} : memref<4096xbf16> 
    %direct_up_3_2 = aie.buffer(%logical_core_13) {sym_name = "direct_up_3_2"} : memref<1024xbf16> 
    %direct_acc0_3_3 = aie.buffer(%logical_core_14) {sym_name = "direct_acc0_3_3"} : memref<1024xf32> 
    %direct_acc1_3_3 = aie.buffer(%logical_core_14) {sym_name = "direct_acc1_3_3"} : memref<1024xf32> 
    %direct_dequant_3_3 = aie.buffer(%logical_core_14) {sym_name = "direct_dequant_3_3"} : memref<4096xbf16> 
    %direct_up_3_3 = aie.buffer(%logical_core_14) {sym_name = "direct_up_3_3"} : memref<1024xbf16> 
    %direct_acc0_4_0 = aie.buffer(%logical_core_15) {sym_name = "direct_acc0_4_0"} : memref<1024xf32> 
    %direct_acc1_4_0 = aie.buffer(%logical_core_15) {sym_name = "direct_acc1_4_0"} : memref<1024xf32> 
    %direct_dequant_4_0 = aie.buffer(%logical_core_15) {sym_name = "direct_dequant_4_0"} : memref<4096xbf16> 
    %direct_acc0_4_1 = aie.buffer(%logical_core_16) {sym_name = "direct_acc0_4_1"} : memref<1024xf32> 
    %direct_acc1_4_1 = aie.buffer(%logical_core_16) {sym_name = "direct_acc1_4_1"} : memref<1024xf32> 
    %direct_dequant_4_1 = aie.buffer(%logical_core_16) {sym_name = "direct_dequant_4_1"} : memref<4096xbf16> 
    %direct_acc0_4_2 = aie.buffer(%logical_core_17) {sym_name = "direct_acc0_4_2"} : memref<1024xf32> 
    %direct_acc1_4_2 = aie.buffer(%logical_core_17) {sym_name = "direct_acc1_4_2"} : memref<1024xf32> 
    %direct_dequant_4_2 = aie.buffer(%logical_core_17) {sym_name = "direct_dequant_4_2"} : memref<4096xbf16> 
    %direct_acc0_4_3 = aie.buffer(%logical_core_18) {sym_name = "direct_acc0_4_3"} : memref<1024xf32> 
    %direct_acc1_4_3 = aie.buffer(%logical_core_18) {sym_name = "direct_acc1_4_3"} : memref<1024xf32> 
    %direct_dequant_4_3 = aie.buffer(%logical_core_18) {sym_name = "direct_dequant_4_3"} : memref<4096xbf16> 
    %direct_acc0_5_0 = aie.buffer(%logical_core_19) {sym_name = "direct_acc0_5_0"} : memref<1024xf32> 
    %direct_acc1_5_0 = aie.buffer(%logical_core_19) {sym_name = "direct_acc1_5_0"} : memref<1024xf32> 
    %direct_dequant_5_0 = aie.buffer(%logical_core_19) {sym_name = "direct_dequant_5_0"} : memref<4096xbf16> 
    %direct_up_5_0 = aie.buffer(%logical_core_19) {sym_name = "direct_up_5_0"} : memref<1024xbf16> 
    %direct_acc0_5_1 = aie.buffer(%logical_core_20) {sym_name = "direct_acc0_5_1"} : memref<1024xf32> 
    %direct_acc1_5_1 = aie.buffer(%logical_core_20) {sym_name = "direct_acc1_5_1"} : memref<1024xf32> 
    %direct_dequant_5_1 = aie.buffer(%logical_core_20) {sym_name = "direct_dequant_5_1"} : memref<4096xbf16> 
    %direct_up_5_1 = aie.buffer(%logical_core_20) {sym_name = "direct_up_5_1"} : memref<1024xbf16> 
    %direct_acc0_5_2 = aie.buffer(%logical_core_21) {sym_name = "direct_acc0_5_2"} : memref<1024xf32> 
    %direct_acc1_5_2 = aie.buffer(%logical_core_21) {sym_name = "direct_acc1_5_2"} : memref<1024xf32> 
    %direct_dequant_5_2 = aie.buffer(%logical_core_21) {sym_name = "direct_dequant_5_2"} : memref<4096xbf16> 
    %direct_up_5_2 = aie.buffer(%logical_core_21) {sym_name = "direct_up_5_2"} : memref<1024xbf16> 
    %direct_acc0_5_3 = aie.buffer(%logical_core_22) {sym_name = "direct_acc0_5_3"} : memref<1024xf32> 
    %direct_acc1_5_3 = aie.buffer(%logical_core_22) {sym_name = "direct_acc1_5_3"} : memref<1024xf32> 
    %direct_dequant_5_3 = aie.buffer(%logical_core_22) {sym_name = "direct_dequant_5_3"} : memref<4096xbf16> 
    %direct_up_5_3 = aie.buffer(%logical_core_22) {sym_name = "direct_up_5_3"} : memref<1024xbf16> 
    %direct_acc0_6_0 = aie.buffer(%logical_core_23) {sym_name = "direct_acc0_6_0"} : memref<1024xf32> 
    %direct_acc1_6_0 = aie.buffer(%logical_core_23) {sym_name = "direct_acc1_6_0"} : memref<1024xf32> 
    %direct_dequant_6_0 = aie.buffer(%logical_core_23) {sym_name = "direct_dequant_6_0"} : memref<4096xbf16> 
    %direct_acc0_6_1 = aie.buffer(%logical_core_24) {sym_name = "direct_acc0_6_1"} : memref<1024xf32> 
    %direct_acc1_6_1 = aie.buffer(%logical_core_24) {sym_name = "direct_acc1_6_1"} : memref<1024xf32> 
    %direct_dequant_6_1 = aie.buffer(%logical_core_24) {sym_name = "direct_dequant_6_1"} : memref<4096xbf16> 
    %direct_acc0_6_2 = aie.buffer(%logical_core_25) {sym_name = "direct_acc0_6_2"} : memref<1024xf32> 
    %direct_acc1_6_2 = aie.buffer(%logical_core_25) {sym_name = "direct_acc1_6_2"} : memref<1024xf32> 
    %direct_dequant_6_2 = aie.buffer(%logical_core_25) {sym_name = "direct_dequant_6_2"} : memref<4096xbf16> 
    %direct_acc0_6_3 = aie.buffer(%logical_core_26) {sym_name = "direct_acc0_6_3"} : memref<1024xf32> 
    %direct_acc1_6_3 = aie.buffer(%logical_core_26) {sym_name = "direct_acc1_6_3"} : memref<1024xf32> 
    %direct_dequant_6_3 = aie.buffer(%logical_core_26) {sym_name = "direct_dequant_6_3"} : memref<4096xbf16> 
    %direct_acc0_7_0 = aie.buffer(%logical_core_27) {sym_name = "direct_acc0_7_0"} : memref<1024xf32> 
    %direct_acc1_7_0 = aie.buffer(%logical_core_27) {sym_name = "direct_acc1_7_0"} : memref<1024xf32> 
    %direct_dequant_7_0 = aie.buffer(%logical_core_27) {sym_name = "direct_dequant_7_0"} : memref<4096xbf16> 
    %direct_up_7_0 = aie.buffer(%logical_core_27) {sym_name = "direct_up_7_0"} : memref<1024xbf16> 
    %direct_acc0_7_1 = aie.buffer(%logical_core_28) {sym_name = "direct_acc0_7_1"} : memref<1024xf32> 
    %direct_acc1_7_1 = aie.buffer(%logical_core_28) {sym_name = "direct_acc1_7_1"} : memref<1024xf32> 
    %direct_dequant_7_1 = aie.buffer(%logical_core_28) {sym_name = "direct_dequant_7_1"} : memref<4096xbf16> 
    %direct_up_7_1 = aie.buffer(%logical_core_28) {sym_name = "direct_up_7_1"} : memref<1024xbf16> 
    %direct_acc0_7_2 = aie.buffer(%logical_core_29) {sym_name = "direct_acc0_7_2"} : memref<1024xf32> 
    %direct_acc1_7_2 = aie.buffer(%logical_core_29) {sym_name = "direct_acc1_7_2"} : memref<1024xf32> 
    %direct_dequant_7_2 = aie.buffer(%logical_core_29) {sym_name = "direct_dequant_7_2"} : memref<4096xbf16> 
    %direct_up_7_2 = aie.buffer(%logical_core_29) {sym_name = "direct_up_7_2"} : memref<1024xbf16> 
    %direct_acc0_7_3 = aie.buffer(%logical_core_30) {sym_name = "direct_acc0_7_3"} : memref<1024xf32> 
    %direct_acc1_7_3 = aie.buffer(%logical_core_30) {sym_name = "direct_acc1_7_3"} : memref<1024xf32> 
    %direct_dequant_7_3 = aie.buffer(%logical_core_30) {sym_name = "direct_dequant_7_3"} : memref<4096xbf16> 
    %direct_up_7_3 = aie.buffer(%logical_core_30) {sym_name = "direct_up_7_3"} : memref<1024xbf16> 
    %core_0_2 = aie.core(%logical_core) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_0) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_0, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_0, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_0) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %4 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_0, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
          %6 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_0, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_0) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %8 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_0, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
          %10 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_0, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_0) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %12 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_0, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
          %14 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_0, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_0) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_0, %direct_dequant_0_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %16 = aie.objectfifo.acquire @direct_gate_0_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_0, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_0_3 = aie.core(%logical_core_0) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_1) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_1, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_1, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_1) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %4 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_1, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
          %6 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_1, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_1) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %8 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_1, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
          %10 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_1, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_1) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %12 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_1, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
          %14 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_1, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_1) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_1, %direct_dequant_0_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %16 = aie.objectfifo.acquire @direct_gate_0_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_1, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_0_4 = aie.core(%logical_core_1) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_2) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_2, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_2, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_2) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %4 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_2, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
          %6 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_2, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_2) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %8 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_2, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
          %10 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_2, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_2) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %12 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_2, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
          %14 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_2, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_2) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_2, %direct_dequant_0_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %16 = aie.objectfifo.acquire @direct_gate_0_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_2, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_0_5 = aie.core(%logical_core_2) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_3) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_3, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_3, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_3) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %4 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_3, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
          %6 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_3, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_3) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %8 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_3, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
          %10 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_3, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_0_3) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %12 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_3, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
          %14 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_0_3, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_0_3) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_0_3, %direct_dequant_0_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_0(Consume, 1)
          }
          %16 = aie.objectfifo.acquire @direct_gate_0_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_0_3, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_1_2 = aie.core(%logical_core_3) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_0) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_1_0, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_1_0, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_0) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_1_0, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_1_0, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_0) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_1_0, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_1_0, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_0) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_1_0, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_1_0, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_0) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_0, %direct_dequant_1_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_0, %direct_up_1_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_0_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_1_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_1_0, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_1_3 = aie.core(%logical_core_4) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_1) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_1_1, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_1_1, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_1) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_1_1, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_1_1, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_1) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_1_1, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_1_1, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_1) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_1_1, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_1_1, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_1) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_1, %direct_dequant_1_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_1, %direct_up_1_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_0_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_1_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_1_1, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_1_4 = aie.core(%logical_core_5) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_2) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_1_2, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_1_2, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_2) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_1_2, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_1_2, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_2) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_1_2, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_1_2, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_2) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_1_2, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_1_2, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_2) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_2, %direct_dequant_1_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_2, %direct_up_1_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_0_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_1_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_1_2, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_1_5 = aie.core(%logical_core_6) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_3) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_1_3, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_1_3, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_3) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_1_3, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_1_3, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_3) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_1_3, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_1_3, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_1_3) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_1_3, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_1_3, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_1_3) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_1_3, %direct_dequant_1_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_1(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_1_3, %direct_up_1_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_0_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_1_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_1_3, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_0_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_1_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_2_2 = aie.core(%logical_core_7) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_0) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc0_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_0, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_0) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %2 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_0, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
          %4 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_0, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_0) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %6 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_0, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
          %8 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_0, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_0) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %10 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_0, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
          %12 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_0, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_0) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_0, %direct_dequant_2_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %14 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_0, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
          %16 = aie.objectfifo.acquire @direct_gate_2_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_0, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_2_3 = aie.core(%logical_core_8) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_1) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc0_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_1, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_1) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %2 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_1, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
          %4 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_1, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_1) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %6 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_1, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
          %8 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_1, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_1) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %10 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_1, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
          %12 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_1, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_1) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_1, %direct_dequant_2_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %14 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_1, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
          %16 = aie.objectfifo.acquire @direct_gate_2_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_1, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_2_4 = aie.core(%logical_core_9) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_2) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc0_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_2, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_2) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %2 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_2, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
          %4 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_2, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_2) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %6 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_2, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
          %8 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_2, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_2) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %10 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_2, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
          %12 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_2, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_2) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_2, %direct_dequant_2_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %14 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_2, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
          %16 = aie.objectfifo.acquire @direct_gate_2_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_2, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_2_5 = aie.core(%logical_core_10) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_3) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc0_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_3, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_3) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %2 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_3, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
          %4 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_3, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_3) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %6 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_3, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
          %8 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_3, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_3) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %10 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_3, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
          %12 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_3, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_2_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_2_3) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_2_3, %direct_dequant_2_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_2(Consume, 1)
          }
          %14 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_2_3, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
          %16 = aie.objectfifo.acquire @direct_gate_2_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_2_3, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_3_2 = aie.core(%logical_core_11) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_0) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc0_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_3_0, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_0) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_3_0, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_3_0, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_0) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_3_0, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_3_0, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_0) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_3_0, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_3_0, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_0) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_0, %direct_dequant_3_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_3_0, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_0, %direct_up_3_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_2_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_3_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_3_0, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_3_3 = aie.core(%logical_core_12) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_1) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc0_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_3_1, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_1) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_3_1, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_3_1, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_1) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_3_1, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_3_1, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_1) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_3_1, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_3_1, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_1) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_1, %direct_dequant_3_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_3_1, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_1, %direct_up_3_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_2_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_3_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_3_1, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_3_4 = aie.core(%logical_core_13) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_2) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc0_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_3_2, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_2) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_3_2, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_3_2, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_2) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_3_2, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_3_2, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_2) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_3_2, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_3_2, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_2) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_2, %direct_dequant_3_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_3_2, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_2, %direct_up_3_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_2_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_3_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_3_2, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_3_5 = aie.core(%logical_core_14) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_3) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc0_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_3_3, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_3) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_3_3, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_3_3, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_3) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_3_3, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_3_3, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_3) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_3_3, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_3_3, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_3_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_3_3) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_3_3, %direct_dequant_3_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_3(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_3_3, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_3_3, %direct_up_3_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_2_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_3_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_3_3, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_2_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_3_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_4_2 = aie.core(%logical_core_15) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_0) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_0, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_0, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_0) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %4 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_0, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
          %6 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_0, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_0) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %8 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_0, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
          %10 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_0, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_0) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %12 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_0, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
          %14 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_0, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_0) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_0, %direct_dequant_4_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %16 = aie.objectfifo.acquire @direct_gate_4_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_0, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_4_3 = aie.core(%logical_core_16) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_1) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_1, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_1, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_1) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %4 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_1, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
          %6 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_1, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_1) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %8 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_1, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
          %10 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_1, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_1) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %12 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_1, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
          %14 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_1, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_1) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_1, %direct_dequant_4_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %16 = aie.objectfifo.acquire @direct_gate_4_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_1, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_4_4 = aie.core(%logical_core_17) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_2) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_2, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_2, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_2) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %4 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_2, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
          %6 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_2, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_2) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %8 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_2, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
          %10 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_2, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_2) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %12 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_2, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
          %14 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_2, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_2) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_2, %direct_dequant_4_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %16 = aie.objectfifo.acquire @direct_gate_4_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_2, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_4_5 = aie.core(%logical_core_18) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_3) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_3, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
          %2 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_3, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_3) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %4 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_3, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
          %6 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_3, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_3) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %8 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_3, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
          %10 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_3, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_4_3) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %12 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_3, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
          %14 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_4_3, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_4_3) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_4(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_4_3, %direct_dequant_4_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_4(Consume, 1)
          }
          %16 = aie.objectfifo.acquire @direct_gate_4_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_4_3, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_5_2 = aie.core(%logical_core_19) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_0) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_5_0, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_5_0, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_0) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_5_0, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_5_0, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_0) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_5_0, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_5_0, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_0) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_5_0, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_5_0, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_0) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_0, %direct_dequant_5_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_0, %direct_up_5_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_4_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_5_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_5_0, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_5_3 = aie.core(%logical_core_20) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_1) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_5_1, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_5_1, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_1) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_5_1, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_5_1, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_1) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_5_1, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_5_1, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_1) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_5_1, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_5_1, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_1) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_1, %direct_dequant_5_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_1, %direct_up_5_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_4_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_5_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_5_1, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_5_4 = aie.core(%logical_core_21) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_2) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_5_2, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_5_2, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_2) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_5_2, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_5_2, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_2) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_5_2, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_5_2, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_2) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_5_2, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_5_2, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_2) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_2, %direct_dequant_5_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_2, %direct_up_5_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_4_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_5_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_5_2, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_5_5 = aie.core(%logical_core_22) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_3) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_5_3, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_5_3, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_3) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_5_3, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_5_3, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_3) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_5_3, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_5_3, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_5_3) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_5_3, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_5_3, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_5_3) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_5(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_5_3, %direct_dequant_5_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_5(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_5_3, %direct_up_5_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_4_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_5_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_5_3, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_4_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_5_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_6_2 = aie.core(%logical_core_23) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_0) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc0_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_0, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_0) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %2 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_0, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
          %4 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_0, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_0) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %6 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_0, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
          %8 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_0, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_0) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %10 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_0, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
          %12 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_0, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_0) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_0, %direct_dequant_6_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %14 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_0, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
          %16 = aie.objectfifo.acquire @direct_gate_6_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_0, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_6_3 = aie.core(%logical_core_24) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_1) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc0_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_1, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_1) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %2 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_1, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
          %4 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_1, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_1) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %6 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_1, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
          %8 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_1, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_1) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %10 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_1, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
          %12 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_1, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_1) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_1, %direct_dequant_6_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %14 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_1, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
          %16 = aie.objectfifo.acquire @direct_gate_6_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_1, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_6_4 = aie.core(%logical_core_25) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_2) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc0_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_2, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_2) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %2 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_2, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
          %4 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_2, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_2) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %6 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_2, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
          %8 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_2, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_2) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %10 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_2, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
          %12 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_2, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_2) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_2, %direct_dequant_6_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %14 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_2, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
          %16 = aie.objectfifo.acquire @direct_gate_6_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_2, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_6_5 = aie.core(%logical_core_26) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_3) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc0_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %0 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_3, %1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_3) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %2 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_3, %3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
          %4 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_3, %5) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_3) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %6 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_3, %7) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
          %8 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_3, %9) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_3) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %10 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_3, %11) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
          %12 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_3, %13) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_6_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_6_3) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %18 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %20 = aie.objectfifo.acquire @direct_w_broadcast_6(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%19, %21, %direct_acc0_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%19, %21, %direct_acc1_6_3, %direct_dequant_6_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_6(Consume, 1)
          }
          %14 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_6_3, %15) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
          %16 = aie.objectfifo.acquire @direct_gate_6_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_6_3, %17) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_7_2 = aie.core(%logical_core_27) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_0) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc0_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_7_0, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_0) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_7_0, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_7_0, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_0) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_7_0, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_7_0, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_0) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_7_0, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_7_0, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_0) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_0) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_0(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_0, %direct_dequant_7_0) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_0(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_7_0, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_0, %direct_up_7_0) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_6_0(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_7_0(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_7_0, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_0(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_0(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_7_3 = aie.core(%logical_core_28) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_1) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc0_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_7_1, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_1) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_7_1, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_7_1, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_1) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_7_1, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_7_1, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_1) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_7_1, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_7_1, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_1) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_1) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_1(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_1, %direct_dequant_7_1) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_1(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_7_1, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_1, %direct_up_7_1) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_6_1(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_7_1(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_7_1, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_1(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_1(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_7_4 = aie.core(%logical_core_29) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_2) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc0_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_7_2, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_2) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_7_2, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_7_2, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_2) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_7_2, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_7_2, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_2) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_7_2, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_7_2, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_2) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_2) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_2(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_2, %direct_dequant_7_2) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_2(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_7_2, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_2, %direct_up_7_2) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_6_2(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_7_2(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_7_2, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_2(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_2(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    %core_7_5 = aie.core(%logical_core_30) {
      %c0 = arith.constant 0 : index
      %c9223372036854775807 = arith.constant 9223372036854775807 : index
      %c1 = arith.constant 1 : index
      scf.for %arg0 = %c0 to %c9223372036854775807 step %c1 {
        %c0_61 = arith.constant 0 : index
        %c2 = arith.constant 2 : index
        %c1_62 = arith.constant 1 : index
        scf.for %arg1 = %c0_61 to %c2 step %c1_62 {
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_3) : (memref<1024xf32>) -> ()
          %c0_63 = arith.constant 0 : index
          %c4 = arith.constant 4 : index
          %c1_64 = arith.constant 1 : index
          scf.for %arg2 = %c0_63 to %c4 step %c1_64 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc0_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %0 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %1 = aie.objectfifo.subview.access %0[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %2 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %3 = aie.objectfifo.subview.access %2[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%1, %direct_up_7_3, %3) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_3) : (memref<1024xf32>) -> ()
          %c0_65 = arith.constant 0 : index
          %c4_66 = arith.constant 4 : index
          %c1_67 = arith.constant 1 : index
          scf.for %arg2 = %c0_65 to %c4_66 step %c1_67 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %4 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %5 = aie.objectfifo.subview.access %4[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %6 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %7 = aie.objectfifo.subview.access %6[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%5, %direct_up_7_3, %7) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %8 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %9 = aie.objectfifo.subview.access %8[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %10 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %11 = aie.objectfifo.subview.access %10[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%9, %direct_up_7_3, %11) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_3) : (memref<1024xf32>) -> ()
          %c0_68 = arith.constant 0 : index
          %c4_69 = arith.constant 4 : index
          %c1_70 = arith.constant 1 : index
          scf.for %arg2 = %c0_68 to %c4_69 step %c1_70 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %12 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %13 = aie.objectfifo.subview.access %12[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %14 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %15 = aie.objectfifo.subview.access %14[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%13, %direct_up_7_3, %15) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %16 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %17 = aie.objectfifo.subview.access %16[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %18 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %19 = aie.objectfifo.subview.access %18[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%17, %direct_up_7_3, %19) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_3) : (memref<1024xf32>) -> ()
          %c0_71 = arith.constant 0 : index
          %c4_72 = arith.constant 4 : index
          %c1_73 = arith.constant 1 : index
          scf.for %arg2 = %c0_71 to %c4_72 step %c1_73 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %20 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %21 = aie.objectfifo.subview.access %20[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %22 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %23 = aie.objectfifo.subview.access %22[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%21, %direct_up_7_3, %23) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %24 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %25 = aie.objectfifo.subview.access %24[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %26 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %27 = aie.objectfifo.subview.access %26[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%25, %direct_up_7_3, %27) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          func.call @w4a16_prefill_reuse_init(%direct_acc0_7_3) : (memref<1024xf32>) -> ()
          func.call @w4a16_prefill_reuse_init(%direct_acc1_7_3) : (memref<1024xf32>) -> ()
          %c0_74 = arith.constant 0 : index
          %c4_75 = arith.constant 4 : index
          %c1_76 = arith.constant 1 : index
          scf.for %arg2 = %c0_74 to %c4_75 step %c1_76 {
            %36 = aie.objectfifo.acquire @direct_a_broadcast_3(Consume, 1) : !aie.objectfifosubview<memref<4096xbf16>>
            %37 = aie.objectfifo.subview.access %36[0] : !aie.objectfifosubview<memref<4096xbf16>> -> memref<4096xbf16>
            %38 = aie.objectfifo.acquire @direct_w_broadcast_7(Consume, 1) : !aie.objectfifosubview<memref<4352xui8>>
            %39 = aie.objectfifo.subview.access %38[0] : !aie.objectfifosubview<memref<4352xui8>> -> memref<4352xui8>
            func.call @w4a16_prefill_reuse_accumulate_low(%37, %39, %direct_acc0_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            func.call @w4a16_prefill_reuse_accumulate_high(%37, %39, %direct_acc1_7_3, %direct_dequant_7_3) : (memref<4096xbf16>, memref<4352xui8>, memref<1024xf32>, memref<4096xbf16>) -> ()
            aie.objectfifo.release @direct_a_broadcast_3(Consume, 1)
            aie.objectfifo.release @direct_w_broadcast_7(Consume, 1)
          }
          func.call @w4a16_prefill_reuse_finish(%direct_acc0_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %28 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %29 = aie.objectfifo.subview.access %28[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %30 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %31 = aie.objectfifo.subview.access %30[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%29, %direct_up_7_3, %31) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
          func.call @w4a16_prefill_reuse_finish(%direct_acc1_7_3, %direct_up_7_3) : (memref<1024xf32>, memref<1024xbf16>) -> ()
          %32 = aie.objectfifo.acquire @direct_gate_6_3(Consume, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %33 = aie.objectfifo.subview.access %32[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          %34 = aie.objectfifo.acquire @direct_y_worker_7_3(Produce, 1) : !aie.objectfifosubview<memref<1024xbf16>>
          %35 = aie.objectfifo.subview.access %34[0] : !aie.objectfifosubview<memref<1024xbf16>> -> memref<1024xbf16>
          func.call @silu_mul_bf16(%33, %direct_up_7_3, %35) : (memref<1024xbf16>, memref<1024xbf16>, memref<1024xbf16>) -> ()
          aie.objectfifo.release @direct_gate_6_3(Consume, 1)
          aie.objectfifo.release @direct_y_worker_7_3(Produce, 1)
        }
      }
      aie.end
    } {dynamic_objfifo_lowering = true, stack_size = 2048 : i32}
    aie.runtime_sequence(%arg0: memref<131072xbf16>, %arg1: memref<557056xui8>, %arg2: memref<557056xui8>, %arg3: memref<294912xbf16>) {
      %0 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 0 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%0)
      %1 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 4224 len = 4096 sizes = [1, 8, 4, 128] strides = [0, 18432, 512, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%1)
      %2 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 8448 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%2)
      %3 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 12672 len = 4096 sizes = [1, 8, 4, 128] strides = [0, 18432, 512, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%3)
      %4 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%4)
      %5 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 16384 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%5)
      %6 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 32768 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%6)
      %7 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 49152 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%7)
      %8 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 139264 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%8)
      %9 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 139264 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%9)
      %10 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 417792 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%10)
      %11 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 417792 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%11)
      %12 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 226304 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%12)
      %13 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 226304 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%13)
      %14 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 504832 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%14)
      %15 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 504832 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%15)
      %16 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 256 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%16)
      %17 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 4352 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%17)
      %18 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 10240 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%18)
      %19 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 14336 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%19)
      %20 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%20)
      %21 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 16384 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%21)
      %22 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 32768 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%22)
      %23 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 49152 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%23)
      %24 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 208896 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%24)
      %25 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 208896 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%25)
      %26 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 487424 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%26)
      %27 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 487424 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%27)
      %28 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 295936 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%28)
      %29 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 295936 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%29)
      %30 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 34816 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%30)
      %31 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 34816 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%31)
      aiex.dma_await_task(%0)
      aiex.dma_await_task(%1)
      aiex.dma_await_task(%2)
      aiex.dma_await_task(%3)
      aiex.dma_free_task(%0)
      aiex.dma_free_task(%1)
      aiex.dma_free_task(%2)
      aiex.dma_free_task(%3)
      aiex.dma_free_task(%4)
      aiex.dma_free_task(%5)
      aiex.dma_free_task(%6)
      aiex.dma_free_task(%7)
      aiex.dma_free_task(%8)
      aiex.dma_free_task(%9)
      aiex.dma_free_task(%10)
      aiex.dma_free_task(%11)
      aiex.dma_free_task(%12)
      aiex.dma_free_task(%13)
      aiex.dma_free_task(%14)
      aiex.dma_free_task(%15)
      %32 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 2048 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%32)
      %33 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 6144 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%33)
      %34 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 10496 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%34)
      %35 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 14592 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%35)
      %36 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%36)
      %37 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 16384 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%37)
      %38 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 32768 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%38)
      %39 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 49152 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%39)
      %40 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 278528 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%40)
      %41 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 278528 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%41)
      %42 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 17408 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%42)
      %43 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 17408 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%43)
      %44 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 365568 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%44)
      %45 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 365568 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%45)
      %46 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 104448 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%46)
      %47 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 104448 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%47)
      aiex.dma_await_task(%16)
      aiex.dma_await_task(%17)
      aiex.dma_await_task(%18)
      aiex.dma_await_task(%19)
      aiex.dma_free_task(%16)
      aiex.dma_free_task(%17)
      aiex.dma_free_task(%18)
      aiex.dma_free_task(%19)
      aiex.dma_free_task(%20)
      aiex.dma_free_task(%21)
      aiex.dma_free_task(%22)
      aiex.dma_free_task(%23)
      aiex.dma_free_task(%24)
      aiex.dma_free_task(%25)
      aiex.dma_free_task(%26)
      aiex.dma_free_task(%27)
      aiex.dma_free_task(%28)
      aiex.dma_free_task(%29)
      aiex.dma_free_task(%30)
      aiex.dma_free_task(%31)
      %48 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 2304 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%48)
      %49 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 6400 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%49)
      %50 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 12288 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%50)
      %51 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 16384 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%51)
      %52 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%52)
      %53 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 16384 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%53)
      %54 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 32768 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%54)
      %55 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 49152 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%55)
      %56 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 348160 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%56)
      %57 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 348160 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%57)
      %58 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 87040 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%58)
      %59 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 87040 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%59)
      %60 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 435200 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%60)
      %61 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 435200 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%61)
      %62 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 174080 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%62)
      %63 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 174080 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%63)
      aiex.dma_await_task(%32)
      aiex.dma_await_task(%33)
      aiex.dma_await_task(%34)
      aiex.dma_await_task(%35)
      aiex.dma_free_task(%32)
      aiex.dma_free_task(%33)
      aiex.dma_free_task(%34)
      aiex.dma_free_task(%35)
      aiex.dma_free_task(%36)
      aiex.dma_free_task(%37)
      aiex.dma_free_task(%38)
      aiex.dma_free_task(%39)
      aiex.dma_free_task(%40)
      aiex.dma_free_task(%41)
      aiex.dma_free_task(%42)
      aiex.dma_free_task(%43)
      aiex.dma_free_task(%44)
      aiex.dma_free_task(%45)
      aiex.dma_free_task(%46)
      aiex.dma_free_task(%47)
      %64 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 4096 len = 4096 sizes = [1, 8, 4, 128] strides = [0, 18432, 512, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%64)
      %65 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 8192 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%65)
      %66 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 12544 len = 4096 sizes = [1, 8, 4, 128] strides = [0, 18432, 512, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%66)
      %67 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 16640 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%67)
      %68 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 0 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%68)
      %69 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 16384 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%69)
      %70 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 32768 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%70)
      %71 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 49152 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%71)
      %72 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 417792 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%72)
      %73 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 417792 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%73)
      %74 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 156672 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%74)
      %75 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 156672 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%75)
      %76 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 504832 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%76)
      %77 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 504832 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%77)
      %78 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 243712 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%78)
      %79 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 243712 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%79)
      aiex.dma_await_task(%48)
      aiex.dma_await_task(%49)
      aiex.dma_await_task(%50)
      aiex.dma_await_task(%51)
      aiex.dma_free_task(%48)
      aiex.dma_free_task(%49)
      aiex.dma_free_task(%50)
      aiex.dma_free_task(%51)
      aiex.dma_free_task(%52)
      aiex.dma_free_task(%53)
      aiex.dma_free_task(%54)
      aiex.dma_free_task(%55)
      aiex.dma_free_task(%56)
      aiex.dma_free_task(%57)
      aiex.dma_free_task(%58)
      aiex.dma_free_task(%59)
      aiex.dma_free_task(%60)
      aiex.dma_free_task(%61)
      aiex.dma_free_task(%62)
      aiex.dma_free_task(%63)
      %80 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 147456 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%80)
      %81 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 151680 len = 4096 sizes = [1, 8, 4, 128] strides = [0, 18432, 512, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%81)
      %82 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 155904 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%82)
      %83 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 160128 len = 4096 sizes = [1, 8, 4, 128] strides = [0, 18432, 512, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%83)
      %84 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 65536 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%84)
      %85 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 81920 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%85)
      %86 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 98304 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%86)
      %87 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 114688 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%87)
      %88 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 139264 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%88)
      %89 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 139264 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%89)
      %90 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 417792 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%90)
      %91 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 417792 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%91)
      %92 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 226304 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%92)
      %93 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 226304 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%93)
      %94 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 504832 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%94)
      %95 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 504832 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%95)
      aiex.dma_await_task(%64)
      aiex.dma_await_task(%65)
      aiex.dma_await_task(%66)
      aiex.dma_await_task(%67)
      aiex.dma_free_task(%64)
      aiex.dma_free_task(%65)
      aiex.dma_free_task(%66)
      aiex.dma_free_task(%67)
      aiex.dma_free_task(%68)
      aiex.dma_free_task(%69)
      aiex.dma_free_task(%70)
      aiex.dma_free_task(%71)
      aiex.dma_free_task(%72)
      aiex.dma_free_task(%73)
      aiex.dma_free_task(%74)
      aiex.dma_free_task(%75)
      aiex.dma_free_task(%76)
      aiex.dma_free_task(%77)
      aiex.dma_free_task(%78)
      aiex.dma_free_task(%79)
      %96 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 147712 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%96)
      %97 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 151808 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%97)
      %98 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 157696 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%98)
      %99 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 161792 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%99)
      %100 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 65536 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%100)
      %101 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 81920 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%101)
      %102 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 98304 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%102)
      %103 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 114688 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%103)
      %104 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 208896 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%104)
      %105 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 208896 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%105)
      %106 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 487424 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%106)
      %107 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 487424 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%107)
      %108 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 295936 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%108)
      %109 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 295936 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%109)
      %110 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 34816 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%110)
      %111 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 34816 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%111)
      aiex.dma_await_task(%80)
      aiex.dma_await_task(%81)
      aiex.dma_await_task(%82)
      aiex.dma_await_task(%83)
      aiex.dma_free_task(%80)
      aiex.dma_free_task(%81)
      aiex.dma_free_task(%82)
      aiex.dma_free_task(%83)
      aiex.dma_free_task(%84)
      aiex.dma_free_task(%85)
      aiex.dma_free_task(%86)
      aiex.dma_free_task(%87)
      aiex.dma_free_task(%88)
      aiex.dma_free_task(%89)
      aiex.dma_free_task(%90)
      aiex.dma_free_task(%91)
      aiex.dma_free_task(%92)
      aiex.dma_free_task(%93)
      aiex.dma_free_task(%94)
      aiex.dma_free_task(%95)
      %112 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 149504 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%112)
      %113 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 153600 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%113)
      %114 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 157952 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%114)
      %115 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 162048 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%115)
      %116 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 65536 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%116)
      %117 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 81920 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%117)
      %118 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 98304 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%118)
      %119 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 114688 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%119)
      %120 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 278528 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%120)
      %121 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 278528 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%121)
      %122 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 17408 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%122)
      %123 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 17408 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%123)
      %124 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 365568 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%124)
      %125 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 365568 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%125)
      %126 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 104448 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%126)
      %127 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 104448 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%127)
      aiex.dma_await_task(%96)
      aiex.dma_await_task(%97)
      aiex.dma_await_task(%98)
      aiex.dma_await_task(%99)
      aiex.dma_free_task(%96)
      aiex.dma_free_task(%97)
      aiex.dma_free_task(%98)
      aiex.dma_free_task(%99)
      aiex.dma_free_task(%100)
      aiex.dma_free_task(%101)
      aiex.dma_free_task(%102)
      aiex.dma_free_task(%103)
      aiex.dma_free_task(%104)
      aiex.dma_free_task(%105)
      aiex.dma_free_task(%106)
      aiex.dma_free_task(%107)
      aiex.dma_free_task(%108)
      aiex.dma_free_task(%109)
      aiex.dma_free_task(%110)
      aiex.dma_free_task(%111)
      %128 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 149760 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%128)
      %129 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 153856 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%129)
      %130 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 159744 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%130)
      %131 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 163840 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%131)
      %132 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 65536 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%132)
      %133 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 81920 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%133)
      %134 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 98304 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%134)
      %135 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 114688 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%135)
      %136 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 348160 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%136)
      %137 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 348160 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%137)
      %138 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 87040 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%138)
      %139 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 87040 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%139)
      %140 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 435200 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%140)
      %141 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 435200 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%141)
      %142 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 174080 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%142)
      %143 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 174080 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%143)
      aiex.dma_await_task(%112)
      aiex.dma_await_task(%113)
      aiex.dma_await_task(%114)
      aiex.dma_await_task(%115)
      aiex.dma_free_task(%112)
      aiex.dma_free_task(%113)
      aiex.dma_free_task(%114)
      aiex.dma_free_task(%115)
      aiex.dma_free_task(%116)
      aiex.dma_free_task(%117)
      aiex.dma_free_task(%118)
      aiex.dma_free_task(%119)
      aiex.dma_free_task(%120)
      aiex.dma_free_task(%121)
      aiex.dma_free_task(%122)
      aiex.dma_free_task(%123)
      aiex.dma_free_task(%124)
      aiex.dma_free_task(%125)
      aiex.dma_free_task(%126)
      aiex.dma_free_task(%127)
      %144 = aiex.dma_configure_task_for @direct_y_host_1 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 151552 len = 4096 sizes = [1, 8, 4, 128] strides = [0, 18432, 512, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%144)
      %145 = aiex.dma_configure_task_for @direct_y_host_3 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 155648 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%145)
      %146 = aiex.dma_configure_task_for @direct_y_host_5 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 160000 len = 4096 sizes = [1, 8, 4, 128] strides = [0, 18432, 512, 1])
        aie.end
      } {issue_token = true}
      aiex.dma_start_task(%146)
      %147 = aiex.dma_configure_task_for @direct_y_host_7 {
        aie.dma_bd(%arg3 : memref<294912xbf16> offset = 164096 len = 4096 sizes = [2, 8, 4, 128] strides = [128, 18432, 512, 1])
        aie.end
      } {issue_token = true, repeat_count = 1 : i32}
      aiex.dma_start_task(%147)
      %148 = aiex.dma_configure_task_for @direct_a_host_0 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 65536 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%148)
      %149 = aiex.dma_configure_task_for @direct_a_host_1 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 81920 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%149)
      %150 = aiex.dma_configure_task_for @direct_a_host_2 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 98304 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%150)
      %151 = aiex.dma_configure_task_for @direct_a_host_3 {
        aie.dma_bd(%arg0 : memref<131072xbf16> offset = 114688 len = 16384 sizes = [1, 16, 2, 512] strides = [0, 512, 8192, 1])
        aie.end
      }
      aiex.dma_start_task(%151)
      %152 = aiex.dma_configure_task_for @direct_w_host_0 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 417792 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%152)
      %153 = aiex.dma_configure_task_for @direct_w_host_1 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 417792 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%153)
      %154 = aiex.dma_configure_task_for @direct_w_host_2 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 156672 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%154)
      %155 = aiex.dma_configure_task_for @direct_w_host_3 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 156672 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%155)
      %156 = aiex.dma_configure_task_for @direct_w_host_4 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 504832 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%156)
      %157 = aiex.dma_configure_task_for @direct_w_host_5 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 504832 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%157)
      %158 = aiex.dma_configure_task_for @direct_w_host_6 {
        aie.dma_bd(%arg1 : memref<557056xui8> offset = 243712 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%158)
      %159 = aiex.dma_configure_task_for @direct_w_host_7 {
        aie.dma_bd(%arg2 : memref<557056xui8> offset = 243712 len = 17408 sizes = [1, 1, 1, 17408] strides = [0, 0, 0, 1])
        aie.end
      }
      aiex.dma_start_task(%159)
      aiex.dma_await_task(%128)
      aiex.dma_await_task(%129)
      aiex.dma_await_task(%130)
      aiex.dma_await_task(%131)
      aiex.dma_free_task(%128)
      aiex.dma_free_task(%129)
      aiex.dma_free_task(%130)
      aiex.dma_free_task(%131)
      aiex.dma_free_task(%132)
      aiex.dma_free_task(%133)
      aiex.dma_free_task(%134)
      aiex.dma_free_task(%135)
      aiex.dma_free_task(%136)
      aiex.dma_free_task(%137)
      aiex.dma_free_task(%138)
      aiex.dma_free_task(%139)
      aiex.dma_free_task(%140)
      aiex.dma_free_task(%141)
      aiex.dma_free_task(%142)
      aiex.dma_free_task(%143)
      aiex.dma_await_task(%144)
      aiex.dma_await_task(%145)
      aiex.dma_await_task(%146)
      aiex.dma_await_task(%147)
      aiex.dma_free_task(%144)
      aiex.dma_free_task(%145)
      aiex.dma_free_task(%146)
      aiex.dma_free_task(%147)
      aiex.dma_free_task(%148)
      aiex.dma_free_task(%149)
      aiex.dma_free_task(%150)
      aiex.dma_free_task(%151)
      aiex.dma_free_task(%152)
      aiex.dma_free_task(%153)
      aiex.dma_free_task(%154)
      aiex.dma_free_task(%155)
      aiex.dma_free_task(%156)
      aiex.dma_free_task(%157)
      aiex.dma_free_task(%158)
      aiex.dma_free_task(%159)
    }
  }
}
