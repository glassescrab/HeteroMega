; ModuleID = '/notebooks/HeteroMega-upstream-partition-20261027/artifacts/upstream_bfp16_projection_m512_k2304_n4096_71726d10ffbf1f69/final.prj/peano-linked_main_core_3_3.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:20:32-i1:8:32-i8:8:32-i16:16:32-i32:32:32-f32:32:32-i64:32-f64:32-a:0:32-n32"
target triple = "aie2p"

@direct_dequant_3_1 = external global [4096 x bfloat]
@direct_acc1_3_1 = external global [2048 x float]
@direct_acc0_3_1 = external global [2048 x float]
@direct_a_broadcast_1_3_cons_buff_0 = external global [8192 x bfloat]
@direct_w_broadcast_3_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_1_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_3_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_3_1_buff_0 = external global [2048 x bfloat]

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.acquire(i32, i32) #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.release(i32, i32) #0

declare void @w4a16_prefill_reuse_init(ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_low(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_high(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_finish(ptr, ptr) local_unnamed_addr

define void @core_3_3() local_unnamed_addr {
  br label %.preheader

.preheader:                                       ; preds = %0, %128
  %1 = phi i32 [ 0, %0 ], [ %122, %128 ]
  %2 = phi i64 [ 0, %0 ], [ %129, %128 ]
  br label %3

3:                                                ; preds = %.preheader, %125
  %4 = phi i32 [ %1, %.preheader ], [ %122, %125 ]
  %5 = phi i64 [ 0, %.preheader ], [ %126, %125 ]
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_1)
  br label %6

6:                                                ; preds = %6, %3
  %7 = phi i32 [ %4, %3 ], [ %17, %6 ]
  %8 = phi i64 [ 0, %3 ], [ %18, %6 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond = icmp eq i32 %7, 1
  %spec.select = select i1 %cond, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %9 = add i32 %7, 1
  %10 = icmp sgt i32 %9, 1
  %11 = select i1 %10, i32 0, i32 %9
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond.1 = icmp eq i32 %11, 1
  %spec.select.1 = select i1 %cond.1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select.1, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select.1, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %12 = add i32 %11, 1
  %13 = icmp sgt i32 %12, 1
  %14 = select i1 %13, i32 0, i32 %12
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond.2 = icmp eq i32 %14, 1
  %spec.select.2 = select i1 %cond.2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select.2, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select.2, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %15 = add i32 %14, 1
  %16 = icmp sgt i32 %15, 1
  %17 = select i1 %16, i32 0, i32 %15
  %18 = add nuw nsw i64 %8, 3
  %19 = icmp samesign ult i64 %8, 15
  br i1 %19, label %6, label %20

20:                                               ; preds = %6
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_y_worker_3_1_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_y_worker_3_1_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_1)
  br label %21

21:                                               ; preds = %21, %20
  %22 = phi i32 [ %17, %20 ], [ %32, %21 ]
  %23 = phi i64 [ 0, %20 ], [ %33, %21 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1 = icmp eq i32 %22, 1
  %spec.select16 = select i1 %cond1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select16, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select16, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %24 = add i32 %22, 1
  %25 = icmp sgt i32 %24, 1
  %26 = select i1 %25, i32 0, i32 %24
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1.1 = icmp eq i32 %26, 1
  %spec.select16.1 = select i1 %cond1.1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select16.1, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select16.1, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %27 = add i32 %26, 1
  %28 = icmp sgt i32 %27, 1
  %29 = select i1 %28, i32 0, i32 %27
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1.2 = icmp eq i32 %29, 1
  %spec.select16.2 = select i1 %cond1.2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select16.2, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select16.2, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %30 = add i32 %29, 1
  %31 = icmp sgt i32 %30, 1
  %32 = select i1 %31, i32 0, i32 %30
  %33 = add nuw nsw i64 %23, 3
  %34 = icmp samesign ult i64 %23, 15
  br i1 %34, label %21, label %35

35:                                               ; preds = %21
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_y_worker_3_1_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_y_worker_3_1_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_1)
  br label %36

36:                                               ; preds = %36, %35
  %37 = phi i32 [ %32, %35 ], [ %47, %36 ]
  %38 = phi i64 [ 0, %35 ], [ %48, %36 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2 = icmp eq i32 %37, 1
  %spec.select17 = select i1 %cond2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select17, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select17, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %39 = add i32 %37, 1
  %40 = icmp sgt i32 %39, 1
  %41 = select i1 %40, i32 0, i32 %39
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2.1 = icmp eq i32 %41, 1
  %spec.select17.1 = select i1 %cond2.1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select17.1, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select17.1, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %42 = add i32 %41, 1
  %43 = icmp sgt i32 %42, 1
  %44 = select i1 %43, i32 0, i32 %42
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2.2 = icmp eq i32 %44, 1
  %spec.select17.2 = select i1 %cond2.2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select17.2, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select17.2, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %45 = add i32 %44, 1
  %46 = icmp sgt i32 %45, 1
  %47 = select i1 %46, i32 0, i32 %45
  %48 = add nuw nsw i64 %38, 3
  %49 = icmp samesign ult i64 %38, 15
  br i1 %49, label %36, label %50

50:                                               ; preds = %36
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_y_worker_3_1_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_y_worker_3_1_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_1)
  br label %51

51:                                               ; preds = %51, %50
  %52 = phi i32 [ %47, %50 ], [ %62, %51 ]
  %53 = phi i64 [ 0, %50 ], [ %63, %51 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3 = icmp eq i32 %52, 1
  %spec.select18 = select i1 %cond3, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select18, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select18, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %54 = add i32 %52, 1
  %55 = icmp sgt i32 %54, 1
  %56 = select i1 %55, i32 0, i32 %54
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3.1 = icmp eq i32 %56, 1
  %spec.select18.1 = select i1 %cond3.1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select18.1, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select18.1, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %57 = add i32 %56, 1
  %58 = icmp sgt i32 %57, 1
  %59 = select i1 %58, i32 0, i32 %57
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3.2 = icmp eq i32 %59, 1
  %spec.select18.2 = select i1 %cond3.2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select18.2, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select18.2, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %60 = add i32 %59, 1
  %61 = icmp sgt i32 %60, 1
  %62 = select i1 %61, i32 0, i32 %60
  %63 = add nuw nsw i64 %53, 3
  %64 = icmp samesign ult i64 %53, 15
  br i1 %64, label %51, label %65

65:                                               ; preds = %51
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_y_worker_3_1_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_y_worker_3_1_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_1)
  br label %66

66:                                               ; preds = %66, %65
  %67 = phi i32 [ %62, %65 ], [ %77, %66 ]
  %68 = phi i64 [ 0, %65 ], [ %78, %66 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4 = icmp eq i32 %67, 1
  %spec.select19 = select i1 %cond4, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select19, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select19, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %69 = add i32 %67, 1
  %70 = icmp sgt i32 %69, 1
  %71 = select i1 %70, i32 0, i32 %69
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4.1 = icmp eq i32 %71, 1
  %spec.select19.1 = select i1 %cond4.1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select19.1, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select19.1, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %72 = add i32 %71, 1
  %73 = icmp sgt i32 %72, 1
  %74 = select i1 %73, i32 0, i32 %72
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4.2 = icmp eq i32 %74, 1
  %spec.select19.2 = select i1 %cond4.2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select19.2, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select19.2, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %75 = add i32 %74, 1
  %76 = icmp sgt i32 %75, 1
  %77 = select i1 %76, i32 0, i32 %75
  %78 = add nuw nsw i64 %68, 3
  %79 = icmp samesign ult i64 %68, 15
  br i1 %79, label %66, label %80

80:                                               ; preds = %66
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_y_worker_3_1_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_y_worker_3_1_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_1)
  br label %81

81:                                               ; preds = %81, %80
  %82 = phi i32 [ %77, %80 ], [ %92, %81 ]
  %83 = phi i64 [ 0, %80 ], [ %93, %81 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5 = icmp eq i32 %82, 1
  %spec.select20 = select i1 %cond5, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select20, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select20, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %84 = add i32 %82, 1
  %85 = icmp sgt i32 %84, 1
  %86 = select i1 %85, i32 0, i32 %84
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5.1 = icmp eq i32 %86, 1
  %spec.select20.1 = select i1 %cond5.1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select20.1, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select20.1, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %87 = add i32 %86, 1
  %88 = icmp sgt i32 %87, 1
  %89 = select i1 %88, i32 0, i32 %87
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5.2 = icmp eq i32 %89, 1
  %spec.select20.2 = select i1 %cond5.2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select20.2, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select20.2, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %90 = add i32 %89, 1
  %91 = icmp sgt i32 %90, 1
  %92 = select i1 %91, i32 0, i32 %90
  %93 = add nuw nsw i64 %83, 3
  %94 = icmp samesign ult i64 %83, 15
  br i1 %94, label %81, label %95

95:                                               ; preds = %81
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_y_worker_3_1_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_y_worker_3_1_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_1)
  br label %96

96:                                               ; preds = %96, %95
  %97 = phi i32 [ %92, %95 ], [ %107, %96 ]
  %98 = phi i64 [ 0, %95 ], [ %108, %96 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6 = icmp eq i32 %97, 1
  %spec.select21 = select i1 %cond6, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select21, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select21, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %99 = add i32 %97, 1
  %100 = icmp sgt i32 %99, 1
  %101 = select i1 %100, i32 0, i32 %99
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6.1 = icmp eq i32 %101, 1
  %spec.select21.1 = select i1 %cond6.1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select21.1, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select21.1, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %102 = add i32 %101, 1
  %103 = icmp sgt i32 %102, 1
  %104 = select i1 %103, i32 0, i32 %102
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6.2 = icmp eq i32 %104, 1
  %spec.select21.2 = select i1 %cond6.2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select21.2, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select21.2, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %105 = add i32 %104, 1
  %106 = icmp sgt i32 %105, 1
  %107 = select i1 %106, i32 0, i32 %105
  %108 = add nuw nsw i64 %98, 3
  %109 = icmp samesign ult i64 %98, 15
  br i1 %109, label %96, label %110

110:                                              ; preds = %96
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_y_worker_3_1_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_y_worker_3_1_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_1)
  br label %111

111:                                              ; preds = %111, %110
  %112 = phi i32 [ %107, %110 ], [ %122, %111 ]
  %113 = phi i64 [ 0, %110 ], [ %123, %111 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7 = icmp eq i32 %112, 1
  %spec.select22 = select i1 %cond7, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select22, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select22, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %114 = add i32 %112, 1
  %115 = icmp sgt i32 %114, 1
  %116 = select i1 %115, i32 0, i32 %114
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7.1 = icmp eq i32 %116, 1
  %spec.select22.1 = select i1 %cond7.1, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select22.1, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select22.1, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %117 = add i32 %116, 1
  %118 = icmp sgt i32 %117, 1
  %119 = select i1 %118, i32 0, i32 %117
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7.2 = icmp eq i32 %119, 1
  %spec.select22.2 = select i1 %cond7.2, ptr @direct_w_broadcast_3_1_cons_buff_1, ptr @direct_w_broadcast_3_1_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select22.2, ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_1_3_cons_buff_0, ptr nonnull %spec.select22.2, ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_dequant_3_1)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %120 = add i32 %119, 1
  %121 = icmp sgt i32 %120, 1
  %122 = select i1 %121, i32 0, i32 %120
  %123 = add nuw nsw i64 %113, 3
  %124 = icmp samesign ult i64 %113, 15
  br i1 %124, label %111, label %125

125:                                              ; preds = %111
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_1, ptr nonnull @direct_y_worker_3_1_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_1, ptr nonnull @direct_y_worker_3_1_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  %126 = add nuw nsw i64 %5, 1
  %127 = icmp eq i64 %5, 0
  br i1 %127, label %3, label %128

128:                                              ; preds = %125
  %129 = add nuw nsw i64 %2, 1
  %.not = icmp eq i64 %129, 9223372036854775807
  br i1 %.not, label %130, label %.preheader

130:                                              ; preds = %128
  ret void
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
