; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aie2p"

@direct_dequant_7_3 = external global [4096 x bfloat]
@direct_acc1_7_3 = external global [2048 x float]
@direct_acc0_7_3 = external global [2048 x float]
@direct_dequant_7_2 = external global [4096 x bfloat]
@direct_acc1_7_2 = external global [2048 x float]
@direct_acc0_7_2 = external global [2048 x float]
@direct_dequant_7_1 = external global [4096 x bfloat]
@direct_acc1_7_1 = external global [2048 x float]
@direct_acc0_7_1 = external global [2048 x float]
@direct_dequant_7_0 = external global [4096 x bfloat]
@direct_acc1_7_0 = external global [2048 x float]
@direct_acc0_7_0 = external global [2048 x float]
@direct_dequant_6_3 = external global [4096 x bfloat]
@direct_acc1_6_3 = external global [2048 x float]
@direct_acc0_6_3 = external global [2048 x float]
@direct_dequant_6_2 = external global [4096 x bfloat]
@direct_acc1_6_2 = external global [2048 x float]
@direct_acc0_6_2 = external global [2048 x float]
@direct_dequant_6_1 = external global [4096 x bfloat]
@direct_acc1_6_1 = external global [2048 x float]
@direct_acc0_6_1 = external global [2048 x float]
@direct_dequant_6_0 = external global [4096 x bfloat]
@direct_acc1_6_0 = external global [2048 x float]
@direct_acc0_6_0 = external global [2048 x float]
@direct_dequant_5_3 = external global [4096 x bfloat]
@direct_acc1_5_3 = external global [2048 x float]
@direct_acc0_5_3 = external global [2048 x float]
@direct_dequant_5_2 = external global [4096 x bfloat]
@direct_acc1_5_2 = external global [2048 x float]
@direct_acc0_5_2 = external global [2048 x float]
@direct_dequant_5_1 = external global [4096 x bfloat]
@direct_acc1_5_1 = external global [2048 x float]
@direct_acc0_5_1 = external global [2048 x float]
@direct_dequant_5_0 = external global [4096 x bfloat]
@direct_acc1_5_0 = external global [2048 x float]
@direct_acc0_5_0 = external global [2048 x float]
@direct_dequant_4_3 = external global [4096 x bfloat]
@direct_acc1_4_3 = external global [2048 x float]
@direct_acc0_4_3 = external global [2048 x float]
@direct_dequant_4_2 = external global [4096 x bfloat]
@direct_acc1_4_2 = external global [2048 x float]
@direct_acc0_4_2 = external global [2048 x float]
@direct_dequant_4_1 = external global [4096 x bfloat]
@direct_acc1_4_1 = external global [2048 x float]
@direct_acc0_4_1 = external global [2048 x float]
@direct_dequant_4_0 = external global [4096 x bfloat]
@direct_acc1_4_0 = external global [2048 x float]
@direct_acc0_4_0 = external global [2048 x float]
@direct_dequant_3_3 = external global [4096 x bfloat]
@direct_acc1_3_3 = external global [2048 x float]
@direct_acc0_3_3 = external global [2048 x float]
@direct_dequant_3_2 = external global [4096 x bfloat]
@direct_acc1_3_2 = external global [2048 x float]
@direct_acc0_3_2 = external global [2048 x float]
@direct_dequant_3_1 = external global [4096 x bfloat]
@direct_acc1_3_1 = external global [2048 x float]
@direct_acc0_3_1 = external global [2048 x float]
@direct_dequant_3_0 = external global [4096 x bfloat]
@direct_acc1_3_0 = external global [2048 x float]
@direct_acc0_3_0 = external global [2048 x float]
@direct_dequant_2_3 = external global [4096 x bfloat]
@direct_acc1_2_3 = external global [2048 x float]
@direct_acc0_2_3 = external global [2048 x float]
@direct_dequant_2_2 = external global [4096 x bfloat]
@direct_acc1_2_2 = external global [2048 x float]
@direct_acc0_2_2 = external global [2048 x float]
@direct_dequant_2_1 = external global [4096 x bfloat]
@direct_acc1_2_1 = external global [2048 x float]
@direct_acc0_2_1 = external global [2048 x float]
@direct_dequant_2_0 = external global [4096 x bfloat]
@direct_acc1_2_0 = external global [2048 x float]
@direct_acc0_2_0 = external global [2048 x float]
@direct_dequant_1_3 = external global [4096 x bfloat]
@direct_acc1_1_3 = external global [2048 x float]
@direct_acc0_1_3 = external global [2048 x float]
@direct_dequant_1_2 = external global [4096 x bfloat]
@direct_acc1_1_2 = external global [2048 x float]
@direct_acc0_1_2 = external global [2048 x float]
@direct_dequant_1_1 = external global [4096 x bfloat]
@direct_acc1_1_1 = external global [2048 x float]
@direct_acc0_1_1 = external global [2048 x float]
@direct_dequant_1_0 = external global [4096 x bfloat]
@direct_acc1_1_0 = external global [2048 x float]
@direct_acc0_1_0 = external global [2048 x float]
@direct_dequant_0_3 = external global [4096 x bfloat]
@direct_acc1_0_3 = external global [2048 x float]
@direct_acc0_0_3 = external global [2048 x float]
@direct_dequant_0_2 = external global [4096 x bfloat]
@direct_acc1_0_2 = external global [2048 x float]
@direct_acc0_0_2 = external global [2048 x float]
@direct_dequant_0_1 = external global [4096 x bfloat]
@direct_acc1_0_1 = external global [2048 x float]
@direct_acc0_0_1 = external global [2048 x float]
@direct_dequant_0_0 = external global [4096 x bfloat]
@direct_acc1_0_0 = external global [2048 x float]
@direct_acc0_0_0 = external global [2048 x float]
@direct_a_broadcast_0_7_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_0_6_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_0_5_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_0_4_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_0_3_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_0_2_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_0_1_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_0_0_cons_buff_0 = external global [8192 x bfloat]
@direct_a_host_0_cons_buff_1 = external global [8192 x bfloat]
@direct_a_host_0_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_1_7_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_1_6_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_1_5_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_1_4_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_1_3_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_1_2_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_1_1_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_1_0_cons_buff_0 = external global [8192 x bfloat]
@direct_a_host_1_cons_buff_1 = external global [8192 x bfloat]
@direct_a_host_1_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_2_7_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_2_6_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_2_5_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_2_4_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_2_3_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_2_2_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_2_1_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_2_0_cons_buff_0 = external global [8192 x bfloat]
@direct_a_host_2_cons_buff_1 = external global [8192 x bfloat]
@direct_a_host_2_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_3_7_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_3_6_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_3_5_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_3_4_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_3_3_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_3_2_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_3_1_cons_buff_0 = external global [8192 x bfloat]
@direct_a_broadcast_3_0_cons_buff_0 = external global [8192 x bfloat]
@direct_a_host_3_cons_buff_1 = external global [8192 x bfloat]
@direct_a_host_3_cons_buff_0 = external global [8192 x bfloat]
@direct_y_host_0_buff_1 = external global [8192 x bfloat]
@direct_y_host_0_buff_0 = external global [8192 x bfloat]
@direct_w_broadcast_0_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_1_buff_1 = external global [8192 x bfloat]
@direct_y_host_1_buff_0 = external global [8192 x bfloat]
@direct_y_host_2_buff_1 = external global [8192 x bfloat]
@direct_y_host_2_buff_0 = external global [8192 x bfloat]
@direct_w_broadcast_1_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_3_buff_1 = external global [8192 x bfloat]
@direct_y_host_3_buff_0 = external global [8192 x bfloat]
@direct_y_host_4_buff_1 = external global [8192 x bfloat]
@direct_y_host_4_buff_0 = external global [8192 x bfloat]
@direct_w_broadcast_2_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_5_buff_1 = external global [8192 x bfloat]
@direct_y_host_5_buff_0 = external global [8192 x bfloat]
@direct_y_host_6_buff_1 = external global [8192 x bfloat]
@direct_y_host_6_buff_0 = external global [8192 x bfloat]
@direct_w_broadcast_3_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_7_buff_1 = external global [8192 x bfloat]
@direct_y_host_7_buff_0 = external global [8192 x bfloat]
@direct_w_broadcast_4_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_0_cons_buff_1 = external global [4352 x i8]
@direct_w_host_0_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_1_cons_buff_1 = external global [4352 x i8]
@direct_w_host_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_2_cons_buff_1 = external global [4352 x i8]
@direct_w_host_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_3_cons_buff_1 = external global [4352 x i8]
@direct_w_host_3_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_0_0_buff_1 = external global [2048 x bfloat]
@direct_y_worker_0_0_buff_0 = external global [2048 x bfloat]
@direct_w_host_4_cons_buff_1 = external global [4352 x i8]
@direct_w_host_4_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_0_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_0_1_buff_0 = external global [2048 x bfloat]
@direct_y_worker_0_2_buff_1 = external global [2048 x bfloat]
@direct_y_worker_0_2_buff_0 = external global [2048 x bfloat]
@direct_w_host_5_cons_buff_1 = external global [4352 x i8]
@direct_w_host_5_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_0_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_0_3_buff_0 = external global [2048 x bfloat]
@direct_w_host_6_cons_buff_1 = external global [4352 x i8]
@direct_w_host_6_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_1_0_buff_1 = external global [2048 x bfloat]
@direct_y_worker_1_0_buff_0 = external global [2048 x bfloat]
@direct_y_worker_1_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_1_1_buff_0 = external global [2048 x bfloat]
@direct_w_host_7_cons_buff_1 = external global [4352 x i8]
@direct_w_host_7_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_1_2_buff_1 = external global [2048 x bfloat]
@direct_y_worker_1_2_buff_0 = external global [2048 x bfloat]
@direct_y_worker_1_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_1_3_buff_0 = external global [2048 x bfloat]
@direct_y_worker_2_0_buff_1 = external global [2048 x bfloat]
@direct_y_worker_2_0_buff_0 = external global [2048 x bfloat]
@direct_y_worker_2_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_2_1_buff_0 = external global [2048 x bfloat]
@direct_y_worker_2_2_buff_1 = external global [2048 x bfloat]
@direct_y_worker_2_2_buff_0 = external global [2048 x bfloat]
@direct_y_worker_2_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_2_3_buff_0 = external global [2048 x bfloat]
@direct_y_worker_3_0_buff_1 = external global [2048 x bfloat]
@direct_y_worker_3_0_buff_0 = external global [2048 x bfloat]
@direct_y_worker_3_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_3_1_buff_0 = external global [2048 x bfloat]
@direct_y_worker_3_2_buff_1 = external global [2048 x bfloat]
@direct_y_worker_3_2_buff_0 = external global [2048 x bfloat]
@direct_y_worker_3_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_3_3_buff_0 = external global [2048 x bfloat]
@direct_y_worker_4_0_buff_1 = external global [2048 x bfloat]
@direct_y_worker_4_0_buff_0 = external global [2048 x bfloat]
@direct_y_worker_4_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_4_1_buff_0 = external global [2048 x bfloat]
@direct_y_worker_4_2_buff_1 = external global [2048 x bfloat]
@direct_y_worker_4_2_buff_0 = external global [2048 x bfloat]
@direct_y_worker_4_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_4_3_buff_0 = external global [2048 x bfloat]
@direct_y_worker_5_0_buff_1 = external global [2048 x bfloat]
@direct_y_worker_5_0_buff_0 = external global [2048 x bfloat]
@direct_y_worker_5_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_5_1_buff_0 = external global [2048 x bfloat]
@direct_y_worker_5_2_buff_1 = external global [2048 x bfloat]
@direct_y_worker_5_2_buff_0 = external global [2048 x bfloat]
@direct_y_worker_5_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_5_3_buff_0 = external global [2048 x bfloat]
@direct_y_worker_6_0_buff_1 = external global [2048 x bfloat]
@direct_y_worker_6_0_buff_0 = external global [2048 x bfloat]
@direct_y_worker_6_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_6_1_buff_0 = external global [2048 x bfloat]
@direct_y_worker_6_2_buff_1 = external global [2048 x bfloat]
@direct_y_worker_6_2_buff_0 = external global [2048 x bfloat]
@direct_y_worker_6_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_6_3_buff_0 = external global [2048 x bfloat]
@direct_y_worker_7_0_buff_1 = external global [2048 x bfloat]
@direct_y_worker_7_0_buff_0 = external global [2048 x bfloat]
@direct_y_worker_7_1_buff_1 = external global [2048 x bfloat]
@direct_y_worker_7_1_buff_0 = external global [2048 x bfloat]
@direct_y_worker_7_2_buff_1 = external global [2048 x bfloat]
@direct_y_worker_7_2_buff_0 = external global [2048 x bfloat]
@direct_y_worker_7_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_7_3_buff_0 = external global [2048 x bfloat]

declare void @debug_i32(i32)

; Unknown intrinsic
declare void @llvm.aie2p.event(i32)

; Unknown intrinsic
declare void @llvm.aie2p.put.ms(i32, i32)

; Unknown intrinsic
declare { i32, i32 } @llvm.aie2p.get.ss()

; Unknown intrinsic
declare void @llvm.aie2p.mcd.write.vec(<16 x i32>, i32)

; Unknown intrinsic
declare <16 x i32> @llvm.aie2p.scd.read.vec(i32)

; Unknown intrinsic
declare void @llvm.aie2p.acquire(i32, i32)

; Unknown intrinsic
declare void @llvm.aie2p.release(i32, i32)

; Unknown intrinsic
declare void @llvm.aie2p.set.ctrl.reg(i32, i32)

declare void @w4a16_prefill_reuse_init(ptr)

declare void @w4a16_prefill_reuse_accumulate_low(ptr, ptr, ptr, ptr)

declare void @w4a16_prefill_reuse_accumulate_high(ptr, ptr, ptr, ptr)

declare void @w4a16_prefill_reuse_finish(ptr, ptr)

define void @core_3_2() {
  br label %1

1:                                                ; preds = %131, %0
  %2 = phi i64 [ %132, %131 ], [ 0, %0 ]
  %3 = phi i32 [ %7, %131 ], [ 0, %0 ]
  %4 = icmp slt i64 %2, 9223372036854775807
  br i1 %4, label %5, label %133

5:                                                ; preds = %129, %1
  %6 = phi i64 [ %130, %129 ], [ 0, %1 ]
  %7 = phi i32 [ %117, %129 ], [ %3, %1 ]
  %8 = icmp slt i64 %6, 2
  br i1 %8, label %9, label %131

9:                                                ; preds = %5
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_3_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_3_0)
  br label %10

10:                                               ; preds = %19, %9
  %11 = phi i64 [ %23, %19 ], [ 0, %9 ]
  %12 = phi i32 [ %22, %19 ], [ %7, %9 ]
  %13 = icmp slt i64 %11, 8
  br i1 %13, label %14, label %24

14:                                               ; preds = %10
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %15 = sext i32 %12 to i64
  switch i64 %15, label %16 [
    i64 0, label %134
    i64 1, label %136
  ]

16:                                               ; preds = %134, %136, %14
  %17 = phi ptr [ %137, %136 ], [ %135, %134 ], [ @direct_w_broadcast_3_0_cons_buff_0, %14 ]
  %18 = getelementptr [4352 x i8], ptr %17, i32 0, i32 0
  br label %19

19:                                               ; preds = %16
  call void @w4a16_prefill_reuse_accumulate_low(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %18, ptr @direct_acc0_3_0, ptr @direct_dequant_3_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %18, ptr @direct_acc1_3_0, ptr @direct_dequant_3_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %20 = add i32 %12, 1
  %21 = icmp sge i32 %20, 2
  %22 = select i1 %21, i32 0, i32 %20
  %23 = add i64 %11, 1
  br label %10

24:                                               ; preds = %10
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_3_0, ptr @direct_y_worker_3_0_buff_0)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_3_0, ptr @direct_y_worker_3_0_buff_1)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_3_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_3_0)
  br label %25

25:                                               ; preds = %34, %24
  %26 = phi i64 [ %38, %34 ], [ 0, %24 ]
  %27 = phi i32 [ %37, %34 ], [ %12, %24 ]
  %28 = icmp slt i64 %26, 8
  br i1 %28, label %29, label %39

29:                                               ; preds = %25
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %30 = sext i32 %27 to i64
  switch i64 %30, label %31 [
    i64 0, label %138
    i64 1, label %140
  ]

31:                                               ; preds = %138, %140, %29
  %32 = phi ptr [ %141, %140 ], [ %139, %138 ], [ @direct_w_broadcast_3_0_cons_buff_0, %29 ]
  %33 = getelementptr [4352 x i8], ptr %32, i32 0, i32 0
  br label %34

34:                                               ; preds = %31
  call void @w4a16_prefill_reuse_accumulate_low(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %33, ptr @direct_acc0_3_0, ptr @direct_dequant_3_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %33, ptr @direct_acc1_3_0, ptr @direct_dequant_3_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %35 = add i32 %27, 1
  %36 = icmp sge i32 %35, 2
  %37 = select i1 %36, i32 0, i32 %35
  %38 = add i64 %26, 1
  br label %25

39:                                               ; preds = %25
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_3_0, ptr @direct_y_worker_3_0_buff_0)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_3_0, ptr @direct_y_worker_3_0_buff_1)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_3_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_3_0)
  br label %40

40:                                               ; preds = %49, %39
  %41 = phi i64 [ %53, %49 ], [ 0, %39 ]
  %42 = phi i32 [ %52, %49 ], [ %27, %39 ]
  %43 = icmp slt i64 %41, 8
  br i1 %43, label %44, label %54

44:                                               ; preds = %40
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %45 = sext i32 %42 to i64
  switch i64 %45, label %46 [
    i64 0, label %142
    i64 1, label %144
  ]

46:                                               ; preds = %142, %144, %44
  %47 = phi ptr [ %145, %144 ], [ %143, %142 ], [ @direct_w_broadcast_3_0_cons_buff_0, %44 ]
  %48 = getelementptr [4352 x i8], ptr %47, i32 0, i32 0
  br label %49

49:                                               ; preds = %46
  call void @w4a16_prefill_reuse_accumulate_low(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %48, ptr @direct_acc0_3_0, ptr @direct_dequant_3_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %48, ptr @direct_acc1_3_0, ptr @direct_dequant_3_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %50 = add i32 %42, 1
  %51 = icmp sge i32 %50, 2
  %52 = select i1 %51, i32 0, i32 %50
  %53 = add i64 %41, 1
  br label %40

54:                                               ; preds = %40
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_3_0, ptr @direct_y_worker_3_0_buff_0)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_3_0, ptr @direct_y_worker_3_0_buff_1)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_3_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_3_0)
  br label %55

55:                                               ; preds = %64, %54
  %56 = phi i64 [ %68, %64 ], [ 0, %54 ]
  %57 = phi i32 [ %67, %64 ], [ %42, %54 ]
  %58 = icmp slt i64 %56, 8
  br i1 %58, label %59, label %69

59:                                               ; preds = %55
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %60 = sext i32 %57 to i64
  switch i64 %60, label %61 [
    i64 0, label %146
    i64 1, label %148
  ]

61:                                               ; preds = %146, %148, %59
  %62 = phi ptr [ %149, %148 ], [ %147, %146 ], [ @direct_w_broadcast_3_0_cons_buff_0, %59 ]
  %63 = getelementptr [4352 x i8], ptr %62, i32 0, i32 0
  br label %64

64:                                               ; preds = %61
  call void @w4a16_prefill_reuse_accumulate_low(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %63, ptr @direct_acc0_3_0, ptr @direct_dequant_3_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %63, ptr @direct_acc1_3_0, ptr @direct_dequant_3_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %65 = add i32 %57, 1
  %66 = icmp sge i32 %65, 2
  %67 = select i1 %66, i32 0, i32 %65
  %68 = add i64 %56, 1
  br label %55

69:                                               ; preds = %55
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_3_0, ptr @direct_y_worker_3_0_buff_0)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_3_0, ptr @direct_y_worker_3_0_buff_1)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_3_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_3_0)
  br label %70

70:                                               ; preds = %79, %69
  %71 = phi i64 [ %83, %79 ], [ 0, %69 ]
  %72 = phi i32 [ %82, %79 ], [ %57, %69 ]
  %73 = icmp slt i64 %71, 8
  br i1 %73, label %74, label %84

74:                                               ; preds = %70
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %75 = sext i32 %72 to i64
  switch i64 %75, label %76 [
    i64 0, label %150
    i64 1, label %152
  ]

76:                                               ; preds = %150, %152, %74
  %77 = phi ptr [ %153, %152 ], [ %151, %150 ], [ @direct_w_broadcast_3_0_cons_buff_0, %74 ]
  %78 = getelementptr [4352 x i8], ptr %77, i32 0, i32 0
  br label %79

79:                                               ; preds = %76
  call void @w4a16_prefill_reuse_accumulate_low(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %78, ptr @direct_acc0_3_0, ptr @direct_dequant_3_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %78, ptr @direct_acc1_3_0, ptr @direct_dequant_3_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %80 = add i32 %72, 1
  %81 = icmp sge i32 %80, 2
  %82 = select i1 %81, i32 0, i32 %80
  %83 = add i64 %71, 1
  br label %70

84:                                               ; preds = %70
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_3_0, ptr @direct_y_worker_3_0_buff_0)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_3_0, ptr @direct_y_worker_3_0_buff_1)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_3_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_3_0)
  br label %85

85:                                               ; preds = %94, %84
  %86 = phi i64 [ %98, %94 ], [ 0, %84 ]
  %87 = phi i32 [ %97, %94 ], [ %72, %84 ]
  %88 = icmp slt i64 %86, 8
  br i1 %88, label %89, label %99

89:                                               ; preds = %85
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %90 = sext i32 %87 to i64
  switch i64 %90, label %91 [
    i64 0, label %154
    i64 1, label %156
  ]

91:                                               ; preds = %154, %156, %89
  %92 = phi ptr [ %157, %156 ], [ %155, %154 ], [ @direct_w_broadcast_3_0_cons_buff_0, %89 ]
  %93 = getelementptr [4352 x i8], ptr %92, i32 0, i32 0
  br label %94

94:                                               ; preds = %91
  call void @w4a16_prefill_reuse_accumulate_low(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %93, ptr @direct_acc0_3_0, ptr @direct_dequant_3_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %93, ptr @direct_acc1_3_0, ptr @direct_dequant_3_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %95 = add i32 %87, 1
  %96 = icmp sge i32 %95, 2
  %97 = select i1 %96, i32 0, i32 %95
  %98 = add i64 %86, 1
  br label %85

99:                                               ; preds = %85
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_3_0, ptr @direct_y_worker_3_0_buff_0)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_3_0, ptr @direct_y_worker_3_0_buff_1)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_3_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_3_0)
  br label %100

100:                                              ; preds = %109, %99
  %101 = phi i64 [ %113, %109 ], [ 0, %99 ]
  %102 = phi i32 [ %112, %109 ], [ %87, %99 ]
  %103 = icmp slt i64 %101, 8
  br i1 %103, label %104, label %114

104:                                              ; preds = %100
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %105 = sext i32 %102 to i64
  switch i64 %105, label %106 [
    i64 0, label %158
    i64 1, label %160
  ]

106:                                              ; preds = %158, %160, %104
  %107 = phi ptr [ %161, %160 ], [ %159, %158 ], [ @direct_w_broadcast_3_0_cons_buff_0, %104 ]
  %108 = getelementptr [4352 x i8], ptr %107, i32 0, i32 0
  br label %109

109:                                              ; preds = %106
  call void @w4a16_prefill_reuse_accumulate_low(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %108, ptr @direct_acc0_3_0, ptr @direct_dequant_3_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %108, ptr @direct_acc1_3_0, ptr @direct_dequant_3_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %110 = add i32 %102, 1
  %111 = icmp sge i32 %110, 2
  %112 = select i1 %111, i32 0, i32 %110
  %113 = add i64 %101, 1
  br label %100

114:                                              ; preds = %100
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_3_0, ptr @direct_y_worker_3_0_buff_0)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_3_0, ptr @direct_y_worker_3_0_buff_1)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_3_0)
  call void @w4a16_prefill_reuse_init(ptr @direct_acc1_3_0)
  br label %115

115:                                              ; preds = %124, %114
  %116 = phi i64 [ %128, %124 ], [ 0, %114 ]
  %117 = phi i32 [ %127, %124 ], [ %102, %114 ]
  %118 = icmp slt i64 %116, 8
  br i1 %118, label %119, label %129

119:                                              ; preds = %115
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %120 = sext i32 %117 to i64
  switch i64 %120, label %121 [
    i64 0, label %162
    i64 1, label %164
  ]

121:                                              ; preds = %162, %164, %119
  %122 = phi ptr [ %165, %164 ], [ %163, %162 ], [ @direct_w_broadcast_3_0_cons_buff_0, %119 ]
  %123 = getelementptr [4352 x i8], ptr %122, i32 0, i32 0
  br label %124

124:                                              ; preds = %121
  call void @w4a16_prefill_reuse_accumulate_low(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %123, ptr @direct_acc0_3_0, ptr @direct_dequant_3_0)
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_0_3_cons_buff_0, ptr %123, ptr @direct_acc1_3_0, ptr @direct_dequant_3_0)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %125 = add i32 %117, 1
  %126 = icmp sge i32 %125, 2
  %127 = select i1 %126, i32 0, i32 %125
  %128 = add i64 %116, 1
  br label %115

129:                                              ; preds = %115
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_3_0, ptr @direct_y_worker_3_0_buff_0)
  call void @llvm.aie2p.release(i32 49, i32 1)
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc1_3_0, ptr @direct_y_worker_3_0_buff_1)
  call void @llvm.aie2p.release(i32 49, i32 1)
  %130 = add i64 %6, 1
  br label %5

131:                                              ; preds = %5
  %132 = add i64 %2, 1
  br label %1

133:                                              ; preds = %1
  ret void

134:                                              ; preds = %14
  %135 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_0, %14 ]
  br label %16

136:                                              ; preds = %14
  %137 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_1, %14 ]
  br label %16

138:                                              ; preds = %29
  %139 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_0, %29 ]
  br label %31

140:                                              ; preds = %29
  %141 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_1, %29 ]
  br label %31

142:                                              ; preds = %44
  %143 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_0, %44 ]
  br label %46

144:                                              ; preds = %44
  %145 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_1, %44 ]
  br label %46

146:                                              ; preds = %59
  %147 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_0, %59 ]
  br label %61

148:                                              ; preds = %59
  %149 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_1, %59 ]
  br label %61

150:                                              ; preds = %74
  %151 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_0, %74 ]
  br label %76

152:                                              ; preds = %74
  %153 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_1, %74 ]
  br label %76

154:                                              ; preds = %89
  %155 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_0, %89 ]
  br label %91

156:                                              ; preds = %89
  %157 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_1, %89 ]
  br label %91

158:                                              ; preds = %104
  %159 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_0, %104 ]
  br label %106

160:                                              ; preds = %104
  %161 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_1, %104 ]
  br label %106

162:                                              ; preds = %119
  %163 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_0, %119 ]
  br label %121

164:                                              ; preds = %119
  %165 = phi ptr [ @direct_w_broadcast_3_0_cons_buff_1, %119 ]
  br label %121
}

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
