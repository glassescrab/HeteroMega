; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target triple = "aie2p"

@direct_dequant_7_3 = external global [4096 x bfloat]
@direct_acc1_7_3 = external global [1024 x float]
@direct_acc0_7_3 = external global [1024 x float]
@direct_dequant_7_2 = external global [4096 x bfloat]
@direct_acc1_7_2 = external global [1024 x float]
@direct_acc0_7_2 = external global [1024 x float]
@direct_dequant_7_1 = external global [4096 x bfloat]
@direct_acc1_7_1 = external global [1024 x float]
@direct_acc0_7_1 = external global [1024 x float]
@direct_dequant_7_0 = external global [4096 x bfloat]
@direct_acc1_7_0 = external global [1024 x float]
@direct_acc0_7_0 = external global [1024 x float]
@direct_dequant_6_3 = external global [4096 x bfloat]
@direct_acc1_6_3 = external global [1024 x float]
@direct_acc0_6_3 = external global [1024 x float]
@direct_dequant_6_2 = external global [4096 x bfloat]
@direct_acc1_6_2 = external global [1024 x float]
@direct_acc0_6_2 = external global [1024 x float]
@direct_dequant_6_1 = external global [4096 x bfloat]
@direct_acc1_6_1 = external global [1024 x float]
@direct_acc0_6_1 = external global [1024 x float]
@direct_dequant_6_0 = external global [4096 x bfloat]
@direct_acc1_6_0 = external global [1024 x float]
@direct_acc0_6_0 = external global [1024 x float]
@direct_dequant_5_3 = external global [4096 x bfloat]
@direct_acc1_5_3 = external global [1024 x float]
@direct_acc0_5_3 = external global [1024 x float]
@direct_dequant_5_2 = external global [4096 x bfloat]
@direct_acc1_5_2 = external global [1024 x float]
@direct_acc0_5_2 = external global [1024 x float]
@direct_dequant_5_1 = external global [4096 x bfloat]
@direct_acc1_5_1 = external global [1024 x float]
@direct_acc0_5_1 = external global [1024 x float]
@direct_dequant_5_0 = external global [4096 x bfloat]
@direct_acc1_5_0 = external global [1024 x float]
@direct_acc0_5_0 = external global [1024 x float]
@direct_dequant_4_3 = external global [4096 x bfloat]
@direct_acc1_4_3 = external global [1024 x float]
@direct_acc0_4_3 = external global [1024 x float]
@direct_dequant_4_2 = external global [4096 x bfloat]
@direct_acc1_4_2 = external global [1024 x float]
@direct_acc0_4_2 = external global [1024 x float]
@direct_dequant_4_1 = external global [4096 x bfloat]
@direct_acc1_4_1 = external global [1024 x float]
@direct_acc0_4_1 = external global [1024 x float]
@direct_dequant_4_0 = external global [4096 x bfloat]
@direct_acc1_4_0 = external global [1024 x float]
@direct_acc0_4_0 = external global [1024 x float]
@direct_dequant_3_3 = external global [4096 x bfloat]
@direct_acc1_3_3 = external global [1024 x float]
@direct_acc0_3_3 = external global [1024 x float]
@direct_dequant_3_2 = external global [4096 x bfloat]
@direct_acc1_3_2 = external global [1024 x float]
@direct_acc0_3_2 = external global [1024 x float]
@direct_dequant_3_1 = external global [4096 x bfloat]
@direct_acc1_3_1 = external global [1024 x float]
@direct_acc0_3_1 = external global [1024 x float]
@direct_dequant_3_0 = external global [4096 x bfloat]
@direct_acc1_3_0 = external global [1024 x float]
@direct_acc0_3_0 = external global [1024 x float]
@direct_dequant_2_3 = external global [4096 x bfloat]
@direct_acc1_2_3 = external global [1024 x float]
@direct_acc0_2_3 = external global [1024 x float]
@direct_dequant_2_2 = external global [4096 x bfloat]
@direct_acc1_2_2 = external global [1024 x float]
@direct_acc0_2_2 = external global [1024 x float]
@direct_dequant_2_1 = external global [4096 x bfloat]
@direct_acc1_2_1 = external global [1024 x float]
@direct_acc0_2_1 = external global [1024 x float]
@direct_dequant_2_0 = external global [4096 x bfloat]
@direct_acc1_2_0 = external global [1024 x float]
@direct_acc0_2_0 = external global [1024 x float]
@direct_dequant_1_3 = external global [4096 x bfloat]
@direct_acc1_1_3 = external global [1024 x float]
@direct_acc0_1_3 = external global [1024 x float]
@direct_dequant_1_2 = external global [4096 x bfloat]
@direct_acc1_1_2 = external global [1024 x float]
@direct_acc0_1_2 = external global [1024 x float]
@direct_dequant_1_1 = external global [4096 x bfloat]
@direct_acc1_1_1 = external global [1024 x float]
@direct_acc0_1_1 = external global [1024 x float]
@direct_dequant_1_0 = external global [4096 x bfloat]
@direct_acc1_1_0 = external global [1024 x float]
@direct_acc0_1_0 = external global [1024 x float]
@direct_dequant_0_3 = external global [4096 x bfloat]
@direct_acc1_0_3 = external global [1024 x float]
@direct_acc0_0_3 = external global [1024 x float]
@direct_dequant_0_2 = external global [4096 x bfloat]
@direct_acc1_0_2 = external global [1024 x float]
@direct_acc0_0_2 = external global [1024 x float]
@direct_dequant_0_1 = external global [4096 x bfloat]
@direct_acc1_0_1 = external global [1024 x float]
@direct_acc0_0_1 = external global [1024 x float]
@direct_dequant_0_0 = external global [4096 x bfloat]
@direct_acc1_0_0 = external global [1024 x float]
@direct_acc0_0_0 = external global [1024 x float]
@direct_a_broadcast_0_7_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_6_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_5_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_4_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_3_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_0_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_host_0_cons_buff_1 = external global [4096 x bfloat]
@direct_a_host_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_7_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_6_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_5_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_4_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_3_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_1_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_host_1_cons_buff_1 = external global [4096 x bfloat]
@direct_a_host_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_7_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_6_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_5_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_4_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_3_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_2_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_host_2_cons_buff_1 = external global [4096 x bfloat]
@direct_a_host_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_7_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_6_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_5_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_4_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_3_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_2_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_1_cons_buff_0 = external global [4096 x bfloat]
@direct_a_broadcast_3_0_cons_buff_0 = external global [4096 x bfloat]
@direct_a_host_3_cons_buff_1 = external global [4096 x bfloat]
@direct_a_host_3_cons_buff_0 = external global [4096 x bfloat]
@direct_y_host_0_buff_1 = external global [4096 x bfloat]
@direct_y_host_0_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_0_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_0_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_1_buff_1 = external global [4096 x bfloat]
@direct_y_host_1_buff_0 = external global [4096 x bfloat]
@direct_y_host_2_buff_1 = external global [4096 x bfloat]
@direct_y_host_2_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_1_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_1_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_1_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_3_buff_1 = external global [4096 x bfloat]
@direct_y_host_3_buff_0 = external global [4096 x bfloat]
@direct_y_host_4_buff_1 = external global [4096 x bfloat]
@direct_y_host_4_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_2_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_2_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_2_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_5_buff_1 = external global [4096 x bfloat]
@direct_y_host_5_buff_0 = external global [4096 x bfloat]
@direct_y_host_6_buff_1 = external global [4096 x bfloat]
@direct_y_host_6_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_3_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_3_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_0_cons_buff_0 = external global [4352 x i8]
@direct_y_host_7_buff_1 = external global [4096 x bfloat]
@direct_y_host_7_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_4_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_4_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_4_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_0_cons_buff_1 = external global [4352 x i8]
@direct_w_host_0_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_5_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_1_cons_buff_1 = external global [4352 x i8]
@direct_w_host_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_6_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_6_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_2_cons_buff_1 = external global [4352 x i8]
@direct_w_host_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_3_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_2_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_2_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_1_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_1_cons_buff_0 = external global [4352 x i8]
@direct_w_broadcast_7_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_7_0_cons_buff_0 = external global [4352 x i8]
@direct_w_host_3_cons_buff_1 = external global [4352 x i8]
@direct_w_host_3_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_0_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_0_0_buff_0 = external global [1024 x bfloat]
@direct_w_host_4_cons_buff_1 = external global [4352 x i8]
@direct_w_host_4_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_0_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_0_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_0_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_0_2_buff_0 = external global [1024 x bfloat]
@direct_w_host_5_cons_buff_1 = external global [4352 x i8]
@direct_w_host_5_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_0_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_0_3_buff_0 = external global [1024 x bfloat]
@direct_w_host_6_cons_buff_1 = external global [4352 x i8]
@direct_w_host_6_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_1_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_1_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_1_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_1_1_buff_0 = external global [1024 x bfloat]
@direct_w_host_7_cons_buff_1 = external global [4352 x i8]
@direct_w_host_7_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_1_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_1_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_1_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_1_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_2_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_2_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_2_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_2_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_2_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_2_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_2_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_2_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_3_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_3_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_3_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_3_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_3_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_3_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_3_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_3_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_4_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_4_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_4_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_4_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_4_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_4_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_4_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_4_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_5_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_5_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_5_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_5_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_6_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_6_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_6_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_6_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_6_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_6_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_6_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_6_3_buff_0 = external global [1024 x bfloat]
@direct_y_worker_7_0_buff_1 = external global [1024 x bfloat]
@direct_y_worker_7_0_buff_0 = external global [1024 x bfloat]
@direct_y_worker_7_1_buff_1 = external global [1024 x bfloat]
@direct_y_worker_7_1_buff_0 = external global [1024 x bfloat]
@direct_y_worker_7_2_buff_1 = external global [1024 x bfloat]
@direct_y_worker_7_2_buff_0 = external global [1024 x bfloat]
@direct_y_worker_7_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_7_3_buff_0 = external global [1024 x bfloat]

declare void @debug_i32(i32)

; Unknown intrinsic
declare void @llvm.aie2p.event(i32)

; Unknown intrinsic
declare void @llvm.aie2p.put.ms(i32, i32)

; Unknown intrinsic
declare { i32, i32 } @llvm.aie2p.get.ss()

; Unknown intrinsic
declare void @llvm.aie2p.mcd.write.vec(<16 x i32>, i32)

; Unknown intrinsic
declare <16 x i32> @llvm.aie2p.scd.read.vec(i32)

; Unknown intrinsic
declare void @llvm.aie2p.acquire(i32, i32)

; Unknown intrinsic
declare void @llvm.aie2p.release(i32, i32)

; Unknown intrinsic
declare void @llvm.aie2p.set.ctrl.reg(i32, i32)

declare void @w4a16_prefill_reuse_init(ptr)

declare void @w4a16_prefill_reuse_accumulate_low(ptr, ptr, ptr, ptr)

declare void @w4a16_prefill_reuse_accumulate_high(ptr, ptr, ptr, ptr)

declare void @w4a16_prefill_reuse_finish(ptr, ptr)

define void @core_7_3() {
  br label %1

1:                                                ; preds = %26, %0
  %2 = phi i64 [ %30, %26 ], [ 0, %0 ]
  %3 = phi i32 [ %9, %26 ], [ 0, %0 ]
  %4 = phi i32 [ %29, %26 ], [ 0, %0 ]
  %5 = icmp slt i64 %2, 9223372036854775807
  br i1 %5, label %6, label %31

6:                                                ; preds = %1
  call void @w4a16_prefill_reuse_init(ptr @direct_acc0_7_1)
  br label %7

7:                                                ; preds = %16, %6
  %8 = phi i64 [ %20, %16 ], [ 0, %6 ]
  %9 = phi i32 [ %19, %16 ], [ %3, %6 ]
  %10 = icmp slt i64 %8, 4
  br i1 %10, label %11, label %21

11:                                               ; preds = %7
  call void @llvm.aie2p.acquire(i32 53, i32 -1)
  call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %12 = sext i32 %9 to i64
  switch i64 %12, label %13 [
    i64 0, label %32
    i64 1, label %34
  ]

13:                                               ; preds = %32, %34, %11
  %14 = phi ptr [ %35, %34 ], [ %33, %32 ], [ @direct_w_broadcast_7_1_cons_buff_0, %11 ]
  %15 = getelementptr [4352 x i8], ptr %14, i32 0, i32 0
  br label %16

16:                                               ; preds = %13
  call void @w4a16_prefill_reuse_accumulate_high(ptr @direct_a_broadcast_1_7_cons_buff_0, ptr %15, ptr @direct_acc0_7_1, ptr @direct_dequant_7_1)
  call void @llvm.aie2p.release(i32 52, i32 1)
  call void @llvm.aie2p.release(i32 50, i32 1)
  %17 = add i32 %9, 1
  %18 = icmp sge i32 %17, 2
  %19 = select i1 %18, i32 0, i32 %17
  %20 = add i64 %8, 1
  br label %7

21:                                               ; preds = %7
  call void @llvm.aie2p.acquire(i32 48, i32 -1)
  %22 = sext i32 %4 to i64
  switch i64 %22, label %23 [
    i64 0, label %36
    i64 1, label %38
  ]

23:                                               ; preds = %36, %38, %21
  %24 = phi ptr [ %39, %38 ], [ %37, %36 ], [ @direct_y_worker_7_1_buff_0, %21 ]
  %25 = getelementptr [1024 x bfloat], ptr %24, i32 0, i32 0
  br label %26

26:                                               ; preds = %23
  call void @w4a16_prefill_reuse_finish(ptr @direct_acc0_7_1, ptr %25)
  call void @llvm.aie2p.release(i32 49, i32 1)
  %27 = add i32 %4, 1
  %28 = icmp sge i32 %27, 2
  %29 = select i1 %28, i32 0, i32 %27
  %30 = add i64 %2, 1
  br label %1

31:                                               ; preds = %1
  ret void

32:                                               ; preds = %11
  %33 = phi ptr [ @direct_w_broadcast_7_1_cons_buff_0, %11 ]
  br label %13

34:                                               ; preds = %11
  %35 = phi ptr [ @direct_w_broadcast_7_1_cons_buff_1, %11 ]
  br label %13

36:                                               ; preds = %21
  %37 = phi ptr [ @direct_y_worker_7_1_buff_0, %21 ]
  br label %23

38:                                               ; preds = %21
  %39 = phi ptr [ @direct_y_worker_7_1_buff_1, %21 ]
  br label %23
}

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
