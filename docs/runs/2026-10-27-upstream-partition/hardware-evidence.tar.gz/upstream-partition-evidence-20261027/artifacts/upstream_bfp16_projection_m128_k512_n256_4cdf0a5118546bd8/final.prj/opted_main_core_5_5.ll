; ModuleID = '/notebooks/HeteroMega-upstream-partition-20261027/artifacts/upstream_bfp16_projection_m128_k512_n256_4cdf0a5118546bd8/final.prj/peano-linked_main_core_5_5.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:20:32-i1:8:32-i8:8:32-i16:16:32-i32:32:32-f32:32:32-i64:32-f64:32-a:0:32-n32"
target triple = "aie2p"

@direct_dequant_5_3 = external global [4096 x bfloat]
@direct_acc0_5_3 = external global [1024 x float]
@direct_a_broadcast_3_5_cons_buff_0 = external global [4096 x bfloat]
@direct_w_broadcast_5_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_5_3_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_5_3_buff_1 = external global [1024 x bfloat]
@direct_y_worker_5_3_buff_0 = external global [1024 x bfloat]

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.acquire(i32, i32) #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.release(i32, i32) #0

declare void @w4a16_prefill_reuse_init(ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_high(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_finish(ptr, ptr) local_unnamed_addr

define void @core_5_5() local_unnamed_addr {
  br label %1

1:                                                ; preds = %0, %1
  %2 = phi i32 [ 0, %0 ], [ %6, %1 ]
  %3 = phi i64 [ 0, %0 ], [ %7, %1 ]
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_5_3)
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_5_cons_buff_0, ptr nonnull @direct_w_broadcast_5_3_cons_buff_0, ptr nonnull @direct_acc0_5_3, ptr nonnull @direct_dequant_5_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_5_cons_buff_0, ptr nonnull @direct_w_broadcast_5_3_cons_buff_1, ptr nonnull @direct_acc0_5_3, ptr nonnull @direct_dequant_5_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_5_cons_buff_0, ptr nonnull @direct_w_broadcast_5_3_cons_buff_0, ptr nonnull @direct_acc0_5_3, ptr nonnull @direct_dequant_5_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_5_cons_buff_0, ptr nonnull @direct_w_broadcast_5_3_cons_buff_1, ptr nonnull @direct_acc0_5_3, ptr nonnull @direct_dequant_5_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  %cond1 = icmp eq i32 %2, 1
  %spec.select3 = select i1 %cond1, ptr @direct_y_worker_5_3_buff_1, ptr @direct_y_worker_5_3_buff_0
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_5_3, ptr nonnull %spec.select3)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  %4 = add i32 %2, 1
  %5 = icmp sgt i32 %4, 1
  %6 = select i1 %5, i32 0, i32 %4
  %7 = add nuw nsw i64 %3, 1
  %.not = icmp eq i64 %7, 9223372036854775807
  br i1 %.not, label %8, label %1

8:                                                ; preds = %1
  ret void
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
