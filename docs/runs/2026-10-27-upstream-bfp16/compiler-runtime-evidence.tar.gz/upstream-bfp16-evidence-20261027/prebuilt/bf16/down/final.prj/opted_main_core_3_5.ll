; ModuleID = '/notebooks/HeteroMega-upstream-bfp16-20261027/artifacts/upstream_bf16_projection_m512_k2560_n4096_f34cdf629757364f/final.prj/peano-linked_main_core_3_5.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:20:32-i1:8:32-i8:8:32-i16:16:32-i32:32:32-f32:32:32-i64:32-f64:32-a:0:32-n32"
target triple = "aie2p"

@direct_dequant_3_3 = external global [4096 x bfloat]
@direct_acc1_3_3 = external global [2048 x float]
@direct_acc0_3_3 = external global [2048 x float]
@direct_a_broadcast_3_3_cons_buff_0 = external global [8192 x bfloat]
@direct_w_broadcast_3_3_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_3_3_cons_buff_0 = external global [4352 x i8]
@direct_y_worker_3_3_buff_1 = external global [2048 x bfloat]
@direct_y_worker_3_3_buff_0 = external global [2048 x bfloat]

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.acquire(i32, i32) #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.release(i32, i32) #0

declare void @w4a16_prefill_reuse_init(ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_low(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_high(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_finish(ptr, ptr) local_unnamed_addr

define void @core_3_5() local_unnamed_addr {
  br label %.preheader

.preheader:                                       ; preds = %0, %160
  %1 = phi i32 [ 0, %0 ], [ %154, %160 ]
  %2 = phi i64 [ 0, %0 ], [ %161, %160 ]
  br label %3

3:                                                ; preds = %.preheader, %157
  %4 = phi i32 [ %1, %.preheader ], [ %154, %157 ]
  %5 = phi i64 [ 0, %.preheader ], [ %158, %157 ]
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %6

6:                                                ; preds = %6, %3
  %7 = phi i32 [ %4, %3 ], [ %21, %6 ]
  %8 = phi i64 [ 0, %3 ], [ %22, %6 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond = icmp eq i32 %7, 1
  %spec.select = select i1 %cond, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %9 = add i32 %7, 1
  %10 = icmp sgt i32 %9, 1
  %11 = select i1 %10, i32 0, i32 %9
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond.1 = icmp eq i32 %11, 1
  %spec.select.1 = select i1 %cond.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %12 = add i32 %11, 1
  %13 = icmp sgt i32 %12, 1
  %14 = select i1 %13, i32 0, i32 %12
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond.2 = icmp eq i32 %14, 1
  %spec.select.2 = select i1 %cond.2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select.2, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select.2, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %15 = add i32 %14, 1
  %16 = icmp sgt i32 %15, 1
  %17 = select i1 %16, i32 0, i32 %15
  %18 = or disjoint i64 %8, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond.3 = icmp eq i32 %17, 1
  %spec.select.3 = select i1 %cond.3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select.3, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select.3, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %19 = add i32 %17, 1
  %20 = icmp sgt i32 %19, 1
  %21 = select i1 %20, i32 0, i32 %19
  %22 = add nuw nsw i64 %8, 4
  %23 = icmp samesign ult i64 %18, 19
  br i1 %23, label %6, label %24

24:                                               ; preds = %6
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %25

25:                                               ; preds = %25, %24
  %26 = phi i32 [ %21, %24 ], [ %40, %25 ]
  %27 = phi i64 [ 0, %24 ], [ %41, %25 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1 = icmp eq i32 %26, 1
  %spec.select16 = select i1 %cond1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %28 = add i32 %26, 1
  %29 = icmp sgt i32 %28, 1
  %30 = select i1 %29, i32 0, i32 %28
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1.1 = icmp eq i32 %30, 1
  %spec.select16.1 = select i1 %cond1.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %31 = add i32 %30, 1
  %32 = icmp sgt i32 %31, 1
  %33 = select i1 %32, i32 0, i32 %31
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1.2 = icmp eq i32 %33, 1
  %spec.select16.2 = select i1 %cond1.2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16.2, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16.2, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %34 = add i32 %33, 1
  %35 = icmp sgt i32 %34, 1
  %36 = select i1 %35, i32 0, i32 %34
  %37 = or disjoint i64 %27, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond1.3 = icmp eq i32 %36, 1
  %spec.select16.3 = select i1 %cond1.3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16.3, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select16.3, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %38 = add i32 %36, 1
  %39 = icmp sgt i32 %38, 1
  %40 = select i1 %39, i32 0, i32 %38
  %41 = add nuw nsw i64 %27, 4
  %42 = icmp samesign ult i64 %37, 19
  br i1 %42, label %25, label %43

43:                                               ; preds = %25
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %44

44:                                               ; preds = %44, %43
  %45 = phi i32 [ %40, %43 ], [ %59, %44 ]
  %46 = phi i64 [ 0, %43 ], [ %60, %44 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2 = icmp eq i32 %45, 1
  %spec.select17 = select i1 %cond2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %47 = add i32 %45, 1
  %48 = icmp sgt i32 %47, 1
  %49 = select i1 %48, i32 0, i32 %47
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2.1 = icmp eq i32 %49, 1
  %spec.select17.1 = select i1 %cond2.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %50 = add i32 %49, 1
  %51 = icmp sgt i32 %50, 1
  %52 = select i1 %51, i32 0, i32 %50
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2.2 = icmp eq i32 %52, 1
  %spec.select17.2 = select i1 %cond2.2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17.2, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17.2, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %53 = add i32 %52, 1
  %54 = icmp sgt i32 %53, 1
  %55 = select i1 %54, i32 0, i32 %53
  %56 = or disjoint i64 %46, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond2.3 = icmp eq i32 %55, 1
  %spec.select17.3 = select i1 %cond2.3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17.3, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select17.3, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %57 = add i32 %55, 1
  %58 = icmp sgt i32 %57, 1
  %59 = select i1 %58, i32 0, i32 %57
  %60 = add nuw nsw i64 %46, 4
  %61 = icmp samesign ult i64 %56, 19
  br i1 %61, label %44, label %62

62:                                               ; preds = %44
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %63

63:                                               ; preds = %63, %62
  %64 = phi i32 [ %59, %62 ], [ %78, %63 ]
  %65 = phi i64 [ 0, %62 ], [ %79, %63 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3 = icmp eq i32 %64, 1
  %spec.select18 = select i1 %cond3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %66 = add i32 %64, 1
  %67 = icmp sgt i32 %66, 1
  %68 = select i1 %67, i32 0, i32 %66
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3.1 = icmp eq i32 %68, 1
  %spec.select18.1 = select i1 %cond3.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %69 = add i32 %68, 1
  %70 = icmp sgt i32 %69, 1
  %71 = select i1 %70, i32 0, i32 %69
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3.2 = icmp eq i32 %71, 1
  %spec.select18.2 = select i1 %cond3.2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18.2, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18.2, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %72 = add i32 %71, 1
  %73 = icmp sgt i32 %72, 1
  %74 = select i1 %73, i32 0, i32 %72
  %75 = or disjoint i64 %65, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond3.3 = icmp eq i32 %74, 1
  %spec.select18.3 = select i1 %cond3.3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18.3, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select18.3, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %76 = add i32 %74, 1
  %77 = icmp sgt i32 %76, 1
  %78 = select i1 %77, i32 0, i32 %76
  %79 = add nuw nsw i64 %65, 4
  %80 = icmp samesign ult i64 %75, 19
  br i1 %80, label %63, label %81

81:                                               ; preds = %63
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %82

82:                                               ; preds = %82, %81
  %83 = phi i32 [ %78, %81 ], [ %97, %82 ]
  %84 = phi i64 [ 0, %81 ], [ %98, %82 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4 = icmp eq i32 %83, 1
  %spec.select19 = select i1 %cond4, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %85 = add i32 %83, 1
  %86 = icmp sgt i32 %85, 1
  %87 = select i1 %86, i32 0, i32 %85
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4.1 = icmp eq i32 %87, 1
  %spec.select19.1 = select i1 %cond4.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %88 = add i32 %87, 1
  %89 = icmp sgt i32 %88, 1
  %90 = select i1 %89, i32 0, i32 %88
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4.2 = icmp eq i32 %90, 1
  %spec.select19.2 = select i1 %cond4.2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19.2, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19.2, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %91 = add i32 %90, 1
  %92 = icmp sgt i32 %91, 1
  %93 = select i1 %92, i32 0, i32 %91
  %94 = or disjoint i64 %84, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond4.3 = icmp eq i32 %93, 1
  %spec.select19.3 = select i1 %cond4.3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19.3, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select19.3, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %95 = add i32 %93, 1
  %96 = icmp sgt i32 %95, 1
  %97 = select i1 %96, i32 0, i32 %95
  %98 = add nuw nsw i64 %84, 4
  %99 = icmp samesign ult i64 %94, 19
  br i1 %99, label %82, label %100

100:                                              ; preds = %82
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %101

101:                                              ; preds = %101, %100
  %102 = phi i32 [ %97, %100 ], [ %116, %101 ]
  %103 = phi i64 [ 0, %100 ], [ %117, %101 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5 = icmp eq i32 %102, 1
  %spec.select20 = select i1 %cond5, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %104 = add i32 %102, 1
  %105 = icmp sgt i32 %104, 1
  %106 = select i1 %105, i32 0, i32 %104
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5.1 = icmp eq i32 %106, 1
  %spec.select20.1 = select i1 %cond5.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %107 = add i32 %106, 1
  %108 = icmp sgt i32 %107, 1
  %109 = select i1 %108, i32 0, i32 %107
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5.2 = icmp eq i32 %109, 1
  %spec.select20.2 = select i1 %cond5.2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20.2, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20.2, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %110 = add i32 %109, 1
  %111 = icmp sgt i32 %110, 1
  %112 = select i1 %111, i32 0, i32 %110
  %113 = or disjoint i64 %103, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond5.3 = icmp eq i32 %112, 1
  %spec.select20.3 = select i1 %cond5.3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20.3, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select20.3, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %114 = add i32 %112, 1
  %115 = icmp sgt i32 %114, 1
  %116 = select i1 %115, i32 0, i32 %114
  %117 = add nuw nsw i64 %103, 4
  %118 = icmp samesign ult i64 %113, 19
  br i1 %118, label %101, label %119

119:                                              ; preds = %101
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %120

120:                                              ; preds = %120, %119
  %121 = phi i32 [ %116, %119 ], [ %135, %120 ]
  %122 = phi i64 [ 0, %119 ], [ %136, %120 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6 = icmp eq i32 %121, 1
  %spec.select21 = select i1 %cond6, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %123 = add i32 %121, 1
  %124 = icmp sgt i32 %123, 1
  %125 = select i1 %124, i32 0, i32 %123
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6.1 = icmp eq i32 %125, 1
  %spec.select21.1 = select i1 %cond6.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %126 = add i32 %125, 1
  %127 = icmp sgt i32 %126, 1
  %128 = select i1 %127, i32 0, i32 %126
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6.2 = icmp eq i32 %128, 1
  %spec.select21.2 = select i1 %cond6.2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21.2, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21.2, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %129 = add i32 %128, 1
  %130 = icmp sgt i32 %129, 1
  %131 = select i1 %130, i32 0, i32 %129
  %132 = or disjoint i64 %122, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond6.3 = icmp eq i32 %131, 1
  %spec.select21.3 = select i1 %cond6.3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21.3, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select21.3, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %133 = add i32 %131, 1
  %134 = icmp sgt i32 %133, 1
  %135 = select i1 %134, i32 0, i32 %133
  %136 = add nuw nsw i64 %122, 4
  %137 = icmp samesign ult i64 %132, 19
  br i1 %137, label %120, label %138

138:                                              ; preds = %120
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_3_3)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_3_3)
  br label %139

139:                                              ; preds = %139, %138
  %140 = phi i32 [ %135, %138 ], [ %154, %139 ]
  %141 = phi i64 [ 0, %138 ], [ %155, %139 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7 = icmp eq i32 %140, 1
  %spec.select22 = select i1 %cond7, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %142 = add i32 %140, 1
  %143 = icmp sgt i32 %142, 1
  %144 = select i1 %143, i32 0, i32 %142
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7.1 = icmp eq i32 %144, 1
  %spec.select22.1 = select i1 %cond7.1, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22.1, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22.1, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %145 = add i32 %144, 1
  %146 = icmp sgt i32 %145, 1
  %147 = select i1 %146, i32 0, i32 %145
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7.2 = icmp eq i32 %147, 1
  %spec.select22.2 = select i1 %cond7.2, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22.2, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22.2, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %148 = add i32 %147, 1
  %149 = icmp sgt i32 %148, 1
  %150 = select i1 %149, i32 0, i32 %148
  %151 = or disjoint i64 %141, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  tail call void @llvm.aie2p.acquire(i32 51, i32 -1)
  %cond7.3 = icmp eq i32 %150, 1
  %spec.select22.3 = select i1 %cond7.3, ptr @direct_w_broadcast_3_3_cons_buff_1, ptr @direct_w_broadcast_3_3_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22.3, ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull @direct_a_broadcast_3_3_cons_buff_0, ptr nonnull %spec.select22.3, ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_dequant_3_3)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  tail call void @llvm.aie2p.release(i32 50, i32 1)
  %152 = add i32 %150, 1
  %153 = icmp sgt i32 %152, 1
  %154 = select i1 %153, i32 0, i32 %152
  %155 = add nuw nsw i64 %141, 4
  %156 = icmp samesign ult i64 %151, 19
  br i1 %156, label %139, label %157

157:                                              ; preds = %139
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_3_3, ptr nonnull @direct_y_worker_3_3_buff_0)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  tail call void @llvm.aie2p.acquire(i32 48, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_3_3, ptr nonnull @direct_y_worker_3_3_buff_1)
  tail call void @llvm.aie2p.release(i32 49, i32 1)
  %158 = add nuw nsw i64 %5, 1
  %159 = icmp eq i64 %5, 0
  br i1 %159, label %3, label %160

160:                                              ; preds = %157
  %161 = add nuw nsw i64 %2, 1
  %.not = icmp eq i64 %161, 9223372036854775807
  br i1 %.not, label %162, label %.preheader

162:                                              ; preds = %160
  ret void
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
