; ModuleID = '/notebooks/HeteroMega-upstream-bfp16-20261027/artifacts/upstream_bf16_swiglu_m512_k4096_n2560_42f1cd988c4d9a63/final.prj/peano-linked_main_core_0_2.ll'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:20:32-i1:8:32-i8:8:32-i16:16:32-i32:32:32-f32:32:32-i64:32-f64:32-a:0:32-n32"
target triple = "aie2p"

@direct_dequant_0_0 = external global [4096 x bfloat]
@direct_acc1_0_0 = external global [1024 x float]
@direct_acc0_0_0 = external global [1024 x float]
@direct_a_broadcast_0_0_cons_buff_1 = external global [4096 x bfloat]
@direct_a_broadcast_0_0_cons_buff_0 = external global [4096 x bfloat]
@direct_gate_0_0_buff_1 = external global [1024 x bfloat]
@direct_gate_0_0_buff_0 = external global [1024 x bfloat]
@direct_w_broadcast_0_0_cons_buff_1 = external global [4352 x i8]
@direct_w_broadcast_0_0_cons_buff_0 = external global [4352 x i8]

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.acquire(i32, i32) #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare void @llvm.aie2p.release(i32, i32) #0

declare void @w4a16_prefill_reuse_init(ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_low(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_accumulate_high(ptr, ptr, ptr, ptr) local_unnamed_addr

declare void @w4a16_prefill_reuse_finish(ptr, ptr) local_unnamed_addr

define void @core_0_2() local_unnamed_addr {
  br label %.preheader

.preheader:                                       ; preds = %0, %370
  %1 = phi i32 [ 0, %0 ], [ %364, %370 ]
  %2 = phi i32 [ 0, %0 ], [ %361, %370 ]
  %3 = phi i64 [ 0, %0 ], [ %371, %370 ]
  br label %4

4:                                                ; preds = %.preheader, %367
  %5 = phi i32 [ %1, %.preheader ], [ %364, %367 ]
  %6 = phi i32 [ %2, %.preheader ], [ %361, %367 ]
  %7 = phi i64 [ 0, %.preheader ], [ %368, %367 ]
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %8

8:                                                ; preds = %8, %4
  %9 = phi i32 [ %5, %4 ], [ %40, %8 ]
  %10 = phi i32 [ %6, %4 ], [ %37, %8 ]
  %11 = phi i64 [ 0, %4 ], [ %41, %8 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond = icmp eq i32 %10, 1
  %spec.select = select i1 %cond, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond1 = icmp eq i32 %9, 1
  %12 = select i1 %cond1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select, ptr nonnull %12, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select, ptr nonnull %12, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %13 = add i32 %10, 1
  %14 = icmp sgt i32 %13, 1
  %15 = select i1 %14, i32 0, i32 %13
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %16 = add i32 %9, 1
  %17 = icmp sgt i32 %16, 1
  %18 = select i1 %17, i32 0, i32 %16
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond.1 = icmp eq i32 %15, 1
  %spec.select.1 = select i1 %cond.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond1.1 = icmp eq i32 %18, 1
  %19 = select i1 %cond1.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select.1, ptr nonnull %19, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select.1, ptr nonnull %19, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %20 = add i32 %15, 1
  %21 = icmp sgt i32 %20, 1
  %22 = select i1 %21, i32 0, i32 %20
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %23 = add i32 %18, 1
  %24 = icmp sgt i32 %23, 1
  %25 = select i1 %24, i32 0, i32 %23
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond.2 = icmp eq i32 %22, 1
  %spec.select.2 = select i1 %cond.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond1.2 = icmp eq i32 %25, 1
  %26 = select i1 %cond1.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select.2, ptr nonnull %26, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select.2, ptr nonnull %26, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %27 = add i32 %22, 1
  %28 = icmp sgt i32 %27, 1
  %29 = select i1 %28, i32 0, i32 %27
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %30 = add i32 %25, 1
  %31 = icmp sgt i32 %30, 1
  %32 = select i1 %31, i32 0, i32 %30
  %33 = or disjoint i64 %11, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond.3 = icmp eq i32 %29, 1
  %spec.select.3 = select i1 %cond.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond1.3 = icmp eq i32 %32, 1
  %34 = select i1 %cond1.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select.3, ptr nonnull %34, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select.3, ptr nonnull %34, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %35 = add i32 %29, 1
  %36 = icmp sgt i32 %35, 1
  %37 = select i1 %36, i32 0, i32 %35
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %38 = add i32 %32, 1
  %39 = icmp sgt i32 %38, 1
  %40 = select i1 %39, i32 0, i32 %38
  %41 = add nuw nsw i64 %11, 4
  %42 = icmp samesign ult i64 %33, 31
  br i1 %42, label %8, label %43

43:                                               ; preds = %8
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %44

44:                                               ; preds = %44, %43
  %45 = phi i32 [ %40, %43 ], [ %76, %44 ]
  %46 = phi i32 [ %37, %43 ], [ %73, %44 ]
  %47 = phi i64 [ 0, %43 ], [ %77, %44 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond2 = icmp eq i32 %46, 1
  %spec.select30 = select i1 %cond2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond3 = icmp eq i32 %45, 1
  %48 = select i1 %cond3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select30, ptr nonnull %48, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select30, ptr nonnull %48, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %49 = add i32 %46, 1
  %50 = icmp sgt i32 %49, 1
  %51 = select i1 %50, i32 0, i32 %49
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %52 = add i32 %45, 1
  %53 = icmp sgt i32 %52, 1
  %54 = select i1 %53, i32 0, i32 %52
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond2.1 = icmp eq i32 %51, 1
  %spec.select30.1 = select i1 %cond2.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond3.1 = icmp eq i32 %54, 1
  %55 = select i1 %cond3.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select30.1, ptr nonnull %55, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select30.1, ptr nonnull %55, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %56 = add i32 %51, 1
  %57 = icmp sgt i32 %56, 1
  %58 = select i1 %57, i32 0, i32 %56
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %59 = add i32 %54, 1
  %60 = icmp sgt i32 %59, 1
  %61 = select i1 %60, i32 0, i32 %59
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond2.2 = icmp eq i32 %58, 1
  %spec.select30.2 = select i1 %cond2.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond3.2 = icmp eq i32 %61, 1
  %62 = select i1 %cond3.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select30.2, ptr nonnull %62, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select30.2, ptr nonnull %62, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %63 = add i32 %58, 1
  %64 = icmp sgt i32 %63, 1
  %65 = select i1 %64, i32 0, i32 %63
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %66 = add i32 %61, 1
  %67 = icmp sgt i32 %66, 1
  %68 = select i1 %67, i32 0, i32 %66
  %69 = or disjoint i64 %47, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond2.3 = icmp eq i32 %65, 1
  %spec.select30.3 = select i1 %cond2.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond3.3 = icmp eq i32 %68, 1
  %70 = select i1 %cond3.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select30.3, ptr nonnull %70, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select30.3, ptr nonnull %70, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %71 = add i32 %65, 1
  %72 = icmp sgt i32 %71, 1
  %73 = select i1 %72, i32 0, i32 %71
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %74 = add i32 %68, 1
  %75 = icmp sgt i32 %74, 1
  %76 = select i1 %75, i32 0, i32 %74
  %77 = add nuw nsw i64 %47, 4
  %78 = icmp samesign ult i64 %69, 31
  br i1 %78, label %44, label %79

79:                                               ; preds = %44
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %80

80:                                               ; preds = %80, %79
  %81 = phi i32 [ %76, %79 ], [ %112, %80 ]
  %82 = phi i32 [ %73, %79 ], [ %109, %80 ]
  %83 = phi i64 [ 0, %79 ], [ %113, %80 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond4 = icmp eq i32 %82, 1
  %spec.select31 = select i1 %cond4, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond5 = icmp eq i32 %81, 1
  %84 = select i1 %cond5, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select31, ptr nonnull %84, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select31, ptr nonnull %84, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %85 = add i32 %82, 1
  %86 = icmp sgt i32 %85, 1
  %87 = select i1 %86, i32 0, i32 %85
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %88 = add i32 %81, 1
  %89 = icmp sgt i32 %88, 1
  %90 = select i1 %89, i32 0, i32 %88
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond4.1 = icmp eq i32 %87, 1
  %spec.select31.1 = select i1 %cond4.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond5.1 = icmp eq i32 %90, 1
  %91 = select i1 %cond5.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select31.1, ptr nonnull %91, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select31.1, ptr nonnull %91, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %92 = add i32 %87, 1
  %93 = icmp sgt i32 %92, 1
  %94 = select i1 %93, i32 0, i32 %92
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %95 = add i32 %90, 1
  %96 = icmp sgt i32 %95, 1
  %97 = select i1 %96, i32 0, i32 %95
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond4.2 = icmp eq i32 %94, 1
  %spec.select31.2 = select i1 %cond4.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond5.2 = icmp eq i32 %97, 1
  %98 = select i1 %cond5.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select31.2, ptr nonnull %98, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select31.2, ptr nonnull %98, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %99 = add i32 %94, 1
  %100 = icmp sgt i32 %99, 1
  %101 = select i1 %100, i32 0, i32 %99
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %102 = add i32 %97, 1
  %103 = icmp sgt i32 %102, 1
  %104 = select i1 %103, i32 0, i32 %102
  %105 = or disjoint i64 %83, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond4.3 = icmp eq i32 %101, 1
  %spec.select31.3 = select i1 %cond4.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond5.3 = icmp eq i32 %104, 1
  %106 = select i1 %cond5.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select31.3, ptr nonnull %106, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select31.3, ptr nonnull %106, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %107 = add i32 %101, 1
  %108 = icmp sgt i32 %107, 1
  %109 = select i1 %108, i32 0, i32 %107
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %110 = add i32 %104, 1
  %111 = icmp sgt i32 %110, 1
  %112 = select i1 %111, i32 0, i32 %110
  %113 = add nuw nsw i64 %83, 4
  %114 = icmp samesign ult i64 %105, 31
  br i1 %114, label %80, label %115

115:                                              ; preds = %80
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %116

116:                                              ; preds = %116, %115
  %117 = phi i32 [ %112, %115 ], [ %148, %116 ]
  %118 = phi i32 [ %109, %115 ], [ %145, %116 ]
  %119 = phi i64 [ 0, %115 ], [ %149, %116 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond6 = icmp eq i32 %118, 1
  %spec.select32 = select i1 %cond6, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond7 = icmp eq i32 %117, 1
  %120 = select i1 %cond7, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select32, ptr nonnull %120, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select32, ptr nonnull %120, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %121 = add i32 %118, 1
  %122 = icmp sgt i32 %121, 1
  %123 = select i1 %122, i32 0, i32 %121
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %124 = add i32 %117, 1
  %125 = icmp sgt i32 %124, 1
  %126 = select i1 %125, i32 0, i32 %124
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond6.1 = icmp eq i32 %123, 1
  %spec.select32.1 = select i1 %cond6.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond7.1 = icmp eq i32 %126, 1
  %127 = select i1 %cond7.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select32.1, ptr nonnull %127, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select32.1, ptr nonnull %127, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %128 = add i32 %123, 1
  %129 = icmp sgt i32 %128, 1
  %130 = select i1 %129, i32 0, i32 %128
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %131 = add i32 %126, 1
  %132 = icmp sgt i32 %131, 1
  %133 = select i1 %132, i32 0, i32 %131
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond6.2 = icmp eq i32 %130, 1
  %spec.select32.2 = select i1 %cond6.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond7.2 = icmp eq i32 %133, 1
  %134 = select i1 %cond7.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select32.2, ptr nonnull %134, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select32.2, ptr nonnull %134, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %135 = add i32 %130, 1
  %136 = icmp sgt i32 %135, 1
  %137 = select i1 %136, i32 0, i32 %135
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %138 = add i32 %133, 1
  %139 = icmp sgt i32 %138, 1
  %140 = select i1 %139, i32 0, i32 %138
  %141 = or disjoint i64 %119, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond6.3 = icmp eq i32 %137, 1
  %spec.select32.3 = select i1 %cond6.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond7.3 = icmp eq i32 %140, 1
  %142 = select i1 %cond7.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select32.3, ptr nonnull %142, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select32.3, ptr nonnull %142, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %143 = add i32 %137, 1
  %144 = icmp sgt i32 %143, 1
  %145 = select i1 %144, i32 0, i32 %143
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %146 = add i32 %140, 1
  %147 = icmp sgt i32 %146, 1
  %148 = select i1 %147, i32 0, i32 %146
  %149 = add nuw nsw i64 %119, 4
  %150 = icmp samesign ult i64 %141, 31
  br i1 %150, label %116, label %151

151:                                              ; preds = %116
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %152

152:                                              ; preds = %152, %151
  %153 = phi i32 [ %148, %151 ], [ %184, %152 ]
  %154 = phi i32 [ %145, %151 ], [ %181, %152 ]
  %155 = phi i64 [ 0, %151 ], [ %185, %152 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond8 = icmp eq i32 %154, 1
  %spec.select33 = select i1 %cond8, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond9 = icmp eq i32 %153, 1
  %156 = select i1 %cond9, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select33, ptr nonnull %156, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select33, ptr nonnull %156, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %157 = add i32 %154, 1
  %158 = icmp sgt i32 %157, 1
  %159 = select i1 %158, i32 0, i32 %157
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %160 = add i32 %153, 1
  %161 = icmp sgt i32 %160, 1
  %162 = select i1 %161, i32 0, i32 %160
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond8.1 = icmp eq i32 %159, 1
  %spec.select33.1 = select i1 %cond8.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond9.1 = icmp eq i32 %162, 1
  %163 = select i1 %cond9.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select33.1, ptr nonnull %163, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select33.1, ptr nonnull %163, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %164 = add i32 %159, 1
  %165 = icmp sgt i32 %164, 1
  %166 = select i1 %165, i32 0, i32 %164
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %167 = add i32 %162, 1
  %168 = icmp sgt i32 %167, 1
  %169 = select i1 %168, i32 0, i32 %167
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond8.2 = icmp eq i32 %166, 1
  %spec.select33.2 = select i1 %cond8.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond9.2 = icmp eq i32 %169, 1
  %170 = select i1 %cond9.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select33.2, ptr nonnull %170, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select33.2, ptr nonnull %170, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %171 = add i32 %166, 1
  %172 = icmp sgt i32 %171, 1
  %173 = select i1 %172, i32 0, i32 %171
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %174 = add i32 %169, 1
  %175 = icmp sgt i32 %174, 1
  %176 = select i1 %175, i32 0, i32 %174
  %177 = or disjoint i64 %155, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond8.3 = icmp eq i32 %173, 1
  %spec.select33.3 = select i1 %cond8.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond9.3 = icmp eq i32 %176, 1
  %178 = select i1 %cond9.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select33.3, ptr nonnull %178, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select33.3, ptr nonnull %178, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %179 = add i32 %173, 1
  %180 = icmp sgt i32 %179, 1
  %181 = select i1 %180, i32 0, i32 %179
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %182 = add i32 %176, 1
  %183 = icmp sgt i32 %182, 1
  %184 = select i1 %183, i32 0, i32 %182
  %185 = add nuw nsw i64 %155, 4
  %186 = icmp samesign ult i64 %177, 31
  br i1 %186, label %152, label %187

187:                                              ; preds = %152
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %188

188:                                              ; preds = %188, %187
  %189 = phi i32 [ %184, %187 ], [ %220, %188 ]
  %190 = phi i32 [ %181, %187 ], [ %217, %188 ]
  %191 = phi i64 [ 0, %187 ], [ %221, %188 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond10 = icmp eq i32 %190, 1
  %spec.select34 = select i1 %cond10, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond11 = icmp eq i32 %189, 1
  %192 = select i1 %cond11, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select34, ptr nonnull %192, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select34, ptr nonnull %192, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %193 = add i32 %190, 1
  %194 = icmp sgt i32 %193, 1
  %195 = select i1 %194, i32 0, i32 %193
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %196 = add i32 %189, 1
  %197 = icmp sgt i32 %196, 1
  %198 = select i1 %197, i32 0, i32 %196
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond10.1 = icmp eq i32 %195, 1
  %spec.select34.1 = select i1 %cond10.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond11.1 = icmp eq i32 %198, 1
  %199 = select i1 %cond11.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select34.1, ptr nonnull %199, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select34.1, ptr nonnull %199, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %200 = add i32 %195, 1
  %201 = icmp sgt i32 %200, 1
  %202 = select i1 %201, i32 0, i32 %200
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %203 = add i32 %198, 1
  %204 = icmp sgt i32 %203, 1
  %205 = select i1 %204, i32 0, i32 %203
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond10.2 = icmp eq i32 %202, 1
  %spec.select34.2 = select i1 %cond10.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond11.2 = icmp eq i32 %205, 1
  %206 = select i1 %cond11.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select34.2, ptr nonnull %206, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select34.2, ptr nonnull %206, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %207 = add i32 %202, 1
  %208 = icmp sgt i32 %207, 1
  %209 = select i1 %208, i32 0, i32 %207
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %210 = add i32 %205, 1
  %211 = icmp sgt i32 %210, 1
  %212 = select i1 %211, i32 0, i32 %210
  %213 = or disjoint i64 %191, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond10.3 = icmp eq i32 %209, 1
  %spec.select34.3 = select i1 %cond10.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond11.3 = icmp eq i32 %212, 1
  %214 = select i1 %cond11.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select34.3, ptr nonnull %214, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select34.3, ptr nonnull %214, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %215 = add i32 %209, 1
  %216 = icmp sgt i32 %215, 1
  %217 = select i1 %216, i32 0, i32 %215
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %218 = add i32 %212, 1
  %219 = icmp sgt i32 %218, 1
  %220 = select i1 %219, i32 0, i32 %218
  %221 = add nuw nsw i64 %191, 4
  %222 = icmp samesign ult i64 %213, 31
  br i1 %222, label %188, label %223

223:                                              ; preds = %188
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %224

224:                                              ; preds = %224, %223
  %225 = phi i32 [ %220, %223 ], [ %256, %224 ]
  %226 = phi i32 [ %217, %223 ], [ %253, %224 ]
  %227 = phi i64 [ 0, %223 ], [ %257, %224 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond12 = icmp eq i32 %226, 1
  %spec.select35 = select i1 %cond12, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond13 = icmp eq i32 %225, 1
  %228 = select i1 %cond13, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select35, ptr nonnull %228, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select35, ptr nonnull %228, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %229 = add i32 %226, 1
  %230 = icmp sgt i32 %229, 1
  %231 = select i1 %230, i32 0, i32 %229
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %232 = add i32 %225, 1
  %233 = icmp sgt i32 %232, 1
  %234 = select i1 %233, i32 0, i32 %232
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond12.1 = icmp eq i32 %231, 1
  %spec.select35.1 = select i1 %cond12.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond13.1 = icmp eq i32 %234, 1
  %235 = select i1 %cond13.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select35.1, ptr nonnull %235, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select35.1, ptr nonnull %235, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %236 = add i32 %231, 1
  %237 = icmp sgt i32 %236, 1
  %238 = select i1 %237, i32 0, i32 %236
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %239 = add i32 %234, 1
  %240 = icmp sgt i32 %239, 1
  %241 = select i1 %240, i32 0, i32 %239
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond12.2 = icmp eq i32 %238, 1
  %spec.select35.2 = select i1 %cond12.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond13.2 = icmp eq i32 %241, 1
  %242 = select i1 %cond13.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select35.2, ptr nonnull %242, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select35.2, ptr nonnull %242, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %243 = add i32 %238, 1
  %244 = icmp sgt i32 %243, 1
  %245 = select i1 %244, i32 0, i32 %243
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %246 = add i32 %241, 1
  %247 = icmp sgt i32 %246, 1
  %248 = select i1 %247, i32 0, i32 %246
  %249 = or disjoint i64 %227, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond12.3 = icmp eq i32 %245, 1
  %spec.select35.3 = select i1 %cond12.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond13.3 = icmp eq i32 %248, 1
  %250 = select i1 %cond13.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select35.3, ptr nonnull %250, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select35.3, ptr nonnull %250, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %251 = add i32 %245, 1
  %252 = icmp sgt i32 %251, 1
  %253 = select i1 %252, i32 0, i32 %251
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %254 = add i32 %248, 1
  %255 = icmp sgt i32 %254, 1
  %256 = select i1 %255, i32 0, i32 %254
  %257 = add nuw nsw i64 %227, 4
  %258 = icmp samesign ult i64 %249, 31
  br i1 %258, label %224, label %259

259:                                              ; preds = %224
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %260

260:                                              ; preds = %260, %259
  %261 = phi i32 [ %256, %259 ], [ %292, %260 ]
  %262 = phi i32 [ %253, %259 ], [ %289, %260 ]
  %263 = phi i64 [ 0, %259 ], [ %293, %260 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond14 = icmp eq i32 %262, 1
  %spec.select36 = select i1 %cond14, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond15 = icmp eq i32 %261, 1
  %264 = select i1 %cond15, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select36, ptr nonnull %264, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select36, ptr nonnull %264, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %265 = add i32 %262, 1
  %266 = icmp sgt i32 %265, 1
  %267 = select i1 %266, i32 0, i32 %265
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %268 = add i32 %261, 1
  %269 = icmp sgt i32 %268, 1
  %270 = select i1 %269, i32 0, i32 %268
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond14.1 = icmp eq i32 %267, 1
  %spec.select36.1 = select i1 %cond14.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond15.1 = icmp eq i32 %270, 1
  %271 = select i1 %cond15.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select36.1, ptr nonnull %271, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select36.1, ptr nonnull %271, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %272 = add i32 %267, 1
  %273 = icmp sgt i32 %272, 1
  %274 = select i1 %273, i32 0, i32 %272
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %275 = add i32 %270, 1
  %276 = icmp sgt i32 %275, 1
  %277 = select i1 %276, i32 0, i32 %275
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond14.2 = icmp eq i32 %274, 1
  %spec.select36.2 = select i1 %cond14.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond15.2 = icmp eq i32 %277, 1
  %278 = select i1 %cond15.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select36.2, ptr nonnull %278, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select36.2, ptr nonnull %278, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %279 = add i32 %274, 1
  %280 = icmp sgt i32 %279, 1
  %281 = select i1 %280, i32 0, i32 %279
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %282 = add i32 %277, 1
  %283 = icmp sgt i32 %282, 1
  %284 = select i1 %283, i32 0, i32 %282
  %285 = or disjoint i64 %263, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond14.3 = icmp eq i32 %281, 1
  %spec.select36.3 = select i1 %cond14.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond15.3 = icmp eq i32 %284, 1
  %286 = select i1 %cond15.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select36.3, ptr nonnull %286, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select36.3, ptr nonnull %286, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %287 = add i32 %281, 1
  %288 = icmp sgt i32 %287, 1
  %289 = select i1 %288, i32 0, i32 %287
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %290 = add i32 %284, 1
  %291 = icmp sgt i32 %290, 1
  %292 = select i1 %291, i32 0, i32 %290
  %293 = add nuw nsw i64 %263, 4
  %294 = icmp samesign ult i64 %285, 31
  br i1 %294, label %260, label %295

295:                                              ; preds = %260
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %296

296:                                              ; preds = %296, %295
  %297 = phi i32 [ %292, %295 ], [ %328, %296 ]
  %298 = phi i32 [ %289, %295 ], [ %325, %296 ]
  %299 = phi i64 [ 0, %295 ], [ %329, %296 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond16 = icmp eq i32 %298, 1
  %spec.select37 = select i1 %cond16, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond17 = icmp eq i32 %297, 1
  %300 = select i1 %cond17, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select37, ptr nonnull %300, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select37, ptr nonnull %300, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %301 = add i32 %298, 1
  %302 = icmp sgt i32 %301, 1
  %303 = select i1 %302, i32 0, i32 %301
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %304 = add i32 %297, 1
  %305 = icmp sgt i32 %304, 1
  %306 = select i1 %305, i32 0, i32 %304
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond16.1 = icmp eq i32 %303, 1
  %spec.select37.1 = select i1 %cond16.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond17.1 = icmp eq i32 %306, 1
  %307 = select i1 %cond17.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select37.1, ptr nonnull %307, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select37.1, ptr nonnull %307, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %308 = add i32 %303, 1
  %309 = icmp sgt i32 %308, 1
  %310 = select i1 %309, i32 0, i32 %308
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %311 = add i32 %306, 1
  %312 = icmp sgt i32 %311, 1
  %313 = select i1 %312, i32 0, i32 %311
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond16.2 = icmp eq i32 %310, 1
  %spec.select37.2 = select i1 %cond16.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond17.2 = icmp eq i32 %313, 1
  %314 = select i1 %cond17.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select37.2, ptr nonnull %314, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select37.2, ptr nonnull %314, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %315 = add i32 %310, 1
  %316 = icmp sgt i32 %315, 1
  %317 = select i1 %316, i32 0, i32 %315
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %318 = add i32 %313, 1
  %319 = icmp sgt i32 %318, 1
  %320 = select i1 %319, i32 0, i32 %318
  %321 = or disjoint i64 %299, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond16.3 = icmp eq i32 %317, 1
  %spec.select37.3 = select i1 %cond16.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond17.3 = icmp eq i32 %320, 1
  %322 = select i1 %cond17.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select37.3, ptr nonnull %322, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select37.3, ptr nonnull %322, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %323 = add i32 %317, 1
  %324 = icmp sgt i32 %323, 1
  %325 = select i1 %324, i32 0, i32 %323
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %326 = add i32 %320, 1
  %327 = icmp sgt i32 %326, 1
  %328 = select i1 %327, i32 0, i32 %326
  %329 = add nuw nsw i64 %299, 4
  %330 = icmp samesign ult i64 %321, 31
  br i1 %330, label %296, label %331

331:                                              ; preds = %296
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc0_0_0)
  tail call void @w4a16_prefill_reuse_init(ptr nonnull @direct_acc1_0_0)
  br label %332

332:                                              ; preds = %332, %331
  %333 = phi i32 [ %328, %331 ], [ %364, %332 ]
  %334 = phi i32 [ %325, %331 ], [ %361, %332 ]
  %335 = phi i64 [ 0, %331 ], [ %365, %332 ]
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond18 = icmp eq i32 %334, 1
  %spec.select38 = select i1 %cond18, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond19 = icmp eq i32 %333, 1
  %336 = select i1 %cond19, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select38, ptr nonnull %336, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select38, ptr nonnull %336, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %337 = add i32 %334, 1
  %338 = icmp sgt i32 %337, 1
  %339 = select i1 %338, i32 0, i32 %337
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %340 = add i32 %333, 1
  %341 = icmp sgt i32 %340, 1
  %342 = select i1 %341, i32 0, i32 %340
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond18.1 = icmp eq i32 %339, 1
  %spec.select38.1 = select i1 %cond18.1, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond19.1 = icmp eq i32 %342, 1
  %343 = select i1 %cond19.1, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select38.1, ptr nonnull %343, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select38.1, ptr nonnull %343, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %344 = add i32 %339, 1
  %345 = icmp sgt i32 %344, 1
  %346 = select i1 %345, i32 0, i32 %344
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %347 = add i32 %342, 1
  %348 = icmp sgt i32 %347, 1
  %349 = select i1 %348, i32 0, i32 %347
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond18.2 = icmp eq i32 %346, 1
  %spec.select38.2 = select i1 %cond18.2, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond19.2 = icmp eq i32 %349, 1
  %350 = select i1 %cond19.2, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select38.2, ptr nonnull %350, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select38.2, ptr nonnull %350, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %351 = add i32 %346, 1
  %352 = icmp sgt i32 %351, 1
  %353 = select i1 %352, i32 0, i32 %351
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %354 = add i32 %349, 1
  %355 = icmp sgt i32 %354, 1
  %356 = select i1 %355, i32 0, i32 %354
  %357 = or disjoint i64 %335, 3
  tail call void @llvm.aie2p.acquire(i32 53, i32 -1)
  %cond18.3 = icmp eq i32 %353, 1
  %spec.select38.3 = select i1 %cond18.3, ptr @direct_a_broadcast_0_0_cons_buff_1, ptr @direct_a_broadcast_0_0_cons_buff_0
  tail call void @llvm.aie2p.acquire(i32 49, i32 -1)
  %cond19.3 = icmp eq i32 %356, 1
  %358 = select i1 %cond19.3, ptr @direct_w_broadcast_0_0_cons_buff_1, ptr @direct_w_broadcast_0_0_cons_buff_0
  tail call void @w4a16_prefill_reuse_accumulate_low(ptr nonnull %spec.select38.3, ptr nonnull %358, ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @w4a16_prefill_reuse_accumulate_high(ptr nonnull %spec.select38.3, ptr nonnull %358, ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_dequant_0_0)
  tail call void @llvm.aie2p.release(i32 52, i32 1)
  %359 = add i32 %353, 1
  %360 = icmp sgt i32 %359, 1
  %361 = select i1 %360, i32 0, i32 %359
  tail call void @llvm.aie2p.release(i32 48, i32 1)
  %362 = add i32 %356, 1
  %363 = icmp sgt i32 %362, 1
  %364 = select i1 %363, i32 0, i32 %362
  %365 = add nuw nsw i64 %335, 4
  %366 = icmp samesign ult i64 %357, 31
  br i1 %366, label %332, label %367

367:                                              ; preds = %332
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc0_0_0, ptr nonnull @direct_gate_0_0_buff_0)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  tail call void @llvm.aie2p.acquire(i32 50, i32 -1)
  tail call void @w4a16_prefill_reuse_finish(ptr nonnull @direct_acc1_0_0, ptr nonnull @direct_gate_0_0_buff_1)
  tail call void @llvm.aie2p.release(i32 51, i32 1)
  %368 = add nuw nsw i64 %7, 1
  %369 = icmp samesign ult i64 %7, 3
  br i1 %369, label %4, label %370

370:                                              ; preds = %367
  %371 = add nuw nsw i64 %3, 1
  %.not = icmp eq i64 %371, 9223372036854775807
  br i1 %.not, label %372, label %.preheader

372:                                              ; preds = %370
  ret void
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
